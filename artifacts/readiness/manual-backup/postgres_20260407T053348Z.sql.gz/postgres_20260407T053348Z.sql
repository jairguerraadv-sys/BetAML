--
-- PostgreSQL database dump
--

\restrict jXqiBorBcIYkIV1mdT62bi59sfLliKFPuQTtipMCeWmbdUiZYfGDBQi0UkYmpiQ

-- Dumped from database version 16.13
-- Dumped by pg_dump version 16.13

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: current_tenant_id(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.current_tenant_id() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
    SELECT NULLIF(current_setting('app.current_tenant', TRUE), '')::UUID;
$$;


--
-- Name: prevent_audit_log_mutation(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.prevent_audit_log_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION 'audit_logs is immutable: operation % is not allowed', TG_OP;
END;
$$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    rule_id uuid,
    alert_type text DEFAULT 'RULE'::text NOT NULL,
    severity text NOT NULL,
    status text DEFAULT 'OPEN'::text NOT NULL,
    title text NOT NULL,
    description text,
    evidence jsonb DEFAULT '{}'::jsonb NOT NULL,
    anomaly_score numeric(5,4),
    source_event_id text,
    case_id uuid,
    triaged_by uuid,
    triaged_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    label text,
    labeled_by uuid,
    labeled_at timestamp with time zone,
    rule_weight numeric(4,3) DEFAULT 0.4,
    ml_weight numeric(4,3) DEFAULT 0.4,
    network_weight numeric(4,3) DEFAULT 0.2,
    composite_score numeric(5,4),
    score_breakdown jsonb DEFAULT '{}'::jsonb,
    compound_rule_id uuid,
    label_note text,
    ingest_mode character varying(20) DEFAULT 'incremental'::character varying NOT NULL,
    backfill_job_id text,
    CONSTRAINT alerts_alert_type_check CHECK ((alert_type = ANY (ARRAY['RULE'::text, 'ANOMALY'::text, 'COMPOSITE'::text]))),
    CONSTRAINT alerts_label_check CHECK ((label = ANY (ARRAY['TRUE_POSITIVE'::text, 'FALSE_POSITIVE'::text, 'UNKNOWN'::text]))),
    CONSTRAINT alerts_severity_check CHECK ((severity = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text, 'CRITICAL'::text]))),
    CONSTRAINT alerts_status_check CHECK ((status = ANY (ARRAY['OPEN'::text, 'IN_REVIEW'::text, 'CLOSED'::text, 'FALSE_POSITIVE'::text])))
);

ALTER TABLE ONLY public.alerts FORCE ROW LEVEL SECURITY;


--
-- Name: COLUMN alerts.backfill_job_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.alerts.backfill_job_id IS 'ID do IngestJob de backfill/reprocess que originou este alerta. Preenchido quando ingest_mode IN (''backfill'', ''reprocess'').';


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    key_hash text NOT NULL,
    key_prefix text NOT NULL,
    source_system text,
    permissions jsonb DEFAULT '["ingest"]'::jsonb NOT NULL,
    active boolean DEFAULT true NOT NULL,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_by uuid,
    revoked_by uuid,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.api_keys FORCE ROW LEVEL SECURITY;


--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text,
    before jsonb,
    after jsonb,
    ip_address text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    pii_accessed text
);

ALTER TABLE ONLY public.audit_logs FORCE ROW LEVEL SECURITY;


--
-- Name: COLUMN audit_logs.pii_accessed; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.audit_logs.pii_accessed IS 'Campo de PII acessado — cpf, cpf_masked, full_name, etc. (LGPD Art. 37 rastreabilidade)';


--
-- Name: bets; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.bets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    external_bet_id text,
    source_system text NOT NULL,
    bet_type text DEFAULT 'SPORTS'::text NOT NULL,
    stake_amount numeric(15,2) NOT NULL,
    potential_payout numeric(15,2),
    actual_payout numeric(15,2),
    odds numeric(10,4),
    currency text DEFAULT 'BRL'::text NOT NULL,
    status text DEFAULT 'OPEN'::text NOT NULL,
    event_name text,
    market_name text,
    selection_name text,
    source_event_id text,
    ingest_job_id uuid,
    raw_payload jsonb DEFAULT '{}'::jsonb,
    occurred_at timestamp with time zone NOT NULL,
    settled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    product_type text DEFAULT 'SPORTSBOOK'::text NOT NULL,
    game_id text,
    game_name text,
    game_provider text,
    game_category text,
    rtp_teorico numeric(6,4)
);


--
-- Name: case_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.case_events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    case_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    event_type text NOT NULL,
    content jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT case_events_event_type_check CHECK ((event_type = ANY (ARRAY['NOTE'::text, 'STATUS_CHANGE'::text, 'EVIDENCE_UPLOAD'::text, 'ASSIGNMENT'::text, 'REPORT_GENERATED'::text, 'REPORT_SUBMITTED'::text])))
);

ALTER TABLE ONLY public.case_events FORCE ROW LEVEL SECURITY;


--
-- Name: cases; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.cases (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    title text NOT NULL,
    description text,
    status text DEFAULT 'OPEN'::text NOT NULL,
    severity text DEFAULT 'HIGH'::text NOT NULL,
    assigned_to uuid,
    created_by uuid,
    closed_by uuid,
    closed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    reference_number text,
    sla_due_at timestamp with time zone,
    priority text DEFAULT 'MEDIUM'::text,
    auto_created boolean DEFAULT false NOT NULL,
    auto_created_reason text,
    source_alert_id uuid,
    backfill_job_id text,
    ingest_mode character varying(20) DEFAULT 'incremental'::character varying NOT NULL,
    CONSTRAINT cases_priority_check CHECK ((priority = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text, 'CRITICAL'::text]))),
    CONSTRAINT cases_severity_check CHECK ((severity = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text, 'CRITICAL'::text]))),
    CONSTRAINT cases_status_check CHECK ((status = ANY (ARRAY['OPEN'::text, 'INVESTIGATING'::text, 'PENDING_REVIEW'::text, 'CLOSED'::text, 'REPORTED'::text])))
);

ALTER TABLE ONLY public.cases FORCE ROW LEVEL SECURITY;


--
-- Name: COLUMN cases.backfill_job_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.cases.backfill_job_id IS 'ID do IngestJob de backfill/reprocess que originou este caso automaticamente.';


--
-- Name: compound_rules; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.compound_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    n_threshold integer,
    severity_mode text DEFAULT 'MAX'::text NOT NULL,
    fixed_severity text,
    version integer DEFAULT 1 NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    logic text,
    component_rule_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    score_weights jsonb DEFAULT '{}'::jsonb NOT NULL,
    min_score_threshold numeric(5,4),
    CONSTRAINT compound_rules_fixed_severity_check CHECK ((fixed_severity = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text, 'CRITICAL'::text]))),
    CONSTRAINT compound_rules_severity_mode_check CHECK ((severity_mode = ANY (ARRAY['MAX'::text, 'MIN'::text, 'FIXED'::text]))),
    CONSTRAINT compound_rules_status_check CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'INACTIVE'::text, 'DRAFT'::text])))
);

ALTER TABLE ONLY public.compound_rules FORCE ROW LEVEL SECURITY;


--
-- Name: device_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.device_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    external_evt_id text,
    source_system text NOT NULL,
    action text NOT NULL,
    device_id text,
    device_type text,
    device_hash text,
    ip_address text,
    ip_hash text,
    country_code text,
    user_agent text,
    session_id text,
    source_event_id text,
    ingest_job_id uuid,
    raw_payload jsonb DEFAULT '{}'::jsonb,
    occurred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: external_validation_requests; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.external_validation_requests (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid NOT NULL,
    provider character varying(40) NOT NULL,
    validation_type character varying(40) NOT NULL,
    status character varying(20) NOT NULL,
    request_payload jsonb NOT NULL,
    response_payload jsonb,
    external_request_id text,
    error_message text,
    requested_by uuid,
    requested_at timestamp with time zone DEFAULT now(),
    completed_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now()
);


--
-- Name: feature_snapshots; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.feature_snapshots (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid NOT NULL,
    feature_date date NOT NULL,
    features jsonb DEFAULT '{}'::jsonb NOT NULL,
    drift_score numeric(5,4),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    snapshot_date date,
    feature_version integer DEFAULT 2 NOT NULL
);

ALTER TABLE ONLY public.feature_snapshots FORCE ROW LEVEL SECURITY;


--
-- Name: financial_transactions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.financial_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    external_tx_id text,
    source_system text NOT NULL,
    type text NOT NULL,
    amount numeric(15,2) NOT NULL,
    currency text DEFAULT 'BRL'::text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    payment_method text,
    payment_instrument text,
    bank_account_hash text,
    source_event_id text,
    ingest_job_id uuid,
    raw_payload jsonb DEFAULT '{}'::jsonb,
    occurred_at timestamp with time zone NOT NULL,
    settled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    payment_method_flagged boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_payment_method CHECK ((payment_method = ANY (ARRAY['PIX'::text, 'TED'::text, 'DEBIT'::text, 'CARD_DEBIT'::text, 'CARD_CREDIT'::text, 'WALLET'::text, 'OTHER'::text, 'CARD'::text]))),
    CONSTRAINT chk_transaction_type CHECK ((type = ANY (ARRAY['DEPOSIT'::text, 'WITHDRAWAL'::text, 'REVERSAL'::text, 'BONUS'::text, 'FREE_BET'::text, 'CASHOUT'::text, 'ADJUSTMENT'::text, 'CHARGEBACK'::text])))
);


--
-- Name: ingest_errors; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingest_errors (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    ingest_job_id uuid,
    source_system text NOT NULL,
    entity_type text,
    raw_payload text NOT NULL,
    error_reason text NOT NULL,
    error_detail jsonb DEFAULT '{}'::jsonb NOT NULL,
    line_number integer,
    resolved boolean DEFAULT false NOT NULL,
    resolved_by uuid,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.ingest_errors FORCE ROW LEVEL SECURITY;


--
-- Name: ingest_jobs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.ingest_jobs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    source_system text NOT NULL,
    mapping_config_id uuid,
    file_name text,
    file_size_bytes bigint,
    file_path text,
    status text DEFAULT 'QUEUED'::text NOT NULL,
    total_records integer,
    processed_records integer DEFAULT 0,
    failed_records integer DEFAULT 0,
    error_message text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    bytes_processed bigint DEFAULT 0,
    duration_ms bigint,
    error_sample jsonb DEFAULT '[]'::jsonb,
    connector_type text DEFAULT 'FILE'::text,
    reprocessed_from uuid,
    mapping_version_id uuid,
    ingest_mode character varying(20) DEFAULT 'incremental'::character varying NOT NULL,
    is_backfill boolean DEFAULT false NOT NULL,
    CONSTRAINT ingest_jobs_connector_type_check CHECK ((connector_type = ANY (ARRAY['FILE'::text, 'WEBHOOK'::text, 'WEBSOCKET'::text, 'NDJSON'::text, 'XML'::text]))),
    CONSTRAINT ingest_jobs_status_check CHECK ((status = ANY (ARRAY['QUEUED'::text, 'PROCESSING'::text, 'DONE'::text, 'FAILED'::text, 'PARTIAL'::text])))
);

ALTER TABLE ONLY public.ingest_jobs FORCE ROW LEVEL SECURITY;


--
-- Name: mapping_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.mapping_configs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    source_system text NOT NULL,
    entity_type text NOT NULL,
    version text DEFAULT '1.0'::text NOT NULL,
    config_json jsonb NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    parent_id uuid,
    is_current boolean DEFAULT true NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    change_notes text
);

ALTER TABLE ONLY public.mapping_configs FORCE ROW LEVEL SECURITY;


--
-- Name: model_inference_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_inference_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    model_id uuid,
    model_variant text NOT NULL,
    anomaly_score numeric(5,4) NOT NULL,
    is_anomaly boolean DEFAULT false NOT NULL,
    request_id text,
    scored_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.model_inference_logs FORCE ROW LEVEL SECURITY;


--
-- Name: model_registry; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.model_registry (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    model_name text NOT NULL,
    model_version text NOT NULL,
    algorithm text NOT NULL,
    dataset_window_days integer,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    trained_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    model_type text DEFAULT 'ANOMALY'::text,
    status text DEFAULT 'STAGING'::text,
    dataset_window_start timestamp with time zone,
    dataset_window_end timestamp with time zone,
    promoted_by uuid,
    promoted_at timestamp with time zone,
    is_challenger boolean DEFAULT false,
    champion_id uuid,
    artifact_uri text,
    is_active boolean DEFAULT false NOT NULL,
    training_rows integer,
    trained_by text,
    feature_columns jsonb DEFAULT '[]'::jsonb,
    CONSTRAINT model_registry_model_type_check CHECK ((model_type = ANY (ARRAY['ANOMALY'::text, 'STRUCTURING'::text, 'NETWORK'::text, 'RECURRENCE'::text]))),
    CONSTRAINT model_registry_status_check CHECK ((status = ANY (ARRAY['STAGING'::text, 'PRODUCTION'::text, 'ARCHIVED'::text])))
);


--
-- Name: notifications; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.notifications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    body text,
    entity_type text,
    entity_id text,
    read boolean DEFAULT false NOT NULL,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    reference_type text,
    reference_id text,
    CONSTRAINT notifications_type_check CHECK ((type = ANY (ARRAY['ALERT_CRITICAL'::text, 'CASE_ASSIGNED'::text, 'SLA_WARNING'::text, 'MODEL_DRIFT'::text, 'FEATURE_DRIFT'::text, 'DLQ_PENDING'::text, 'MENTION'::text, 'SYSTEM'::text])))
);

ALTER TABLE ONLY public.notifications FORCE ROW LEVEL SECURITY;


--
-- Name: player_kyc_events; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_kyc_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id text NOT NULL,
    entity_type character varying(40) NOT NULL,
    subtype character varying(60) NOT NULL,
    provider text,
    document_type text,
    pep_flag boolean DEFAULT false NOT NULL,
    income_declared numeric(18,2),
    exclusion_source text,
    exclusion_scope text,
    exclusion_duration_days integer,
    old_deposit_limit numeric(18,2),
    new_deposit_limit numeric(18,2),
    previous_status text,
    new_status text,
    reason text,
    ingest_mode character varying(20) DEFAULT 'incremental'::character varying NOT NULL,
    backfill_job_id text,
    occurred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: TABLE player_kyc_events; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON TABLE public.player_kyc_events IS 'Eventos de ciclo de vida do player: KYC, jogo responsável (auto-exclusão SIGAP/operador) e alterações de status. Portaria SPA/MF 1.143/2024.';


--
-- Name: player_list_entries; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_list_entries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    list_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    external_player_id text,
    cpf_hash text,
    notes text,
    added_by uuid,
    added_at timestamp with time zone DEFAULT now() NOT NULL,
    value text,
    value_type text,
    player_list_id uuid
);

ALTER TABLE ONLY public.player_list_entries FORCE ROW LEVEL SECURITY;


--
-- Name: player_lists; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.player_lists (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    list_type text NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL,
    source text DEFAULT 'MANUAL'::text NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT player_lists_list_type_check CHECK ((list_type = ANY (ARRAY['WHITELIST'::text, 'BLACKLIST'::text, 'WATCH_LIST'::text, 'CUSTOM'::text]))),
    CONSTRAINT player_lists_source_check CHECK ((source = ANY (ARRAY['MANUAL'::text, 'AUTO'::text, 'INTEGRATION'::text])))
);

ALTER TABLE ONLY public.player_lists FORCE ROW LEVEL SECURITY;


--
-- Name: players; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.players (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    external_player_id text NOT NULL,
    cpf_encrypted bytea NOT NULL,
    name_encrypted bytea NOT NULL,
    birth_date date,
    pep_flag boolean DEFAULT false NOT NULL,
    declared_income_monthly numeric(15,2),
    profession text,
    risk_score numeric(5,4) DEFAULT 0.0 NOT NULL,
    last_scored_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    registered_since date,
    status text DEFAULT 'ACTIVE'::text,
    external_id text,
    risk_band text DEFAULT 'LOW'::text NOT NULL,
    cpf_hmac character varying(64),
    self_exclusion_flag boolean DEFAULT false NOT NULL,
    deposit_limit_daily numeric(15,2),
    features jsonb DEFAULT '{}'::jsonb NOT NULL,
    cluster_id integer,
    cluster_size integer DEFAULT 0 NOT NULL,
    CONSTRAINT chk_player_status CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'INACTIVE'::text, 'BLOCKED'::text, 'ERASED'::text, 'PENDING_REVIEW'::text, 'WATCHLIST'::text]))),
    CONSTRAINT players_risk_band_check CHECK ((risk_band = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text])))
);

ALTER TABLE ONLY public.players FORCE ROW LEVEL SECURITY;


--
-- Name: COLUMN players.self_exclusion_flag; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.players.self_exclusion_flag IS 'Apostador com autoexclusão ativa no SIGAP — apostas devem ser bloqueadas (Portaria 1.231/2024)';


--
-- Name: COLUMN players.deposit_limit_daily; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.players.deposit_limit_daily IS 'Limite de depósito diário declarado voluntariamente pelo apostador durante KYC';


--
-- Name: COLUMN players.features; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.players.features IS 'JSONB com features ML calculadas pelo ML Trainer (anomaly_score, recurrence_score, network features etc.)';


--
-- Name: COLUMN players.cluster_id; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.players.cluster_id IS 'ID do cluster DBSCAN detectado pelo network_clustering. NULL = sem cluster.';


--
-- Name: COLUMN players.cluster_size; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.players.cluster_size IS 'Tamanho do cluster de rede ao qual o player pertence. 0 = isolado.';


--
-- Name: report_packages; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.report_packages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    case_id uuid NOT NULL,
    player_id uuid,
    payload jsonb NOT NULL,
    format text DEFAULT 'JSON'::text NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    pdf_path text,
    status text DEFAULT 'DRAFT'::text,
    analyst_narrative text,
    decision text,
    CONSTRAINT report_packages_decision_check CHECK ((decision = ANY (ARRAY['REPORT'::text, 'CLOSE'::text, 'MONITOR'::text]))),
    CONSTRAINT report_packages_format_check CHECK ((format = ANY (ARRAY['JSON'::text, 'CSV'::text]))),
    CONSTRAINT report_packages_status_check CHECK ((status = ANY (ARRAY['DRAFT'::text, 'FINAL'::text, 'PENDING_REVIEW'::text, 'FILED'::text, 'REJECTED'::text, 'ARCHIVED'::text])))
);

ALTER TABLE ONLY public.report_packages FORCE ROW LEVEL SECURITY;


--
-- Name: rule_definitions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rule_definitions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    severity text DEFAULT 'MEDIUM'::text NOT NULL,
    scope text DEFAULT 'TRANSACTION'::text NOT NULL,
    condition_dsl text NOT NULL,
    params jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    weight numeric(4,3) DEFAULT 0.5 NOT NULL,
    CONSTRAINT rule_definitions_scope_check CHECK ((scope = ANY (ARRAY['TRANSACTION'::text, 'BET'::text, 'PLAYER'::text, 'DEVICE_EVENT'::text]))),
    CONSTRAINT rule_definitions_severity_check CHECK ((severity = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text, 'CRITICAL'::text]))),
    CONSTRAINT rule_definitions_status_check CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'INACTIVE'::text, 'DRAFT'::text])))
);

ALTER TABLE ONLY public.rule_definitions FORCE ROW LEVEL SECURITY;


--
-- Name: rule_execution_logs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rule_execution_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    rule_id uuid NOT NULL,
    rule_version integer NOT NULL,
    source_event_id text NOT NULL,
    player_id uuid,
    matched boolean NOT NULL,
    evaluation_ms integer,
    context_snapshot jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: rule_macros; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.rule_macros (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    body_dsl text NOT NULL,
    description text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: schema_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.schema_migrations (
    filename text NOT NULL,
    checksum text NOT NULL,
    applied_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: scoring_configs; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.scoring_configs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    rule_weight numeric(4,3) DEFAULT 0.4 NOT NULL,
    ml_weight numeric(4,3) DEFAULT 0.4 NOT NULL,
    network_weight numeric(4,3) DEFAULT 0.2 NOT NULL,
    auto_case_threshold numeric(5,4) DEFAULT 0.75 NOT NULL,
    sla_critical_hours integer DEFAULT 4 NOT NULL,
    sla_high_hours integer DEFAULT 24 NOT NULL,
    sla_medium_hours integer DEFAULT 72 NOT NULL,
    sla_low_hours integer DEFAULT 168 NOT NULL,
    ingest_rate_limit_tpm integer DEFAULT 1000 NOT NULL,
    data_retention_raw_years integer DEFAULT 5 NOT NULL,
    data_retention_silver_years integer DEFAULT 5 NOT NULL,
    data_retention_gold_years integer DEFAULT 3 NOT NULL,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    risk_band_low_threshold numeric(5,4) DEFAULT 0.35 NOT NULL,
    risk_band_high_threshold numeric(5,4) DEFAULT 0.70 NOT NULL,
    income_volume_ratio_threshold numeric(5,2) DEFAULT 1.50 NOT NULL,
    low_threshold numeric(5,2) DEFAULT 30.0 NOT NULL,
    medium_threshold numeric(5,2) DEFAULT 60.0 NOT NULL,
    high_threshold numeric(5,2) DEFAULT 80.0 NOT NULL,
    critical_threshold numeric(5,2) DEFAULT 95.0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    data_retention_days integer DEFAULT 1825 NOT NULL,
    ml_challenger_pct integer DEFAULT 0 NOT NULL
);

ALTER TABLE ONLY public.scoring_configs FORCE ROW LEVEL SECURITY;


--
-- Name: system_flags; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.system_flags (
    key text NOT NULL,
    value jsonb DEFAULT 'null'::jsonb NOT NULL,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


--
-- Name: tenants; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.tenants (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    risk_score_threshold numeric(5,2) DEFAULT 0.75 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    cnpj character varying(14),
    plan_tier character varying(20) DEFAULT 'standard'::character varying NOT NULL,
    CONSTRAINT tenants_plan_tier_check CHECK (((plan_tier)::text = ANY ((ARRAY['starter'::character varying, 'standard'::character varying, 'professional'::character varying, 'enterprise'::character varying])::text[])))
);

ALTER TABLE ONLY public.tenants FORCE ROW LEVEL SECURITY;


--
-- Name: COLUMN tenants.cnpj; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.tenants.cnpj IS 'CNPJ do operador (14 dígitos sem pontuação) — obrigatório para geração de XML COAF (MIFD v3)';


--
-- Name: users; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    role character varying(50) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    refresh_token_jti text,
    roles jsonb DEFAULT '[]'::jsonb,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY (ARRAY['ADMIN'::text, 'AML_ANALYST'::text, 'AUDITOR'::text])))
);


--
-- Name: COLUMN users.refresh_token_jti; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON COLUMN public.users.refresh_token_jti IS 'JTI do refresh token ativo (rotacionado a cada /auth/refresh, NULL quando revogado no logout)';


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.alerts (id, tenant_id, player_id, rule_id, alert_type, severity, status, title, description, evidence, anomaly_score, source_event_id, case_id, triaged_by, triaged_at, created_at, updated_at, label, labeled_by, labeled_at, rule_weight, ml_weight, network_weight, composite_score, score_breakdown, compound_rule_id, label_note, ingest_mode, backfill_job_id) FROM stdin;
fc0d197d-f78c-45af-96a5-36d9e16277a2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	4633153f-6cca-40b2-b0f7-30df770677ec	\N	RULE	HIGH	OPEN	Structuring detectado — EXT-OPERADOR_A-001	8 depósitos de R$900 em 24h (total R$7.200)	{"triggered_at": "2026-04-04T09:08:16.838197+00:00", "threshold_sum": 5000, "deposit_sum_24h": 7200, "threshold_count": 5, "deposit_count_24h": 8}	\N	73f6d8bc-9cc0-44f7-9bf2-059559d4f720	\N	\N	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
a46e9188-2dd8-40eb-ae5f-f2390e0d8dd7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	CRITICAL	OPEN	PEP com depósito acima do threshold — EXT-OPERADOR_A-002	Jogador PEP depositou R$15.000 (acima do threshold de R$5.000)	{"amount": 15000, "pep_flag": true, "threshold": 5000, "triggered_at": "2026-04-04T09:08:16.838299+00:00"}	\N	f528cf58-2adb-4292-bcb0-0f2201d25eb0	\N	\N	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
2cdcd699-09ef-44ea-bd97-37c1876d6977	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	d5bcf2ee-3cce-4588-b12f-fac85a059270	\N	RULE	HIGH	OPEN	Múltiplos CPFs no mesmo device — EXT-OPERADOR_A-003	Device dev-shared-001 associado a 5 CPFs distintos	{"device_id": "dev-shared-001", "threshold": 3, "triggered_at": "2026-04-04T09:08:16.838354+00:00", "shared_device_count": 5}	\N	f3ebbdd0-26f0-44b5-bf4a-9f37ff57d10e	\N	\N	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
258e1ad4-2dbf-4be4-936d-dd3e9b0dd6bb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	144de474-f551-4a16-9497-cc9307d98461	\N	COMPOSITE	CRITICAL	OPEN	Round-tripping detectado — EXT-OPERADOR_A-004	Depósito R$20.000 → aposta R$20 → saque R$19.500 em 2h	{"ratio": 0.975, "triggered_at": "2026-04-04T09:08:16.838394+00:00", "deposit_sum_24h": 20000, "bet_stake_sum_24h": 20, "withdrawal_sum_24h": 19500}	0.9100	426080d9-6ed9-4bd6-b8af-085fcb55e0ab	5c7eac24-5048-4f59-877d-c398a522a6ca	\N	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
533d3bcd-7f0d-489c-a52c-3dcbcd5d3ea6	40e341ad-cf4a-484b-9926-3d56cc58fa1f	28468030-6f88-44de-b31b-f628e9a6011d	\N	RULE	HIGH	OPEN	Structuring detectado — EXT-OPERADOR_B-001	8 depósitos de R$900 em 24h (total R$7.200)	{"triggered_at": "2026-04-04T09:08:17.676399+00:00", "threshold_sum": 5000, "deposit_sum_24h": 7200, "threshold_count": 5, "deposit_count_24h": 8}	\N	11caadea-2043-4b6d-810c-7cc4bce36b83	\N	\N	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
06207492-ce4f-4ddf-9123-6cec094443cd	40e341ad-cf4a-484b-9926-3d56cc58fa1f	adf6f239-4e9c-4649-9bec-8dd930aaca18	\N	RULE	CRITICAL	OPEN	PEP com depósito acima do threshold — EXT-OPERADOR_B-002	Jogador PEP depositou R$15.000 (acima do threshold de R$5.000)	{"amount": 15000, "pep_flag": true, "threshold": 5000, "triggered_at": "2026-04-04T09:08:17.676543+00:00"}	\N	74bf4c09-842d-4e39-806b-d3d5cd03c162	\N	\N	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
9ff6e703-b4e6-4fc3-9b26-f8c24fce88f7	40e341ad-cf4a-484b-9926-3d56cc58fa1f	3deb2da5-9d7b-4ebf-8a28-ead586a31793	\N	RULE	HIGH	OPEN	Múltiplos CPFs no mesmo device — EXT-OPERADOR_B-003	Device dev-shared-001 associado a 5 CPFs distintos	{"device_id": "dev-shared-001", "threshold": 3, "triggered_at": "2026-04-04T09:08:17.676595+00:00", "shared_device_count": 5}	\N	07a1a300-abc3-454f-a314-2f1b28b130ed	\N	\N	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
0f308c45-b230-49f6-bd6d-cb23ddb54340	40e341ad-cf4a-484b-9926-3d56cc58fa1f	80fbe818-191f-4c2d-9472-18ec2429d42f	\N	COMPOSITE	CRITICAL	OPEN	Round-tripping detectado — EXT-OPERADOR_B-004	Depósito R$20.000 → aposta R$20 → saque R$19.500 em 2h	{"ratio": 0.975, "triggered_at": "2026-04-04T09:08:17.676641+00:00", "deposit_sum_24h": 20000, "bet_stake_sum_24h": 20, "withdrawal_sum_24h": 19500}	0.9100	242de573-d4b7-4f55-a169-097b2fdfa7de	db2af615-083f-4ffb-bd53-e05d9ce4cfb2	\N	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
7b1f7343-0712-4d14-ab23-484802b6eae7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E triage alert 1775531374481	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775531374524", "created_at": "2026-04-07T03:09:34.533693+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-7226cda2-856b-43a7-a054-c2b26fd5a482	\N	\N	\N	2026-04-07 03:09:34.531988+00	2026-04-07 03:09:34.531988+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
33b62967-b9b1-4a04-99e1-e55777a413c5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E link alert 1775531406400	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775531406451", "created_at": "2026-04-07T03:10:06.468312+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-343663ab-e57c-488d-9076-895114d2830a	\N	\N	\N	2026-04-07 03:10:06.466421+00	2026-04-07 03:10:06.466421+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
7f8c2b29-b5c0-491a-8ae2-2927aa8a6766	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E close and label alert 1775531440777	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775531440803", "created_at": "2026-04-07T03:10:40.810388+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-909ff3e9-8991-4509-aa30-0f903839f495	\N	\N	\N	2026-04-07 03:10:40.808853+00	2026-04-07 03:10:40.808853+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
d83ac39f-e38e-4a86-9b20-7002c321563e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	FALSE_POSITIVE	E2E triage alert 1775531705910	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775531705938", "created_at": "2026-04-07T03:15:05.950893+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-bb5323e5-dfb7-42a5-8d96-f3ca9b9111e2	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:15:07.123122+00	2026-04-07 03:15:05.948992+00	2026-04-07 03:15:07.117578+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
007923b2-28d8-41a9-83fc-6aae2196213e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E link alert 1775531709682	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775531709701", "created_at": "2026-04-07T03:15:09.710065+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-33e47137-850d-430b-be92-9e17933b3800	99b538e8-3337-41b9-8feb-b7abb7c581ee	\N	\N	2026-04-07 03:15:09.707815+00	2026-04-07 03:15:10.594751+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
a0318a15-380b-48d3-b3a6-a43c295a6493	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	CLOSED	E2E close and label alert 1775531724346	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775531724379", "created_at": "2026-04-07T03:15:24.394663+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-087cd68e-9de3-4394-8fda-d5ec0f6591a2	\N	\N	\N	2026-04-07 03:15:24.391039+00	2026-04-07 03:15:25.385369+00	FALSE_POSITIVE	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:15:25.239874+00	0.400	0.400	0.200	\N	{}	\N	Feedback de qualidade via Playwright	incremental	\N
69f9f731-d910-497e-89c1-bf1467902f29	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	FALSE_POSITIVE	E2E triage alert 1775531838084	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775531838102", "created_at": "2026-04-07T03:17:18.111681+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-7110df2f-d6cc-48c5-9664-99c23b2e5656	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:17:19.240395+00	2026-04-07 03:17:18.109481+00	2026-04-07 03:17:19.237131+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
c6329a9f-15aa-446e-b3c0-57548b46c5d1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E link alert 1775531841687	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775531841701", "created_at": "2026-04-07T03:17:21.707564+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-2e686fb2-0b7f-494e-86b1-517f11c57b83	a25984d7-bd65-41e9-ab9a-3085fe15899a	\N	\N	2026-04-07 03:17:21.706152+00	2026-04-07 03:17:22.587107+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
7cce0257-6101-45f8-8a9e-ceb4abeb78f7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	CLOSED	E2E close and label alert 1775531844903	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775531844923", "created_at": "2026-04-07T03:17:24.930962+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-8e42f56c-383e-4e73-9325-e53d9b5fb63d	\N	\N	\N	2026-04-07 03:17:24.929028+00	2026-04-07 03:17:25.872723+00	FALSE_POSITIVE	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:17:25.723343+00	0.400	0.400	0.200	\N	{}	\N	Feedback de qualidade via Playwright	incremental	\N
1e305969-7e4a-42fa-bee8-7027f6591fce	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	FALSE_POSITIVE	E2E triage alert 1775532398924	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775532398942", "created_at": "2026-04-07T03:26:38.950620+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-581a2b39-cab4-4404-8b4f-845278738e01	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:26:40.238345+00	2026-04-07 03:26:38.948593+00	2026-04-07 03:26:40.235739+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
61e3a1d9-a460-42ae-8b54-904752357b87	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E link alert 1775532402863	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775532402891", "created_at": "2026-04-07T03:26:42.904542+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-976533cf-ae67-49fc-8160-e9036e02f9eb	a451aa80-ae65-42a6-b94e-e8c098eead5b	\N	\N	2026-04-07 03:26:42.902666+00	2026-04-07 03:26:43.832339+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
3f4ffee2-c4f1-4f7e-b663-7c20de8eb25b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	CLOSED	E2E close and label alert 1775532406194	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775532406221", "created_at": "2026-04-07T03:26:46.229991+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-bb8315fc-3090-41dd-8c66-3fa3f47795cd	\N	\N	\N	2026-04-07 03:26:46.227363+00	2026-04-07 03:26:47.236802+00	FALSE_POSITIVE	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:26:47.101711+00	0.400	0.400	0.200	\N	{}	\N	Feedback de qualidade via Playwright	incremental	\N
23a44fd1-3e1c-4275-912e-4e80e13a61b5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	FALSE_POSITIVE	E2E triage alert 1775532836658	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775532836687", "created_at": "2026-04-07T03:33:56.696502+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-18605695-2129-4020-bb1a-2ee862ba1fdf	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:33:58.338892+00	2026-04-07 03:33:56.694591+00	2026-04-07 03:33:58.335573+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
6faf53e2-169c-4f8b-bbc4-82c95d06495d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E link alert 1775532840861	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775532840880", "created_at": "2026-04-07T03:34:00.886276+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-7384b9d9-b0e6-4fc0-894f-673110ded112	2c80aa82-4998-4e1c-8a64-f699f78de516	\N	\N	2026-04-07 03:34:00.884841+00	2026-04-07 03:34:01.750832+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
7ddf87ff-cadd-461e-9b13-4cc42abbee58	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	CLOSED	E2E close and label alert 1775532844207	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775532844227", "created_at": "2026-04-07T03:34:04.234771+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-03d0a073-42e1-4987-a446-f4fa4c304736	\N	\N	\N	2026-04-07 03:34:04.232899+00	2026-04-07 03:34:05.234219+00	FALSE_POSITIVE	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:34:05.093215+00	0.400	0.400	0.200	\N	{}	\N	Feedback de qualidade via Playwright	incremental	\N
c7387d28-773f-440b-a438-08a66a589990	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	FALSE_POSITIVE	E2E triage alert 1775533118359	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775533118383", "created_at": "2026-04-07T03:38:38.392317+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-895cf06f-6677-45b3-93e1-bc9d8d1edb4a	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:38:40.013965+00	2026-04-07 03:38:38.390484+00	2026-04-07 03:38:40.011019+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
3545d5c8-ca54-4426-9ba9-e7505a91cb9c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E link alert 1775533122906	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775533122954", "created_at": "2026-04-07T03:38:42.983473+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-16bfffae-93fa-4d92-bb6b-c7696d760172	e6aaf58a-1466-4728-bada-045db352f214	\N	\N	2026-04-07 03:38:42.974891+00	2026-04-07 03:38:43.890037+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
72723df7-a958-4add-b419-6d36a14a560d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	CLOSED	E2E close and label alert 1775533126276	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775533126295", "created_at": "2026-04-07T03:38:46.303781+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-148ac04b-57b3-4c56-a24a-48289433d5fb	\N	\N	\N	2026-04-07 03:38:46.302064+00	2026-04-07 03:38:47.293221+00	FALSE_POSITIVE	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:38:47.160374+00	0.400	0.400	0.200	\N	{}	\N	Feedback de qualidade via Playwright	incremental	\N
2c249c7a-3664-42f2-9fac-9885d592ecaf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	FALSE_POSITIVE	E2E triage alert 1775533907979	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775533908010", "created_at": "2026-04-07T03:51:48.019167+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-a0bab80f-bdba-42e3-a518-e9eb46262117	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:51:49.830904+00	2026-04-07 03:51:48.017343+00	2026-04-07 03:51:49.827847+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
596a9339-5b20-4757-b70c-52903e217a03	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E link alert 1775533912341	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775533912364", "created_at": "2026-04-07T03:51:52.372171+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-8816e0eb-ac16-4c99-9cf5-2f54335c1de3	62f3228e-998c-4cec-af91-4ac475562664	\N	\N	2026-04-07 03:51:52.370522+00	2026-04-07 03:51:53.281389+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
97e3fdaf-f042-4655-bae4-4162b029676e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	CLOSED	E2E close and label alert 1775533916189	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775533916213", "created_at": "2026-04-07T03:51:56.221688+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-47caeec8-fca9-4ff0-ac77-c89d93a9d95e	\N	\N	\N	2026-04-07 03:51:56.219553+00	2026-04-07 03:51:57.177405+00	FALSE_POSITIVE	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:51:57.033729+00	0.400	0.400	0.200	\N	{}	\N	Feedback de qualidade via Playwright	incremental	\N
410d868c-321f-4dea-a9de-b959bcb05f22	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	FALSE_POSITIVE	E2E triage alert 1775534085867	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775534085889", "created_at": "2026-04-07T03:54:45.898938+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-f71089ec-d159-4071-a91a-a6774924d29e	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:54:47.843325+00	2026-04-07 03:54:45.896965+00	2026-04-07 03:54:47.84024+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
4264e047-d5ef-491a-ba98-30d3b03eca93	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E link alert 1775534090555	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775534090579", "created_at": "2026-04-07T03:54:50.588596+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-385f92c3-7378-41a0-85f1-57b87d69ed4c	8075dabc-8936-4d78-866d-0fe44bd45a4b	\N	\N	2026-04-07 03:54:50.586738+00	2026-04-07 03:54:51.602895+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
b126eb3e-e69a-4d3c-ba30-022f41f2ce64	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	CLOSED	E2E close and label alert 1775534094155	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775534094179", "created_at": "2026-04-07T03:54:54.212852+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-32383865-dac8-4ecb-98b6-840e7652c8aa	\N	\N	\N	2026-04-07 03:54:54.211348+00	2026-04-07 03:54:55.273818+00	FALSE_POSITIVE	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:54:55.114459+00	0.400	0.400	0.200	\N	{}	\N	Feedback de qualidade via Playwright	incremental	\N
bdd7eb13-3e55-4344-9060-132fd5ab4c06	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	FALSE_POSITIVE	E2E triage alert 1775534257509	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775534257532", "created_at": "2026-04-07T03:57:37.542052+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-748d178c-778b-4f4a-b9e6-c65f6431da71	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:57:39.251703+00	2026-04-07 03:57:37.540494+00	2026-04-07 03:57:39.248158+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
971a0d9d-cbdf-4845-8a00-0c72dafe413a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E link alert 1775534262091	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775534262113", "created_at": "2026-04-07T03:57:42.120917+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-f8adf271-4b4e-4d20-9331-47ae533a45a8	47e1a129-8365-4217-8dcd-3f3338962ebf	\N	\N	2026-04-07 03:57:42.118934+00	2026-04-07 03:57:43.166076+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
51607e36-edd8-4ead-8edf-23e7e4a03ce9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	CLOSED	E2E close and label alert 1775534265850	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775534265875", "created_at": "2026-04-07T03:57:45.884687+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-d0b182cd-3db9-4db3-8270-66a945da0a5b	\N	\N	\N	2026-04-07 03:57:45.882658+00	2026-04-07 03:57:46.952095+00	FALSE_POSITIVE	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:57:46.785813+00	0.400	0.400	0.200	\N	{}	\N	Feedback de qualidade via Playwright	incremental	\N
5574a59a-b40b-4dd1-9719-734ba7699a96	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E RBAC alert 1775538757918	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775538757943", "created_at": "2026-04-07T05:12:37.949685+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-db3587a1-8507-448c-aab8-1b257d876c23	\N	\N	\N	2026-04-07 05:12:37.948178+00	2026-04-07 05:12:38.257919+00	FALSE_POSITIVE	a295ceae-bac0-4c7f-8fe8-e8431d651700	2026-04-07 05:12:38.263207+00	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
97ecb9a0-c3a9-46df-aa04-26efc3b9d9fd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E RBAC alert 1775539267343	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775539267366", "created_at": "2026-04-07T05:21:07.383966+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-0aca3d55-4bf0-462c-a698-85d102804c25	\N	\N	\N	2026-04-07 05:21:07.38228+00	2026-04-07 05:21:07.38228+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
7e230ee5-e6eb-47cd-a4be-0ae66eae4f03	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	\N	RULE	HIGH	OPEN	E2E RBAC alert 1775539377629	Alerta criado automaticamente pela suíte E2E	{"marker": "e2e-1775539377659", "created_at": "2026-04-07T05:22:57.665943+00:00", "created_via": "internal_e2e_fixture"}	\N	e2e-1b9a4f06-5ac1-4277-9283-db96a9daf023	\N	\N	\N	2026-04-07 05:22:57.664591+00	2026-04-07 05:22:57.664591+00	\N	\N	\N	0.400	0.400	0.200	\N	{}	\N	\N	incremental	\N
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.api_keys (id, tenant_id, name, key_hash, key_prefix, source_system, permissions, active, last_used_at, expires_at, created_by, revoked_by, revoked_at, created_at) FROM stdin;
57286b04-9b47-4054-bee3-16f4d61df0cf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	e2e-key-1775533226217	525b5a38c725fe9096110d60f78f35318bf7f9207c6414ddf2b2d28aaa07aa1a	btml_4f0	connector_delta	["ingest"]	f	\N	2026-07-06 03:40:32.89121+00	\N	\N	\N	2026-04-07 03:40:32.889401+00
f06b8597-300c-4f7f-a817-f4d2d7cdc374	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	e2e-key-1775533684644	c63478c1b787ad0e873ca80b78c0cd84d0e03227ff56811fd6544b866717868c	btml_4f0	connector_delta	["ingest"]	f	\N	2026-07-06 03:48:07.061723+00	\N	\N	\N	2026-04-07 03:48:07.05974+00
d6306956-d6de-4133-a531-ab2ae9e97614	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	e2e-key-1775533746195	72bb4b60b17b0ccf5f852cc7966bed2c87feab56f9c5e82ca10211ee25ecddb9	btml_4f0	connector_delta	["ingest"]	f	\N	2026-07-06 03:49:08.612181+00	\N	\N	\N	2026-04-07 03:49:08.610117+00
855dd7ab-17dc-48e7-bd7c-e2c583ef65a8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	e2e-key-1775533840119	57492555aa9f691898efe89dd8de15cc7b5d68c846415587b4f6023f505ef1e3	btml_4f0	connector_delta	["ingest"]	f	\N	2026-07-06 03:50:42.333406+00	\N	\N	\N	2026-04-07 03:50:42.331845+00
abb666cf-7e04-4bec-ae0e-6ce1d9b632f3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	e2e-key-1775534369309	9aafd0f86b677cf02aebf9ed6aed41c4fc453c34fd5df5e3d4da18f73a817787	btml_4f0	connector_delta	["ingest"]	f	\N	2026-07-06 03:59:31.760229+00	\N	\N	\N	2026-04-07 03:59:31.758809+00
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.audit_logs (id, tenant_id, user_id, action, entity_type, entity_id, before, after, ip_address, created_at, pii_accessed) FROM stdin;
6f853db8-af84-41a8-b78c-4a8bb48c7a2b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-04 10:40:07.644938+00	\N
521c8142-948a-4673-abb6-f5295e37cdfd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-04 10:40:27.395694+00	\N
754d3b69-c879-4046-a0b4-1c0376d26a70	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 04:41:28.072401+00	\N
0743b8f9-a967-46eb-95c6-d9d1f7380dfe	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-04 10:40:59.150095+00	\N
17eb7c3c-a6aa-4802-820e-10e9c2825f93	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-04 10:40:59.46246+00	\N
fd06d1b6-4666-4560-ba82-41cef6e6f8e8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	d48c68fe-fad6-4d61-94b1-451938885a6d	null	{"title": "Smoke Fase 1 e2e 20260404T104059Z", "severity": "HIGH", "player_id": "4633153f-6cca-40b2-b0f7-30df770677ec", "description": "Caso criado por smoke automatizado da fase 1"}	\N	2026-04-04 10:40:59.600383+00	\N
875d7c16-05c7-4105-a93d-a3dd86245362	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	UPLOAD_EVIDENCE	Case	d48c68fe-fad6-4d61-94b1-451938885a6d	null	{"sha256": "017144b7b656699d8a1c0fa5217fd8bfc2fd3fe3a5764ab46a4ec76de66cd19d", "event_id": "e7f7c5ab-18f8-4ed0-a8bc-ec5290b32362", "file_name": "tmp.L9xKHjsnJ1", "size_bytes": 96}	\N	2026-04-04 10:40:59.80439+00	\N
34236cee-07a2-4e11-873f-bf4d83e096db	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	DOWNLOAD_EVIDENCE	CaseEvent	e7f7c5ab-18f8-4ed0-a8bc-ec5290b32362	null	{"sha256": "017144b7b656699d8a1c0fa5217fd8bfc2fd3fe3a5764ab46a4ec76de66cd19d", "case_id": "d48c68fe-fad6-4d61-94b1-451938885a6d", "file_name": "tmp.L9xKHjsnJ1"}	\N	2026-04-04 10:41:00.038564+00	\N
3c4d16b5-96bc-4a7b-b9a0-c87c08994fd6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	d48c68fe-fad6-4d61-94b1-451938885a6d	null	{"decision": "FILE_SAR", "report_id": "a8db01a8-fe3b-4c62-ad4e-b04e085268a3", "pdf_sha256": "bc37d97e18b7efae772824037d6a5e0c1b3f52f6f80627413bb12a7b3cdd0342", "payload_sha256": "680cae2557619cff023175c15e2817a268c8aa70c8ff6f8286203a8e51d9b4f5"}	\N	2026-04-04 10:41:00.136006+00	\N
4d573732-fbf4-4895-931d-ee265cd355ce	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_JSON	ReportPackage	66572478-754e-47b0-af54-8de0489872a9	null	null	\N	2026-04-04 10:41:00.786815+00	\N
66de9eef-bcef-4213-a228-1e21c4f0e212	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_PDF	ReportPackage	66572478-754e-47b0-af54-8de0489872a9	null	{"case_id": "d48c68fe-fad6-4d61-94b1-451938885a6d"}	\N	2026-04-04 10:41:00.825496+00	\N
2fd90907-c008-4136-9f8a-2e20f0cd3b68	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	SUBMIT_COAF_REPORT	Case	d48c68fe-fad6-4d61-94b1-451938885a6d	null	{"case_status": "REPORTED", "tracking_id": "134850b5-64a7-4434-a602-906a1a2b51ad", "report_package_id": "66572478-754e-47b0-af54-8de0489872a9"}	\N	2026-04-04 10:41:00.959734+00	\N
04775d1b-0eab-46d3-85a1-b48dbe44fc73	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-04 10:41:14.77023+00	\N
8594c1c3-5e78-475d-9d1a-09ab0a63dcf5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	DOWNLOAD_COAF_XML	Case	d48c68fe-fad6-4d61-94b1-451938885a6d	null	null	\N	2026-04-04 10:41:14.803918+00	\N
9cf85dd4-0480-406e-a07e-e92e3a9e3bb2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:05:06.613941+00	\N
7133b94d-7005-4087-bb70-3051b47f1fb4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:05:06.895693+00	\N
4e3b83c3-1c14-406d-986f-653cbd6fb653	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:05:07.596362+00	\N
b5e44bbe-f1e3-44d0-952d-2dfed7645b90	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:05:07.928333+00	\N
5370d799-812f-4e87-9d2e-390dff3546af	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:05:08.639176+00	\N
fadcc7ff-a084-4695-86b7-6ea1dbca8fb2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:06:32.208825+00	\N
93036dee-f4e7-4ba2-b8e5-cc2ac5669068	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:06:32.210511+00	\N
1b531953-a309-46b6-9d53-04823240bc4a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:06:33.238704+00	\N
cd8bef3a-09ba-4d49-a691-922c4373090a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:06:33.240911+00	\N
7e64ac52-23f4-4e8c-88b1-f97126695066	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:06:33.964937+00	\N
68ed8f92-aad2-40b2-849b-6b0fc9e1e3c4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:09:21.04785+00	\N
d78bcdf2-9903-48ac-8f8c-b010aba1e51a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:09:28.272956+00	\N
f21fc4c5-f48a-4ec4-ba74-903a9b91e70e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:09:31.095741+00	\N
19ffe36d-8804-4882-b7d2-e95d69857097	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:09:33.242083+00	\N
f7669089-0e56-4d4c-9766-b671b29ffc44	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:09:34.449072+00	\N
785e97ae-d48a-4b51-93bf-a9e3b6663adf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	ec7951b7-6bf7-4652-a6eb-f53cd4489d43	null	{"title": "E2E Audit Export 1775536888121", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 04:41:28.126493+00	\N
610b34ad-f1b8-4d75-82be-02c4fdc9a802	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	7b1f7343-0712-4d14-ab23-484802b6eae7	null	{"title": "E2E triage alert 1775531374481", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:09:34.531988+00	\N
4d7ae36e-93d1-4fcb-bb31-46340060b794	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:10:05.051026+00	\N
3c6951c2-df12-421f-b194-fe88fdc8e690	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:10:06.364454+00	\N
18e2ec31-1dd6-48c1-a0bd-256a0aef2d9c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	33b62967-b9b1-4a04-99e1-e55777a413c5	null	{"title": "E2E link alert 1775531406400", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:10:06.466421+00	\N
5b18caac-c3de-496c-b98d-6bbee86f3121	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	28e93fee-30ea-4f56-8cd3-5174f829908d	null	{"title": "Case for alert link 1775531406493", "severity": "MEDIUM", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:10:06.521633+00	\N
9d20f5dd-b243-4f8b-857a-25e74306e1c3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:10:37.083061+00	\N
9379d3e0-1ab2-435c-b9ea-2b13be0abcd4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:10:40.740428+00	\N
a7d9a70f-c508-4f92-9699-1b79a19a3c82	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	ec7951b7-6bf7-4652-a6eb-f53cd4489d43	null	{"new_status": "INVESTIGATING"}	\N	2026-04-07 04:41:28.153851+00	\N
175fdef7-9b6f-489e-a59e-00810fef35e9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	ee834080-3262-4085-8152-dd965c298122	null	{"title": "E2E Narrative Suggestion 1775531543719", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:12:23.782319+00	\N
33ab09f3-1603-42dd-a11c-cbb712b3600a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:12:55.354811+00	\N
ddf16f4a-477b-4b22-bed0-3f00480c62ba	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:14:59.695469+00	\N
04dc3992-a7e9-40e1-b92c-8a95f60160d7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:15:05.88361+00	\N
6ed5ec49-cac0-4344-90db-57cc4cc2bab8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	ec7951b7-6bf7-4652-a6eb-f53cd4489d43	null	{"new_status": "PENDING_REVIEW"}	\N	2026-04-07 04:41:28.174388+00	\N
a6f2f12f-0d0a-4a0c-b503-52fd2babe27c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	007923b2-28d8-41a9-83fc-6aae2196213e	null	{"title": "E2E link alert 1775531709682", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:15:09.707815+00	\N
8c349962-ccee-45b9-bca5-0181ae630587	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LINK_ALERT	Case	99b538e8-3337-41b9-8feb-b7abb7c581ee	null	{"alert_id": "007923b2-28d8-41a9-83fc-6aae2196213e"}	\N	2026-04-07 03:15:10.594751+00	\N
af7c140c-c976-4767-b730-ea2b067cf381	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:15:24.321153+00	\N
12afe873-a5c9-41e2-b986-817348f5fa9b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	ec7951b7-6bf7-4652-a6eb-f53cd4489d43	null	{"new_status": "CLOSED"}	\N	2026-04-07 04:41:28.189644+00	\N
b9eafa88-9d3f-4dfd-b9cc-fe76f243095f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CLOSE	Alert	a0318a15-380b-48d3-b3a6-a43c295a6493	null	null	\N	2026-04-07 03:15:25.385369+00	\N
a610a0eb-3822-4274-ab68-cf0cc0b3f830	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:33.405421+00	\N
d5552a36-6296-45b4-a837-fb4c2394b1f2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:37.43766+00	\N
9798f7b7-0819-46ca-b060-f240a3e25ead	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_COMMENT	Case	b4213734-3133-47e5-952d-1abac9728fe2	null	{"length": 47, "mentions": []}	\N	2026-04-07 03:15:43.624484+00	\N
2ed981cf-0002-4e1e-bd2c-2faea12baa9c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:46.717443+00	\N
8dabc6d7-9f97-4249-ad01-60165952bbee	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:49.933686+00	\N
58c7ae28-1d63-493e-9264-53f004cf626d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:51.416044+00	\N
4d9bd599-648c-41fd-ba7c-2996728662df	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:52.869688+00	\N
a860d839-398a-4f21-857f-ebb2bc04e90a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:54.43135+00	\N
7aa168f8-d8d7-4d10-938a-ada3d0349553	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 04:41:29.770523+00	\N
75bd55fd-197d-4392-b27b-b2a74984b94d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	441cc147-981f-4e3a-9415-9af11b1aa905	null	{"title": "E2E Report Export 1775536889795", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 04:41:29.800057+00	\N
dd4f0e64-394b-48fc-baae-0e2194814f9a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	441cc147-981f-4e3a-9415-9af11b1aa905	null	{"decision": "NO_ACTION", "report_id": "476c6d48-c2d7-4e4d-9be4-af19c7ad74eb", "pdf_sha256": "d110bc65095a26fceaf818b33a3b6de4af34023b71dd0a12ef809c1b4e695fff", "payload_sha256": "89af9cfbf0f264955afbbc4bee411f9cc0a991d761719efd1ffc44ab5fc1e947"}	\N	2026-04-07 04:41:29.813773+00	\N
93116236-5425-4a5e-9819-ee8fbfd2b557	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_JSON	ReportPackage	88eab46f-3f06-4586-91b4-5ec04a641faf	null	null	\N	2026-04-07 04:41:30.012541+00	\N
dd52c415-1fe1-443c-bf2f-5d4e812b927d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_PDF	ReportPackage	88eab46f-3f06-4586-91b4-5ec04a641faf	null	{"case_id": "441cc147-981f-4e3a-9415-9af11b1aa905"}	\N	2026-04-07 04:41:30.03053+00	\N
de1c3685-74c7-4e32-afcf-95acbc4d5bd0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 04:41:30.376674+00	\N
4c91e488-e964-4698-bcc3-2b908a9d22c3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	468ac1e7-13d8-4b71-a76b-ac47b9de7567	null	{"title": "E2E Auditor Export 1775536890399", "severity": "MEDIUM", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 04:41:30.403748+00	\N
c3d28a7a-e452-46f1-95fa-370cf7e37508	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	468ac1e7-13d8-4b71-a76b-ac47b9de7567	null	{"decision": "NO_ACTION", "report_id": "fd1ab90b-9473-44c6-8d1e-a7657a0ce5a0", "pdf_sha256": "007a33f2145c85ae7ade529c7384c56b7bee22d9e5d083606368579ab3b93a5e", "payload_sha256": "457a0bab1efba1813c5146cacdb518703c742b3d5ba1830c9ffd5bd0b28436b0"}	\N	2026-04-07 04:41:30.417455+00	\N
29036174-29a1-411b-a54a-d928df40f03c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.1	2026-04-07 04:41:30.754533+00	\N
97ce5e6c-4d43-4d11-9d54-d8996e2c799b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	EXPORT_REPORT_JSON	ReportPackage	d969a955-3a13-4440-9866-ec9c18ddd2e5	null	null	\N	2026-04-07 04:41:30.765165+00	\N
d75326b1-1432-47ab-819b-9a320bda84de	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:42:00.55756+00	\N
0824752d-dc9f-44b8-8892-3d030a59ded6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE	Case	93d9d925-f602-4c06-9368-83e31001bc4b	null	{"title": "tmp", "severity": "HIGH", "player_id": "4633153f-6cca-40b2-b0f7-30df770677ec", "description": "tmp"}	\N	2026-04-07 04:42:00.580418+00	\N
7273582f-b8a1-4e93-80a9-97d1b3360878	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CASE_STATUS_CHANGE	Case	93d9d925-f602-4c06-9368-83e31001bc4b	null	{"new_status": "INVESTIGATING"}	\N	2026-04-07 04:42:00.593491+00	\N
545a1aa1-74c2-4805-a767-b737ac36d49a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CASE_STATUS_CHANGE	Case	93d9d925-f602-4c06-9368-83e31001bc4b	null	{"new_status": "PENDING_REVIEW"}	\N	2026-04-07 04:42:00.605513+00	\N
1f5faee3-56c1-487e-91ac-0508224b7b1b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CASE_STATUS_CHANGE	Case	93d9d925-f602-4c06-9368-83e31001bc4b	null	{"new_status": "CLOSED"}	\N	2026-04-07 04:42:00.622068+00	\N
a5f5e2ea-a62a-4d51-afea-eb628fe9fb34	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	7f8c2b29-b5c0-491a-8ae2-2927aa8a6766	null	{"title": "E2E close and label alert 1775531440777", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:10:40.808853+00	\N
1c1728f3-e613-4d40-aa35-b2b9b3a0aeea	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:11:17.323252+00	\N
75aa9b7e-f08c-42c5-be32-7af8011be7a1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:12:22.406213+00	\N
2c1293e5-a29a-4e0c-9699-8efa97c3689d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:12:56.905849+00	\N
9fbae4df-7e3b-4d13-a30b-59641cecf068	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:12:58.432352+00	\N
f9f1783a-a5ff-4335-90ff-cd748efb2d10	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:13:00.126799+00	\N
110b339a-38d2-45da-ae23-06b8954ca566	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 04:43:28.203969+00	\N
aee67981-0e27-412c-b132-919a762d04b8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:41.302958+00	\N
fd4e7722-3750-489a-9363-6c3468a06c29	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	b4213734-3133-47e5-952d-1abac9728fe2	null	{"decision": "NO_ACTION", "report_id": "6c12850c-de05-49ba-9ae0-2d91f630e016", "pdf_sha256": "5d83499762aa38af1a9c4ff267c7a1c05936e9cbedaef1da9193c50dbafeea30", "payload_sha256": "c2f668930b322df3a1227372a013b322588d63902c0ab19a3d80510803c08c14"}	\N	2026-04-07 03:15:43.825332+00	\N
716856b7-7002-40ec-b1eb-12e9db085a8a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:43:29.437529+00	\N
6cc4e3cd-d680-4167-b96d-ec44bf41f2c6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE	Case	ec263c8f-4edc-4dfb-b508-bb1bbd2dbb69	null	{"title": "tmp", "severity": "HIGH", "player_id": "4633153f-6cca-40b2-b0f7-30df770677ec", "description": "tmp"}	\N	2026-04-07 04:43:29.47056+00	\N
30ee9859-4deb-437a-a606-17ae7cf90bbd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CASE_STATUS_CHANGE	Case	ec263c8f-4edc-4dfb-b508-bb1bbd2dbb69	null	{"new_status": "INVESTIGATING"}	\N	2026-04-07 04:43:29.489338+00	\N
80c7be8e-1118-4634-9538-5350f2ee7bf4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CASE_STATUS_CHANGE	Case	ec263c8f-4edc-4dfb-b508-bb1bbd2dbb69	null	{"new_status": "PENDING_REVIEW"}	\N	2026-04-07 04:43:29.502982+00	\N
eec60625-7596-4ab5-a53c-80678a1b5594	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CASE_STATUS_CHANGE	Case	ec263c8f-4edc-4dfb-b508-bb1bbd2dbb69	null	{"new_status": "CLOSED"}	\N	2026-04-07 04:43:29.517983+00	\N
3bad55f7-2e38-423e-a427-0d2fc8c8266a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 04:43:47.901858+00	\N
a79c489a-71d9-429d-bd38-1661eed5dede	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	43b747b8-5e26-476f-8e2a-53f894d1041a	null	{"title": "E2E Audit Export 1775537027939", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 04:43:47.945394+00	\N
1415f345-8575-40fd-a07a-8a16401f0390	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	43b747b8-5e26-476f-8e2a-53f894d1041a	null	{"new_status": "INVESTIGATING"}	\N	2026-04-07 04:43:47.967224+00	\N
d9f94681-3cfc-43e3-81cd-9f5c8aaf9d1f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	43b747b8-5e26-476f-8e2a-53f894d1041a	null	{"new_status": "PENDING_REVIEW"}	\N	2026-04-07 04:43:47.983148+00	\N
a9c521c8-70d6-49af-af60-2bab0ccb270a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	43b747b8-5e26-476f-8e2a-53f894d1041a	null	{"new_status": "CLOSED"}	\N	2026-04-07 04:43:47.997074+00	\N
29051bc0-9790-4400-835a-20992f943c6a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	43b747b8-5e26-476f-8e2a-53f894d1041a	null	{"decision": "FILE_SAR", "report_id": "3abb3fcb-b6d7-4803-bf59-97e0bd2c4f6f", "pdf_sha256": "129f78b2a805f280a2ef0de900dd3de2dfeabb839992ec146761156f1a948a07", "payload_sha256": "667c3b36c61bb048fc883092eedd661f853be8db706686f4e0dba781595750f2"}	\N	2026-04-07 04:43:48.014574+00	\N
6dc9c51e-2528-4321-81d4-c55f7f91b213	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_JSON	ReportPackage	50be8c2d-fa5b-4166-8a57-78c3777ba48d	null	null	\N	2026-04-07 04:43:48.048124+00	\N
d0851b7f-bf30-46dc-9fba-3b01d9720f39	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_PDF	ReportPackage	50be8c2d-fa5b-4166-8a57-78c3777ba48d	null	{"case_id": "43b747b8-5e26-476f-8e2a-53f894d1041a"}	\N	2026-04-07 04:43:48.059506+00	\N
d4d18edd-85f2-4a42-a421-78944e6d5f20	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	DOWNLOAD_COAF_XML	Case	43b747b8-5e26-476f-8e2a-53f894d1041a	null	null	\N	2026-04-07 04:43:48.077298+00	\N
e9988ac5-0e27-485e-b1f3-d9fe90d647a7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 04:45:29.33899+00	\N
0fbe2c90-8702-440b-b050-a89af154e757	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	09fb76ee-85d5-4706-bb22-301996504548	null	{"title": "E2E Audit Export 1775537129376", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 04:45:29.382368+00	\N
65b708f4-e233-4511-96e1-6c75fd3a0ce9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	09fb76ee-85d5-4706-bb22-301996504548	null	{"new_status": "INVESTIGATING"}	\N	2026-04-07 04:45:29.40036+00	\N
1884e974-0272-4373-82b6-38633362f905	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	09fb76ee-85d5-4706-bb22-301996504548	null	{"new_status": "PENDING_REVIEW"}	\N	2026-04-07 04:45:29.416863+00	\N
fa53d5db-8019-4cdc-a6b4-ace1c8b7a0ae	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	09fb76ee-85d5-4706-bb22-301996504548	null	{"new_status": "CLOSED"}	\N	2026-04-07 04:45:29.435685+00	\N
88467cf7-1605-4632-8afe-b25a2d41193f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	09fb76ee-85d5-4706-bb22-301996504548	null	{"decision": "FILE_SAR", "report_id": "119d42c0-6495-4a28-a6d6-e26b247b9fda", "pdf_sha256": "cce477e95f45f7dff0433b57eedb469c0188aecd2a974199d02e4b1003f49752", "payload_sha256": "cb7d6ade34969b7ebc33089ba568b970e34714143cea5881a3c2afe91327a079"}	\N	2026-04-07 04:45:29.456389+00	\N
b93ee187-5cf5-45a6-b52b-59a1bd3cc6a5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_JSON	ReportPackage	defa2505-d8b0-4728-bfe8-b017af5ca885	null	null	\N	2026-04-07 04:45:29.500954+00	\N
ce493369-dcbd-4b1f-8374-c5ce20ecd8c4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_PDF	ReportPackage	defa2505-d8b0-4728-bfe8-b017af5ca885	null	{"case_id": "09fb76ee-85d5-4706-bb22-301996504548"}	\N	2026-04-07 04:45:29.525564+00	\N
0e16416c-38a3-4c0d-a0ce-217b9eb906ea	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	DOWNLOAD_COAF_XML	Case	09fb76ee-85d5-4706-bb22-301996504548	null	null	\N	2026-04-07 04:45:29.553773+00	\N
09d3e0c0-feaf-4367-a91f-3bdcea164de3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.1	2026-04-07 04:45:29.878802+00	\N
8fa9863b-8015-415d-95d0-516982576e4e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:45:58.440806+00	\N
46d1a48e-a787-4023-96a4-6ac36a92e1b4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:11:08.790045+00	\N
3059a4e7-a4ea-4aad-b7d7-1a6967be404c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:11:50.877738+00	\N
b21749f2-c07a-45ef-b7f3-b6add08aca42	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:11:52.113307+00	\N
3e1790bc-f17e-4de8-94e3-8d3ec88d94e0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:04.710256+00	\N
7e53b7cb-b9c4-469d-b0d6-8028aea4895f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:08.403017+00	\N
b538736e-fbab-46b2-a54a-e7baacfa39a6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LABEL_ALERT	Alert	a0318a15-380b-48d3-b3a6-a43c295a6493	null	{"label": "FALSE_POSITIVE", "label_note": "Feedback de qualidade via Playwright"}	\N	2026-04-07 03:15:25.234834+00	\N
a0206d53-1394-426a-995b-6f1d2d1e45cc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:27.270467+00	\N
1bb792eb-c640-4657-ab1c-8d381f62126d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:45:59.910504+00	\N
4d027dd0-4d0c-4cd8-941a-bc550f2c87c3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:46:39.600755+00	\N
99af6fcf-57f0-4b1a-a012-d7461651d6ea	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:48:59.553211+00	\N
e88e7dad-1daa-4704-a300-f4961d3fc848	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:49:13.648414+00	\N
c677e4b7-94ea-4076-b40b-665c9295fb0b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:11:11.774631+00	\N
dfd47cc9-411f-4a85-afb2-e64600157388	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	fad6d360-2b3f-4cce-a4b9-2a2d0692da04	null	{"title": "E2E Workflow Case 1775531512179", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:11:52.190935+00	\N
8159c870-39d8-41ac-a7f0-875f0614627d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:12:23.688634+00	\N
a5160f00-ab8d-4cb0-b2ba-c003d601543f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:46:38.122951+00	\N
e15d8110-0caa-41cb-bb09-d349740699a4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	d83ac39f-e38e-4a86-9b20-7002c321563e	null	{"title": "E2E triage alert 1775531705910", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:15:05.948992+00	\N
4de9fef8-043b-4868-b518-20cab3ac2fb1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:15:09.663895+00	\N
44846da0-8c8c-43b9-954e-8e30d789d8ab	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	a0318a15-380b-48d3-b3a6-a43c295a6493	null	{"title": "E2E close and label alert 1775531724346", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:15:24.391039+00	\N
5a0a33b2-751b-4136-a5c2-2c125382c0d4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	b4213734-3133-47e5-952d-1abac9728fe2	null	{"title": "E2E Workflow Case 1775531742561", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:15:42.567831+00	\N
70b87eb4-0663-48a4-9c4c-68e2ce59201e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	76431f6b-a665-4238-98e6-52121c6ddaad	null	{"title": "E2E Narrative Suggestion 1775531747942", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:15:47.965579+00	\N
f19729c5-355d-4a73-8bc6-936fe5164f58	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:11:15.248341+00	\N
4008eb18-e3cf-49dd-bd1c-7e40e596f75c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:11:19.245279+00	\N
ca871ced-87b0-4a96-9aa1-4300fdfff2c9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:02.768882+00	\N
7ba70a28-6633-4d80-af91-f54fa7570ff0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	TRIAGE	Alert	d83ac39f-e38e-4a86-9b20-7002c321563e	null	null	\N	2026-04-07 03:15:07.117578+00	\N
725adde8-9f95-4d53-a14a-baf818fbfaaa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	99b538e8-3337-41b9-8feb-b7abb7c581ee	null	{"title": "Case for alert link 1775531709721", "severity": "MEDIUM", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:15:09.745207+00	\N
d7d7cefa-0785-4ff3-82af-afa29eedbcf2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:23.157691+00	\N
73fdf6e0-0b14-45a3-a289-82aea4723a6d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:30.285648+00	\N
77f8abd3-20c6-4c5c-81be-402c877c9fce	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:15:35.367956+00	\N
8608b5e7-22f3-43b9-b376-4854c7861803	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	25a140ef-d778-4f04-85cc-56f83ef54cc3	null	{"title": "E2E Manual Case 1775531738284", "severity": "HIGH", "player_id": null, "description": "Caso criado pela suíte E2E para validar o fluxo manual."}	\N	2026-04-07 03:15:39.375308+00	\N
debf75fe-f80f-4bd8-8110-5d29be19617e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:15:42.516196+00	\N
750d0d2f-0676-4861-9e00-f0eea669cd01	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:15:47.923928+00	\N
00f2d550-11f3-48b4-ba93-fcf47d977492	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:49:12.287281+00	\N
a62075d6-f8a2-4ea4-9562-647995d04049	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:11.999181+00	\N
a1295505-5efc-4ee0-982c-fe893ad8624b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:14.846387+00	\N
579049ee-7e51-45f3-b1d4-5219fbb96433	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:16.89772+00	\N
1dbb7518-b7b2-45bc-a534-04d8c86c365b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:17:18.061234+00	\N
66cf0c13-d379-4dc8-94b2-afca16fb9752	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	69f9f731-d910-497e-89c1-bf1467902f29	null	{"title": "E2E triage alert 1775531838084", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:17:18.109481+00	\N
0426a36e-1f2c-4c3b-a54f-5fdb372b8940	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	TRIAGE	Alert	69f9f731-d910-497e-89c1-bf1467902f29	null	null	\N	2026-04-07 03:17:19.237131+00	\N
4bde7d0b-0e58-4f89-8194-39501d9a997a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:20.311524+00	\N
1acb5c87-a5cc-4fdd-af1e-f73dd1f78461	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:17:21.68024+00	\N
ce114a1d-ba00-46f1-9128-ebe1b9ccbbae	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	c6329a9f-15aa-446e-b3c0-57548b46c5d1	null	{"title": "E2E link alert 1775531841687", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:17:21.706152+00	\N
394fb2ac-35fb-4b7c-ba61-fe6114f79fa5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	a25984d7-bd65-41e9-ab9a-3085fe15899a	null	{"title": "Case for alert link 1775531841714", "severity": "MEDIUM", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:17:21.731552+00	\N
3265f550-0932-47a4-8a5c-8d800d324bad	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LINK_ALERT	Case	a25984d7-bd65-41e9-ab9a-3085fe15899a	null	{"alert_id": "c6329a9f-15aa-446e-b3c0-57548b46c5d1"}	\N	2026-04-07 03:17:22.587107+00	\N
0331d012-f66a-45bf-89df-10cb18ec48db	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:23.69648+00	\N
591d8e7d-574e-4e3c-9c46-c4c8a077b7e2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:17:24.887084+00	\N
1fc47cea-a6b7-4a08-9b3b-fc72cadce04c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	7cce0257-6101-45f8-8a9e-ceb4abeb78f7	null	{"title": "E2E close and label alert 1775531844903", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:17:24.929028+00	\N
43d96bcb-384c-430d-996f-9e5bc9839846	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LABEL_ALERT	Alert	7cce0257-6101-45f8-8a9e-ceb4abeb78f7	null	{"label": "FALSE_POSITIVE", "label_note": "Feedback de qualidade via Playwright"}	\N	2026-04-07 03:17:25.717407+00	\N
96978eab-2f39-4c43-97b6-8de3faa43e7f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CLOSE	Alert	7cce0257-6101-45f8-8a9e-ceb4abeb78f7	null	null	\N	2026-04-07 03:17:25.872723+00	\N
a6021e44-3739-4e64-b2db-c350646eb941	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:27.583492+00	\N
a7483a7a-39cd-411c-a80e-5aa399e22504	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:30.462849+00	\N
015035d1-8179-4482-963e-cb023796c492	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:32.715965+00	\N
13285493-87d3-431b-b20e-008e6be83695	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:34.634808+00	\N
e1be0f12-ef52-44e1-830d-59a4a613e7d7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:36.576409+00	\N
8553f716-bb12-4b26-826e-7126e860148c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	98c9d904-7e0a-439f-919c-6cf6b7e71f46	null	{"title": "E2E Manual Case 1775531857447", "severity": "HIGH", "player_id": null, "description": "Caso criado pela suíte E2E para validar o fluxo manual."}	\N	2026-04-07 03:17:38.011145+00	\N
079cd919-dc6b-4888-b087-ead03c9f600e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:40.00864+00	\N
e0a59e22-9fe0-4684-9d18-baabcb3dc114	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:17:41.221346+00	\N
204efdcd-87d2-4267-861f-4e83a022e1ca	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:43.610928+00	\N
1f609f53-847a-45a8-ab79-a92067548691	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	e73da2b6-9649-48ca-bf4b-4ccf9871f227	null	{"title": "E2E Workflow Case 1775531861256", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:17:41.260695+00	\N
8d0b57d7-ff7e-4411-970f-100d9788c30f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:17:44.786481+00	\N
92d92b85-1ccc-442f-b6b5-0af5376c8ba5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE	Case	3141b074-65ff-4add-a096-bcb9878af0e6	null	{"title": "Search Case 1775531886133", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado para validar a busca global via E2E."}	\N	2026-04-07 03:18:06.151403+00	\N
954b3fc4-82bb-431b-97e6-1b070f733bbd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:18:11.683899+00	\N
fa162ce1-f179-41d2-98bc-49fc727d70a9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:18:12.821272+00	\N
aeced5c7-33b7-4252-94a5-694b68a1ad7a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:24:55.422059+00	\N
51a644a6-2985-4649-998c-68c845a7e7fd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:49:20.563487+00	\N
28a7e0ef-018e-41c6-9a81-a0ceb1531648	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:49:21.753589+00	\N
73f5a6b1-10c1-4ecd-8cd1-3778a16f166a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:49:26.061923+00	\N
f23c7b9f-5aba-4e5b-b18b-91627e7b2015	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 1}	\N	2026-04-07 04:49:31.105205+00	\N
13253124-ebd6-4e6c-aec5-b3cf3c5bdbc0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:49:41.532274+00	\N
9d5d06c6-1730-4627-ad30-5ffc2f576c3e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 04:49:46.866959+00	\N
d0c74227-d87d-4643-a1c1-eb2c70e01478	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_JSON	ReportPackage	908994f0-b260-478e-927d-803cebd6a005	null	null	\N	2026-04-07 04:49:46.978477+00	\N
09288b16-3d84-42a6-8f34-68e0dbf89345	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	08150300-1e4c-420b-b78b-b08f5ace85a5	null	{"title": "E2E Auditor Export 1775537387355", "severity": "MEDIUM", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 04:49:47.374659+00	\N
45992ef9-5541-4216-ac92-10481f0e7478	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	EXPORT_REPORT_JSON	ReportPackage	77397113-347a-40a9-9b9c-a5bc199262c7	null	null	\N	2026-04-07 04:49:47.782694+00	\N
7a7f59ef-21b6-494c-a630-9ab9dcf61b96	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	SET_MAINTENANCE_MODE	SystemFlag	\N	\N	{"enabled": false}	\N	2026-04-07 04:49:50.916663+00	\N
7f2dfe8f-1f84-4258-92fa-e157d8c15626	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	95a6b4ac-f960-4fb7-a7ab-d106bcf625e0	null	{"title": "E2E Audit Export 1775537393760", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 04:49:53.765242+00	\N
1f8eab9d-3ed8-4e4c-9f0f-4e6ffc75757a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_PDF	ReportPackage	385291a2-4755-498b-940a-4d293da609ed	null	{"case_id": "95a6b4ac-f960-4fb7-a7ab-d106bcf625e0"}	\N	2026-04-07 04:49:53.883881+00	\N
f178334f-f85b-4034-9227-ec798ae0f536	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_COMMENT	Case	e73da2b6-9649-48ca-bf4b-4ccf9871f227	null	{"length": 47, "mentions": []}	\N	2026-04-07 03:17:42.403622+00	\N
bb3aaead-405e-4d20-90b0-13874bd46577	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	7a245cbf-ef16-40e2-8c88-041c129ca71a	null	{"title": "E2E Narrative Suggestion 1775531864801", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:17:44.83012+00	\N
dac3df26-98d9-4ed2-bc91-f795c7ec351a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:57.333438+00	\N
1947169a-1a48-4646-9f72-1a37f053d0ae	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:19:54.390519+00	\N
cc27e14e-51b2-4dd7-9d3b-b890efa20b42	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:24:34.400783+00	\N
1e926618-70b4-4f00-90b8-5c5515b46d74	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:24:39.520364+00	\N
b682a3ef-7817-4e3e-bfa5-83df4e75d1b2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:24:44.999609+00	\N
6595a675-cb41-46aa-8907-8c6e5aafb82c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:48:58.110569+00	\N
0e185023-99ab-441e-a85a-e6db5327a8a8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:49:31.068645+00	\N
561c375c-54fe-4f88-a420-fed56587be1c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:49:34.545598+00	\N
46b65c6e-8ecc-433f-ab11-89c16611eb49	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 04:49:47.330115+00	\N
240b1161-e4fe-4044-93a4-c575732832ca	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:49:50.855783+00	\N
065fbbc0-4075-41ca-ba88-66762175f820	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 04:49:53.734614+00	\N
1697a3a7-ef25-4619-b328-676744d31aa7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	95a6b4ac-f960-4fb7-a7ab-d106bcf625e0	null	{"decision": "FILE_SAR", "report_id": "83016b0c-b9f0-4c55-b153-e9eea80497b7", "pdf_sha256": "ccdff1b80752992e71f4fa293dd06c9fd8f6aa07aba4f2d039e6ee6434a88086", "payload_sha256": "9642bd2855eb6f2d505a427b91e76687702a16dd3de14cec36d85bdbc98f91e5"}	\N	2026-04-07 04:49:53.825388+00	\N
3b268e16-005e-4fa2-8c39-00510fba43e8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.1	2026-04-07 04:49:54.203478+00	\N
43a9bbe6-35da-46b9-8fb3-ef67d5db609c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	e73da2b6-9649-48ca-bf4b-4ccf9871f227	null	{"decision": "NO_ACTION", "report_id": "7b032d8c-35ed-4be7-91b2-4c28c7cd7a4d", "pdf_sha256": "64329ae2044f5712dd7154e7926b8c48f56e14ad56c60ad9189b9b33217f6574", "payload_sha256": "b797234aafe24441d643ae8141d41cc8d6d2857e413d227f444758b81d1892e8"}	\N	2026-04-07 03:17:42.553882+00	\N
f746b862-73f4-40f3-8488-4a52ee68a2a2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:17:56.3797+00	\N
563cb464-c0c5-4f5f-8c7d-52220743e2a5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:18:06.121491+00	\N
9f845016-11ed-47f0-9e8f-1331b34d7988	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:18:07.103021+00	\N
5277149e-890e-4156-8445-dcc64f58183e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:19:14.590494+00	\N
82ce05e5-3b40-4434-8564-77086010315f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:49:23.831602+00	\N
0fc25500-3904-48ac-9cf7-a79151177ed2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 100000}	\N	2026-04-07 04:49:31.210132+00	\N
4551b505-f1db-4b94-b9fb-6e3d7f540f43	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:49:34.1174+00	\N
446eb51b-face-43f3-9f17-7c88d8f3d7c3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:49:38.097024+00	\N
70c49ec5-6656-49c8-a2f6-dffe5386771b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	216f8b56-54a1-42aa-b69f-cb19a82a689a	null	{"decision": "NO_ACTION", "report_id": "ba3cefd0-3548-49e6-970c-1574a9e0f5c5", "pdf_sha256": "14ebdea1a92190836eeb5d8825d01ad7a0ffed0f137b668814c76275858a0c8b", "payload_sha256": "89c5b5337184a3667ac4eb3acf29387449e1a4f269849efac28afcbbac1ab456"}	\N	2026-04-07 04:49:46.929672+00	\N
5779f6ef-5ef2-452d-b97f-fbdeb15933f2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.1	2026-04-07 04:49:47.77248+00	\N
e6b6b349-a973-49d5-b58c-c036cec7368f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	SET_MAINTENANCE_MODE	SystemFlag	\N	\N	{"enabled": true}	\N	2026-04-07 04:49:50.88789+00	\N
a2b49d5c-6625-46c3-9d3b-3519ce7fd79b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	95a6b4ac-f960-4fb7-a7ab-d106bcf625e0	null	{"new_status": "PENDING_REVIEW"}	\N	2026-04-07 04:49:53.795481+00	\N
79a772ed-aa9f-4aab-af0e-16a29d3374b3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_JSON	ReportPackage	385291a2-4755-498b-940a-4d293da609ed	null	null	\N	2026-04-07 04:49:53.869636+00	\N
a8d1185c-80e0-4b1e-9548-3be613a19e1b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:51:53.676373+00	\N
2b59020c-491c-4afe-b7d3-fe3a62a4411e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:47.076454+00	\N
adf7ac77-0dd8-427a-a4cd-d05408bc5c91	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:48.490675+00	\N
9515d3d4-b107-4ae5-922b-9772de09d997	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:49.992834+00	\N
b097066c-6115-4a32-8b80-0aa9b4cd9615	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:17:51.780148+00	\N
74c7cd6d-0e0f-4e91-8d6f-84093882242f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:19:56.585334+00	\N
5bcf5768-85cc-4613-8b65-a798aec51348	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:25:00.097383+00	\N
64e30fa2-ba36-4028-b122-c7baba0f22cd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:49:35.017083+00	\N
7e27078b-eaa5-4a48-b3a2-d92d71dd673f	40e341ad-cf4a-484b-9926-3d56cc58fa1f	e653024a-8bee-46b0-ae12-63177bb0dc61	LOGIN	User	e653024a-8bee-46b0-ae12-63177bb0dc61	null	null	172.18.0.1	2026-04-07 04:49:38.396089+00	\N
10b90dba-9cb4-44ea-a945-1a22fa089f32	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_PDF	ReportPackage	908994f0-b260-478e-927d-803cebd6a005	null	{"case_id": "216f8b56-54a1-42aa-b69f-cb19a82a689a"}	\N	2026-04-07 04:49:46.99298+00	\N
b842f33b-832a-481d-95cc-fad596b03fd0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	95a6b4ac-f960-4fb7-a7ab-d106bcf625e0	null	{"new_status": "CLOSED"}	\N	2026-04-07 04:49:53.809726+00	\N
2a369ce6-245b-4b58-ae77-706d28ef0566	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	DOWNLOAD_COAF_XML	Case	95a6b4ac-f960-4fb7-a7ab-d106bcf625e0	null	null	\N	2026-04-07 04:49:53.90141+00	\N
d38b9152-11b1-48d4-9f8b-00b06a4b65b6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:49:58.612924+00	\N
bbdc5ab8-e38c-4561-b9d0-fa9913c22b9b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	216f8b56-54a1-42aa-b69f-cb19a82a689a	null	{"title": "E2E Report Export 1775537386902", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 04:49:46.906942+00	\N
040c484f-5bb5-4663-b3a0-c7ddae6c252a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	08150300-1e4c-420b-b78b-b08f5ace85a5	null	{"decision": "NO_ACTION", "report_id": "dafc5b90-1e19-483f-aedb-814d900d25ab", "pdf_sha256": "7bb0034b919e06814f0a78ef7f90734a5a5e7006802bb873b70dc78e89860219", "payload_sha256": "8abbbc0976a88a612513bd70c90ac0528b157e19624c8a1368398331108f1de4"}	\N	2026-04-07 04:49:47.40483+00	\N
706307c9-cfa4-4cfc-8acc-147739eef20c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:18:43.210278+00	\N
c1a668cf-6f67-4d93-aace-982a8f2a6d87	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:18:44.427963+00	\N
12de73cc-1e44-4c66-9840-995933175719	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:19:23.050226+00	\N
e86ab61a-a064-4e9f-a02e-1637c235c0f4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:19:55.694261+00	\N
25ba30f6-6fe5-4d6f-8cfa-c74a991104a3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	95a6b4ac-f960-4fb7-a7ab-d106bcf625e0	null	{"new_status": "INVESTIGATING"}	\N	2026-04-07 04:49:53.780876+00	\N
dbc5439a-fee1-42b1-a823-558aed537af4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:20:00.617091+00	\N
dc22a00f-040d-4ca9-be3c-566523cecbab	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:24:33.311733+00	\N
bf5bd199-3088-4bc0-a57c-c783052c5076	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:24:41.758918+00	\N
cb96ea57-61d8-4e81-8c4f-db20fa9fb107	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:24:43.068221+00	\N
1b982557-cc0e-4923-b99c-32030cfa0e94	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:24:52.683758+00	\N
67e1f3b9-c193-456a-a57d-78a41123d354	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:24:58.876021+00	\N
ba0ddab2-818d-4d54-bab0-0f8e06dd50af	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:51:53.97862+00	\N
122e5801-d715-48a7-bcd2-46105cb43666	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:25:00.993379+00	\N
b7030b75-6848-4d53-9faa-33d027b7ebaa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:25:03.281407+00	\N
45b99cc4-cdcd-47ff-a18b-3d0bea2bfa6a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE_PLAYER_LIST	PlayerList	ca3df0be-8eb7-4d0f-be7f-9f85774e505a	null	{"name": "[REDACTED]"}	\N	2026-04-07 03:25:05.786686+00	\N
20ac6bb1-af27-4a0f-9b5d-30bba0d4c7ba	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:25:37.262497+00	\N
01f45a59-8909-4bde-8b1c-c886564cd5ea	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:25:38.606278+00	\N
b87bbd9b-d3eb-4daf-84aa-a44d1d338fa8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:25:56.760836+00	\N
bbd820ce-1336-4364-9767-41e28e52c6de	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:25:57.992978+00	\N
393c8f94-cb46-4027-97c7-464063033ba8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:26:31.786061+00	\N
1064c781-d691-4a19-9100-5760705bcb75	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:26:35.469449+00	\N
d756b8ca-aaba-41a3-a246-7fbb78b28478	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:26:37.565133+00	\N
b12b7fee-dbfe-4936-9cd4-e2bada62deb9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:26:38.900183+00	\N
7cf4e032-f4dc-4c24-9d77-1ab6d70d8847	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	1e305969-7e4a-42fa-bee8-7027f6591fce	null	{"title": "E2E triage alert 1775532398924", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:26:38.948593+00	\N
3aa1c745-321d-40e2-a3b3-e129bfb1e241	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	TRIAGE	Alert	1e305969-7e4a-42fa-bee8-7027f6591fce	null	null	\N	2026-04-07 03:26:40.235739+00	\N
20574675-ec40-4e35-882a-d84da2a3ccc2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:26:41.486874+00	\N
3e680fc2-cd66-4adc-98d4-135670546ef8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:26:42.847671+00	\N
615f196e-4c4a-4bde-abc1-e0cc03dba29f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	61e3a1d9-a460-42ae-8b54-904752357b87	null	{"title": "E2E link alert 1775532402863", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:26:42.902666+00	\N
2adf6054-51bf-49f2-9f51-bbf658d92dd9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	a451aa80-ae65-42a6-b94e-e8c098eead5b	null	{"title": "Case for alert link 1775532402921", "severity": "MEDIUM", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:26:42.949893+00	\N
ff3f87ad-cbe4-4e9a-a930-bc63593b0a08	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LINK_ALERT	Case	a451aa80-ae65-42a6-b94e-e8c098eead5b	null	{"alert_id": "61e3a1d9-a460-42ae-8b54-904752357b87"}	\N	2026-04-07 03:26:43.832339+00	\N
41873a92-beb5-4086-818e-e94a28ed0bdc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:26:44.93657+00	\N
d5c2ccc4-bfb6-4201-9e22-3075008c97cb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:26:46.167546+00	\N
4ac17224-dad4-4473-b9ad-1829f5172f6e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	3f4ffee2-c4f1-4f7e-b663-7c20de8eb25b	null	{"title": "E2E close and label alert 1775532406194", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:26:46.227363+00	\N
d3c905e2-5c38-4113-b93f-782510613f6d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LABEL_ALERT	Alert	3f4ffee2-c4f1-4f7e-b663-7c20de8eb25b	null	{"label": "FALSE_POSITIVE", "label_note": "Feedback de qualidade via Playwright"}	\N	2026-04-07 03:26:47.098394+00	\N
b812fea8-899f-4605-b92c-94b4bea6cf8c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CLOSE	Alert	3f4ffee2-c4f1-4f7e-b663-7c20de8eb25b	null	null	\N	2026-04-07 03:26:47.236802+00	\N
a5cae3a9-01fb-4e7d-836a-ff35b55e6d4b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:26:48.999209+00	\N
aa98d6a4-7fd7-4868-853c-46c4399a74ab	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:26:51.893629+00	\N
223ee489-d0ad-4cd0-8ca7-32bd14cae546	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_COMMENT	Case	daf0619d-d49a-44d9-91ff-f72e37bc8a5e	null	{"length": 47, "mentions": []}	\N	2026-04-07 03:27:04.148967+00	\N
e421ebdc-e2ee-487c-a080-da4963ef124c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:27:13.356434+00	\N
5c1a7e8a-385d-46f9-9a70-c8fbed17688a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:27:17.547985+00	\N
b41c1d84-abd7-416f-8a27-805082f6f56b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:27:33.668487+00	\N
26e518bd-f689-4829-a6de-108fda30e6e7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:27:39.138519+00	\N
a5ab94bb-8b17-407a-b756-e373168093b6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cfc988d-8513-443c-8d90-da05dd2fac23	LOGIN	User	8cfc988d-8513-443c-8d90-da05dd2fac23	null	null	172.18.0.1	2026-04-07 05:04:03.3749+00	\N
dd40f1b8-35dc-4961-9937-c4406fea022c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cfc988d-8513-443c-8d90-da05dd2fac23	LOGIN	User	8cfc988d-8513-443c-8d90-da05dd2fac23	null	null	172.18.0.11	2026-04-07 05:04:10.681175+00	\N
7dd0037f-19f2-4910-a72c-d8b1c97a252e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:26:53.827506+00	\N
110e7dcb-45bc-4276-95dc-70bc5279bef7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:27:03.03667+00	\N
1493a05b-89b8-469d-8d80-dd26604eea91	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	daf0619d-d49a-44d9-91ff-f72e37bc8a5e	null	{"title": "E2E Workflow Case 1775532423073", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:27:03.078159+00	\N
d252e620-3710-4ec7-93bc-ec0ac76112be	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:27:10.258972+00	\N
a1e9f95e-a58a-407e-bc9e-9e4389a44bdf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cfc988d-8513-443c-8d90-da05dd2fac23	LOGIN	User	8cfc988d-8513-443c-8d90-da05dd2fac23	null	null	172.18.0.1	2026-04-07 05:05:06.405951+00	\N
9d417266-c2ac-4349-b028-5f6ed9ea2201	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:27:28.271796+00	\N
26afa31e-66b8-472f-acfe-8309b63ed815	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	EXPORT_MONTHLY_SUMMARY_JSON	Report	2026-04-01:2026-04-07	null	{"date_to": "2026-04-07", "date_from": "2026-04-01"}	\N	2026-04-07 03:28:14.726953+00	\N
6ab1bdcb-63bd-4980-aca8-32b7b7f5b370	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:26:55.879418+00	\N
8b91f219-82b2-48ac-99d7-b5f11b0e8e80	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:27:11.744081+00	\N
d3f4a68b-5240-44f4-8650-c748cb8bc136	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cfc988d-8513-443c-8d90-da05dd2fac23	LOGIN	User	8cfc988d-8513-443c-8d90-da05dd2fac23	null	null	172.18.0.1	2026-04-07 05:10:12.306983+00	\N
de3c1917-3b19-41a0-b456-fe5c544eaf22	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cfc988d-8513-443c-8d90-da05dd2fac23	CREATE_TENANT	Tenant	9f428c2a-354c-435a-933d-0fcbbf39802a	\N	{"slug": "operador-e2e-1775538611988", "admin_username": "tenant_admin_1775538611988"}	\N	2026-04-07 05:10:12.325651+00	\N
21f8477b-2db2-40b4-9ffe-8ed854649ffd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:27:38.190288+00	\N
48f86807-a905-4b43-8cff-12f2c33f4882	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cfc988d-8513-443c-8d90-da05dd2fac23	LOGIN	User	8cfc988d-8513-443c-8d90-da05dd2fac23	null	null	172.18.0.11	2026-04-07 05:10:19.028433+00	\N
cea12c2d-efb4-46b2-a9ca-450e1e660f03	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cfc988d-8513-443c-8d90-da05dd2fac23	CREATE_TENANT	Tenant	23f4e6fb-ac62-49d9-94d0-078f0aa8924d	\N	{"slug": "operador-e2e-1775538617510", "admin_username": "tenant_admin_1775538617510"}	\N	2026-04-07 05:10:20.475717+00	\N
a12ce55d-1e94-4683-b652-530c039b295b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 05:11:01.934818+00	\N
8a715a2e-af73-4a1b-bb2a-80249619ffdf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 05:11:05.396401+00	\N
0912c97e-616f-4125-a191-2ddb5fda967b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	ed136fe5-5990-4a83-b5dd-b217d7cdc020	null	{"title": "E2E Report Export 1775538678055", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 05:11:18.060058+00	\N
88465283-d549-49e3-867b-8501d4f47961	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	ef28e581-2794-4286-9627-108a7278a3a0	null	{"decision": "NO_ACTION", "report_id": "27be5112-edd1-40d2-aa73-2fc8d2f74786", "pdf_sha256": "d9c21b17f406245909b176841945ea858b897c468f1a8544a4e7546340557c34", "payload_sha256": "6020e2bd3aa9724a59334d4be53a0cc2a93e75178dedab05b5b966d849896a68"}	\N	2026-04-07 05:11:18.705184+00	\N
07324ea7-bc38-47de-bc0b-7c51e1dba5ba	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	e9e5d372-aac2-4a13-aaf7-e15fd25faaaf	null	{"new_status": "INVESTIGATING"}	\N	2026-04-07 05:11:24.973059+00	\N
63257182-dc2a-40ec-8acf-2d0c92aba093	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cfc988d-8513-443c-8d90-da05dd2fac23	CREATE_TENANT	Tenant	d3108642-40e7-4da1-aa68-4a17aac45b10	\N	{"slug": "operador-e2e-1775538688614", "admin_username": "tenant_admin_1775538688614"}	\N	2026-04-07 05:11:31.253621+00	\N
e7155819-2bc9-444b-9d00-7d7ca2619e35	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cfc988d-8513-443c-8d90-da05dd2fac23	LOGIN	User	8cfc988d-8513-443c-8d90-da05dd2fac23	null	null	172.18.0.11	2026-04-07 05:12:05.828368+00	\N
2fa2e43d-9cf6-4c82-adc1-fee40e8008d6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:26:57.856938+00	\N
382dbb07-8c37-4afc-af4d-5db7bb2e0587	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	19d3de12-395f-46ce-9448-b8f95da5b2f2	null	{"title": "E2E Manual Case 1775532418746", "severity": "HIGH", "player_id": null, "description": "Caso criado pela suíte E2E para validar o fluxo manual."}	\N	2026-04-07 03:26:59.848965+00	\N
396408b7-4b8c-4b37-8ae7-45b48f5043da	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	daf0619d-d49a-44d9-91ff-f72e37bc8a5e	null	{"decision": "NO_ACTION", "report_id": "abd4d4ca-c6ba-4a06-b928-3dd1c335058d", "pdf_sha256": "17bc8e0a440901b85a7b35b0c1c7f4856f1bf462458b5a435095f53470a68a39", "payload_sha256": "64bcfaacb09ac114c1a32d816c1a4b8b3295975cd7983f8172a781dbbf3dc0c3"}	\N	2026-04-07 03:27:04.341508+00	\N
3482d093-9989-43ae-847d-ef776d4d1f57	23f4e6fb-ac62-49d9-94d0-078f0aa8924d	8cfc988d-8513-443c-8d90-da05dd2fac23	CREATE_INGEST_SAMPLE_JOB	IngestJob	47385ab9-d4e3-4f38-abb4-8814c99f32a4	\N	{"via": "admin_onboarding", "file_name": "onboarding-1775538617510.csv", "source_system": "ConnectorDelta", "mapping_config_id": null}	\N	2026-04-07 05:10:20.941581+00	\N
273b2479-d6ca-4d83-b422-bf3cce50609e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:27:08.6614+00	\N
1915efac-eccd-45c3-864d-164e5b3081cd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:27:18.479675+00	\N
8f99fb1f-19bb-4a02-9464-66c251e8916d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE	Case	46886398-cbee-4f44-bf79-2a5b3e61770c	null	{"title": "Search Case 1775532440861", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado para validar a busca global via E2E."}	\N	2026-04-07 03:27:20.877473+00	\N
3ec48c17-d307-4523-817a-4dc863baefa7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:27:29.449804+00	\N
e3b86774-e287-4894-9f94-fa9a0e38e3cd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:27:30.867212+00	\N
cdc8b158-3c50-4e1c-b9b3-f3e97018d701	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:27:36.987965+00	\N
9c5040eb-f334-4270-8066-99b4a2baaf39	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:27:47.843237+00	\N
d8b24759-6049-4a45-8561-692e58239b2f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:27:01.817186+00	\N
85364e5e-e314-4d08-b135-ab50503845dd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:27:05.42571+00	\N
f1fc222a-9bb4-49dd-ba87-bad7bbc66478	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:27:06.647262+00	\N
486e53bc-8f2a-4ba6-85ae-3d0e916fab6e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	5f5eca0e-1459-4663-832c-dcf77fd0c30c	null	{"title": "E2E Narrative Suggestion 1775532426663", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:27:06.686427+00	\N
7998ef92-b3bf-4d97-a50f-fd95b4648f0f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:27:20.855444+00	\N
f8084be9-2451-43e4-a491-54f0ccede261	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:27:25.211519+00	\N
4d6da4bf-b63c-40be-9eb8-c46fa48d4a51	23f4e6fb-ac62-49d9-94d0-078f0aa8924d	8cfc988d-8513-443c-8d90-da05dd2fac23	CREATE	RuleDefinition	3805092b-77f2-4eaf-9279-c41d019c7d29	\N	{"via": "admin_onboarding", "name": "Spike de Depósito", "scope": "TRANSACTION", "params": {}, "status": "ACTIVE", "weight": 0.5, "severity": "HIGH", "description": "Detecta depósito de alto valor combinado com frequência elevada nas últimas 24h.", "condition_dsl": "transaction.type == \\"DEPOSIT\\" and transaction.amount > 10000 and features.deposit_count_24h >= 3"}	\N	2026-04-07 05:10:21.159085+00	\N
dde9a147-157e-4fb0-bafb-e84ff5619ffa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 05:10:51.3322+00	\N
110b2c09-73bb-46e2-80ee-dc60f8bd4882	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 05:10:52.554699+00	\N
211812df-cb36-4996-8c3f-e28bb60d159f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_PDF	ReportPackage	f9f7543d-2687-4b43-8a9c-12a597ddca31	null	{"case_id": "ed136fe5-5990-4a83-b5dd-b217d7cdc020"}	\N	2026-04-07 05:11:18.329159+00	\N
cba9fa82-bb85-42fe-a18b-15d30e7320a9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	e9e5d372-aac2-4a13-aaf7-e15fd25faaaf	null	{"new_status": "CLOSED"}	\N	2026-04-07 05:11:25.007729+00	\N
f1fb8dc7-54bc-4ac8-a6cf-067205b464bf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	DOWNLOAD_COAF_XML	Case	e9e5d372-aac2-4a13-aaf7-e15fd25faaaf	null	null	\N	2026-04-07 05:11:25.112685+00	\N
322cfea9-3ac0-4f0a-9e23-81893a1c0e4b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cfc988d-8513-443c-8d90-da05dd2fac23	LOGIN	User	8cfc988d-8513-443c-8d90-da05dd2fac23	null	null	172.18.0.11	2026-04-07 05:11:29.792252+00	\N
5b0dfd6b-5494-4b11-8aa4-585b171adaf3	d3108642-40e7-4da1-aa68-4a17aac45b10	8cfc988d-8513-443c-8d90-da05dd2fac23	CREATE_INGEST_SAMPLE_JOB	IngestJob	75dd17b2-8856-4c59-9aec-4a1750d71d54	\N	{"via": "admin_onboarding", "file_name": "onboarding-1775538688614.csv", "source_system": "ConnectorDelta", "mapping_config_id": null}	\N	2026-04-07 05:11:31.726758+00	\N
a5dfad21-71d0-426e-8c5c-b7ea26ee016c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 05:10:41.249333+00	\N
f91cf4d4-cf3b-4eb2-b6c8-aa905953d3e5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:27:21.985564+00	\N
f3d97f24-9134-4873-bee9-0b95e3963b2d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:27:26.883129+00	\N
d4dbc664-5abf-423d-ab2b-c7078b952050	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:27:41.327969+00	\N
04610120-d081-4ed2-a3a2-c91a049e9d96	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE_PLAYER_LIST	PlayerList	6771112b-e53a-4487-b6a5-36df24490af4	null	{"name": "[REDACTED]"}	\N	2026-04-07 03:27:43.247278+00	\N
d93a11d2-f8ad-42e2-aa4e-c3e323dd6c83	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:27:50.401081+00	\N
0f0adfae-1eba-41bd-a72c-6b55d83cb40c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:27:51.421173+00	\N
b9a016a7-667c-4e69-9721-c08fe072936e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:27:59.065696+00	\N
753b53ed-45f1-481f-a486-d4832c466eea	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:28:00.156549+00	\N
1a8c4e78-7fc7-433a-91e0-cff9488c771c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:28:08.583974+00	\N
4daacb91-713b-454f-9776-adda15dce6e7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:28:12.181633+00	\N
57b168f8-c5fa-4633-aa46-8435c00ade94	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	GENERATE_MONTHLY_SUMMARY	Report	2026-04	null	{"year": 2026, "month": 4}	\N	2026-04-07 03:28:14.887933+00	\N
4b36ed24-c847-4d3f-aa82-62735d1a1439	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:33:27.72778+00	\N
db7b75cc-1291-4855-ad16-7b9c6ed1bd87	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:33:29.845021+00	\N
34093a17-c06d-41c3-b678-4a20b5adc3e5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:33:33.879577+00	\N
564f1168-40e1-45bd-8711-c40c281147a6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:33:34.915991+00	\N
3e15b4e3-a071-4939-98fb-f9c9a5b620d3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:33:50.09576+00	\N
ec82829a-8c5e-4237-96c4-0a864656a527	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:33:53.280555+00	\N
a5d2fb2c-c01e-465f-8201-0bf26a7ec291	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:33:55.316802+00	\N
df7f44cb-dfbc-4291-93e0-715d59e1e44e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:33:56.635581+00	\N
eb8325dc-a609-4307-b74d-e732377db5d7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 05:10:56.985188+00	\N
a5facb43-0103-4f70-a0aa-a999bbae0546	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	23a44fd1-3e1c-4275-912e-4e80e13a61b5	null	{"title": "E2E triage alert 1775532836658", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:33:56.694591+00	\N
e6f34d9d-0fcf-400b-be02-2121ced794e9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	TRIAGE	Alert	23a44fd1-3e1c-4275-912e-4e80e13a61b5	null	null	\N	2026-04-07 03:33:58.335573+00	\N
affb27c6-bd05-4aa4-b1aa-e1f43dcc6f8c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:33:59.475269+00	\N
ee83ae4d-880a-42cd-b280-cf4219c1f797	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:34:00.850445+00	\N
ad9bfeaa-50a6-4291-a78a-732c2b596c6c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	6faf53e2-169c-4f8b-bbc4-82c95d06495d	null	{"title": "E2E link alert 1775532840861", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:34:00.884841+00	\N
20a7a40d-74e6-4ec4-8685-c4f471dce0fe	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	2c80aa82-4998-4e1c-8a64-f699f78de516	null	{"title": "Case for alert link 1775532840894", "severity": "MEDIUM", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:34:00.910324+00	\N
d20783de-2e4a-451a-b2c2-4c7c2de4ea2a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LINK_ALERT	Case	2c80aa82-4998-4e1c-8a64-f699f78de516	null	{"alert_id": "6faf53e2-169c-4f8b-bbc4-82c95d06495d"}	\N	2026-04-07 03:34:01.750832+00	\N
80c23c3d-6f26-46b4-967b-44fb14187e5e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:34:02.994364+00	\N
dd53ef80-ceee-4ff9-affb-46240ec8cea0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:34:04.190981+00	\N
1947e86b-d19d-4a9d-9b61-aa2c299d6cd0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	7ddf87ff-cadd-461e-9b13-4cc42abbee58	null	{"title": "E2E close and label alert 1775532844207", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:34:04.232899+00	\N
6453a312-d5db-4f29-9a74-c702f7624176	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LABEL_ALERT	Alert	7ddf87ff-cadd-461e-9b13-4cc42abbee58	null	{"label": "FALSE_POSITIVE", "label_note": "Feedback de qualidade via Playwright"}	\N	2026-04-07 03:34:05.0883+00	\N
955c8642-dc6c-4b38-9d9b-11b04f20645b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CLOSE	Alert	7ddf87ff-cadd-461e-9b13-4cc42abbee58	null	null	\N	2026-04-07 03:34:05.234219+00	\N
52a2cd20-88c5-4f16-b06c-0cb91a17152e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:34:07.030855+00	\N
c3f05f56-9c7f-43b6-839a-8ac858a13f51	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:34:10.157793+00	\N
2067e8e9-9784-40ac-8bd9-936ef9da0a38	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:34:12.084632+00	\N
4f44f2d6-0705-425c-a9ea-e0e8cad268cd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:34:14.096482+00	\N
dd41f8c8-039b-4216-9060-728c2f16bc6c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:34:16.196032+00	\N
4de51ca6-207f-423a-927d-29763d76ff90	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	fb7d6cfd-57c2-42f9-b2be-08ae202cebe5	null	{"title": "E2E Manual Case 1775532857190", "severity": "HIGH", "player_id": null, "description": "Caso criado pela suíte E2E para validar o fluxo manual."}	\N	2026-04-07 03:34:18.216291+00	\N
2598d4f1-3c8a-44f7-b6d3-1e66b74e3521	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:34:20.239813+00	\N
ef9fa9a8-3d9f-4269-ae49-4710a2c60ac7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:34:21.414266+00	\N
806e0eba-e249-4498-9035-27163eaebc0b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 05:10:43.089231+00	\N
8d03c776-caae-4bb1-adb8-20d75348b9b3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:34:25.361766+00	\N
fc1494dc-ae2d-4c6b-a529-4024347247a9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 05:10:54.517018+00	\N
530006be-3e10-4ee0-b879-a33bf89c4aa7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:34:28.994029+00	\N
f0260ac8-3eeb-4a03-932f-160ba2bb5e1c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:34:30.543139+00	\N
dac2e7ec-ae43-499a-9add-e51b27f29ff1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:34:32.269559+00	\N
05090302-e063-4a72-bd1d-948e0319691e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 100000}	\N	2026-04-07 05:11:02.089792+00	\N
4e914b94-66f6-42bf-b2e8-579b3eff7c27	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:34:53.858904+00	\N
f07809c4-9e07-45f4-b0ec-63f28464786a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:35:10.940407+00	\N
03f0dfa6-c337-43a5-81de-e99a8fad53aa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 05:11:04.986418+00	\N
9ca707d1-7bea-4e11-ad06-8e99c7fd1b20	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:38:06.784665+00	\N
20feae05-0b69-4c02-921f-be97e0154f81	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:38:34.507739+00	\N
04a586b5-b6e9-4a00-a8ca-cfcf66abbc02	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	c7387d28-773f-440b-a438-08a66a589990	null	{"title": "E2E triage alert 1775533118359", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:38:38.390484+00	\N
8c7c5076-714b-46ba-8f5e-811e6ff36e91	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	72723df7-a958-4add-b419-6d36a14a560d	null	{"title": "E2E close and label alert 1775533126276", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:38:46.302064+00	\N
16bd7b60-e32f-41c9-9b45-874aafb3fa47	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CLOSE	Alert	72723df7-a958-4add-b419-6d36a14a560d	null	null	\N	2026-04-07 03:38:47.293221+00	\N
50ac6156-0af3-4b79-90ee-480bb2c4e4c8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 05:11:08.954032+00	\N
3859a4dd-7b76-4674-8657-e140b78f8c18	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 05:11:18.644243+00	\N
4595dc60-674c-4c07-8aed-82ea7fb263a8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 05:11:21.947948+00	\N
b2174b54-4012-4e31-a7a2-1cc2d4fcf93a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 05:11:24.920974+00	\N
6a3626c5-68f1-4982-9dae-96c2093bfd0d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	e9e5d372-aac2-4a13-aaf7-e15fd25faaaf	null	{"decision": "FILE_SAR", "report_id": "f5bc91f2-19dd-46b1-9f3a-519406ee305b", "pdf_sha256": "e55e7c8a89a4da79f77ba3ba656cae4ac004b0b59e590fb5426f124f68f4254f", "payload_sha256": "320770a080a61b5e634ef8cb572709148ffc1ca4608b206c3bec5adcd0478f69"}	\N	2026-04-07 05:11:25.023909+00	\N
947ab719-eb1f-4c85-bcbf-dd5ef35a4b72	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.1	2026-04-07 05:11:25.401905+00	\N
17237c57-9e46-4577-b890-b2fabf9dc9cf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cfc988d-8513-443c-8d90-da05dd2fac23	CREATE_TENANT	Tenant	ace787b5-e77f-4947-a83d-5e3333d063ed	\N	{"slug": "operador-e2e-1775538718617", "admin_username": "tenant_admin_1775538718617"}	\N	2026-04-07 05:11:59.246302+00	\N
1fc448e7-e972-4f13-877b-e772aeac64fa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	29a33c2e-9730-4576-abc3-fd77bd81a53f	null	{"title": "E2E Workflow Case 1775532861447", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:34:21.451256+00	\N
9d1b555d-b239-4da3-926d-b5c78cd1a5cc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_COMMENT	Case	29a33c2e-9730-4576-abc3-fd77bd81a53f	null	{"length": 47, "mentions": []}	\N	2026-04-07 03:34:22.513532+00	\N
9c690f30-e02c-4fb3-8f06-ae6a870f0e06	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:34:37.264958+00	\N
806e4788-e370-4594-97bf-18394ec0c0b2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE	Case	4df9ae34-69d1-4e79-a2cb-53cfce07bcc0	null	{"title": "Search Case 1775532880498", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado para validar a busca global via E2E."}	\N	2026-04-07 03:34:40.515264+00	\N
f33965e2-a0fa-4eb3-a58e-c52985157490	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 1}	\N	2026-04-07 05:11:01.967786+00	\N
43c647cf-49a4-477b-bffe-8ffeefec2538	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 05:11:12.431948+00	\N
5e6973e1-9c27-4fc6-ac18-780d363674ca	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	ed136fe5-5990-4a83-b5dd-b217d7cdc020	null	{"decision": "NO_ACTION", "report_id": "427bddb4-0471-4b5c-b46a-da1f0b32fa85", "pdf_sha256": "45eefde0ee00921d14c813cefaf1e1cc24390a55a09f6a0271b0e5a77025d789", "payload_sha256": "5717ba3d499823eefa58c6021967a8db89c71a7b03a0d38d34468d43aac35e3a"}	\N	2026-04-07 05:11:18.087472+00	\N
4129d023-c155-4f5f-ba1f-6ed42ecbd798	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.1	2026-04-07 05:11:19.020374+00	\N
06928362-572e-451a-8ed6-48d56617c21d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	SET_MAINTENANCE_MODE	SystemFlag	\N	\N	{"enabled": true}	\N	2026-04-07 05:11:21.979184+00	\N
a5ae36a1-aa31-4be8-bd5b-2b9b1b53a7ee	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_STATUS_CHANGE	Case	e9e5d372-aac2-4a13-aaf7-e15fd25faaaf	null	{"new_status": "PENDING_REVIEW"}	\N	2026-04-07 05:11:24.991105+00	\N
3a192a48-859a-484c-ba0e-9ac79367e689	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_JSON	ReportPackage	5cea27d3-001d-486c-b9a2-7ff8f7436a73	null	null	\N	2026-04-07 05:11:25.076614+00	\N
35439aa3-9e87-473e-8743-3855d861611f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 05:11:57.515845+00	\N
38897b53-d081-4117-afa3-69e86a394474	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	29a33c2e-9730-4576-abc3-fd77bd81a53f	null	{"decision": "NO_ACTION", "report_id": "55deb976-0de5-4e86-b0a2-508ac5071ebe", "pdf_sha256": "08d880ceba365dcbf806cd11bcbb6845e7e5d70432e3b791da6edada5706ba93", "payload_sha256": "bd7a9d84926697de6084736a43ed272d8ca8c0cecbd7f53916e595989ec59263"}	\N	2026-04-07 03:34:22.665415+00	\N
46c0f9ab-5d57-47e9-a37c-126f096c7be2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:34:38.24119+00	\N
640dc865-586d-448c-9d85-a6a1d4b61fdb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:34:40.492038+00	\N
8e81ae45-5341-4a34-bcd3-5d00823fc093	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:34:41.575851+00	\N
54e9474a-b2c6-4dc7-a053-9f0d4e25246a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:34:46.677383+00	\N
861d20e7-552c-457f-9f69-eef61d682850	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:34:49.337695+00	\N
8f305709-9dbe-4582-958c-9e667c6261a6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 05:11:05.811235+00	\N
f8f3778d-45cc-4d60-b06f-285aa9d0cff8	40e341ad-cf4a-484b-9926-3d56cc58fa1f	e653024a-8bee-46b0-ae12-63177bb0dc61	LOGIN	User	e653024a-8bee-46b0-ae12-63177bb0dc61	null	null	172.18.0.1	2026-04-07 05:11:09.263288+00	\N
3dbae333-dd55-498b-ba13-66f9581672a9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 05:11:18.016755+00	\N
1d324c39-96a1-41d5-b68c-6d1e71fae720	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_JSON	ReportPackage	f9f7543d-2687-4b43-8a9c-12a597ddca31	null	null	\N	2026-04-07 05:11:18.313627+00	\N
36d092f2-70d5-444f-8c0f-6b61d09c42a2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	ef28e581-2794-4286-9627-108a7278a3a0	null	{"title": "E2E Auditor Export 1775538678666", "severity": "MEDIUM", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 05:11:18.671793+00	\N
3a8fcbfa-823f-43c6-a671-4ada23ca562e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	EXPORT_REPORT_JSON	ReportPackage	e6203490-ae88-4da7-a33d-b3c81e640a06	null	null	\N	2026-04-07 05:11:19.029881+00	\N
ae792def-4bfc-4a9a-9e48-80ab8fdc9146	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	SET_MAINTENANCE_MODE	SystemFlag	\N	\N	{"enabled": false}	\N	2026-04-07 05:11:22.011662+00	\N
aa9bd317-b13d-40d8-bc27-c312d23f1bf3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	e9e5d372-aac2-4a13-aaf7-e15fd25faaaf	null	{"title": "E2E Audit Export 1775538684952", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 05:11:24.956478+00	\N
f37ec069-848b-4151-bce0-e490e48024e7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_PDF	ReportPackage	5cea27d3-001d-486c-b9a2-7ff8f7436a73	null	{"case_id": "e9e5d372-aac2-4a13-aaf7-e15fd25faaaf"}	\N	2026-04-07 05:11:25.09389+00	\N
8ed5750f-7f2c-4ec5-b49c-8e70e3ad94db	d3108642-40e7-4da1-aa68-4a17aac45b10	8cfc988d-8513-443c-8d90-da05dd2fac23	CREATE	RuleDefinition	6b543bdf-c077-4bd8-a931-1f3027d66e8d	\N	{"via": "admin_onboarding", "name": "Spike de Depósito", "scope": "TRANSACTION", "params": {}, "status": "ACTIVE", "weight": 0.5, "severity": "HIGH", "description": "Detecta depósito de alto valor combinado com frequência elevada nas últimas 24h.", "condition_dsl": "transaction.type == \\"DEPOSIT\\" and transaction.amount > 10000 and features.deposit_count_24h >= 3"}	\N	2026-04-07 05:11:31.97926+00	\N
d4aeeb12-815d-4d0c-bca4-10bb87d66338	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cfc988d-8513-443c-8d90-da05dd2fac23	LOGIN	User	8cfc988d-8513-443c-8d90-da05dd2fac23	null	null	172.18.0.1	2026-04-07 05:11:59.232637+00	\N
c8c1aaee-91c3-418e-ac86-23b761d0244d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:34:24.136096+00	\N
3d415945-5f0b-47b4-9c85-9fc98a4dbb5f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:34:27.536815+00	\N
baa98483-ee58-44e9-ac66-69c224b5b42e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cfc988d-8513-443c-8d90-da05dd2fac23	CREATE_TENANT	Tenant	71825dca-3ce0-4230-a48d-da36c09148cd	\N	{"slug": "operador-e2e-1775538724541", "admin_username": "tenant_admin_1775538724541"}	\N	2026-04-07 05:12:07.055717+00	\N
2d05ba23-30a2-4901-9c64-e0d3d47a103a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:38:10.256597+00	\N
b3272280-5096-4023-a850-fe3f507fa2cf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	TRIAGE	Alert	c7387d28-773f-440b-a438-08a66a589990	null	null	\N	2026-04-07 03:38:40.011019+00	\N
c84d3c9e-212a-4201-b1b2-1113851b016f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:38:56.704072+00	\N
816e2f66-fb85-4043-87fb-81bd52d8a87d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:39:00.988713+00	\N
9245b93f-a8e2-41d7-9c57-08f0222f38a9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 05:12:37.902266+00	\N
8a61f779-d46d-4dfa-9934-0594672754ff	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	33399e7e-20db-41e6-938a-d9fcd48ed71a	null	{"title": "E2E Narrative Suggestion 1775532865376", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:34:25.401552+00	\N
1395c37d-6962-4f8a-93ed-607c4d8744b4	71825dca-3ce0-4230-a48d-da36c09148cd	8cfc988d-8513-443c-8d90-da05dd2fac23	CREATE_INGEST_SAMPLE_JOB	IngestJob	1da7e721-9b47-4b0b-aba8-17ea4096b923	\N	{"via": "admin_onboarding", "file_name": "onboarding-1775538724541.csv", "source_system": "ConnectorDelta", "mapping_config_id": null}	\N	2026-04-07 05:12:07.559773+00	\N
640a718a-878e-4cf8-9472-aed4dde3939d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:34:44.931443+00	\N
f9eb5eba-99b6-4148-8939-7922d4fa789b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:34:48.04462+00	\N
8b4b5cbe-abc7-4357-826b-19c43efda9b7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:34:50.763254+00	\N
6f3c76bd-aa92-48d5-ad80-d985b44551a0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:35:08.685346+00	\N
88cdee4e-61b0-4ab4-bf8e-d82f046b59ea	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:35:09.959563+00	\N
28cf2e1b-0d0e-487a-b69a-febfcaa4ba09	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:35:13.268378+00	\N
afae47ce-701b-47c7-9478-ee9a0495b86b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE_PLAYER_LIST	PlayerList	a3c7c220-e848-4cea-abf4-bda581a90d19	null	{"name": "[REDACTED]"}	\N	2026-04-07 03:35:15.154194+00	\N
81ce35e9-df99-402a-b70c-02b5400233fd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:38:04.317322+00	\N
0efd0c1d-53ad-4f69-9f22-3ffcd67a2aad	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LABEL_ALERT	Alert	5574a59a-b40b-4dd1-9719-734ba7699a96	null	{"label": "FALSE_POSITIVE", "label_note": null}	\N	2026-04-07 05:12:38.257919+00	\N
e57155d2-df27-4f82-bf9c-b3ed49006a40	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:38:11.625053+00	\N
d3e803ee-63f4-4305-a422-fedceb7ec387	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:38:12.581143+00	\N
0e4cffd2-4a35-4d9a-8c1a-05d710087295	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:38:31.810853+00	\N
81862af1-e35a-4f14-84af-4c0f82bb03d6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:38:37.040232+00	\N
0d801b88-e124-4833-95d7-91aaca80a68f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:38:38.334359+00	\N
20867fe3-fdfa-472b-9f46-7e4a848aa052	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:38:41.493059+00	\N
d52ea36a-387b-4021-a2e4-1a5386d96565	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:38:42.870463+00	\N
39107778-d753-4e55-911f-257cae2255e3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	3545d5c8-ca54-4426-9ba9-e7505a91cb9c	null	{"title": "E2E link alert 1775533122906", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:38:42.974891+00	\N
670da0ef-26a7-42a5-aa7a-5344ac46a268	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	e6aaf58a-1466-4728-bada-045db352f214	null	{"title": "Case for alert link 1775533123012", "severity": "MEDIUM", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:38:43.042497+00	\N
b30dea87-7141-4725-bdb1-d0e42586d3d1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LINK_ALERT	Case	e6aaf58a-1466-4728-bada-045db352f214	null	{"alert_id": "3545d5c8-ca54-4426-9ba9-e7505a91cb9c"}	\N	2026-04-07 03:38:43.890037+00	\N
4f275c3f-a68b-4cf6-af8c-a45d63c77e06	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:38:45.024671+00	\N
06a3a5b1-2081-44a9-a950-5fb7ddfec1ef	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:38:46.260659+00	\N
21b196e5-24e7-4677-80f7-6819758ef15e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LABEL_ALERT	Alert	72723df7-a958-4add-b419-6d36a14a560d	null	{"label": "FALSE_POSITIVE", "label_note": "Feedback de qualidade via Playwright"}	\N	2026-04-07 03:38:47.157104+00	\N
ed8c9a5f-ccbe-4b95-bd39-e42e63171c26	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:38:49.127159+00	\N
3c91c39d-4d10-442e-9871-d45b4826078e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:38:53.169453+00	\N
30e0f56d-6df2-4ff6-b730-46e6974a8721	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:38:58.770547+00	\N
339da748-b453-4473-b069-da6c126a42a2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	a4ba0530-29bf-45c3-89f3-b3c2e9aaeb19	null	{"title": "E2E Manual Case 1775533141997", "severity": "HIGH", "player_id": null, "description": "Caso criado pela suíte E2E para validar o fluxo manual."}	\N	2026-04-07 03:39:03.04271+00	\N
9a830ce9-72a2-4626-920a-4a88cc15f8ad	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:39:04.988772+00	\N
174e4a0a-2c1a-4a78-9ccd-f3990824888a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:39:06.263752+00	\N
7eb088dd-a18a-4182-bab4-6b0e1bf67ca7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	43759d5b-e04e-47c8-86e9-62e51ff47593	null	{"title": "E2E Workflow Case 1775533146299", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:39:06.304256+00	\N
f8f37022-5bab-475e-a547-e541f780e8a1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_COMMENT	Case	43759d5b-e04e-47c8-86e9-62e51ff47593	null	{"length": 47, "mentions": []}	\N	2026-04-07 03:39:07.401565+00	\N
f3600903-f5e8-44ec-90fd-130ee0fc1544	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	43759d5b-e04e-47c8-86e9-62e51ff47593	null	{"decision": "NO_ACTION", "report_id": "0638fb1d-e159-4942-a4e9-686da414c132", "pdf_sha256": "81ef7319aa454c1e57fa0c4bab13d8f455579697f7c49105c1cfd10b540d0351", "payload_sha256": "379924fa13763b1019fdb241bd2e82c19ed9d090ea3b415823b92450c1470fd5"}	\N	2026-04-07 03:39:07.589651+00	\N
c529b55c-e6be-4694-b8fc-e725fbcb64e1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:39:08.723322+00	\N
c01e3706-c3f3-4c84-9991-93041cb8aea4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:39:09.92324+00	\N
2089ac13-0490-4072-baca-519971d0ad3d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:39:12.349435+00	\N
7ec51aa4-37c1-4364-a263-e8b122a82695	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:39:22.372267+00	\N
1cd04b45-c83c-4e4a-92e4-1c5ab66b4626	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE	Case	7c37ad54-1588-47ac-999a-ebbdf2937e25	null	{"title": "Search Case 1775533164586", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado para validar a busca global via E2E."}	\N	2026-04-07 03:39:24.610712+00	\N
1ba84085-eb4e-443b-b64a-8f9bbf802ac9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:39:30.852419+00	\N
8d46ce24-2221-4344-80e2-55795eca05a4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:39:40.592171+00	\N
60863ff1-f560-48b7-8b84-b08288f3b06c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:39:53.219604+00	\N
a0f4acd9-785b-4eca-adc6-be8989ae6c75	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	GENERATE_MONTHLY_SUMMARY	Report	2026-04	null	{"year": 2026, "month": 4}	\N	2026-04-07 03:40:05.60839+00	\N
ab0d8e1a-956e-445d-8605-ea04ed518f44	71825dca-3ce0-4230-a48d-da36c09148cd	8cfc988d-8513-443c-8d90-da05dd2fac23	CREATE	RuleDefinition	3814106b-58ff-49ab-acde-4d5108b13340	\N	{"via": "admin_onboarding", "name": "Spike de Depósito", "scope": "TRANSACTION", "params": {}, "status": "ACTIVE", "weight": 0.5, "severity": "HIGH", "description": "Detecta depósito de alto valor combinado com frequência elevada nas últimas 24h.", "condition_dsl": "transaction.type == \\"DEPOSIT\\" and transaction.amount > 10000 and features.deposit_count_24h >= 3"}	\N	2026-04-07 05:12:07.876622+00	\N
013dd6a3-5985-459d-8f41-438140f173ea	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 05:12:22.713748+00	\N
c2baedb2-505c-41e5-9b34-ccf38ad6b524	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.1	2026-04-07 05:12:38.244567+00	\N
23f3221b-3036-4ea7-bdf2-5f5183d1dcfb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 05:12:21.436694+00	\N
473ed61c-fe13-48a4-add6-47fe2212946b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:39:13.836275+00	\N
16a162b1-fe9e-4a83-8153-29890913172f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:39:21.223196+00	\N
5da13cb2-34ac-43e4-8147-76852cbc34c6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:39:41.826387+00	\N
613b2cc1-3004-4d04-8d43-c7fc0162e7c5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:39:45.200291+00	\N
a7140ffd-2010-4705-a3f8-e01b3aa64506	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:40:03.71484+00	\N
924a3351-06a8-4361-99fa-baeebb53a380	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:40:09.83253+00	\N
e7bde79d-6cc6-4fe5-b2bf-a0ccb377e55f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:40:17.641407+00	\N
3ca67be0-ac2b-4997-a401-c60384c8d24f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	5574a59a-b40b-4dd1-9719-734ba7699a96	null	{"title": "E2E RBAC alert 1775538757918", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 05:12:37.948178+00	\N
10335901-774f-4b04-9f00-c426ca0684cb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	48033aa9-0f0c-48ee-8d19-38ca15c49c41	null	{"title": "E2E Narrative Suggestion 1775533149938", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:39:09.963179+00	\N
f4dbdee0-2ab7-456f-829f-1e0cd6c776b3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:39:15.346722+00	\N
31d4c7ed-2a43-4eea-8628-9eb883300ea7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:39:17.026916+00	\N
d79884e9-f5a2-4f48-bfa8-7d946df41064	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:39:24.576477+00	\N
d835a2bd-0057-4e11-82d5-5d624715aeb3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.11	2026-04-07 05:12:45.537871+00	\N
7818a79c-56ee-483b-b0b7-53f114ab222b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:39:25.654522+00	\N
b84438f6-a1fb-4628-883c-5323e71c0253	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:39:29.135343+00	\N
8f5ba0bf-1332-43a7-86f6-2ca74dde7962	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:39:33.541244+00	\N
9152112e-8adb-4636-a939-341d3d22a8ca	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:39:57.259576+00	\N
99a9567b-a233-408a-8f27-9f5a343ab5f5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:40:00.698783+00	\N
2e64e51f-c250-4419-8940-98a45fff9cd3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	EXPORT_MONTHLY_SUMMARY_JSON	Report	2026-04-01:2026-04-07	null	{"date_to": "2026-04-07", "date_from": "2026-04-01"}	\N	2026-04-07 03:40:05.454677+00	\N
7ea544bf-28e4-4f66-9024-c55745d2c1dc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:40:13.666065+00	\N
75fdeaf8-c644-4178-88e2-1ea6d190d6e0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:39:32.274322+00	\N
7a8da322-33b5-47ce-88eb-25eea1806a43	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:39:34.988784+00	\N
d68cac2e-f6d0-4d17-9879-a2495c5d0e01	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:39:37.156312+00	\N
ba997e0f-f8e9-4262-82e5-c827d167476d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:39:42.871203+00	\N
dfba968d-ac1f-4258-9117-dea5ac112049	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE_PLAYER_LIST	PlayerList	54af9eba-196e-44ef-8b1b-76cf929342d3	null	{"name": "[REDACTED]"}	\N	2026-04-07 03:39:46.838859+00	\N
7a0b507c-c0e8-44e4-a31c-0d25974297f8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 05:20:59.770908+00	\N
005f05dd-6003-45fe-920c-a7e11322f2ec	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 05:21:02.332669+00	\N
91f201cc-0cf8-4460-a827-42f84ba63f26	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	7e230ee5-e6eb-47cd-a4be-0ae66eae4f03	null	{"title": "E2E RBAC alert 1775539377629", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 05:22:57.664591+00	\N
318f1afc-bd22-4325-89fa-a7dc0ef0d7b4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:39:50.993825+00	\N
900b6540-7304-4edf-a1fe-ca3a1161f8b2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:39:54.381944+00	\N
e350232c-bc31-4f4e-bc8d-79d2eebb178b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:39:58.268308+00	\N
9a67dca8-9d8e-4fbb-922a-4f7d83c72dbe	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:40:31.56533+00	\N
941714e3-53cb-45ec-8a19-dfffa391cfe5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE_API_KEY	ApiKey	57286b04-9b47-4054-bee3-16f4d61df0cf	\N	{"name": "e2e-key-1775533226217", "permissions": ["ingest"], "source_system": "connector_delta", "expires_in_days": 90}	\N	2026-04-07 03:40:32.889401+00	\N
8cf14255-deba-474a-ac11-46975f973a0f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	REVOKE_API_KEY	ApiKey	57286b04-9b47-4054-bee3-16f4d61df0cf	\N	{}	\N	2026-04-07 03:40:33.295481+00	\N
0b8fb752-29f0-4384-ae40-943805bafc52	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:47:52.234302+00	\N
f063132d-8df7-46ad-8610-0a873654e557	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:47:54.679857+00	\N
3e161d82-776f-4234-a30f-278181784efa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:47:57.125405+00	\N
6d9db21d-c1ae-46ca-a7e2-5086a58d5f23	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:48:05.868592+00	\N
40b86df5-7ceb-459b-ab1b-65687217b3c6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE_API_KEY	ApiKey	f06b8597-300c-4f7f-a817-f4d2d7cdc374	\N	{"name": "e2e-key-1775533684644", "permissions": ["ingest"], "source_system": "connector_delta", "expires_in_days": 90}	\N	2026-04-07 03:48:07.05974+00	\N
db349125-4471-49ea-b58e-558d6e8a3a39	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	REVOKE_API_KEY	ApiKey	f06b8597-300c-4f7f-a817-f4d2d7cdc374	\N	{}	\N	2026-04-07 03:48:07.404065+00	\N
9a31f713-3fa0-419a-b757-c241515bd33c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:48:48.666426+00	\N
b7fcfc0e-39d2-4dfe-ba18-55feed69473a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:48:50.913618+00	\N
9d7a065f-c282-4f41-a2d7-62014281bfb1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:48:53.490428+00	\N
bdceb277-53ec-4f50-a2ed-c6675db6b7e3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:49:07.409322+00	\N
7f537e71-ebcf-44f1-a82a-41e5f3c2aefa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE_API_KEY	ApiKey	d6306956-d6de-4133-a531-ab2ae9e97614	\N	{"name": "e2e-key-1775533746195", "permissions": ["ingest"], "source_system": "connector_delta", "expires_in_days": 90}	\N	2026-04-07 03:49:08.610117+00	\N
452b92ee-803b-41ff-8f21-9de74ca9d9a1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	REVOKE_API_KEY	ApiKey	d6306956-d6de-4133-a531-ab2ae9e97614	\N	{}	\N	2026-04-07 03:49:08.936326+00	\N
03c8ab4f-9cc0-44b9-ae6b-7d2f9aac7a41	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:50:31.551112+00	\N
8ff6a7f3-5dcb-4d21-9527-bd1c559a121f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:50:34.704326+00	\N
0f5d4765-613a-43bf-b443-4442aba3cf03	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:50:38.723614+00	\N
f3f72a74-e0e0-4267-98da-d4a94eecf3eb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ml_weight": 0.4, "rule_weight": 0.4, "low_threshold": 30.0, "sla_low_hours": 168, "high_threshold": 80.0, "network_weight": 0.2, "sla_high_hours": 24, "medium_threshold": 60.0, "sla_medium_hours": 72, "ml_challenger_pct": 0, "critical_threshold": 95.0, "sla_critical_hours": 4, "auto_case_threshold": 0.75, "data_retention_days": 1825, "ingest_rate_limit_tpm": 100000, "data_retention_raw_years": 5, "data_retention_gold_years": 3, "data_retention_silver_years": 5}	\N	2026-04-07 03:50:39.916771+00	\N
3c8e7be5-bf2d-48a1-8435-b655345e3d18	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:50:41.082439+00	\N
66bc3b96-2125-4efa-a02c-5e6d2f5bd6bb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE_API_KEY	ApiKey	855dd7ab-17dc-48e7-bd7c-e2c583ef65a8	\N	{"name": "e2e-key-1775533840119", "permissions": ["ingest"], "source_system": "connector_delta", "expires_in_days": 90}	\N	2026-04-07 03:50:42.331845+00	\N
767677eb-befd-49b9-a380-8d0ed1517206	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	REVOKE_API_KEY	ApiKey	855dd7ab-17dc-48e7-bd7c-e2c583ef65a8	\N	{}	\N	2026-04-07 03:50:42.694452+00	\N
15c8704d-3602-467d-b53b-75e6bd8ef4aa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:51:40.596533+00	\N
3a14f81f-4bec-4bdc-9b26-6cca759f6665	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:51:44.414831+00	\N
062f8e73-b551-4de5-915a-6aa5f60a41a6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:51:46.646491+00	\N
ebd5ab6f-330f-4dc5-9eca-ed89c0364577	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:51:47.953946+00	\N
b2af6256-9bda-43dd-879a-04d451e3d9b1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	2c249c7a-3664-42f2-9fac-9885d592ecaf	null	{"title": "E2E triage alert 1775533907979", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:51:48.017343+00	\N
c8a6b965-b60e-41e2-b7df-4329ca655cce	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	TRIAGE	Alert	2c249c7a-3664-42f2-9fac-9885d592ecaf	null	null	\N	2026-04-07 03:51:49.827847+00	\N
f6312dc9-3b07-486a-9e28-f9e02560c36b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:51:51.042248+00	\N
336a7f4f-7988-4ef1-87da-53c5bef2641c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:51:52.32004+00	\N
a2a57c3a-1ff8-4021-b978-7b93fc0e596d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	97ecb9a0-c3a9-46df-aa04-26efc3b9d9fd	null	{"title": "E2E RBAC alert 1775539267343", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 05:21:07.38228+00	\N
aef57659-ae14-471f-a54c-a470c6dc15cd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	596a9339-5b20-4757-b70c-52903e217a03	null	{"title": "E2E link alert 1775533912341", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:51:52.370522+00	\N
e4182fed-b5ac-4708-b687-849294ca8b8e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	62f3228e-998c-4cec-af91-4ac475562664	null	{"title": "Case for alert link 1775533912381", "severity": "MEDIUM", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:51:52.404363+00	\N
4acc5e49-5ee5-4fce-a173-d8b5d5a993aa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LINK_ALERT	Case	62f3228e-998c-4cec-af91-4ac475562664	null	{"alert_id": "596a9339-5b20-4757-b70c-52903e217a03"}	\N	2026-04-07 03:51:53.281389+00	\N
f5e84264-c9fe-4bde-9d78-151568789fce	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:51:54.749545+00	\N
3edba055-9890-423b-bfb1-b9ec92f4894c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.11	2026-04-07 05:21:05.340092+00	\N
d2d30126-a4ee-4a65-8472-2edeb6fcb341	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 05:21:07.336485+00	\N
609f60db-2343-4669-ac7b-3123db4118c1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 05:22:48.733231+00	\N
c4231174-b47e-4566-ac7d-4f2c87fb5be0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.11	2026-04-07 05:23:02.095661+00	\N
731ee741-38c8-4768-87f9-2436fa2b73ca	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:51:56.172656+00	\N
4d2397b8-5d01-4aa5-b9e9-bb7fac75eb19	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	97e3fdaf-f042-4655-bae4-4162b029676e	null	{"title": "E2E close and label alert 1775533916189", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:51:56.219553+00	\N
15a9fcea-21a4-458c-bd35-6b0f0c32db8d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LABEL_ALERT	Alert	97e3fdaf-f042-4655-bae4-4162b029676e	null	{"label": "FALSE_POSITIVE", "label_note": "Feedback de qualidade via Playwright"}	\N	2026-04-07 03:51:57.028423+00	\N
aaf41f55-6623-4103-845e-790e19ecfdf9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.1	2026-04-07 05:21:07.673793+00	\N
93483f39-cbe6-4fcd-9dae-391fe4804588	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CLOSE	Alert	97e3fdaf-f042-4655-bae4-4162b029676e	null	null	\N	2026-04-07 03:51:57.177405+00	\N
c988990a-3bc1-4f86-bcbf-7481c20f596b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.11	2026-04-07 05:21:08.912319+00	\N
90107294-0284-4d3d-895a-f130b2b374ab	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:51:59.077141+00	\N
53040c34-e315-4e56-94b7-9c65b3a80f7b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.11	2026-04-07 05:22:53.037073+00	\N
9694f804-bf00-4f8b-921c-a3c36e0b0701	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 05:22:57.613863+00	\N
4a659e8c-e343-49a4-aa4d-4f56660457bf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:52:02.060373+00	\N
96f435d5-3782-4d3c-89c0-d634d2c74f1f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:52:04.9816+00	\N
18bd7e90-627d-45cf-9759-677d35e4cdc5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:52:07.115753+00	\N
390776c7-6dcc-46a7-8a25-ea20b396f994	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:52:09.404828+00	\N
a7fbbc75-83b1-4426-9e75-36c8d9db2d4d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	ab33f18a-3946-4152-b7d7-c34c74e72f77	null	{"title": "E2E Manual Case 1775533930385", "severity": "HIGH", "player_id": null, "description": "Caso criado pela suíte E2E para validar o fluxo manual."}	\N	2026-04-07 03:52:11.409123+00	\N
6b3e77de-8f58-4dd1-a1b2-3491f7da0e11	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:52:14.389499+00	\N
a8ba7d39-b75b-46ef-99d2-ff082616839c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:52:15.793296+00	\N
839e52be-90d9-4b26-8914-6eb7deb9bb47	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 05:22:50.179979+00	\N
6beba6ce-0ceb-44b3-a261-e6ce2d7e9ef0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	90ee3ad8-5f7a-45ee-9a30-6fa1507af0ec	null	{"title": "E2E Workflow Case 1775533935835", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:52:15.839928+00	\N
eb0738a7-4a6e-42a8-a032-75a6b5fa6b82	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_COMMENT	Case	90ee3ad8-5f7a-45ee-9a30-6fa1507af0ec	null	{"length": 47, "mentions": []}	\N	2026-04-07 03:52:16.876909+00	\N
9de4c17a-226e-47b5-b691-3fc9b4b94312	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	90ee3ad8-5f7a-45ee-9a30-6fa1507af0ec	null	{"decision": "NO_ACTION", "report_id": "f6bd79e4-a1b2-46aa-bcd0-647d36bce39b", "pdf_sha256": "4dd897cb8c5cb0505aa56b78f01e72316ededbe5682a8ce2ede2d50d668b01ce", "payload_sha256": "5a34351e106764eace63f49f1002e2b9b2e359e21769b8d87fe34a8d65a14cf0"}	\N	2026-04-07 03:52:17.030033+00	\N
ce76502f-c21d-4934-8751-9edbefd6ba5a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:52:18.54161+00	\N
0fda2c24-de5a-40a8-8c10-69135f19108f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:52:19.762738+00	\N
21043a1a-99b4-4831-b91a-12e44033a447	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	6d9fae96-b4e4-48ce-be8d-b4c8fe9c06cb	null	{"title": "E2E Narrative Suggestion 1775533939775", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:52:19.803031+00	\N
00d60600-1b44-44c6-95ac-32e0396e506f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:52:22.10936+00	\N
59ee54a5-195f-4502-98c1-4df496761caf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:52:23.833257+00	\N
f8c2cf89-097c-432f-af05-7e93e7aedc32	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:52:25.539396+00	\N
2d54bc24-0841-4a29-bb0a-f77284ff7ef9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:52:27.305382+00	\N
3783b355-d203-4eb9-bb4f-97ae79075390	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:52:31.712604+00	\N
5b52a260-3e2f-4fdf-afd2-7d5bd0c32da1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.1	2026-04-07 05:22:57.95646+00	\N
a756492f-c483-4aec-b72f-fe010c6514a1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:52:32.812268+00	\N
0017a0e4-2fbe-46c2-83b2-67a2d8bb15a5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:52:35.594543+00	\N
ee093123-79df-40e8-bd15-f40f606c22c4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE	Case	d5bbb065-dae6-4f52-8f71-37da67149a64	null	{"title": "Search Case 1775533955602", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado para validar a busca global via E2E."}	\N	2026-04-07 03:52:35.623379+00	\N
5103d1c6-2c6b-4ebe-aa84-7b49efc15ece	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:52:36.731288+00	\N
7b67a3e5-a295-4c04-9d3d-b5fd8bc40b1c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:52:40.458685+00	\N
22128090-0b8f-4ba2-a6e2-72ea001c5023	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:52:42.285649+00	\N
d68be714-9faf-4f79-a0eb-32fb259a97c1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:52:43.948084+00	\N
e3b4dcad-a953-4234-88ef-e64bde0a3b3f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:52:45.374227+00	\N
0f7ce8e3-9e43-4ae1-aefb-e94ac311033c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:52:46.911553+00	\N
ce93330d-55d8-4c78-bad1-d06293ea1840	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:52:49.342682+00	\N
5ddde48a-3368-47de-91c6-ddfea7d61d22	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:53:04.499643+00	\N
7b8fe838-80fc-4e60-b56f-9b882d4a2bda	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:53:05.862793+00	\N
03c952a7-4c5c-471e-88e3-77867e03097d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:53:06.912015+00	\N
a2673936-7aab-4dfe-b70a-cf73da9c79c6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:53:09.64551+00	\N
f7215b26-9441-4ba4-a470-60ef0ba7d908	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE_PLAYER_LIST	PlayerList	26153a7b-84f8-4e7d-9762-4a25147eea9c	null	{"name": "[REDACTED]"}	\N	2026-04-07 03:53:11.892446+00	\N
2f06ef71-12e1-435f-9033-24583e67853c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:54:17.307829+00	\N
ec76120e-98f7-4128-b7eb-70128d2ce037	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:54:19.771701+00	\N
42848913-c728-4dc0-90bc-98be6bf83539	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:54:21.131563+00	\N
ac496f73-2a6c-4224-80bc-117a1bb8557d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:54:45.843448+00	\N
33cf29d9-4ee7-403c-8cad-3d0ab54f3d11	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	410d868c-321f-4dea-a9de-b959bcb05f22	null	{"title": "E2E triage alert 1775534085867", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:54:45.896965+00	\N
ba782f17-8159-4c7f-aef0-a8b2c99fb65b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	TRIAGE	Alert	410d868c-321f-4dea-a9de-b959bcb05f22	null	null	\N	2026-04-07 03:54:47.84024+00	\N
a121196b-7a3c-4c81-995a-c2f8103be084	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:55:07.40414+00	\N
ef7cc005-cb11-43a5-8b4c-02d1a0cc424b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	ca2420d2-f9f9-4b17-99b3-3484586722a5	null	{"title": "E2E Manual Case 1775534108408", "severity": "HIGH", "player_id": null, "description": "Caso criado pela suíte E2E para validar o fluxo manual."}	\N	2026-04-07 03:55:09.451973+00	\N
8badfee9-8803-453b-80eb-9cfaaa3b0fd9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:55:12.504095+00	\N
8014b303-ff70-44e4-ad92-c01345d6701b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:55:17.794802+00	\N
f4b8f917-bd46-424c-8a9f-2f79d395ae3d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:55:30.900896+00	\N
f061472f-6c46-4ebd-95a8-6eadd6b8d6f8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE	Case	e5e3c918-68b3-4d1e-8d13-08eea27949f5	null	{"title": "Search Case 1775534134799", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado para validar a busca global via E2E."}	\N	2026-04-07 03:55:34.816494+00	\N
4573ee3b-f667-4084-ada8-04554065570a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:55:51.937937+00	\N
ac56b91a-b83a-4ec5-91d3-de6402936727	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:54:54.140406+00	\N
31648a30-0727-4bde-ad56-0abbbed4c63a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	b126eb3e-e69a-4d3c-ba30-022f41f2ce64	null	{"title": "E2E close and label alert 1775534094155", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:54:54.211348+00	\N
5f7d4577-727b-40ac-b6fc-21d975f4ac1c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LABEL_ALERT	Alert	b126eb3e-e69a-4d3c-ba30-022f41f2ce64	null	{"label": "FALSE_POSITIVE", "label_note": "Feedback de qualidade via Playwright"}	\N	2026-04-07 03:54:55.109221+00	\N
7fdd5fcd-6bfc-4e5f-8387-600f270f9fc8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	6775d966-a130-4a61-9456-f9a704165746	null	{"title": "E2E Narrative Suggestion 1775534117812", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:55:17.841028+00	\N
5669bd03-fcfa-4842-a0ca-c72db2ac2667	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:54:23.506547+00	\N
a26352ee-91c1-4c7b-9713-855fe344bb4e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:54:24.811736+00	\N
689e58c8-1aa7-4d95-a1b6-87ca27b63b82	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:54:25.786479+00	\N
5ce4e864-5c25-433d-8430-daafba970802	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:54:42.110743+00	\N
10d9c532-125a-4dff-a40f-f14e7ecfe747	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:55:00.34427+00	\N
01c734f8-00bd-4a06-844d-65806f65067a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_COMMENT	Case	d71eec3c-f7fb-4689-826f-d4e3c7fb4a65	null	{"length": 47, "mentions": []}	\N	2026-04-07 03:55:15.034526+00	\N
d72a055f-4059-41a5-910d-21792d70d621	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:55:21.996529+00	\N
be84e73d-6b08-4874-8b04-992de8d81ca2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:55:35.914083+00	\N
5b316729-cd6e-483b-a732-2fcba2882f4f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:55:44.290737+00	\N
7490d291-0525-4924-b06d-2d832c5a5e71	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LINK_ALERT	Case	8075dabc-8936-4d78-866d-0fe44bd45a4b	null	{"alert_id": "4264e047-d5ef-491a-ba98-30d3b03eca93"}	\N	2026-04-07 03:54:51.602895+00	\N
f5be6895-3d6c-4eb2-8ec9-4c3f876011f0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:55:05.264434+00	\N
e88c6564-b0e2-4a96-8635-1c089c14346c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:55:13.894356+00	\N
295b939e-c8c0-4630-a097-ab5d54ac3070	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	d71eec3c-f7fb-4689-826f-d4e3c7fb4a65	null	{"title": "E2E Workflow Case 1775534113929", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:55:13.934418+00	\N
aabb003f-bfe5-4a77-8ee3-f1ef3181da36	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:55:23.631255+00	\N
4934e0c1-f851-4eb8-bf6c-f646290ec45e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:55:53.208907+00	\N
41d5ce82-3318-48c5-9d61-47cc6110283a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:54:39.920697+00	\N
5afa9321-f6c4-46d0-9a54-48d36bf08480	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:54:49.152193+00	\N
28883b74-3be2-4193-b6f7-5cf5b52a3fdb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	8075dabc-8936-4d78-866d-0fe44bd45a4b	null	{"title": "Case for alert link 1775534090599", "severity": "MEDIUM", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:54:50.63171+00	\N
514367c8-e40e-4ce5-93ed-4d106ace19cb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:54:52.834085+00	\N
26b5dbd8-96a9-45f7-ba52-dbe3b4be7bca	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:54:57.242139+00	\N
962b79e3-b476-4f46-ab6e-c61c42acf533	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	d71eec3c-f7fb-4689-826f-d4e3c7fb4a65	null	{"decision": "NO_ACTION", "report_id": "d3fc41e9-bf1b-4949-b980-5def09e89fa3", "pdf_sha256": "145c5102fc12f449a3071e82cb612c025be23ff22da8b1565729daa5f61d5e94", "payload_sha256": "c4213c7c06d3c834c00352e7e29c3118edd1d81e69eaa551f5aed55599e94248"}	\N	2026-04-07 03:55:15.235409+00	\N
bc0d9fe5-79ca-427c-a89c-75ca360f650c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:55:25.524246+00	\N
be0a5cf5-53c6-4f8a-a615-f432bb892834	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:55:29.797079+00	\N
671dc549-c41c-4d29-a2c8-e39bb9a9870e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:55:39.585158+00	\N
65bed3ef-0ae0-4954-8600-9356c047ea69	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:55:41.570275+00	\N
8a0792eb-1c1b-47c4-a4d1-6432c5d74e41	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:55:42.976142+00	\N
b006b310-908d-445e-bfe1-6f8e770d44f2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:55:49.54081+00	\N
0548c439-1232-423f-8196-7ab250fd6055	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:56:08.099156+00	\N
1a1c0f7e-0048-4215-9c73-afc4034c912a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:54:44.510269+00	\N
a4af0a2a-3088-449d-9b57-ea1c1e1623c4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:54:50.538495+00	\N
68963dfe-1716-4283-aa53-bb47540f39a0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	4264e047-d5ef-491a-ba98-30d3b03eca93	null	{"title": "E2E link alert 1775534090555", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:54:50.586738+00	\N
3ca87416-77dd-4c8d-9a34-96d8527ae789	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CLOSE	Alert	b126eb3e-e69a-4d3c-ba30-022f41f2ce64	null	null	\N	2026-04-07 03:54:55.273818+00	\N
20f434c2-c789-4a76-aaa8-e6af8537d870	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:55:03.113734+00	\N
04e9acb1-33ee-4d2e-937e-9f133738420c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:55:16.418964+00	\N
9a6d5fa1-54f2-4a5a-b08d-99463e34efb4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:55:20.371489+00	\N
cd633f30-7ebf-4cb9-aaef-31b8676b0144	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:55:34.791939+00	\N
f09e88d6-98af-42b9-b881-060742f52846	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:55:45.851114+00	\N
561383b9-6088-4581-9eb7-99827e67fa13	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:55:48.190899+00	\N
d88fda1b-d484-4a8c-b683-7b1cc1d95b87	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:55:54.164182+00	\N
ab9327ec-6297-433d-a9a5-402ae635a89f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE_PLAYER_LIST	PlayerList	a908dfec-1fcf-46f2-9895-58de4ca6cd9a	null	{"name": "[REDACTED]"}	\N	2026-04-07 03:56:10.23481+00	\N
11436cf3-42fe-4d19-925e-59c3ce02e53b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:57:08.350882+00	\N
6cc0fea2-a2c6-4b4f-b9b9-455e50823471	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:57:11.189038+00	\N
d077cd80-0c8c-4525-85e6-7ad39f5b53d7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:57:12.646619+00	\N
dbb492e8-d290-443a-8373-eabfc539ebcc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:57:15.045229+00	\N
8359c285-31a0-4b0b-8f32-35cf82bbb700	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:57:16.428914+00	\N
90a6b3ee-14a9-4834-9d85-78b79aa0fcb0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:57:17.467399+00	\N
ff021426-658f-4946-9c3a-5ca476896715	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:57:31.222426+00	\N
df0a6057-bc20-499a-be09-2fbc180d539f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:57:33.443811+00	\N
42a7a06d-62b6-4738-9f4f-6473c62ff506	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:57:36.010481+00	\N
2a022d41-7b0a-4477-a85c-afa900eab4fa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:57:37.484077+00	\N
8eaa2a06-2ccb-4945-bfec-5eb45bb98d56	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	bdd7eb13-3e55-4344-9060-132fd5ab4c06	null	{"title": "E2E triage alert 1775534257509", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:57:37.540494+00	\N
2f7a84c9-7277-489f-894f-b23516e7a661	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	TRIAGE	Alert	bdd7eb13-3e55-4344-9060-132fd5ab4c06	null	null	\N	2026-04-07 03:57:39.248158+00	\N
ac1fe140-19ec-4ac4-9e9e-176311fdd777	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:57:40.650963+00	\N
eea9ffea-188c-455d-8638-06e1c3c7a356	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:57:42.07559+00	\N
737a9dfc-be06-4a64-9ad1-e5049ea6b872	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	971a0d9d-cbdf-4845-8a00-0c72dafe413a	null	{"title": "E2E link alert 1775534262091", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:57:42.118934+00	\N
df305ce3-2911-452f-8569-338328cf9599	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	47e1a129-8365-4217-8dcd-3f3338962ebf	null	{"title": "Case for alert link 1775534262130", "severity": "MEDIUM", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:57:42.159228+00	\N
d16a33fd-bd74-4480-b874-d164a4d737c8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LINK_ALERT	Case	47e1a129-8365-4217-8dcd-3f3338962ebf	null	{"alert_id": "971a0d9d-cbdf-4845-8a00-0c72dafe413a"}	\N	2026-04-07 03:57:43.166076+00	\N
b8ec43f9-b023-4bdc-8c33-2e9a2c72e276	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:57:44.438129+00	\N
da29eede-51fe-4977-96f8-c4580c383657	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:57:45.842983+00	\N
251f9353-f01f-418c-bcd1-9214ecb30422	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE_E2E_ALERT	Alert	51607e36-edd8-4ead-8edf-23e7e4a03ce9	null	{"title": "E2E close and label alert 1775534265850", "status": "OPEN", "severity": "HIGH"}	\N	2026-04-07 03:57:45.882658+00	\N
8989bdcc-33ef-4c2f-a15c-b774bb1caabd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LABEL_ALERT	Alert	51607e36-edd8-4ead-8edf-23e7e4a03ce9	null	{"label": "FALSE_POSITIVE", "label_note": "Feedback de qualidade via Playwright"}	\N	2026-04-07 03:57:46.782616+00	\N
9552c8d0-221f-4185-932b-01f21469fc5d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CLOSE	Alert	51607e36-edd8-4ead-8edf-23e7e4a03ce9	null	null	\N	2026-04-07 03:57:46.952095+00	\N
43e4e68a-7257-48d4-ae7d-af25c87848e2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:58:04.811334+00	\N
b7fbf432-c3ed-48d5-96d0-7cf5765c3b00	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	6f8474c4-ddcc-44cd-b47b-7bc0f1cbf5c9	null	{"title": "E2E Workflow Case 1775534286179", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:58:06.184283+00	\N
aaccc008-d171-4f23-a7f8-7de008397bde	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:58:16.169876+00	\N
395b86bc-ae18-4ed3-b948-4e1c356e4e44	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:58:35.985197+00	\N
a3c68a12-e56a-456f-ad6c-3678d5f5307d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:58:46.859195+00	\N
a49dd54a-fe19-4040-8522-8bc634352fbf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:11:29.474611+00	\N
26091807-f476-4b84-95e5-53d76ce4a5b8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:57:48.93967+00	\N
eda933b7-65b2-42a8-966b-6843631ff80c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:57:55.103498+00	\N
f77dc5df-9202-4bf1-bc7e-70540fdba174	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:58:14.505301+00	\N
7a297274-62ed-4c19-af26-0d2feaa01d14	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:59:05.67673+00	\N
546c6e0f-5ae8-489c-99ad-1260d567fe74	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:59:08.629398+00	\N
bcd65744-bd68-45bd-9469-0b33e588b4bd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:59:19.189566+00	\N
b94402b6-eb88-4165-9f31-5b4a6c606e15	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE_API_KEY	ApiKey	abb666cf-7e04-4bec-ae0e-6ce1d9b632f3	\N	{"name": "e2e-key-1775534369309", "permissions": ["ingest"], "source_system": "connector_delta", "expires_in_days": 90}	\N	2026-04-07 03:59:31.758809+00	\N
b9f3655c-8d1f-4543-a385-66f06f304e6f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:04:51.919194+00	\N
ce6ca3b8-00af-4c39-a8ed-af0eaa9f3cd8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:04:53.195303+00	\N
bf989721-f93c-46de-969a-68ae68834113	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:08:50.580519+00	\N
c7aca068-8847-4004-89c5-14f59d67852e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:11:02.792568+00	\N
ea9bba97-5370-40fa-8446-e85b3af83b40	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:11:35.254292+00	\N
3fb7273c-c41d-40b8-85eb-87c0791d80e2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:57:52.361254+00	\N
03fc872b-92fe-4b69-95a7-52a316dd704c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:58:45.442404+00	\N
9cd7bab0-7d0c-4115-b95d-f7d2cb5707f2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:58:57.210535+00	\N
7b9c0011-db39-4c37-90cc-08972edf772e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	EXPORT_MONTHLY_SUMMARY_JSON	Report	2026-04-01:2026-04-07	null	{"date_to": "2026-04-07", "date_from": "2026-04-01"}	\N	2026-04-07 03:59:14.43947+00	\N
7e5bc061-0f55-47e7-b76a-a0f6c50c3cdc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:59:27.785888+00	\N
322b4213-37d4-4997-a771-44cff8d34a77	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:12:22.826276+00	\N
ae1b4d91-dca8-4cad-a057-946faa0fa488	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:57:57.366294+00	\N
855957df-93f3-4287-87c6-8b41b4c35c4b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	29e027d1-d682-44e7-b00a-50976c40864b	null	{"title": "E2E Manual Case 1775534280699", "severity": "HIGH", "player_id": null, "description": "Caso criado pela suíte E2E para validar o fluxo manual."}	\N	2026-04-07 03:58:01.74686+00	\N
a6898561-5aa6-4fd1-b402-593fdc239ec7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CASE_COMMENT	Case	6f8474c4-ddcc-44cd-b47b-7bc0f1cbf5c9	null	{"length": 47, "mentions": []}	\N	2026-04-07 03:58:07.505037+00	\N
1ae67901-734b-4d7d-9152-d217cecd614c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	f66e8169-9ada-4f7d-a44e-8b24fdfcb375	null	{"title": "E2E Narrative Suggestion 1775534290432", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 03:58:10.464886+00	\N
b76ce61d-bff7-45db-b512-1970adc982fb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ml_weight": 0.4, "rule_weight": 0.4, "low_threshold": 30.0, "sla_low_hours": 168, "high_threshold": 80.0, "network_weight": 0.2, "sla_high_hours": 24, "medium_threshold": 60.0, "sla_medium_hours": 72, "ml_challenger_pct": 0, "critical_threshold": 95.0, "sla_critical_hours": 4, "auto_case_threshold": 0.75, "data_retention_days": 1825, "ingest_rate_limit_tpm": 100000, "data_retention_raw_years": 5, "data_retention_gold_years": 3, "data_retention_silver_years": 5}	\N	2026-04-07 03:59:29.09297+00	\N
e2266c80-4afd-4a2f-9321-0e7b391076fc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:12:54.251829+00	\N
c3e7c281-1dae-4c04-9114-c30d254735a9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:12:56.556163+00	\N
fdf0431d-e91a-4314-af29-2094889151cb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:13:02.021036+00	\N
670f4863-3393-471b-b6b1-c558e26f0c2c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:57:59.569212+00	\N
dc4f7fbf-4b1a-4f22-8344-921ab37bec5e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:58:06.138351+00	\N
2a485264-463a-41c3-bfa2-05c451e66ba2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:58:18.010442+00	\N
362226d5-4114-4609-93c3-272e2ae9f79b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:58:22.400912+00	\N
43337f41-e66d-47d8-af56-152014bd6f9c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:58:23.517584+00	\N
3b8a8fae-60a2-43d9-ada4-2fc85a4145cd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:58:28.47751+00	\N
8697be7a-1a13-4922-9827-79df71ccab52	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:58:32.118067+00	\N
3fd05abe-850b-4a77-a274-6139f4df9577	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:58:37.275191+00	\N
6cc2cf6b-de45-41da-aea8-6bfc77b1651b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:58:38.839862+00	\N
c5ef5047-1727-48b7-9a2f-c5a86f095f2b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:58:42.946174+00	\N
bd611e62-a1c7-4c57-89dc-141e2930fa2e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:58:47.912737+00	\N
97cd19d5-8b44-43ad-9892-a328e2fa4a3d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:59:04.318133+00	\N
0365cfaa-f18e-43a7-a5c2-bd03d87761d0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:59:30.427735+00	\N
2e222320-f71e-4d19-8884-07f4f976952e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:11:28.229311+00	\N
33b92226-ae36-4b13-99eb-75811e8af685	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:58:12.848039+00	\N
76820978-b104-4eb4-8d8d-7769f93805d4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:58:27.337354+00	\N
03684341-d627-4f49-aa4c-c59e42a23ae4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:58:34.444356+00	\N
77bd9a8c-466f-4f38-82b3-5ff9da34b4e6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	6f8474c4-ddcc-44cd-b47b-7bc0f1cbf5c9	null	{"decision": "NO_ACTION", "report_id": "4aa97796-1885-4efd-a689-8682cbfccc15", "pdf_sha256": "8c6f4d9603dbbc8fe3e525fcfc91a6a46017907a666ba237433e895236c33853", "payload_sha256": "0b1eec4e44012e1c7a6f2f26b35a79e628bb2428942e221bcd95a8a58689e78c"}	\N	2026-04-07 03:58:07.748728+00	\N
1335d25a-e15c-4492-aa5b-f75ce662ad39	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 03:58:10.415927+00	\N
311c5c27-1953-4a29-9824-07e57a96c2f1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE	Case	b0b71c54-f846-405a-9bf0-5f754edc93b3	null	{"title": "Search Case 1775534307343", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado para validar a busca global via E2E."}	\N	2026-04-07 03:58:27.362212+00	\N
dad9fed4-06c1-4fbb-8e23-48c0e88ab82e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:58:41.573066+00	\N
0e533aa0-a4b1-4f46-b578-36769eb4b521	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:58:50.512236+00	\N
27821d1f-995f-48b0-bc12-2cfbc914b77e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	CREATE_PLAYER_LIST	PlayerList	c42697f7-c1c1-4217-81dc-f2e72abf0d9e	null	{"name": "[REDACTED]"}	\N	2026-04-07 03:58:52.673257+00	\N
bbf4736a-40b4-45dc-a398-46d197336014	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 03:58:59.946546+00	\N
b25b6b7a-74ca-4056-bf41-0bdb4bb4dffb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:59:23.803712+00	\N
0d0b5925-0419-41a0-8a15-5752c321e2b9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	REVOKE_API_KEY	ApiKey	abb666cf-7e04-4bec-ae0e-6ce1d9b632f3	\N	{}	\N	2026-04-07 03:59:32.093643+00	\N
51f0baec-0c8d-43bc-ab92-396de98783f3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:11:36.59362+00	\N
e6860bd3-1e5d-45b7-8836-f4a5cb387abd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:11:47.759022+00	\N
e16f0b7e-d202-4f51-8c20-1675d9b585d7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.11	2026-04-07 03:58:09.086753+00	\N
d5723443-e698-4cdd-8796-7f37f1b68b8b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:59:01.207095+00	\N
a6aa4620-158b-4c82-a17f-ed9b3f70993d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 03:59:12.100233+00	\N
7dc2ecae-565f-40da-abf1-cf4dd18a6313	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	GENERATE_MONTHLY_SUMMARY	Report	2026-04	null	{"year": 2026, "month": 4}	\N	2026-04-07 03:59:14.589519+00	\N
0ed08b54-41fe-47c6-9b65-27fe6c3e1ff3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:07:22.102499+00	\N
5265dc51-2401-4087-8f07-2d705139d741	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:07:23.385713+00	\N
760317c2-6790-414b-8c3a-acca08fe15d9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:08:49.248294+00	\N
c0f3cbbd-c901-45c9-8de0-a783c4e7cf04	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:11:01.244762+00	\N
479a77d9-d56d-449f-9085-ca45a7350456	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:11:45.468474+00	\N
8ce930bd-f57d-4198-8283-e2b3d0d9e0d4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:12:24.097372+00	\N
14cb32c2-ed10-4ab6-9bf0-1f0a991676b3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:12:26.356324+00	\N
5e296e12-8285-456d-9301-d07f07509036	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:12:28.564181+00	\N
24c01d41-f981-4aaa-adf9-27af427b95c7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:12:44.183723+00	\N
39531b2d-3eb3-4696-9d06-5d02ac14ce0b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:12:45.445167+00	\N
3c053312-4f5a-489c-8844-512c5d82f990	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:12:51.119563+00	\N
b56f25c2-1d37-4925-ae1c-439cb13c2e59	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:12:52.288022+00	\N
ef75fad3-1593-4c53-8e25-38fd0088d8f7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:15:19.315904+00	\N
3134de8c-d228-4836-bf1a-eeba49b9e2c5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 1}	\N	2026-04-07 04:15:19.352987+00	\N
0eb2b022-39d5-4d3d-b90e-a885c40e66d8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 100000}	\N	2026-04-07 04:15:19.481711+00	\N
4c78d33d-e5f2-4e58-8a59-0a406627f187	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:15:31.70452+00	\N
7bf481f0-425d-4967-9b10-cf8b008b9d6c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:15:33.250756+00	\N
1a440aab-e27b-4b93-9dc0-f133e75f0769	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:15:39.430931+00	\N
242603a3-bc52-4951-ac82-72889af7e701	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:15:40.695151+00	\N
595f593e-218c-43ab-ae3a-8b5ca562a2fd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:15:42.738464+00	\N
558b7ae0-692d-4dac-85a7-e6dcd001e0c6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:15:45.013841+00	\N
0e3d4c98-901f-4fa5-9cda-1a2ba3afa092	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:15:49.823677+00	\N
4b551330-fb93-4c45-9c8d-eb3d9d26f159	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 1}	\N	2026-04-07 04:15:49.861868+00	\N
0a761f96-1502-4ce3-88d3-6800909cac89	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:15:53.001186+00	\N
73fe71a8-100c-4c19-951f-e41bbbcfde8e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:19:24.706295+00	\N
5ae43033-6aee-4144-8864-f90750105c7c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:19:25.124014+00	\N
a59ad11f-ee39-4714-b1f8-133a91418ddd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:19:39.216449+00	\N
c6d5ae9b-0457-4187-aead-4ae046596816	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 100000}	\N	2026-04-07 04:19:57.609084+00	\N
9f8df59d-10da-4adb-88d4-4b213ff6195e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:20:00.497606+00	\N
16606fcb-2e33-4da2-836b-b977c152a2b7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:20:04.584848+00	\N
32b49bce-c5c0-4338-802b-39ef8c8560f2	40e341ad-cf4a-484b-9926-3d56cc58fa1f	e653024a-8bee-46b0-ae12-63177bb0dc61	LOGIN	User	e653024a-8bee-46b0-ae12-63177bb0dc61	null	null	172.18.0.1	2026-04-07 04:20:48.600935+00	\N
27f85045-8d04-4742-8ab4-fd649b68a651	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:21:12.988419+00	\N
5d9172a2-eda3-4858-9d3e-9d9a185578fa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:22:53.32647+00	\N
842cd132-ddcb-464a-96be-f8f529fd9ccf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 1}	\N	2026-04-07 04:23:10.73242+00	\N
f3f7242f-f272-4e1d-b0c7-9ace0e07daa0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 100000}	\N	2026-04-07 04:15:49.929682+00	\N
6e0a9741-28de-4045-9a0b-e39b69c0e48e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:19:40.573338+00	\N
08090126-d84c-475a-a568-d70870fb8dd0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:19:50.208875+00	\N
723a5dda-ddf7-4ab1-96ab-bbc6299a649b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:15:54.605304+00	\N
207b7875-0a97-4fe2-94f0-e11232d55465	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:19:52.448212+00	\N
48202b64-a89a-4811-ba12-561e7eda315a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 1}	\N	2026-04-07 04:19:57.516428+00	\N
9bf39b96-2006-460e-b921-742ad2d99387	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:20:48.295915+00	\N
11fbc971-36d7-482d-9845-aba46a6aba00	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:23:10.699333+00	\N
6382df48-efc3-4655-82f2-403c9f879f7e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:23:13.908507+00	\N
a1d54d62-29fb-4748-965f-7ccdd100cc22	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:15:56.070755+00	\N
2073d26e-775a-4ede-8fc4-829c962b4987	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:19:24.246439+00	\N
043b6c1a-33d3-42f9-9760-94207a89b991	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:19:46.857861+00	\N
cbf7945e-e67c-465d-8447-d1acf658f76e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:19:48.184284+00	\N
71633e7c-dd6f-404f-b3e7-26cdcbdfdc86	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:19:57.473622+00	\N
a93f5415-0c93-4bbf-b3f5-89112bdb299f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:20:00.921801+00	\N
0922c7c1-86c2-460f-8480-45795d21ef79	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:20:01.300112+00	\N
fa109cdc-20b6-4013-81b2-5d61ffb53939	40e341ad-cf4a-484b-9926-3d56cc58fa1f	e653024a-8bee-46b0-ae12-63177bb0dc61	LOGIN	User	e653024a-8bee-46b0-ae12-63177bb0dc61	null	null	172.18.0.1	2026-04-07 04:20:04.88303+00	\N
48da2987-e427-4fb1-9393-07e7f9e0242f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:21:14.281013+00	\N
c823f2a1-bc46-4efb-abfd-c96c0743745c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:22:36.613802+00	\N
cd9a5c45-50b9-434e-a23b-f21455748083	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:22:38.258719+00	\N
60b0efe4-00c4-4116-be06-03c4dde89d9f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:22:54.588094+00	\N
0381747a-e5e2-49e6-b8db-1433286666c9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:23:00.247018+00	\N
5982c627-2c7c-4552-a18c-d51d5e1a0487	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:23:01.477403+00	\N
bd8688ef-283b-45c4-a2e1-0c3a81141d25	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:23:03.580292+00	\N
8198cf12-e6a3-4a1f-8344-f91c9b136d10	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:23:05.748303+00	\N
bdf91170-e10d-4d44-9552-7957202850e3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 100000}	\N	2026-04-07 04:23:10.823959+00	\N
1a080086-beca-4695-9607-8df133f497b0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:23:14.29931+00	\N
c5814f81-aae5-45f4-a2ca-8de49f8660d9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:23:14.777218+00	\N
d62a5387-645d-45f5-8eae-6b258e300270	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:23:18.083799+00	\N
97450ca3-1ef5-45cd-8829-4916d4f5f491	40e341ad-cf4a-484b-9926-3d56cc58fa1f	e653024a-8bee-46b0-ae12-63177bb0dc61	LOGIN	User	e653024a-8bee-46b0-ae12-63177bb0dc61	null	null	172.18.0.1	2026-04-07 04:23:18.392239+00	\N
d117455b-6f17-429c-8673-b44ce759776e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:23:21.729431+00	\N
a739621f-8be8-4680-8886-3a949106912d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:28:02.706866+00	\N
06ccc082-6987-4608-b2ee-8189d0b44938	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:28:06.833058+00	\N
a662ade3-9a4c-420c-abc8-0cebe0c7adda	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:28:07.227712+00	\N
63918655-3756-4fa0-b1e1-5e7a8b5d4736	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:28:07.588229+00	\N
c1ba310a-9349-4fb4-8e16-a9978d9587c8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:31:14.893164+00	\N
a8973246-2b45-4109-8da1-9b7e57fa542a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:32:21.715788+00	\N
b917ac8d-c6b3-433c-8fa2-33df04d50e5a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:32:42.23727+00	\N
f1e46fc1-33f5-4c7d-b161-fc170c1a8b8d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:32:43.641406+00	\N
752bb6d2-25c0-479b-b848-0fe2b5c8fb31	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:35:53.319759+00	\N
75739c10-f260-41a5-b138-6fb584364e85	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:35:54.718277+00	\N
aaca9218-b735-4617-bf53-b70e94320848	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:35:59.060782+00	\N
50489bf9-a4e2-4aec-bcb1-83931d7b1885	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:36:00.485563+00	\N
b95360b0-5b95-4b16-a30a-20d6e23f1fdd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:36:04.765385+00	\N
32c102fe-5727-4bcd-ab21-89f52a9e8b0e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:36:06.067422+00	\N
6cf1a4bf-0370-44ac-bb54-ff59b824e03d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:36:10.333548+00	\N
a8148217-fc33-4ad0-9c41-02ff297b8c12	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:36:11.634096+00	\N
872e39ef-74ab-4a80-8188-f40bfb035bbd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:37:03.787179+00	\N
9ebbe852-c64a-41ec-beda-59a584ca6249	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	5d2a65d5-de6e-4c5c-b70b-fc9e9de0315a	null	{"title": "E2E Report Export 1775536656799", "severity": "HIGH", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 04:37:36.803766+00	\N
2bc86de1-00b9-497b-8d22-d963eef32a7a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	5ea5229f-6e09-4c30-8c47-16c797039bef	null	{"decision": "NO_ACTION", "report_id": "5f97e445-660b-4876-9a1f-a3371bc2d615", "pdf_sha256": "12a737b25b487180b60aa8932b54221b9fd33e6e22acb09f2119728941c5113b", "payload_sha256": "64e758641ccc274c5efca7620cb410c36672ddbb1136b0c269dfce2dfab90078"}	\N	2026-04-07 04:37:37.480986+00	\N
78e7e4c8-2b00-4b0f-93e5-3ff76a813d98	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:36:15.741221+00	\N
a1ad88fb-3dc9-4dda-ba77-d7b622054ea8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:37:02.530175+00	\N
68bb934a-5297-4789-9559-567ce64e57fd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:37:13.5862+00	\N
97e83039-24f1-4f69-b6d2-ef0ddf0c9a2f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:37:24.851363+00	\N
3e963bb6-0e54-4788-9c4b-9ad015d192de	40e341ad-cf4a-484b-9926-3d56cc58fa1f	e653024a-8bee-46b0-ae12-63177bb0dc61	LOGIN	User	e653024a-8bee-46b0-ae12-63177bb0dc61	null	null	172.18.0.1	2026-04-07 04:37:28.160233+00	\N
bec44685-f583-478a-807d-fbeffa6f0894	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_PDF	ReportPackage	584dd595-91d1-4765-b35e-8edcd1f6302f	null	{"case_id": "5d2a65d5-de6e-4c5c-b70b-fc9e9de0315a"}	\N	2026-04-07 04:37:37.113813+00	\N
a61129f2-7b9d-4d50-ae8f-692d8b43315f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	EXPORT_REPORT_PDF	ReportPackage	862088d6-c243-4a16-a2c0-09db833d3ec3	null	{"case_id": "5ea5229f-6e09-4c30-8c47-16c797039bef"}	\N	2026-04-07 04:37:37.822497+00	\N
e5480c7b-34c3-410a-bf71-bb7c54f3e39a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:37:09.803224+00	\N
8db1ffad-0378-4197-83a3-ba0092999c46	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:37:11.514435+00	\N
d93d8814-6643-4eda-9413-d2d9d67c88e0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:36:17.000664+00	\N
430c3b4d-82c6-4f56-9221-33a87739e181	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.11	2026-04-07 04:37:15.822628+00	\N
b48c93f9-f14a-46f2-b4d1-2d73d017c83c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:37:20.942682+00	\N
a0b0e28d-b3c8-493c-a9ed-3677e0be7b2b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 1}	\N	2026-04-07 04:37:20.981536+00	\N
32d5e592-77f8-4930-99d6-488b25bb3120	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	UPDATE_SCORING_CONFIG	ScoringConfig	ae97ee23-536b-47b3-8c4d-a45bbc806176	\N	{"ingest_rate_limit_tpm": 100000}	\N	2026-04-07 04:37:21.075274+00	\N
f2b8f3b5-9997-47f2-af08-fe3f00acae36	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:37:24.031484+00	\N
a0c85d55-d993-4481-a676-2e2799d339ee	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:37:24.433314+00	\N
a6d29b48-975a-4a84-9ff0-5106eef5970d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:37:27.846055+00	\N
ef4ab2e2-9282-4d95-9ebc-51e94afbaf97	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c9dc0c7-cc53-4e4d-857b-a267c9355532	LOGIN	User	2c9dc0c7-cc53-4e4d-857b-a267c9355532	null	null	172.18.0.1	2026-04-07 04:37:31.279669+00	\N
cb7d17b7-8438-483f-b139-dfaf4f5fbec5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 04:37:36.76298+00	\N
dcdf0fab-1fcc-4067-8ab2-bb0a6b3982a2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	GENERATE_REPORT	Case	5d2a65d5-de6e-4c5c-b70b-fc9e9de0315a	null	{"decision": "NO_ACTION", "report_id": "598c2407-8ab0-4503-8a98-5234a2ecfaa2", "pdf_sha256": "2f5805fb4ad45bdf73c2864e54fbee851b20cbe1e3806dd30de5ed95333b15fa", "payload_sha256": "ca31757a4df58fc9574a3ab180a3918f8da2d01c08e986fced97bb954b151a3e"}	\N	2026-04-07 04:37:36.831169+00	\N
3f20dbf3-16a1-449b-84e1-d688566207c7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	EXPORT_REPORT_JSON	ReportPackage	584dd595-91d1-4765-b35e-8edcd1f6302f	null	null	\N	2026-04-07 04:37:37.098125+00	\N
d573f879-7af2-4112-8b4f-c0afc58f45cc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	LOGIN	User	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	null	null	172.18.0.1	2026-04-07 04:37:37.421838+00	\N
99decfef-43b7-4190-9d94-6f1f76a1200a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	CREATE	Case	5ea5229f-6e09-4c30-8c47-16c797039bef	null	{"title": "E2E Auditor Export 1775536657452", "severity": "MEDIUM", "player_id": "464e8bab-c13c-4d14-b512-f008f997e437", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-04-07 04:37:37.457159+00	\N
cfeaec09-db37-46ca-85bd-441ff19860af	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	LOGIN	User	a295ceae-bac0-4c7f-8fe8-e8431d651700	null	null	172.18.0.1	2026-04-07 04:37:37.799622+00	\N
4887d158-d47d-42a2-ace4-75d6488d07a6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a295ceae-bac0-4c7f-8fe8-e8431d651700	EXPORT_REPORT_JSON	ReportPackage	862088d6-c243-4a16-a2c0-09db833d3ec3	null	null	\N	2026-04-07 04:37:37.810775+00	\N
\.


--
-- Data for Name: bets; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.bets (id, tenant_id, player_id, external_bet_id, source_system, bet_type, stake_amount, potential_payout, actual_payout, odds, currency, status, event_name, market_name, selection_name, source_event_id, ingest_job_id, raw_payload, occurred_at, settled_at, created_at, product_type, game_id, game_name, game_provider, game_category, rtp_teorico) FROM stdin;
\.


--
-- Data for Name: case_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.case_events (id, case_id, tenant_id, event_type, content, created_by, created_at) FROM stdin;
ae81159f-d5fa-40bf-88e2-9fcb85a4d423	5c7eac24-5048-4f59-877d-c398a522a6ca	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"note": "Caso criado automaticamente por alta severidade e anomaly_score > 0.9"}	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-04 09:08:16.001152+00
e64ce096-a1bc-4acf-b33e-53d931d1ae65	db2af615-083f-4ffb-bd53-e05d9ce4cfb2	40e341ad-cf4a-484b-9926-3d56cc58fa1f	NOTE	{"note": "Caso criado automaticamente por alta severidade e anomaly_score > 0.9"}	e653024a-8bee-46b0-ae12-63177bb0dc61	2026-04-04 09:08:16.001152+00
e7f7c5ab-18f8-4ed0-a8bc-ec5290b32362	d48c68fe-fad6-4d61-94b1-451938885a6d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EVIDENCE_UPLOAD	{"bucket": "betaml-evidence", "sha256": "017144b7b656699d8a1c0fa5217fd8bfc2fd3fe3a5764ab46a4ec76de66cd19d", "file_name": "tmp.L9xKHjsnJ1", "size_bytes": 96, "description": "Smoke evidence attachment", "object_name": "cases/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/d48c68fe-fad6-4d61-94b1-451938885a6d/20260404T104059Z_6feee16da42042f9b361348807236d24_tmp.L9xKHjsnJ1", "uploaded_at": "2026-04-04T10:40:59.825735+00:00", "content_type": "text/plain", "storage_backend": "minio"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-04 10:40:59.80439+00
25589393-a64c-4005-8fa3-8f6e5116deca	d48c68fe-fad6-4d61-94b1-451938885a6d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "a8db01a8-fe3b-4c62-ad4e-b04e085268a3", "pdf_sha256": "bc37d97e18b7efae772824037d6a5e0c1b3f52f6f80627413bb12a7b3cdd0342", "payload_sha256": "680cae2557619cff023175c15e2817a268c8aa70c8ff6f8286203a8e51d9b4f5", "attachments_count": 1}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-04 10:41:00.136006+00
ff236830-93b8-4ac9-a58e-6333292a7935	d48c68fe-fad6-4d61-94b1-451938885a6d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_SUBMITTED	{"note": "Submissão manual registrada com maker-checker e trilha de custódia preservada. Enquanto não houver integração oficial, o envio ao portal regulatório permanece controlado fora da plataforma.", "channel": "MANUAL_PORTAL", "case_status": "REPORTED", "tracking_id": "134850b5-64a7-4434-a602-906a1a2b51ad", "submitted_at": "2026-04-04T10:41:00.966047+00:00", "submitted_by": "2c9dc0c7-cc53-4e4d-857b-a267c9355532", "payload_sha256": "680cae2557619cff023175c15e2817a268c8aa70c8ff6f8286203a8e51d9b4f5", "report_package_id": "66572478-754e-47b0-af54-8de0489872a9"}	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-04 10:41:00.959734+00
41cdadee-d4e5-4ef5-8793-8a9defb794db	99b538e8-3337-41b9-8feb-b7abb7c581ee	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"kind": "ALERT_LINKED", "alert_id": "007923b2-28d8-41a9-83fc-6aae2196213e", "severity": "HIGH", "alert_title": "E2E link alert 1775531709682", "case_reference_number": "CASE-20260407-99B538E8"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:15:10.594751+00
4529289a-2db8-4ee9-95ad-34b519d2700a	b4213734-3133-47e5-952d-1abac9728fe2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:15:43.624484+00
d65ed91e-70fe-4b7f-a42c-10c0d5f1adcb	b4213734-3133-47e5-952d-1abac9728fe2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "6c12850c-de05-49ba-9ae0-2d91f630e016", "pdf_sha256": "5d83499762aa38af1a9c4ff267c7a1c05936e9cbedaef1da9193c50dbafeea30", "payload_sha256": "c2f668930b322df3a1227372a013b322588d63902c0ab19a3d80510803c08c14", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:15:43.825332+00
d07b2a83-d4a5-4544-85e5-4a7fb9d90e97	a25984d7-bd65-41e9-ab9a-3085fe15899a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"kind": "ALERT_LINKED", "alert_id": "c6329a9f-15aa-446e-b3c0-57548b46c5d1", "severity": "HIGH", "alert_title": "E2E link alert 1775531841687", "case_reference_number": "CASE-20260407-A25984D7"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:17:22.587107+00
7b165a0e-bbbd-46b0-87eb-798f07565eb3	e73da2b6-9649-48ca-bf4b-4ccf9871f227	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:17:42.403622+00
baf61ba6-e042-4df4-abbf-01db7f3c5d0f	e73da2b6-9649-48ca-bf4b-4ccf9871f227	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "7b032d8c-35ed-4be7-91b2-4c28c7cd7a4d", "pdf_sha256": "64329ae2044f5712dd7154e7926b8c48f56e14ad56c60ad9189b9b33217f6574", "payload_sha256": "b797234aafe24441d643ae8141d41cc8d6d2857e413d227f444758b81d1892e8", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:17:42.553882+00
4f3e4d8e-eab3-4afe-a4c7-6e9630da1b8e	a451aa80-ae65-42a6-b94e-e8c098eead5b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"kind": "ALERT_LINKED", "alert_id": "61e3a1d9-a460-42ae-8b54-904752357b87", "severity": "HIGH", "alert_title": "E2E link alert 1775532402863", "case_reference_number": "CASE-20260407-A451AA80"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:26:43.832339+00
2457c939-bee2-4115-b168-c2b73477a9f4	daf0619d-d49a-44d9-91ff-f72e37bc8a5e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:27:04.148967+00
5f77c3ce-da74-465a-a698-821f3cb95609	daf0619d-d49a-44d9-91ff-f72e37bc8a5e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "abd4d4ca-c6ba-4a06-b928-3dd1c335058d", "pdf_sha256": "17bc8e0a440901b85a7b35b0c1c7f4856f1bf462458b5a435095f53470a68a39", "payload_sha256": "64bcfaacb09ac114c1a32d816c1a4b8b3295975cd7983f8172a781dbbf3dc0c3", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:27:04.341508+00
f5a144b0-5912-4780-8a29-bd0c54c6aeda	2c80aa82-4998-4e1c-8a64-f699f78de516	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"kind": "ALERT_LINKED", "alert_id": "6faf53e2-169c-4f8b-bbc4-82c95d06495d", "severity": "HIGH", "alert_title": "E2E link alert 1775532840861", "case_reference_number": "CASE-20260407-2C80AA82"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:34:01.750832+00
8eaabf18-e559-4605-b792-14367666a3da	29a33c2e-9730-4576-abc3-fd77bd81a53f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:34:22.513532+00
38854aba-a4c9-48ff-9759-2aced923d621	29a33c2e-9730-4576-abc3-fd77bd81a53f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "55deb976-0de5-4e86-b0a2-508ac5071ebe", "pdf_sha256": "08d880ceba365dcbf806cd11bcbb6845e7e5d70432e3b791da6edada5706ba93", "payload_sha256": "bd7a9d84926697de6084736a43ed272d8ca8c0cecbd7f53916e595989ec59263", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:34:22.665415+00
4de8b589-62d6-4bd8-9796-59d23ba1fb4e	e6aaf58a-1466-4728-bada-045db352f214	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"kind": "ALERT_LINKED", "alert_id": "3545d5c8-ca54-4426-9ba9-e7505a91cb9c", "severity": "HIGH", "alert_title": "E2E link alert 1775533122906", "case_reference_number": "CASE-20260407-E6AAF58A"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:38:43.890037+00
7213c7ef-8d3c-4d30-a4b5-d37b7471b687	43759d5b-e04e-47c8-86e9-62e51ff47593	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:39:07.401565+00
8a1e7833-4637-4949-842c-2cb877e045e7	43759d5b-e04e-47c8-86e9-62e51ff47593	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "0638fb1d-e159-4942-a4e9-686da414c132", "pdf_sha256": "81ef7319aa454c1e57fa0c4bab13d8f455579697f7c49105c1cfd10b540d0351", "payload_sha256": "379924fa13763b1019fdb241bd2e82c19ed9d090ea3b415823b92450c1470fd5", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:39:07.589651+00
11d69155-6346-4f8c-b996-cafc9457d17c	62f3228e-998c-4cec-af91-4ac475562664	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"kind": "ALERT_LINKED", "alert_id": "596a9339-5b20-4757-b70c-52903e217a03", "severity": "HIGH", "alert_title": "E2E link alert 1775533912341", "case_reference_number": "CASE-20260407-62F3228E"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:51:53.281389+00
818f188d-27bb-41db-b716-bb16066f39e9	90ee3ad8-5f7a-45ee-9a30-6fa1507af0ec	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:52:16.876909+00
5b9919ea-6104-46b4-98c6-3bd25a96a851	90ee3ad8-5f7a-45ee-9a30-6fa1507af0ec	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "f6bd79e4-a1b2-46aa-bcd0-647d36bce39b", "pdf_sha256": "4dd897cb8c5cb0505aa56b78f01e72316ededbe5682a8ce2ede2d50d668b01ce", "payload_sha256": "5a34351e106764eace63f49f1002e2b9b2e359e21769b8d87fe34a8d65a14cf0", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:52:17.030033+00
1088d09b-43a0-4506-a311-c79bfcc4fbe4	e9e5d372-aac2-4a13-aaf7-e15fd25faaaf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 05:11:24.991105+00
885be40d-ffe3-4c85-953d-ead664a0bb8f	8075dabc-8936-4d78-866d-0fe44bd45a4b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"kind": "ALERT_LINKED", "alert_id": "4264e047-d5ef-491a-ba98-30d3b03eca93", "severity": "HIGH", "alert_title": "E2E link alert 1775534090555", "case_reference_number": "CASE-20260407-8075DABC"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:54:51.602895+00
ae75ff99-581f-4734-b70d-f776f4af256f	6f8474c4-ddcc-44cd-b47b-7bc0f1cbf5c9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "4aa97796-1885-4efd-a689-8682cbfccc15", "pdf_sha256": "8c6f4d9603dbbc8fe3e525fcfc91a6a46017907a666ba237433e895236c33853", "payload_sha256": "0b1eec4e44012e1c7a6f2f26b35a79e628bb2428942e221bcd95a8a58689e78c", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:58:07.748728+00
12528a53-21b2-4959-8a3f-85c38b2ad9eb	d71eec3c-f7fb-4689-826f-d4e3c7fb4a65	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:55:15.034526+00
c98d1cfc-3988-4ebe-80e3-3cd712be636e	d71eec3c-f7fb-4689-826f-d4e3c7fb4a65	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "d3fc41e9-bf1b-4949-b980-5def09e89fa3", "pdf_sha256": "145c5102fc12f449a3071e82cb612c025be23ff22da8b1565729daa5f61d5e94", "payload_sha256": "c4213c7c06d3c834c00352e7e29c3118edd1d81e69eaa551f5aed55599e94248", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:55:15.235409+00
7d060428-567f-4131-9849-8f1f7b189fe2	47e1a129-8365-4217-8dcd-3f3338962ebf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"kind": "ALERT_LINKED", "alert_id": "971a0d9d-cbdf-4845-8a00-0c72dafe413a", "severity": "HIGH", "alert_title": "E2E link alert 1775534262091", "case_reference_number": "CASE-20260407-47E1A129"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:57:43.166076+00
7467c90e-871b-4af9-b85b-c8dfd391d977	6f8474c4-ddcc-44cd-b47b-7bc0f1cbf5c9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	NOTE	{"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:58:07.505037+00
5491072f-221e-46cd-aba5-b38b074a1271	5d2a65d5-de6e-4c5c-b70b-fc9e9de0315a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "598c2407-8ab0-4503-8a98-5234a2ecfaa2", "pdf_sha256": "2f5805fb4ad45bdf73c2864e54fbee851b20cbe1e3806dd30de5ed95333b15fa", "payload_sha256": "ca31757a4df58fc9574a3ab180a3918f8da2d01c08e986fced97bb954b151a3e", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:37:36.831169+00
8daabc2c-acd7-4661-87f7-e247151c6e58	5ea5229f-6e09-4c30-8c47-16c797039bef	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "5f97e445-660b-4876-9a1f-a3371bc2d615", "pdf_sha256": "12a737b25b487180b60aa8932b54221b9fd33e6e22acb09f2119728941c5113b", "payload_sha256": "64e758641ccc274c5efca7620cb410c36672ddbb1136b0c269dfce2dfab90078", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:37:37.480986+00
fe1905a7-4ba4-4beb-9707-a51b5e1ed24d	ec7951b7-6bf7-4652-a6eb-f53cd4489d43	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:41:28.153851+00
a1028746-af22-4eb4-9ac4-2b048b464494	ec7951b7-6bf7-4652-a6eb-f53cd4489d43	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:41:28.174388+00
18380e4a-cc89-45b0-acb2-33457e98bdcd	ec7951b7-6bf7-4652-a6eb-f53cd4489d43	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "CLOSED"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:41:28.189644+00
e4a3d36b-53a9-4d8e-8870-ca5069583e35	441cc147-981f-4e3a-9415-9af11b1aa905	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "476c6d48-c2d7-4e4d-9be4-af19c7ad74eb", "pdf_sha256": "d110bc65095a26fceaf818b33a3b6de4af34023b71dd0a12ef809c1b4e695fff", "payload_sha256": "89af9cfbf0f264955afbbc4bee411f9cc0a991d761719efd1ffc44ab5fc1e947", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:41:29.813773+00
8d54bdbd-f740-4547-9648-2f18523f3634	468ac1e7-13d8-4b71-a76b-ac47b9de7567	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "fd1ab90b-9473-44c6-8d1e-a7657a0ce5a0", "pdf_sha256": "007a33f2145c85ae7ade529c7384c56b7bee22d9e5d083606368579ab3b93a5e", "payload_sha256": "457a0bab1efba1813c5146cacdb518703c742b3d5ba1830c9ffd5bd0b28436b0", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:41:30.417455+00
cf58ca44-72cf-47d6-9150-84d316f2c16b	93d9d925-f602-4c06-9368-83e31001bc4b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:42:00.593491+00
0a00479a-071b-4bf2-b359-0747ed03ddb2	93d9d925-f602-4c06-9368-83e31001bc4b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:42:00.605513+00
7e437cb7-e5be-4422-999e-330b725cde00	93d9d925-f602-4c06-9368-83e31001bc4b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "CLOSED"}	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:42:00.622068+00
0fc53da3-13a8-4b2f-89d1-6fe6f6676c83	ec263c8f-4edc-4dfb-b508-bb1bbd2dbb69	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:43:29.489338+00
9aec485f-4df1-413d-b1ef-1ba5f4fd77e5	ec263c8f-4edc-4dfb-b508-bb1bbd2dbb69	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:43:29.502982+00
000d0049-8cd2-4c3b-846f-52b2b54ce0d5	ec263c8f-4edc-4dfb-b508-bb1bbd2dbb69	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "CLOSED"}	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:43:29.517983+00
b89c55e5-175f-4f07-8745-799b547d486a	43b747b8-5e26-476f-8e2a-53f894d1041a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:43:47.967224+00
fb140fb7-b552-42c5-b905-8cb7126d42ac	43b747b8-5e26-476f-8e2a-53f894d1041a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:43:47.983148+00
165fbf8f-e448-4fe2-bfb0-a1aabfa3e747	43b747b8-5e26-476f-8e2a-53f894d1041a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "CLOSED"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:43:47.997074+00
bd1edb39-b794-4a8c-9287-0008ec441116	43b747b8-5e26-476f-8e2a-53f894d1041a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "3abb3fcb-b6d7-4803-bf59-97e0bd2c4f6f", "pdf_sha256": "129f78b2a805f280a2ef0de900dd3de2dfeabb839992ec146761156f1a948a07", "payload_sha256": "667c3b36c61bb048fc883092eedd661f853be8db706686f4e0dba781595750f2", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:43:48.014574+00
c99663c1-3ecd-41e9-a6f9-527baecbe374	09fb76ee-85d5-4706-bb22-301996504548	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:45:29.40036+00
10ac6ada-ff3b-4e05-b487-e5eab7375b78	09fb76ee-85d5-4706-bb22-301996504548	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:45:29.416863+00
7ee7bb3b-3ce0-4cd3-a7c5-c815a6185d49	09fb76ee-85d5-4706-bb22-301996504548	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "CLOSED"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:45:29.435685+00
07831518-a5f1-487a-abc9-6f27e4ca2554	09fb76ee-85d5-4706-bb22-301996504548	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "119d42c0-6495-4a28-a6d6-e26b247b9fda", "pdf_sha256": "cce477e95f45f7dff0433b57eedb469c0188aecd2a974199d02e4b1003f49752", "payload_sha256": "cb7d6ade34969b7ebc33089ba568b970e34714143cea5881a3c2afe91327a079", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:45:29.456389+00
c130b51e-d686-4626-8d0e-4566ef43ba56	216f8b56-54a1-42aa-b69f-cb19a82a689a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "ba3cefd0-3548-49e6-970c-1574a9e0f5c5", "pdf_sha256": "14ebdea1a92190836eeb5d8825d01ad7a0ffed0f137b668814c76275858a0c8b", "payload_sha256": "89c5b5337184a3667ac4eb3acf29387449e1a4f269849efac28afcbbac1ab456", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:49:46.929672+00
03f93ef6-9d94-4099-9e54-13832ac49153	08150300-1e4c-420b-b78b-b08f5ace85a5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "dafc5b90-1e19-483f-aedb-814d900d25ab", "pdf_sha256": "7bb0034b919e06814f0a78ef7f90734a5a5e7006802bb873b70dc78e89860219", "payload_sha256": "8abbbc0976a88a612513bd70c90ac0528b157e19624c8a1368398331108f1de4", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:49:47.40483+00
adf4c7bf-6528-4f7f-8af0-76fcc08631ca	95a6b4ac-f960-4fb7-a7ab-d106bcf625e0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:49:53.780876+00
02ae8cf8-b6c4-44e4-b5da-caa8aaa002f9	95a6b4ac-f960-4fb7-a7ab-d106bcf625e0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:49:53.795481+00
80780fa2-3ec0-4b51-915e-a131bcac74c5	95a6b4ac-f960-4fb7-a7ab-d106bcf625e0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "CLOSED"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:49:53.809726+00
4379473f-b40d-42c0-89d8-c314a5d224a1	95a6b4ac-f960-4fb7-a7ab-d106bcf625e0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "83016b0c-b9f0-4c55-b153-e9eea80497b7", "pdf_sha256": "ccdff1b80752992e71f4fa293dd06c9fd8f6aa07aba4f2d039e6ee6434a88086", "payload_sha256": "9642bd2855eb6f2d505a427b91e76687702a16dd3de14cec36d85bdbc98f91e5", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:49:53.825388+00
6ded91b1-31a9-4a6e-80ae-34ed719deea6	ed136fe5-5990-4a83-b5dd-b217d7cdc020	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "427bddb4-0471-4b5c-b46a-da1f0b32fa85", "pdf_sha256": "45eefde0ee00921d14c813cefaf1e1cc24390a55a09f6a0271b0e5a77025d789", "payload_sha256": "5717ba3d499823eefa58c6021967a8db89c71a7b03a0d38d34468d43aac35e3a", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 05:11:18.087472+00
8352023a-edb3-4b79-8490-f8070c4c15fa	ef28e581-2794-4286-9627-108a7278a3a0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "27be5112-edd1-40d2-aa73-2fc8d2f74786", "pdf_sha256": "d9c21b17f406245909b176841945ea858b897c468f1a8544a4e7546340557c34", "payload_sha256": "6020e2bd3aa9724a59334d4be53a0cc2a93e75178dedab05b5b966d849896a68", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 05:11:18.705184+00
f71d011e-1929-4c7b-94a4-9d87cdd0d167	e9e5d372-aac2-4a13-aaf7-e15fd25faaaf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 05:11:24.973059+00
7e99c065-a07d-4237-8b69-98c64f2d6f6c	e9e5d372-aac2-4a13-aaf7-e15fd25faaaf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	STATUS_CHANGE	{"new_status": "CLOSED"}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 05:11:25.007729+00
f4e041dc-e61c-45a5-8f42-5478ecf4aa09	e9e5d372-aac2-4a13-aaf7-e15fd25faaaf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "f5bc91f2-19dd-46b1-9f3a-519406ee305b", "pdf_sha256": "e55e7c8a89a4da79f77ba3ba656cae4ac004b0b59e590fb5426f124f68f4254f", "payload_sha256": "320770a080a61b5e634ef8cb572709148ffc1ca4608b206c3bec5adcd0478f69", "attachments_count": 0}	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 05:11:25.023909+00
\.


--
-- Data for Name: cases; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.cases (id, tenant_id, player_id, title, description, status, severity, assigned_to, created_by, closed_by, closed_at, created_at, updated_at, reference_number, sla_due_at, priority, auto_created, auto_created_reason, source_alert_id, backfill_job_id, ingest_mode) FROM stdin;
db2af615-083f-4ffb-bd53-e05d9ce4cfb2	40e341ad-cf4a-484b-9926-3d56cc58fa1f	80fbe818-191f-4c2d-9472-18ec2429d42f	Investigação PLD — Round-tripping EXT-OPERADOR_B-004	Caso auto-criado por detecção de padrão de round-tripping	OPEN	CRITICAL	\N	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	\N	MEDIUM	t	scoring.alerts: anomaly_score=0.91, severity=CRITICAL	0f308c45-b230-49f6-bd6d-cb23ddb54340	\N	incremental
d48c68fe-fad6-4d61-94b1-451938885a6d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	4633153f-6cca-40b2-b0f7-30df770677ec	Smoke Fase 1 e2e 20260404T104059Z	Caso criado por smoke automatizado da fase 1	REPORTED	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-04 10:41:00.966014+00	2026-04-04 10:40:59.600383+00	2026-04-04 10:41:00.959734+00	CASE-20260404-D48C68FE	2026-04-05 10:40:59.612306+00	MEDIUM	f	\N	\N	\N	incremental
28e93fee-30ea-4f56-8cd3-5174f829908d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Case for alert link 1775531406493	Caso criado automaticamente pela suíte E2E	OPEN	MEDIUM	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:10:06.521633+00	2026-04-07 03:10:06.521633+00	CASE-20260407-28E93FEE	2026-04-10 03:10:06.533043+00	MEDIUM	f	\N	\N	\N	incremental
5c7eac24-5048-4f59-877d-c398a522a6ca	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	144de474-f551-4a16-9497-cc9307d98461	Investigação PLD — Round-tripping EXT-OPERADOR_A-004	Caso auto-criado por detecção de padrão de round-tripping	OPEN	CRITICAL	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	\N	2026-04-04 09:08:16.001152+00	2026-04-07 03:11:14.253874+00	CASE-20260404-5C7EAC24	\N	MEDIUM	t	scoring.alerts: anomaly_score=0.91, severity=CRITICAL	258e1ad4-2dbf-4be4-936d-dd3e9b0dd6bb	\N	incremental
fad6d360-2b3f-4cce-a4b9-2a2d0692da04	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Workflow Case 1775531512179	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:11:52.190935+00	2026-04-07 03:11:52.190935+00	CASE-20260407-FAD6D360	2026-04-08 03:11:52.197566+00	MEDIUM	f	\N	\N	\N	incremental
ee834080-3262-4085-8152-dd965c298122	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Narrative Suggestion 1775531543719	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:12:23.782319+00	2026-04-07 03:12:23.782319+00	CASE-20260407-EE834080	2026-04-08 03:12:23.794452+00	MEDIUM	f	\N	\N	\N	incremental
99b538e8-3337-41b9-8feb-b7abb7c581ee	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Case for alert link 1775531709721	Caso criado automaticamente pela suíte E2E	OPEN	MEDIUM	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:15:09.745207+00	2026-04-07 03:15:10.594751+00	CASE-20260407-99B538E8	2026-04-10 03:15:09.749751+00	MEDIUM	f	\N	007923b2-28d8-41a9-83fc-6aae2196213e	\N	incremental
25a140ef-d778-4f04-85cc-56f83ef54cc3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	E2E Manual Case 1775531738284	Caso criado pela suíte E2E para validar o fluxo manual.	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:15:39.375308+00	2026-04-07 03:15:39.375308+00	CASE-20260407-25A140EF	2026-04-08 03:15:39.3805+00	MEDIUM	f	\N	\N	\N	incremental
b4213734-3133-47e5-952d-1abac9728fe2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Workflow Case 1775531742561	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:15:42.567831+00	2026-04-07 03:15:42.567831+00	CASE-20260407-B4213734	2026-04-08 03:15:42.573208+00	MEDIUM	f	\N	\N	\N	incremental
76431f6b-a665-4238-98e6-52121c6ddaad	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Narrative Suggestion 1775531747942	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:15:47.965579+00	2026-04-07 03:15:47.965579+00	CASE-20260407-76431F6B	2026-04-08 03:15:47.970033+00	MEDIUM	f	\N	\N	\N	incremental
a25984d7-bd65-41e9-ab9a-3085fe15899a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Case for alert link 1775531841714	Caso criado automaticamente pela suíte E2E	OPEN	MEDIUM	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:17:21.731552+00	2026-04-07 03:17:22.587107+00	CASE-20260407-A25984D7	2026-04-10 03:17:21.736193+00	MEDIUM	f	\N	c6329a9f-15aa-446e-b3c0-57548b46c5d1	\N	incremental
98c9d904-7e0a-439f-919c-6cf6b7e71f46	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	E2E Manual Case 1775531857447	Caso criado pela suíte E2E para validar o fluxo manual.	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:17:38.011145+00	2026-04-07 03:17:38.011145+00	CASE-20260407-98C9D904	2026-04-08 03:17:38.016025+00	MEDIUM	f	\N	\N	\N	incremental
e73da2b6-9649-48ca-bf4b-4ccf9871f227	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Workflow Case 1775531861256	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:17:41.260695+00	2026-04-07 03:17:41.260695+00	CASE-20260407-E73DA2B6	2026-04-08 03:17:41.265287+00	MEDIUM	f	\N	\N	\N	incremental
7a245cbf-ef16-40e2-8c88-041c129ca71a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Narrative Suggestion 1775531864801	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:17:44.83012+00	2026-04-07 03:17:44.83012+00	CASE-20260407-7A245CBF	2026-04-08 03:17:44.83514+00	MEDIUM	f	\N	\N	\N	incremental
3141b074-65ff-4add-a096-bcb9878af0e6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Search Case 1775531886133	Caso criado para validar a busca global via E2E.	OPEN	HIGH	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	\N	2026-04-07 03:18:06.151403+00	2026-04-07 03:18:06.151403+00	CASE-20260407-3141B074	2026-04-08 03:18:06.154952+00	MEDIUM	f	\N	\N	\N	incremental
a451aa80-ae65-42a6-b94e-e8c098eead5b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Case for alert link 1775532402921	Caso criado automaticamente pela suíte E2E	OPEN	MEDIUM	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:26:42.949893+00	2026-04-07 03:26:43.832339+00	CASE-20260407-A451AA80	2026-04-10 03:26:42.953977+00	MEDIUM	f	\N	61e3a1d9-a460-42ae-8b54-904752357b87	\N	incremental
19d3de12-395f-46ce-9448-b8f95da5b2f2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	E2E Manual Case 1775532418746	Caso criado pela suíte E2E para validar o fluxo manual.	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:26:59.848965+00	2026-04-07 03:26:59.848965+00	CASE-20260407-19D3DE12	2026-04-08 03:26:59.858875+00	MEDIUM	f	\N	\N	\N	incremental
daf0619d-d49a-44d9-91ff-f72e37bc8a5e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Workflow Case 1775532423073	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:27:03.078159+00	2026-04-07 03:27:03.078159+00	CASE-20260407-DAF0619D	2026-04-08 03:27:03.082523+00	MEDIUM	f	\N	\N	\N	incremental
5f5eca0e-1459-4663-832c-dcf77fd0c30c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Narrative Suggestion 1775532426663	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:27:06.686427+00	2026-04-07 03:27:06.686427+00	CASE-20260407-5F5ECA0E	2026-04-08 03:27:06.691044+00	MEDIUM	f	\N	\N	\N	incremental
46886398-cbee-4f44-bf79-2a5b3e61770c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Search Case 1775532440861	Caso criado para validar a busca global via E2E.	OPEN	HIGH	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	\N	2026-04-07 03:27:20.877473+00	2026-04-07 03:27:20.877473+00	CASE-20260407-46886398	2026-04-08 03:27:20.880744+00	MEDIUM	f	\N	\N	\N	incremental
2c80aa82-4998-4e1c-8a64-f699f78de516	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Case for alert link 1775532840894	Caso criado automaticamente pela suíte E2E	OPEN	MEDIUM	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:34:00.910324+00	2026-04-07 03:34:01.750832+00	CASE-20260407-2C80AA82	2026-04-10 03:34:00.920349+00	MEDIUM	f	\N	6faf53e2-169c-4f8b-bbc4-82c95d06495d	\N	incremental
fb7d6cfd-57c2-42f9-b2be-08ae202cebe5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	E2E Manual Case 1775532857190	Caso criado pela suíte E2E para validar o fluxo manual.	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:34:18.216291+00	2026-04-07 03:34:18.216291+00	CASE-20260407-FB7D6CFD	2026-04-08 03:34:18.220281+00	MEDIUM	f	\N	\N	\N	incremental
29a33c2e-9730-4576-abc3-fd77bd81a53f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Workflow Case 1775532861447	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:34:21.451256+00	2026-04-07 03:34:21.451256+00	CASE-20260407-29A33C2E	2026-04-08 03:34:21.457202+00	MEDIUM	f	\N	\N	\N	incremental
33399e7e-20db-41e6-938a-d9fcd48ed71a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Narrative Suggestion 1775532865376	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:34:25.401552+00	2026-04-07 03:34:25.401552+00	CASE-20260407-33399E7E	2026-04-08 03:34:25.409178+00	MEDIUM	f	\N	\N	\N	incremental
4df9ae34-69d1-4e79-a2cb-53cfce07bcc0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Search Case 1775532880498	Caso criado para validar a busca global via E2E.	OPEN	HIGH	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	\N	2026-04-07 03:34:40.515264+00	2026-04-07 03:34:40.515264+00	CASE-20260407-4DF9AE34	2026-04-08 03:34:40.51882+00	MEDIUM	f	\N	\N	\N	incremental
e6aaf58a-1466-4728-bada-045db352f214	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Case for alert link 1775533123012	Caso criado automaticamente pela suíte E2E	OPEN	MEDIUM	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:38:43.042497+00	2026-04-07 03:38:43.890037+00	CASE-20260407-E6AAF58A	2026-04-10 03:38:43.049038+00	MEDIUM	f	\N	3545d5c8-ca54-4426-9ba9-e7505a91cb9c	\N	incremental
a4ba0530-29bf-45c3-89f3-b3c2e9aaeb19	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	E2E Manual Case 1775533141997	Caso criado pela suíte E2E para validar o fluxo manual.	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:39:03.04271+00	2026-04-07 03:39:03.04271+00	CASE-20260407-A4BA0530	2026-04-08 03:39:03.050413+00	MEDIUM	f	\N	\N	\N	incremental
43759d5b-e04e-47c8-86e9-62e51ff47593	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Workflow Case 1775533146299	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:39:06.304256+00	2026-04-07 03:39:06.304256+00	CASE-20260407-43759D5B	2026-04-08 03:39:06.308778+00	MEDIUM	f	\N	\N	\N	incremental
48033aa9-0f0c-48ee-8d19-38ca15c49c41	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Narrative Suggestion 1775533149938	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:39:09.963179+00	2026-04-07 03:39:09.963179+00	CASE-20260407-48033AA9	2026-04-08 03:39:09.967813+00	MEDIUM	f	\N	\N	\N	incremental
7c37ad54-1588-47ac-999a-ebbdf2937e25	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Search Case 1775533164586	Caso criado para validar a busca global via E2E.	OPEN	HIGH	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	\N	2026-04-07 03:39:24.610712+00	2026-04-07 03:39:24.610712+00	CASE-20260407-7C37AD54	2026-04-08 03:39:24.61602+00	MEDIUM	f	\N	\N	\N	incremental
62f3228e-998c-4cec-af91-4ac475562664	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Case for alert link 1775533912381	Caso criado automaticamente pela suíte E2E	OPEN	MEDIUM	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:51:52.404363+00	2026-04-07 03:51:53.281389+00	CASE-20260407-62F3228E	2026-04-10 03:51:52.415664+00	MEDIUM	f	\N	596a9339-5b20-4757-b70c-52903e217a03	\N	incremental
ab33f18a-3946-4152-b7d7-c34c74e72f77	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	E2E Manual Case 1775533930385	Caso criado pela suíte E2E para validar o fluxo manual.	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:52:11.409123+00	2026-04-07 03:52:11.409123+00	CASE-20260407-AB33F18A	2026-04-08 03:52:11.413963+00	MEDIUM	f	\N	\N	\N	incremental
09fb76ee-85d5-4706-bb22-301996504548	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Audit Export 1775537129376	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:45:29.43859+00	2026-04-07 04:45:29.382368+00	2026-04-07 04:45:29.435685+00	CASE-20260407-09FB76EE	2026-04-08 04:45:29.386804+00	MEDIUM	f	\N	\N	\N	incremental
90ee3ad8-5f7a-45ee-9a30-6fa1507af0ec	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Workflow Case 1775533935835	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:52:15.839928+00	2026-04-07 03:52:15.839928+00	CASE-20260407-90EE3AD8	2026-04-08 03:52:15.845801+00	MEDIUM	f	\N	\N	\N	incremental
6d9fae96-b4e4-48ce-be8d-b4c8fe9c06cb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Narrative Suggestion 1775533939775	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:52:19.803031+00	2026-04-07 03:52:19.803031+00	CASE-20260407-6D9FAE96	2026-04-08 03:52:19.808091+00	MEDIUM	f	\N	\N	\N	incremental
216f8b56-54a1-42aa-b69f-cb19a82a689a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Report Export 1775537386902	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 04:49:46.906942+00	2026-04-07 04:49:46.906942+00	CASE-20260407-216F8B56	2026-04-08 04:49:46.914746+00	MEDIUM	f	\N	\N	\N	incremental
d5bbb065-dae6-4f52-8f71-37da67149a64	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Search Case 1775533955602	Caso criado para validar a busca global via E2E.	OPEN	HIGH	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	\N	2026-04-07 03:52:35.623379+00	2026-04-07 03:52:35.623379+00	CASE-20260407-D5BBB065	2026-04-08 03:52:35.627919+00	MEDIUM	f	\N	\N	\N	incremental
8075dabc-8936-4d78-866d-0fe44bd45a4b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Case for alert link 1775534090599	Caso criado automaticamente pela suíte E2E	OPEN	MEDIUM	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:54:50.63171+00	2026-04-07 03:54:51.602895+00	CASE-20260407-8075DABC	2026-04-10 03:54:50.638947+00	MEDIUM	f	\N	4264e047-d5ef-491a-ba98-30d3b03eca93	\N	incremental
08150300-1e4c-420b-b78b-b08f5ace85a5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Auditor Export 1775537387355	Caso criado automaticamente pela suíte E2E	OPEN	MEDIUM	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 04:49:47.374659+00	2026-04-07 04:49:47.374659+00	CASE-20260407-08150300	2026-04-10 04:49:47.385735+00	MEDIUM	f	\N	\N	\N	incremental
ca2420d2-f9f9-4b17-99b3-3484586722a5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	E2E Manual Case 1775534108408	Caso criado pela suíte E2E para validar o fluxo manual.	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:55:09.451973+00	2026-04-07 03:55:09.451973+00	CASE-20260407-CA2420D2	2026-04-08 03:55:09.456079+00	MEDIUM	f	\N	\N	\N	incremental
d71eec3c-f7fb-4689-826f-d4e3c7fb4a65	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Workflow Case 1775534113929	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:55:13.934418+00	2026-04-07 03:55:13.934418+00	CASE-20260407-D71EEC3C	2026-04-08 03:55:13.938634+00	MEDIUM	f	\N	\N	\N	incremental
6775d966-a130-4a61-9456-f9a704165746	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Narrative Suggestion 1775534117812	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:55:17.841028+00	2026-04-07 03:55:17.841028+00	CASE-20260407-6775D966	2026-04-08 03:55:17.847926+00	MEDIUM	f	\N	\N	\N	incremental
e5e3c918-68b3-4d1e-8d13-08eea27949f5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Search Case 1775534134799	Caso criado para validar a busca global via E2E.	OPEN	HIGH	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	\N	2026-04-07 03:55:34.816494+00	2026-04-07 03:55:34.816494+00	CASE-20260407-E5E3C918	2026-04-08 03:55:34.820058+00	MEDIUM	f	\N	\N	\N	incremental
47e1a129-8365-4217-8dcd-3f3338962ebf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Case for alert link 1775534262130	Caso criado automaticamente pela suíte E2E	OPEN	MEDIUM	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:57:42.159228+00	2026-04-07 03:57:43.166076+00	CASE-20260407-47E1A129	2026-04-10 03:57:42.1637+00	MEDIUM	f	\N	971a0d9d-cbdf-4845-8a00-0c72dafe413a	\N	incremental
29e027d1-d682-44e7-b00a-50976c40864b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	E2E Manual Case 1775534280699	Caso criado pela suíte E2E para validar o fluxo manual.	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:58:01.74686+00	2026-04-07 03:58:01.74686+00	CASE-20260407-29E027D1	2026-04-08 03:58:01.753569+00	MEDIUM	f	\N	\N	\N	incremental
6f8474c4-ddcc-44cd-b47b-7bc0f1cbf5c9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Workflow Case 1775534286179	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:58:06.184283+00	2026-04-07 03:58:06.184283+00	CASE-20260407-6F8474C4	2026-04-08 03:58:06.191144+00	MEDIUM	f	\N	\N	\N	incremental
f66e8169-9ada-4f7d-a44e-8b24fdfcb375	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Narrative Suggestion 1775534290432	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 03:58:10.464886+00	2026-04-07 03:58:10.464886+00	CASE-20260407-F66E8169	2026-04-08 03:58:10.472066+00	MEDIUM	f	\N	\N	\N	incremental
b0b71c54-f846-405a-9bf0-5f754edc93b3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	Search Case 1775534307343	Caso criado para validar a busca global via E2E.	OPEN	HIGH	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	\N	2026-04-07 03:58:27.362212+00	2026-04-07 03:58:27.362212+00	CASE-20260407-B0B71C54	2026-04-08 03:58:27.365674+00	MEDIUM	f	\N	\N	\N	incremental
5d2a65d5-de6e-4c5c-b70b-fc9e9de0315a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Report Export 1775536656799	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 04:37:36.803766+00	2026-04-07 04:37:36.803766+00	CASE-20260407-5D2A65D5	2026-04-08 04:37:36.814096+00	MEDIUM	f	\N	\N	\N	incremental
5ea5229f-6e09-4c30-8c47-16c797039bef	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Auditor Export 1775536657452	Caso criado automaticamente pela suíte E2E	OPEN	MEDIUM	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 04:37:37.457159+00	2026-04-07 04:37:37.457159+00	CASE-20260407-5EA5229F	2026-04-10 04:37:37.465917+00	MEDIUM	f	\N	\N	\N	incremental
ec7951b7-6bf7-4652-a6eb-f53cd4489d43	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Audit Export 1775536888121	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:41:28.191902+00	2026-04-07 04:41:28.126493+00	2026-04-07 04:41:28.189644+00	CASE-20260407-EC7951B7	2026-04-08 04:41:28.137247+00	MEDIUM	f	\N	\N	\N	incremental
441cc147-981f-4e3a-9415-9af11b1aa905	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Report Export 1775536889795	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 04:41:29.800057+00	2026-04-07 04:41:29.800057+00	CASE-20260407-441CC147	2026-04-08 04:41:29.803254+00	MEDIUM	f	\N	\N	\N	incremental
468ac1e7-13d8-4b71-a76b-ac47b9de7567	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Auditor Export 1775536890399	Caso criado automaticamente pela suíte E2E	OPEN	MEDIUM	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 04:41:30.403748+00	2026-04-07 04:41:30.403748+00	CASE-20260407-468AC1E7	2026-04-10 04:41:30.406959+00	MEDIUM	f	\N	\N	\N	incremental
93d9d925-f602-4c06-9368-83e31001bc4b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	4633153f-6cca-40b2-b0f7-30df770677ec	tmp	tmp	CLOSED	HIGH	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:42:00.624028+00	2026-04-07 04:42:00.580418+00	2026-04-07 04:42:00.622068+00	CASE-20260407-93D9D925	2026-04-08 04:42:00.583204+00	MEDIUM	f	\N	\N	\N	incremental
ec263c8f-4edc-4dfb-b508-bb1bbd2dbb69	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	4633153f-6cca-40b2-b0f7-30df770677ec	tmp	tmp	CLOSED	HIGH	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:43:29.520143+00	2026-04-07 04:43:29.47056+00	2026-04-07 04:43:29.517983+00	CASE-20260407-EC263C8F	2026-04-08 04:43:29.47572+00	MEDIUM	f	\N	\N	\N	incremental
43b747b8-5e26-476f-8e2a-53f894d1041a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Audit Export 1775537027939	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:43:47.998793+00	2026-04-07 04:43:47.945394+00	2026-04-07 04:43:47.997074+00	CASE-20260407-43B747B8	2026-04-08 04:43:47.949579+00	MEDIUM	f	\N	\N	\N	incremental
95a6b4ac-f960-4fb7-a7ab-d106bcf625e0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Audit Export 1775537393760	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:49:53.812304+00	2026-04-07 04:49:53.765242+00	2026-04-07 04:49:53.809726+00	CASE-20260407-95A6B4AC	2026-04-08 04:49:53.76897+00	MEDIUM	f	\N	\N	\N	incremental
ed136fe5-5990-4a83-b5dd-b217d7cdc020	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Report Export 1775538678055	Caso criado automaticamente pela suíte E2E	OPEN	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 05:11:18.060058+00	2026-04-07 05:11:18.060058+00	CASE-20260407-ED136FE5	2026-04-08 05:11:18.070123+00	MEDIUM	f	\N	\N	\N	incremental
ef28e581-2794-4286-9627-108a7278a3a0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Auditor Export 1775538678666	Caso criado automaticamente pela suíte E2E	OPEN	MEDIUM	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	\N	\N	2026-04-07 05:11:18.671793+00	2026-04-07 05:11:18.671793+00	CASE-20260407-EF28E581	2026-04-10 05:11:18.680715+00	MEDIUM	f	\N	\N	\N	incremental
e9e5d372-aac2-4a13-aaf7-e15fd25faaaf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	E2E Audit Export 1775538684952	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 05:11:25.010216+00	2026-04-07 05:11:24.956478+00	2026-04-07 05:11:25.007729+00	CASE-20260407-E9E5D372	2026-04-08 05:11:24.960222+00	MEDIUM	f	\N	\N	\N	incremental
\.


--
-- Data for Name: compound_rules; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.compound_rules (id, tenant_id, name, description, status, n_threshold, severity_mode, fixed_severity, version, created_by, updated_by, created_at, updated_at, is_active, logic, component_rule_ids, score_weights, min_score_threshold) FROM stdin;
2a133523-72c9-4aba-8f3d-d69da2fe2ac9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Structuring + Spike Combinado	Dispara quando structuring E spike de depósito ocorrem simultaneamente	ACTIVE	\N	MAX	\N	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	t	AND	["32c815b2-5fe3-4136-a864-6b9f7e35acd7", "b754243e-f006-4551-ae19-4f9bdc607e4c"]	{"32c815b2-5fe3-4136-a864-6b9f7e35acd7": 0.6, "b754243e-f006-4551-ae19-4f9bdc607e4c": 0.4}	0.7000
8af1f2bc-ceae-4a4b-b0dd-874606752a36	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Round-trip HIGH Confidence	Round-tripping com alto score composto (regra + ML)	ACTIVE	\N	FIXED	CRITICAL	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	t	OR	["fb2cfc97-d4bf-4e5b-af0d-84903b6415aa"]	{"fb2cfc97-d4bf-4e5b-af0d-84903b6415aa": 1.0}	0.8000
9819eb95-d74e-4f2d-a787-b2db064fb38e	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Structuring + Spike Combinado	Dispara quando structuring E spike de depósito ocorrem simultaneamente	ACTIVE	\N	MAX	\N	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	t	AND	["9d0ae942-31dc-413c-90c8-db33dfa755f9", "669e39d9-70e0-45c0-953d-8bfb8a4a8617"]	{"669e39d9-70e0-45c0-953d-8bfb8a4a8617": 0.4, "9d0ae942-31dc-413c-90c8-db33dfa755f9": 0.6}	0.7000
0c6ff32d-fce1-4461-896e-ce8a6eb115ae	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Round-trip HIGH Confidence	Round-tripping com alto score composto (regra + ML)	ACTIVE	\N	FIXED	CRITICAL	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	t	OR	["9e393a81-e39b-46ac-8e86-de792f3bdfc8"]	{"9e393a81-e39b-46ac-8e86-de792f3bdfc8": 1.0}	0.8000
\.


--
-- Data for Name: device_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.device_events (id, tenant_id, player_id, external_evt_id, source_system, action, device_id, device_type, device_hash, ip_address, ip_hash, country_code, user_agent, session_id, source_event_id, ingest_job_id, raw_payload, occurred_at, created_at) FROM stdin;
\.


--
-- Data for Name: external_validation_requests; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.external_validation_requests (id, tenant_id, player_id, provider, validation_type, status, request_payload, response_payload, external_request_id, error_message, requested_by, requested_at, completed_at, updated_at) FROM stdin;
\.


--
-- Data for Name: feature_snapshots; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.feature_snapshots (id, tenant_id, player_id, feature_date, features, drift_score, created_at, snapshot_date, feature_version) FROM stdin;
25745407-18ea-412b-8e83-d101bf146884	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	4633153f-6cca-40b2-b0f7-30df770677ec	2026-04-04	{"player_id": "4633153f-6cca-40b2-b0f7-30df770677ec", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "cluster_id": "cluster:22e312f27fd5", "computed_at": "2026-04-04T09:11:30.194643", "entity_type": "PLAYER", "bet_count_7d": 0, "cluster_size": 1, "bet_count_30d": 0, "bet_count_90d": 0, "snapshot_date": "2026-04-04", "deposit_sum_7d": 13000.0, "avg_odds_bet_7d": null, "deposit_sum_24h": 13000.0, "deposit_sum_30d": 13000.0, "deposit_sum_90d": 13000.0, "feature_version": 2, "new_device_flag": false, "bet_stake_sum_7d": 0.0, "cashout_ratio_7d": 0.0, "deposit_count_1h": 2, "deposit_count_7d": 2, "deposit_velocity": 0.08333333333333333, "gold_object_path": "gold/tenant_id=4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/feature_date=2026-04-04/entity_type=PLAYER/player_id=4633153f-6cca-40b2-b0f7-30df770677ec.json", "snapshot_version": 2, "bet_stake_sum_24h": 0.0, "deposit_count_24h": 2, "deposit_count_90d": 2, "withdrawal_sum_7d": 0.0, "win_loss_ratio_30d": null, "withdrawal_sum_24h": 0.0, "withdrawal_sum_90d": 0.0, "chargeback_rate_30d": 0.0, "shared_device_count": 0, "shared_device_score": 0.0, "chargeback_count_30d": 0, "night_activity_ratio": 0.0, "withdrawal_count_24h": 0, "unique_instruments_7d": 1, "slot_session_count_24h": 0, "weekend_activity_ratio": 1.0, "baseline_stddev_deposit": 0.0, "bonus_to_real_ratio_30d": 0.0, "shared_instrument_score": 0.0, "bet_product_diversity_7d": 0, "casino_session_count_24h": 0, "failed_deposit_count_24h": 0, "shared_bank_account_count": 0, "baseline_avg_daily_deposit": 13000.0, "inconsistent_currency_flag": false, "unique_instruments_used_7d": 1, "new_payment_instrument_flag": false, "bonus_to_real_money_ratio_30d": 0.0, "ratio_withdrawal_to_deposit_7d": 0.0, "avg_deposit_to_withdrawal_hours": null, "zscore_current_deposit_vs_baseline": 0.0, "avg_time_between_deposit_and_withdrawal_7d": null}	\N	2026-04-04 09:11:30.215248+00	2026-04-04	2
\.


--
-- Data for Name: financial_transactions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.financial_transactions (id, tenant_id, player_id, external_tx_id, source_system, type, amount, currency, status, payment_method, payment_instrument, bank_account_hash, source_event_id, ingest_job_id, raw_payload, occurred_at, settled_at, created_at, payment_method_flagged) FROM stdin;
61572f11-91ef-4427-939a-e9f3b5b9cbcc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	4633153f-6cca-40b2-b0f7-30df770677ec	\N	BackofficeAlpha	DEPOSIT	6500.00	BRL	SETTLED	PIX	{"holder_document": "11122233344"}	ebdca3085b677490512e0078a35b8c93f5e8292845bfcab2f1aca03621c2e4f6	52b20bb4-6352-4714-aaa1-d9e74c1dcdaa	\N	{"amount": 6500.0, "player_id": "4633153f-6cca-40b2-b0f7-30df770677ec"}	2026-04-04 09:01:00+00	\N	2026-04-04 09:10:42.794235+00	f
af00aca2-509f-4e54-8026-613fd0466ad5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	4633153f-6cca-40b2-b0f7-30df770677ec	\N	BackofficeAlpha	DEPOSIT	6500.00	BRL	SETTLED	PIX	{"holder_document": "11122233344"}	ebdca3085b677490512e0078a35b8c93f5e8292845bfcab2f1aca03621c2e4f6	ebc97579-9aef-4280-9083-fa57f95ea17c	\N	{"amount": 6500.0, "player_id": "4633153f-6cca-40b2-b0f7-30df770677ec"}	2026-04-04 09:05:00+00	\N	2026-04-04 09:11:30.188346+00	f
\.


--
-- Data for Name: ingest_errors; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ingest_errors (id, tenant_id, ingest_job_id, source_system, entity_type, raw_payload, error_reason, error_detail, line_number, resolved, resolved_by, resolved_at, created_at) FROM stdin;
d5baef17-f2c5-459a-99b2-47930dea89f0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	44ab1413-e88b-480e-9702-10643c7e4c19	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775531892831","external_player_id":"CPF-1775531892831","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "channel": "webhook", "connector": "epsilon"}	\N	f	\N	\N	2026-04-07 03:18:12.864745+00
f0801b4b-c96b-413d-a525-2b927cef364b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	6890387c-0c66-43c1-9f43-a2dede8292c4	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775532281827","external_player_id":"CPF-1775532281827","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "channel": "webhook", "connector": "epsilon"}	\N	f	\N	\N	2026-04-07 03:24:41.879618+00
68506a4d-dc2d-423d-a3b5-8991280047fa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	f060f354-9cf7-4276-838f-ca57718352d1	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775532446906","external_player_id":"CPF-1775532446906","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "channel": "webhook", "connector": "epsilon"}	\N	f	\N	\N	2026-04-07 03:27:27.068318+00
e1783111-7c6d-4c16-9add-0a666fc54acf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	432447e3-909d-478a-bfd0-8c3784c2a058	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775532886698","external_player_id":"CPF-1775532886698","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "channel": "webhook", "connector": "epsilon"}	\N	f	\N	\N	2026-04-07 03:34:46.756455+00
ff12b35f-930f-44b6-990c-486dafe11b20	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	eb0bea4c-d8a1-4cdc-b59e-678654701dea	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775533170872","external_player_id":"CPF-1775533170872","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "channel": "webhook", "connector": "epsilon"}	\N	f	\N	\N	2026-04-07 03:39:30.913701+00
85104667-f156-4cbd-b973-8ea1302d86ed	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	c0eaa201-2f2e-4a7e-97c2-c19eef0612d6	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775533962339","external_player_id":"CPF-1775533962339","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "channel": "webhook", "connector": "epsilon"}	\N	f	\N	\N	2026-04-07 03:52:42.403415+00
7b39718e-b878-4f63-8fe6-5123881a79cf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	fe56aa90-2ff0-41ed-acd3-fed498c7f3c9	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775534141617","external_player_id":"CPF-1775534141617","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "channel": "webhook", "connector": "epsilon"}	\N	f	\N	\N	2026-04-07 03:55:41.6607+00
cb4a32da-df5b-4979-bd9d-e2e3c5210209	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	d5c1fe04-e334-498b-a066-4a0ba5896817	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775534314457","external_player_id":"CPF-1775534314457","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "channel": "webhook", "connector": "epsilon"}	\N	f	\N	\N	2026-04-07 03:58:34.501816+00
c3853f18-4371-4fb1-b526-a07a472ccb2c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8716f184-4703-4cc9-bc06-8709b0925a25	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775535095266","external_player_id":"CPF-1775535095266","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "channel": "webhook", "connector": "epsilon"}	\N	f	\N	\N	2026-04-07 04:11:35.294235+00
ee85d8d5-c1ff-450d-97d2-0a9485837d46	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8cb2a02f-7e7a-4559-80ad-b190f3d24ecf	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775535142837","external_player_id":"CPF-1775535142837","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "replay": {"note": "Replay validado pela suíte E2E", "status": "QUEUED", "event_id": "fe340fee-6896-40be-bf28-de30478637fa", "entity_type": "TRANSACTION", "replayed_at": "2026-04-07T04:12:25.921151+00:00", "replayed_by": "2c9dc0c7-cc53-4e4d-857b-a267c9355532", "apply_mapping": true, "source_event_id": "e2e-epsilon-error-1775535142837", "mapping_config_id": null, "mapping_version_id": null}, "channel": "webhook", "connector": "epsilon"}	\N	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:12:25.921191+00	2026-04-07 04:12:22.86631+00
4bc76166-192b-4aa1-b9ea-35cf5cf3eace	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	82351593-3512-4424-918b-4c5604baab78	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775535171130","external_player_id":"CPF-1775535171130","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "replay": {"note": "Replay validado pela suíte E2E", "status": "QUEUED", "event_id": "1f856251-4a8e-4cb7-8580-38389ce7b499", "entity_type": "TRANSACTION", "replayed_at": "2026-04-07T04:12:53.823238+00:00", "replayed_by": "2c9dc0c7-cc53-4e4d-857b-a267c9355532", "apply_mapping": true, "source_event_id": "e2e-epsilon-error-1775535171130", "mapping_config_id": null, "mapping_version_id": null}, "channel": "webhook", "connector": "epsilon"}	\N	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:12:53.823268+00	2026-04-07 04:12:51.150679+00
7e177cda-a721-4449-a188-0ebf660bd3ac	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	130c3231-2b1a-436a-a6a6-489a318a4b7b	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775535339444","external_player_id":"CPF-1775535339444","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "replay": {"note": "Replay validado pela suíte E2E", "status": "QUEUED", "event_id": "2951ac61-4705-4185-b748-0bcf0c7fffc1", "entity_type": "TRANSACTION", "replayed_at": "2026-04-07T04:15:42.138917+00:00", "replayed_by": "2c9dc0c7-cc53-4e4d-857b-a267c9355532", "apply_mapping": true, "source_event_id": "e2e-epsilon-error-1775535339444", "mapping_config_id": null, "mapping_version_id": null}, "channel": "webhook", "connector": "epsilon"}	\N	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:42.138954+00	2026-04-07 04:15:39.469038+00
223345ee-9fe3-49a2-b847-492486773d3d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	1074848a-c407-4139-b642-ba5c1509aaba	ConnectorDelta	TRANSACTION	{"id":"delta-bad-json","uid":"CPF-DELTA-2"	Expecting ',' delimiter: line 1 column 43 (char 42)	{"line": 2, "connector": "delta"}	2	f	\N	\N	2026-04-07 04:15:54.645622+00
843b269b-9c18-4133-9c6b-d5c832e903c7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	1130b476-cc4f-4bf3-ac07-ed364e93bb85	ConnectorGamma	TRANSACTION	{"event_id": "gamma-bad-1", "external_player_id": "CPF-GAMMA-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "device_id": "dev-gamma-2", "source_system": "ConnectorGamma"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')	{"stage": "mapping", "connector": "gamma", "mapping_config_id": "943f8513-1141-4aae-8a5d-243a661b50b3"}	\N	f	\N	\N	2026-04-07 04:19:24.323054+00
57377c88-3ae2-4851-8087-0240a7258a2d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	13257e62-d073-488c-9e44-10b8c5bcdefb	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "delta-bad-1775535564739", "uid": "CPF-DELTA-3", "evt_type": "DEPOSIT", "ts": "2026-03-20T12:05:00Z", "val": "not-a-number", "ccy": "BRL", "currency": "BRL"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')	{"stage": "mapping", "connector": "delta", "mapping_config_id": "7c1e754f-5cd9-4d4c-80a1-5c583813f763"}	\N	f	\N	\N	2026-04-07 04:19:24.766832+00
d36da7ca-bc72-4278-94c7-c0322be74bb3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	13257e62-d073-488c-9e44-10b8c5bcdefb	ConnectorDelta	TRANSACTION	{"id":"delta-bad-json","uid":"CPF-DELTA-2"	Expecting ',' delimiter: line 1 column 43 (char 42)	{"line": 2, "connector": "delta"}	2	f	\N	\N	2026-04-07 04:19:24.766832+00
f2a73693-68b5-487d-ac7d-36d75d80bfec	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	72e72c27-58d6-410c-897e-446f71f38326	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775535586872","external_player_id":"CPF-1775535586872","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "replay": {"note": "Replay validado pela suíte E2E", "status": "QUEUED", "event_id": "ecee372f-05d0-438c-b5ae-08011ecb1ba2", "entity_type": "TRANSACTION", "replayed_at": "2026-04-07T04:19:49.743792+00:00", "replayed_by": "2c9dc0c7-cc53-4e4d-857b-a267c9355532", "apply_mapping": true, "source_event_id": "e2e-epsilon-error-1775535586872", "mapping_config_id": null, "mapping_version_id": null}, "channel": "webhook", "connector": "epsilon"}	\N	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:49.74383+00	2026-04-07 04:19:46.896475+00
fbe5ee22-e368-4fa3-86a0-4d1e1caf9e2a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	81b205e1-df41-491e-bd1a-34cc4b552f27	ConnectorGamma	TRANSACTION	{"event_id": "iso-gamma-bad-1", "external_player_id": "CPF-ISO-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "device_id": "dev-iso-2", "source_system": "ConnectorGamma"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')	{"stage": "mapping", "connector": "gamma", "mapping_config_id": "8c3c6e7f-1219-43ee-a385-18714534908c"}	\N	f	\N	\N	2026-04-07 04:23:18.442911+00
7bfeb8cb-f0d8-4040-b56b-8d2e7ffc11b5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	c116fcff-629c-4180-a356-4300e3da8cc0	ConnectorGamma	TRANSACTION	{"event_id": "gamma-bad-1", "external_player_id": "CPF-GAMMA-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "device_id": "dev-gamma-2", "source_system": "ConnectorGamma"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')	{"stage": "mapping", "connector": "gamma", "mapping_config_id": "3dc6fe12-a285-449b-a53e-c54321fc3c3e"}	\N	f	\N	\N	2026-04-07 04:20:00.553184+00
4b060eba-e67d-406d-bed1-e04e2e4c1665	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	f4ac9fba-10ae-4e4e-910d-3d0c9c574116	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "delta-bad-1775535600958", "uid": "CPF-DELTA-3", "evt_type": "DEPOSIT", "ts": "2026-03-20T12:05:00Z", "val": "not-a-number", "ccy": "BRL", "currency": "BRL"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')	{"stage": "mapping", "connector": "delta", "mapping_config_id": "e06ad360-121c-4957-a0f0-1f891bf701e9"}	\N	f	\N	\N	2026-04-07 04:20:00.988483+00
e0840015-ea46-432a-93c0-45b6c79d5d8b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	f4ac9fba-10ae-4e4e-910d-3d0c9c574116	ConnectorDelta	TRANSACTION	{"id":"delta-bad-json","uid":"CPF-DELTA-2"	Expecting ',' delimiter: line 1 column 43 (char 42)	{"line": 2, "connector": "delta"}	2	f	\N	\N	2026-04-07 04:20:00.988483+00
a6275d09-14b3-4717-9924-bfb091781217	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	907f278e-3731-469f-ba41-7a861588376e	ConnectorGamma	TRANSACTION	{"event_id": "iso-gamma-bad-1", "external_player_id": "CPF-ISO-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "device_id": "dev-iso-2", "source_system": "ConnectorGamma"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')	{"stage": "mapping", "connector": "gamma", "mapping_config_id": "461ffb1b-9f2a-4691-8ec1-8dad30780ca7"}	\N	f	\N	\N	2026-04-07 04:20:48.655419+00
ebd047f2-83d8-4220-a4ea-0df6911de07c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8364b8d1-b246-4482-91a4-a2fde9512ab0	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775535780258","external_player_id":"CPF-1775535780258","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "replay": {"note": "Replay validado pela suíte E2E", "status": "QUEUED", "event_id": "de9a75b3-dcb0-4265-9c5a-f6f92832916d", "entity_type": "TRANSACTION", "replayed_at": "2026-04-07T04:23:03.004983+00:00", "replayed_by": "2c9dc0c7-cc53-4e4d-857b-a267c9355532", "apply_mapping": true, "source_event_id": "e2e-epsilon-error-1775535780258", "mapping_config_id": null, "mapping_version_id": null}, "channel": "webhook", "connector": "epsilon"}	\N	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:03.005039+00	2026-04-07 04:23:00.287958+00
2bc1542d-cf37-4688-8fac-c84fc04cf871	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	7c3799e5-4292-4405-aff9-8c05aeabed2d	ConnectorGamma	TRANSACTION	{"event_id": "gamma-bad-1", "external_player_id": "CPF-GAMMA-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "device_id": "dev-gamma-2", "source_system": "ConnectorGamma"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')	{"stage": "mapping", "connector": "gamma", "mapping_config_id": "cb718b5e-d567-4d9c-878a-e1451a5bb48d"}	\N	f	\N	\N	2026-04-07 04:23:13.96678+00
4ca82167-f617-4de9-990c-2f5a18dbb223	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	9f7a7e70-ca02-42c7-ba4b-00fd9a50646c	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "delta-bad-1775535794330", "uid": "CPF-DELTA-3", "evt_type": "DEPOSIT", "ts": "2026-03-20T12:05:00Z", "val": "not-a-number", "ccy": "BRL", "currency": "BRL"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')	{"stage": "mapping", "connector": "delta", "mapping_config_id": "b1c02615-d314-4302-b4bf-039afd7d2b8a"}	\N	f	\N	\N	2026-04-07 04:23:14.35069+00
07eb66d5-7067-4dc3-9359-f21e183c3005	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	9f7a7e70-ca02-42c7-ba4b-00fd9a50646c	ConnectorDelta	TRANSACTION	{"id":"delta-bad-json","uid":"CPF-DELTA-2"	Expecting ',' delimiter: line 1 column 43 (char 42)	{"line": 2, "connector": "delta"}	2	f	\N	\N	2026-04-07 04:23:14.35069+00
2a04751a-8b8a-4d8f-8755-30a35817bc02	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	05616157-43a9-4bad-8b0a-781fbcd29f96	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-NEG", "external_player_id": "PLY-RTR-003", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "-100.00", "occurred_at": "2026-03-21T13:30:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "device_id": "dev-rtr-03", "source_system": "ConnectorGamma"}	validation_failed: amount deve ser maior que zero: '-100.00'	{"stage": "validation", "connector": "gamma", "mapping_config_id": "8c3c6e7f-1219-43ee-a385-18714534908c"}	\N	f	\N	\N	2026-04-07 04:28:03.935742+00
0b09c321-7568-4961-a82b-084d9f90eb5f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	05616157-43a9-4bad-8b0a-781fbcd29f96	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-DATE", "external_player_id": "PLY-SPI-002", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "300.00", "occurred_at": "2026-99-99T99:99:99Z", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "device_id": "dev-spi-02", "source_system": "ConnectorGamma"}	validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'	{"stage": "validation", "connector": "gamma", "mapping_config_id": "8c3c6e7f-1219-43ee-a385-18714534908c"}	\N	f	\N	\N	2026-04-07 04:28:03.935742+00
37683e43-98d2-4141-9310-5be6ee2d8c50	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c02b5f2-e94f-44a2-b188-05f74424af80	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "DELTA-ERR-NEG", "uid": "PLY-NET-005", "evt_type": "DEPOSIT", "ts": "2026-03-21T14:10:00Z", "val": -50.0, "ccy": "BRL", "device": "dev-shared-77", "pay_method": "PIX", "pay_token": "pix-delta-err-neg", "ip": "200.155.10.11", "session_id": "sess-delta-err-neg", "currency": "BRL"}	validation_failed: amount deve ser maior que zero: '-50.0'	{"stage": "validation", "connector": "delta", "mapping_config_id": "b1c02615-d314-4302-b4bf-039afd7d2b8a"}	\N	f	\N	\N	2026-04-07 04:28:04.001197+00
966ea5bc-7b9a-4845-9ddb-5131d0cad5ed	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c02b5f2-e94f-44a2-b188-05f74424af80	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "DELTA-ERR-NO-TS", "uid": "PLY-SPI-002", "evt_type": "DEPOSIT", "val": 300.0, "ccy": "BRL", "device": "dev-spi-02", "pay_method": "CARD", "pay_token": "card-delta-err-no-ts", "ip": "177.20.20.20", "session_id": "sess-delta-err-no-ts", "currency": "BRL"}	mapping_failed: Campo obrigatório 'occurred_at' é None após transform 'parseDate' (source='ts', raw='None')	{"stage": "mapping", "connector": "delta", "mapping_config_id": "b1c02615-d314-4302-b4bf-039afd7d2b8a"}	\N	f	\N	\N	2026-04-07 04:28:04.001197+00
90334606-afb6-4051-9a2a-7f666218205c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2c02b5f2-e94f-44a2-b188-05f74424af80	ConnectorDelta	TRANSACTION	{"id":"DELTA-ERR-MALFORMED","uid":"PLY-PEP-006","evt_type":"DEPOSIT","ts":"2026-03-21T14:12:00Z","val":400.0,"ccy":"BRL"	Expecting ',' delimiter: line 1 column 121 (char 120)	{"line": 7, "connector": "delta"}	7	f	\N	\N	2026-04-07 04:28:04.001197+00
7ef093d4-1878-4731-bca2-7e5705be463f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	08d2ff74-a8b7-4e82-a943-376827b5bc9e	ConnectorGamma	TRANSACTION	{"event_id": "gamma-bad-1", "external_player_id": "CPF-GAMMA-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "device_id": "dev-gamma-2", "source_system": "ConnectorGamma"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')	{"stage": "mapping", "connector": "gamma", "mapping_config_id": "7a451cef-a120-45b9-bf95-eedeb21a4aeb"}	\N	f	\N	\N	2026-04-07 04:28:06.894519+00
b87261b5-394a-4391-ae56-8ad9ee9fd0d7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	9b779d04-1024-44f5-98f0-ad1d7a0b4947	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "delta-bad-1775536087258", "uid": "CPF-DELTA-3", "evt_type": "DEPOSIT", "ts": "2026-03-20T12:05:00Z", "val": "not-a-number", "ccy": "BRL", "currency": "BRL"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')	{"stage": "mapping", "connector": "delta", "mapping_config_id": "08e6917b-e953-47e1-a6fe-c30cc97b8093"}	\N	f	\N	\N	2026-04-07 04:28:07.280703+00
78ee9821-1bd6-44bb-bfb5-59e2051cf115	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	9b779d04-1024-44f5-98f0-ad1d7a0b4947	ConnectorDelta	TRANSACTION	{"id":"delta-bad-json","uid":"CPF-DELTA-2"	Expecting ',' delimiter: line 1 column 43 (char 42)	{"line": 2, "connector": "delta"}	2	f	\N	\N	2026-04-07 04:28:07.280703+00
f04d2cff-cb21-4432-9f66-f1a514976376	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	e14042b0-c894-448b-a1f3-fc8ab03283e2	ConnectorGamma	TRANSACTION	{"id": "gamma-map-1", "player_id": "CPF-GAMMA-MAP-1", "type": "DEPOSIT", "amount": "321.00", "currency": "BRL", "timestamp": "2026-03-20T10:00:00Z", "source_system": "ConnectorGamma"}	validation_failed: empty_required_fields=['external_transaction_id', 'occurred_at', 'player_cpf', 'type']	{"stage": "validation", "connector": "gamma", "mapping_config_id": "7de7afb5-f09e-4995-82ad-fcef870000c0"}	\N	f	\N	\N	2026-04-07 04:28:07.627572+00
39314e8f-5473-49ff-be58-59a32569f142	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	e6e9a8a5-67ad-4dcf-9d83-f54f74e34c70	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-NEG", "external_player_id": "PLY-RTR-003", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "-100.00", "occurred_at": "2026-03-21T13:30:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "device_id": "dev-rtr-03", "source_system": "ConnectorGamma"}	validation_failed: amount deve ser maior que zero: '-100.00'	{"stage": "validation", "connector": "gamma", "mapping_config_id": "7de7afb5-f09e-4995-82ad-fcef870000c0"}	\N	f	\N	\N	2026-04-07 04:31:16.046435+00
0542a672-2256-4eff-9e79-c706e223509f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	e6e9a8a5-67ad-4dcf-9d83-f54f74e34c70	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-DATE", "external_player_id": "PLY-SPI-002", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "300.00", "occurred_at": "2026-99-99T99:99:99Z", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "device_id": "dev-spi-02", "source_system": "ConnectorGamma"}	validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'	{"stage": "validation", "connector": "gamma", "mapping_config_id": "7de7afb5-f09e-4995-82ad-fcef870000c0"}	\N	f	\N	\N	2026-04-07 04:31:16.046435+00
5d8f2a3d-0e7a-46c2-b14a-85e08c3dab4d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	aa9728d6-4c20-4606-a001-83d657ce81c0	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "DELTA-ERR-NEG", "uid": "PLY-NET-005", "evt_type": "DEPOSIT", "ts": "2026-03-21T14:10:00Z", "val": -50.0, "ccy": "BRL", "device": "dev-shared-77", "pay_method": "PIX", "pay_token": "pix-delta-err-neg", "ip": "200.155.10.11", "session_id": "sess-delta-err-neg", "currency": "BRL"}	validation_failed: amount deve ser maior que zero: '-50.0'	{"stage": "validation", "connector": "delta", "mapping_config_id": "08e6917b-e953-47e1-a6fe-c30cc97b8093"}	\N	f	\N	\N	2026-04-07 04:31:16.092169+00
d6d93aa3-fff7-4761-8426-febd52bbad9b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	aa9728d6-4c20-4606-a001-83d657ce81c0	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "DELTA-ERR-NO-TS", "uid": "PLY-SPI-002", "evt_type": "DEPOSIT", "val": 300.0, "ccy": "BRL", "device": "dev-spi-02", "pay_method": "CARD", "pay_token": "card-delta-err-no-ts", "ip": "177.20.20.20", "session_id": "sess-delta-err-no-ts", "currency": "BRL"}	mapping_failed: Campo obrigatório 'occurred_at' é None após transform 'parseDate' (source='ts', raw='None')	{"stage": "mapping", "connector": "delta", "mapping_config_id": "08e6917b-e953-47e1-a6fe-c30cc97b8093"}	\N	f	\N	\N	2026-04-07 04:31:16.092169+00
5423625e-e26f-48e3-b926-9cf4fbfbc32a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	aa9728d6-4c20-4606-a001-83d657ce81c0	ConnectorDelta	TRANSACTION	{"id":"DELTA-ERR-MALFORMED","uid":"PLY-PEP-006","evt_type":"DEPOSIT","ts":"2026-03-21T14:12:00Z","val":400.0,"ccy":"BRL"	Expecting ',' delimiter: line 1 column 121 (char 120)	{"line": 7, "connector": "delta"}	7	f	\N	\N	2026-04-07 04:31:16.092169+00
103df6f8-5710-44e1-b3e2-602b291c49a5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	3bd932ab-c48b-4d71-a1a4-0d69f419dab5	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-NEG", "external_player_id": "PLY-RTR-003", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "-100.00", "occurred_at": "2026-03-21T13:30:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "device_id": "dev-rtr-03", "source_system": "ConnectorGamma"}	validation_failed: amount deve ser maior que zero: '-100.00'	{"stage": "validation", "connector": "gamma", "mapping_config_id": "7de7afb5-f09e-4995-82ad-fcef870000c0"}	\N	f	\N	\N	2026-04-07 04:32:27.907622+00
16d97925-a7a8-4161-945c-90dd3f886e07	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	3bd932ab-c48b-4d71-a1a4-0d69f419dab5	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-DATE", "external_player_id": "PLY-SPI-002", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "300.00", "occurred_at": "2026-99-99T99:99:99Z", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "device_id": "dev-spi-02", "source_system": "ConnectorGamma"}	validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'	{"stage": "validation", "connector": "gamma", "mapping_config_id": "7de7afb5-f09e-4995-82ad-fcef870000c0"}	\N	f	\N	\N	2026-04-07 04:32:27.907622+00
e75914b5-e6f5-4c09-8998-1dbbb738509b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	877a2161-a5b5-4306-ae7f-6e93d7d08844	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "DELTA-ERR-NEG", "uid": "PLY-NET-005", "evt_type": "DEPOSIT", "ts": "2026-03-21T14:10:00Z", "val": -50.0, "ccy": "BRL", "device": "dev-shared-77", "pay_method": "PIX", "pay_token": "pix-delta-err-neg", "ip": "200.155.10.11", "session_id": "sess-delta-err-neg", "currency": "BRL"}	validation_failed: amount deve ser maior que zero: '-50.0'	{"stage": "validation", "connector": "delta", "mapping_config_id": "08e6917b-e953-47e1-a6fe-c30cc97b8093"}	\N	f	\N	\N	2026-04-07 04:32:27.945773+00
59854dc1-e873-48c7-b963-26a0f281fe2e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	877a2161-a5b5-4306-ae7f-6e93d7d08844	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "DELTA-ERR-NO-TS", "uid": "PLY-SPI-002", "evt_type": "DEPOSIT", "val": 300.0, "ccy": "BRL", "device": "dev-spi-02", "pay_method": "CARD", "pay_token": "card-delta-err-no-ts", "ip": "177.20.20.20", "session_id": "sess-delta-err-no-ts", "currency": "BRL"}	mapping_failed: Campo obrigatório 'occurred_at' é None após transform 'parseDate' (source='ts', raw='None')	{"stage": "mapping", "connector": "delta", "mapping_config_id": "08e6917b-e953-47e1-a6fe-c30cc97b8093"}	\N	f	\N	\N	2026-04-07 04:32:27.945773+00
7841874d-be9a-4856-b33b-39fcafd16b2e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	877a2161-a5b5-4306-ae7f-6e93d7d08844	ConnectorDelta	TRANSACTION	{"id":"DELTA-ERR-MALFORMED","uid":"PLY-PEP-006","evt_type":"DEPOSIT","ts":"2026-03-21T14:12:00Z","val":400.0,"ccy":"BRL"	Expecting ',' delimiter: line 1 column 121 (char 120)	{"line": 7, "connector": "delta"}	7	f	\N	\N	2026-04-07 04:32:27.945773+00
c553e2e8-adee-4394-86d3-be3cac87e60b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a327ee17-72e4-49fe-bdb3-6c5abc8ec049	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-NEG", "external_player_id": "PLY-RTR-003", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "-100.00", "occurred_at": "2026-03-21T13:30:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "device_id": "dev-rtr-03", "source_system": "ConnectorGamma"}	validation_failed: amount deve ser maior que zero: '-100.00'	{"line_number": 4}	4	f	\N	\N	2026-04-07 04:32:28.10542+00
c79adb3a-be71-4ce4-a7a6-95af12123220	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	a327ee17-72e4-49fe-bdb3-6c5abc8ec049	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-DATE", "external_player_id": "PLY-SPI-002", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "300.00", "occurred_at": "2026-99-99T99:99:99Z", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "device_id": "dev-spi-02", "source_system": "ConnectorGamma"}	validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'	{"line_number": 5}	5	f	\N	\N	2026-04-07 04:32:28.122757+00
472bf59c-fad6-4a9d-9e42-c775d68f09d5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	f9e919ff-b9e4-4a26-93c7-91b36f8c97c1	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775536629813","external_player_id":"CPF-1775536629813","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "replay": {"note": "Replay validado pela suíte E2E", "status": "QUEUED", "event_id": "e998bbac-5c53-4d86-9438-3a9d3bbafa1a", "entity_type": "TRANSACTION", "replayed_at": "2026-04-07T04:37:13.160502+00:00", "replayed_by": "2c9dc0c7-cc53-4e4d-857b-a267c9355532", "apply_mapping": true, "source_event_id": "e2e-epsilon-error-1775536629813", "mapping_config_id": null, "mapping_version_id": null}, "channel": "webhook", "connector": "epsilon"}	\N	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:13.16055+00	2026-04-07 04:37:09.839551+00
1e278418-5f6e-46ec-aca3-4ca4d2478139	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	44e584b7-98ac-42aa-af16-dea143ffa361	ConnectorGamma	TRANSACTION	{"event_id": "gamma-bad-1", "external_player_id": "CPF-GAMMA-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "device_id": "dev-gamma-2", "source_system": "ConnectorGamma"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')	{"stage": "mapping", "connector": "gamma", "mapping_config_id": "0f9a3081-659b-4260-b778-94204e484544"}	\N	f	\N	\N	2026-04-07 04:37:24.0977+00
7450f6f2-fada-45d0-8a2d-3ee0d086ea5b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	90cc08da-1ef8-4626-86a1-c3e94abe0e99	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "delta-bad-1775536644469", "uid": "CPF-DELTA-3", "evt_type": "DEPOSIT", "ts": "2026-03-20T12:05:00Z", "val": "not-a-number", "ccy": "BRL", "currency": "BRL"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')	{"stage": "mapping", "connector": "delta", "mapping_config_id": "b4739b52-e3d1-4d0a-b9bf-a91df33c5704"}	\N	f	\N	\N	2026-04-07 04:37:24.496238+00
1304ef7e-5331-4f4c-9a7d-e5bf6a9652c0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	90cc08da-1ef8-4626-86a1-c3e94abe0e99	ConnectorDelta	TRANSACTION	{"id":"delta-bad-json","uid":"CPF-DELTA-2"	Expecting ',' delimiter: line 1 column 43 (char 42)	{"line": 2, "connector": "delta"}	2	f	\N	\N	2026-04-07 04:37:24.496238+00
311bd100-c60a-4365-8b47-8046360ac4ae	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2965b160-355c-4d36-aca2-d0738a24cde0	ConnectorGamma	TRANSACTION	{"id": "gamma-map-1", "player_id": "CPF-GAMMA-MAP-1", "type": "DEPOSIT", "amount": "321.00", "currency": "BRL", "timestamp": "2026-03-20T10:00:00Z", "source_system": "ConnectorGamma"}	validation_failed: empty_required_fields=['external_transaction_id', 'occurred_at', 'player_cpf', 'type']	{"stage": "validation", "connector": "gamma", "mapping_config_id": "99919d33-db29-4ca9-b102-1be5eebcbe36"}	\N	f	\N	\N	2026-04-07 04:37:24.901695+00
73faf846-54c6-4738-9d46-8e9f8f9f3cf6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	f3025397-f841-4e75-abb7-747f53bd7824	ConnectorGamma	TRANSACTION	{"event_id": "iso-gamma-bad-1", "external_player_id": "CPF-ISO-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "device_id": "dev-iso-2", "source_system": "ConnectorGamma"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')	{"stage": "mapping", "connector": "gamma", "mapping_config_id": "2aabcb5d-b776-4f6c-bed8-d21640ef6907"}	\N	f	\N	\N	2026-04-07 04:37:28.212722+00
987549a2-27a8-4d4a-a13b-ed6146416291	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	4a049cbd-9b25-48e8-b989-e7d3a8a0dc9f	ConnectorGamma	TRANSACTION	{"event_id": "iso-gamma-bad-1", "external_player_id": "CPF-ISO-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "device_id": "dev-iso-2", "source_system": "ConnectorGamma"}	validation_failed: empty_required_fields=['amount']; amount inválido: None	{"line_number": 2}	2	f	\N	\N	2026-04-07 04:37:28.330595+00
b3d9b626-09a6-4be5-8311-d418fe32aef0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	667f060a-7b8e-4800-beb4-9ba0f6240c0b	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-NEG", "external_player_id": "PLY-RTR-003", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "-100.00", "occurred_at": "2026-03-21T13:30:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "device_id": "dev-rtr-03", "source_system": "ConnectorGamma"}	validation_failed: amount deve ser maior que zero: '-100.00'	{"stage": "validation", "connector": "gamma", "mapping_config_id": "2aabcb5d-b776-4f6c-bed8-d21640ef6907"}	\N	f	\N	\N	2026-04-07 04:37:32.471727+00
4cd588b0-534b-4f4b-89b7-8c52c729dc84	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	667f060a-7b8e-4800-beb4-9ba0f6240c0b	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-DATE", "external_player_id": "PLY-SPI-002", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "300.00", "occurred_at": "2026-99-99T99:99:99Z", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "device_id": "dev-spi-02", "source_system": "ConnectorGamma"}	validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'	{"stage": "validation", "connector": "gamma", "mapping_config_id": "2aabcb5d-b776-4f6c-bed8-d21640ef6907"}	\N	f	\N	\N	2026-04-07 04:37:32.471727+00
66b46809-02cf-4be2-a820-030e5e76bfb2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ede2d78d-486b-49e7-bcb6-43b5508b5e0e	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "DELTA-ERR-NEG", "uid": "PLY-NET-005", "evt_type": "DEPOSIT", "ts": "2026-03-21T14:10:00Z", "val": -50.0, "ccy": "BRL", "device": "dev-shared-77", "pay_method": "PIX", "pay_token": "pix-delta-err-neg", "ip": "200.155.10.11", "session_id": "sess-delta-err-neg", "currency": "BRL"}	validation_failed: amount deve ser maior que zero: '-50.0'	{"stage": "validation", "connector": "delta", "mapping_config_id": "b4739b52-e3d1-4d0a-b9bf-a91df33c5704"}	\N	f	\N	\N	2026-04-07 04:37:32.525821+00
af0fb25d-877c-4cbb-80e2-68ca53838f91	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ede2d78d-486b-49e7-bcb6-43b5508b5e0e	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "DELTA-ERR-NO-TS", "uid": "PLY-SPI-002", "evt_type": "DEPOSIT", "val": 300.0, "ccy": "BRL", "device": "dev-spi-02", "pay_method": "CARD", "pay_token": "card-delta-err-no-ts", "ip": "177.20.20.20", "session_id": "sess-delta-err-no-ts", "currency": "BRL"}	mapping_failed: Campo obrigatório 'occurred_at' é None após transform 'parseDate' (source='ts', raw='None')	{"stage": "mapping", "connector": "delta", "mapping_config_id": "b4739b52-e3d1-4d0a-b9bf-a91df33c5704"}	\N	f	\N	\N	2026-04-07 04:37:32.525821+00
0fe58f12-e723-4c10-a1f2-921797505e2e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ede2d78d-486b-49e7-bcb6-43b5508b5e0e	ConnectorDelta	TRANSACTION	{"id":"DELTA-ERR-MALFORMED","uid":"PLY-PEP-006","evt_type":"DEPOSIT","ts":"2026-03-21T14:12:00Z","val":400.0,"ccy":"BRL"	Expecting ',' delimiter: line 1 column 121 (char 120)	{"line": 7, "connector": "delta"}	7	f	\N	\N	2026-04-07 04:37:32.525821+00
ba48aee6-1e84-4b30-81d5-99b14a9cae8a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	f60df468-d787-4980-b3ea-b022a705e77a	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-NEG", "external_player_id": "PLY-RTR-003", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "-100.00", "occurred_at": "2026-03-21T13:30:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "device_id": "dev-rtr-03", "source_system": "ConnectorGamma"}	validation_failed: amount deve ser maior que zero: '-100.00'	{"line_number": 4}	4	f	\N	\N	2026-04-07 04:37:32.671189+00
d20a9363-f36d-4165-947a-7fc01a25213d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	f60df468-d787-4980-b3ea-b022a705e77a	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-DATE", "external_player_id": "PLY-SPI-002", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "300.00", "occurred_at": "2026-99-99T99:99:99Z", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "device_id": "dev-spi-02", "source_system": "ConnectorGamma"}	validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'	{"line_number": 5}	5	f	\N	\N	2026-04-07 04:37:32.688654+00
297bc342-ad1e-471c-b848-aa9575228c25	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	27c6afdb-de0a-4d37-8296-1c81a0b8893b	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775537360575","external_player_id":"CPF-1775537360575","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "replay": {"note": "Replay validado pela suíte E2E", "status": "QUEUED", "event_id": "d029fa78-0e6f-47aa-bcfe-b92ecd09ddc6", "entity_type": "TRANSACTION", "replayed_at": "2026-04-07T04:49:23.418118+00:00", "replayed_by": "2c9dc0c7-cc53-4e4d-857b-a267c9355532", "apply_mapping": true, "source_event_id": "e2e-epsilon-error-1775537360575", "mapping_config_id": null, "mapping_version_id": null}, "channel": "webhook", "connector": "epsilon"}	\N	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:23.418155+00	2026-04-07 04:49:20.608277+00
d8c37f1e-10bb-41a3-8766-41f712866857	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b38f5fc3-1b8d-4145-8faa-302c23b183d8	ConnectorGamma	TRANSACTION	{"event_id": "gamma-bad-1", "external_player_id": "CPF-GAMMA-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "device_id": "dev-gamma-2", "source_system": "ConnectorGamma"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')	{"stage": "mapping", "connector": "gamma", "mapping_config_id": "341ea838-8b1c-43de-93a3-6b7b2518efd6"}	\N	f	\N	\N	2026-04-07 04:49:34.18063+00
04d20e2d-32d8-4060-8d69-1041546efa3e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	bb02d470-fd0d-4df9-9c0d-49422ae9f2cc	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "delta-bad-1775537374579", "uid": "CPF-DELTA-3", "evt_type": "DEPOSIT", "ts": "2026-03-20T12:05:00Z", "val": "not-a-number", "ccy": "BRL", "currency": "BRL"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')	{"stage": "mapping", "connector": "delta", "mapping_config_id": "f3d0cbec-d091-4935-b6c3-1d0cf4482ebc"}	\N	f	\N	\N	2026-04-07 04:49:34.608239+00
72531849-d944-4a6f-b362-67f60f2ded53	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	bb02d470-fd0d-4df9-9c0d-49422ae9f2cc	ConnectorDelta	TRANSACTION	{"id":"delta-bad-json","uid":"CPF-DELTA-2"	Expecting ',' delimiter: line 1 column 43 (char 42)	{"line": 2, "connector": "delta"}	2	f	\N	\N	2026-04-07 04:49:34.608239+00
6a1f2920-f13d-4a0a-8142-92a99aa60b0d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	d41ad5fd-00f3-4e24-ba31-e6d99baa476c	ConnectorGamma	TRANSACTION	{"id": "gamma-map-1", "player_id": "CPF-GAMMA-MAP-1", "type": "DEPOSIT", "amount": "321.00", "currency": "BRL", "timestamp": "2026-03-20T10:00:00Z", "source_system": "ConnectorGamma"}	validation_failed: empty_required_fields=['external_transaction_id', 'occurred_at', 'player_cpf', 'type']	{"stage": "validation", "connector": "gamma", "mapping_config_id": "e0e75f69-80d9-4337-8b92-0b550df47c66"}	\N	f	\N	\N	2026-04-07 04:49:35.075946+00
273ba28a-914b-4a06-89db-491c6f1ac973	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	632551de-470b-4f59-b6c8-bd8e6b27c5b2	ConnectorGamma	TRANSACTION	{"event_id": "iso-gamma-bad-1", "external_player_id": "CPF-ISO-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "device_id": "dev-iso-2", "source_system": "ConnectorGamma"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')	{"stage": "mapping", "connector": "gamma", "mapping_config_id": "615f7ab8-3f2d-4d71-8b99-82b7c9cdd197"}	\N	f	\N	\N	2026-04-07 04:49:38.445977+00
3d4273c5-7f04-4c64-b833-af02f8a46a30	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8fe20184-b38b-41a2-98ab-8edf85e27262	ConnectorGamma	TRANSACTION	{"event_id": "iso-gamma-bad-1", "external_player_id": "CPF-ISO-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "device_id": "dev-iso-2", "source_system": "ConnectorGamma"}	validation_failed: empty_required_fields=['amount']; amount inválido: None	{"line_number": 2}	2	f	\N	\N	2026-04-07 04:49:38.581237+00
85eec6f3-66af-443c-96d0-ff93d7792cd8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ce188537-4f85-408b-835d-4d537518b883	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-NEG", "external_player_id": "PLY-RTR-003", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "-100.00", "occurred_at": "2026-03-21T13:30:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "device_id": "dev-rtr-03", "source_system": "ConnectorGamma"}	validation_failed: amount deve ser maior que zero: '-100.00'	{"stage": "validation", "connector": "gamma", "mapping_config_id": "615f7ab8-3f2d-4d71-8b99-82b7c9cdd197"}	\N	f	\N	\N	2026-04-07 04:49:42.656775+00
48ee40fe-9141-4b72-a5a8-f77892436cb2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ce188537-4f85-408b-835d-4d537518b883	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-DATE", "external_player_id": "PLY-SPI-002", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "300.00", "occurred_at": "2026-99-99T99:99:99Z", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "device_id": "dev-spi-02", "source_system": "ConnectorGamma"}	validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'	{"stage": "validation", "connector": "gamma", "mapping_config_id": "615f7ab8-3f2d-4d71-8b99-82b7c9cdd197"}	\N	f	\N	\N	2026-04-07 04:49:42.656775+00
8cde1bd9-9284-4b7e-95dd-cb3af264f216	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	4392ead8-c8ab-459f-b9f2-afff06e7a8bd	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "DELTA-ERR-NEG", "uid": "PLY-NET-005", "evt_type": "DEPOSIT", "ts": "2026-03-21T14:10:00Z", "val": -50.0, "ccy": "BRL", "device": "dev-shared-77", "pay_method": "PIX", "pay_token": "pix-delta-err-neg", "ip": "200.155.10.11", "session_id": "sess-delta-err-neg", "currency": "BRL"}	validation_failed: amount deve ser maior que zero: '-50.0'	{"stage": "validation", "connector": "delta", "mapping_config_id": "f3d0cbec-d091-4935-b6c3-1d0cf4482ebc"}	\N	f	\N	\N	2026-04-07 04:49:42.696354+00
9233b8eb-ea1f-41c8-b779-b97cae86dd48	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	4392ead8-c8ab-459f-b9f2-afff06e7a8bd	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "DELTA-ERR-NO-TS", "uid": "PLY-SPI-002", "evt_type": "DEPOSIT", "val": 300.0, "ccy": "BRL", "device": "dev-spi-02", "pay_method": "CARD", "pay_token": "card-delta-err-no-ts", "ip": "177.20.20.20", "session_id": "sess-delta-err-no-ts", "currency": "BRL"}	mapping_failed: Campo obrigatório 'occurred_at' é None após transform 'parseDate' (source='ts', raw='None')	{"stage": "mapping", "connector": "delta", "mapping_config_id": "f3d0cbec-d091-4935-b6c3-1d0cf4482ebc"}	\N	f	\N	\N	2026-04-07 04:49:42.696354+00
74f93ff4-56cb-4b7e-b92c-e4202dec502e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	4392ead8-c8ab-459f-b9f2-afff06e7a8bd	ConnectorDelta	TRANSACTION	{"id":"DELTA-ERR-MALFORMED","uid":"PLY-PEP-006","evt_type":"DEPOSIT","ts":"2026-03-21T14:12:00Z","val":400.0,"ccy":"BRL"	Expecting ',' delimiter: line 1 column 121 (char 120)	{"line": 7, "connector": "delta"}	7	f	\N	\N	2026-04-07 04:49:42.696354+00
40b6de88-749d-4889-be29-6cee62aded4f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	0c1cd880-3b01-47c2-9bcd-be7d10263b28	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-NEG", "external_player_id": "PLY-RTR-003", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "-100.00", "occurred_at": "2026-03-21T13:30:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "device_id": "dev-rtr-03", "source_system": "ConnectorGamma"}	validation_failed: amount deve ser maior que zero: '-100.00'	{"line_number": 4}	4	f	\N	\N	2026-04-07 04:49:42.833626+00
d0539429-60f6-4e58-8c4e-c5649bb55e8d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	0c1cd880-3b01-47c2-9bcd-be7d10263b28	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-DATE", "external_player_id": "PLY-SPI-002", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "300.00", "occurred_at": "2026-99-99T99:99:99Z", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "device_id": "dev-spi-02", "source_system": "ConnectorGamma"}	validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'	{"line_number": 5}	5	f	\N	\N	2026-04-07 04:49:42.849241+00
cbcc0d47-6e96-4dac-ab46-61907c3be517	23f4e6fb-ac62-49d9-94d0-078f0aa8924d	47385ab9-d4e3-4f38-abb4-8814c99f32a4	ConnectorDelta	TRANSACTION	"player_id,amount,currency,transaction_type,occurred_at"	Expecting value: line 1 column 1 (char 0)	{"line_number": 1}	1	f	\N	\N	2026-04-07 05:10:21.015797+00
cc79ffba-06b5-4b22-a468-7aaab71f5b71	23f4e6fb-ac62-49d9-94d0-078f0aa8924d	47385ab9-d4e3-4f38-abb4-8814c99f32a4	ConnectorDelta	TRANSACTION	"PLY-1775538617510,1250,BRL,DEPOSIT,2026-03-20T10:00:00Z"	Expecting value: line 1 column 1 (char 0)	{"line_number": 2}	2	f	\N	\N	2026-04-07 05:10:21.039829+00
6c52b5e9-ab01-4b9c-bd2b-bf2402cb0bb8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	f04d3b6a-08ba-4fc3-ba4d-5a4f2dba409b	ConnectorEpsilon	TRANSACTION	{"event_id":"e2e-epsilon-error-1775538651343","external_player_id":"CPF-1775538651343","transaction_type":"DEPOSIT","amount":"invalid-number","occurred_at":"2026-03-20T12:00:00Z"}	Invalid signature	{"line": null, "replay": {"note": "Replay validado pela suíte E2E", "status": "QUEUED", "event_id": "ffd890e6-24b8-4546-bce3-af9e1a9ec5a1", "entity_type": "TRANSACTION", "replayed_at": "2026-04-07T05:10:54.103586+00:00", "replayed_by": "2c9dc0c7-cc53-4e4d-857b-a267c9355532", "apply_mapping": true, "source_event_id": "e2e-epsilon-error-1775538651343", "mapping_config_id": null, "mapping_version_id": null}, "channel": "webhook", "connector": "epsilon"}	\N	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:10:54.103623+00	2026-04-07 05:10:51.407986+00
d6a862f5-aa02-4219-b663-e50e74e2b37a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	69d80e3e-0546-456a-b409-d9377e14dd37	ConnectorGamma	TRANSACTION	{"event_id": "gamma-bad-1", "external_player_id": "CPF-GAMMA-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "device_id": "dev-gamma-2", "source_system": "ConnectorGamma"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')	{"stage": "mapping", "connector": "gamma", "mapping_config_id": "af9d1e95-e27c-403e-bf65-133a96ab851e"}	\N	f	\N	\N	2026-04-07 05:11:05.042077+00
36cc3b52-23ed-4bbb-97b1-a121142e29f5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	53944e7a-100f-4ef8-b446-1bf87eb50c9c	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "delta-bad-1775538665429", "uid": "CPF-DELTA-3", "evt_type": "DEPOSIT", "ts": "2026-03-20T12:05:00Z", "val": "not-a-number", "ccy": "BRL", "currency": "BRL"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')	{"stage": "mapping", "connector": "delta", "mapping_config_id": "e2c8dd08-d54b-412e-99a0-b284a1c1c934"}	\N	f	\N	\N	2026-04-07 05:11:05.452188+00
7e984caf-ea3d-4ef2-b730-e9b960aeecee	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	53944e7a-100f-4ef8-b446-1bf87eb50c9c	ConnectorDelta	TRANSACTION	{"id":"delta-bad-json","uid":"CPF-DELTA-2"	Expecting ',' delimiter: line 1 column 43 (char 42)	{"line": 2, "connector": "delta"}	2	f	\N	\N	2026-04-07 05:11:05.452188+00
f5adbc33-2435-4466-b2a5-3d840eaa4582	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	be8da54c-f011-4259-b036-61b2407ffbf0	ConnectorGamma	TRANSACTION	{"id": "gamma-map-1", "player_id": "CPF-GAMMA-MAP-1", "type": "DEPOSIT", "amount": "321.00", "currency": "BRL", "timestamp": "2026-03-20T10:00:00Z", "source_system": "ConnectorGamma"}	validation_failed: empty_required_fields=['external_transaction_id', 'occurred_at', 'player_cpf', 'type']	{"stage": "validation", "connector": "gamma", "mapping_config_id": "057d6bef-dddd-405d-93e4-215b97dd9648"}	\N	f	\N	\N	2026-04-07 05:11:05.896265+00
5be1e799-455b-4b1c-af31-9df36cc91a27	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	2734c5f5-1202-4ced-9377-67a8ab54f6b8	ConnectorGamma	TRANSACTION	{"event_id": "iso-gamma-bad-1", "external_player_id": "CPF-ISO-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "device_id": "dev-iso-2", "source_system": "ConnectorGamma"}	mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')	{"stage": "mapping", "connector": "gamma", "mapping_config_id": "abe29951-4a34-40f4-985e-484a876ebc39"}	\N	f	\N	\N	2026-04-07 05:11:09.354232+00
5e76fa4d-b910-4e79-8cf5-28cd7d3fa3f0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	bff67acd-99a6-4b60-b6e6-44b0b293a1da	ConnectorGamma	TRANSACTION	{"event_id": "iso-gamma-bad-1", "external_player_id": "CPF-ISO-2", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "not-a-number", "occurred_at": "2026-03-20T10:05:00Z", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "device_id": "dev-iso-2", "source_system": "ConnectorGamma"}	validation_failed: empty_required_fields=['amount']; amount inválido: None	{"line_number": 2}	2	f	\N	\N	2026-04-07 05:11:09.492991+00
19852230-6b49-4ee0-8152-13e4609fc8e3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8daa394b-665b-4c99-a20c-09fe1d27087c	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-NEG", "external_player_id": "PLY-RTR-003", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "-100.00", "occurred_at": "2026-03-21T13:30:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "device_id": "dev-rtr-03", "source_system": "ConnectorGamma"}	validation_failed: amount deve ser maior que zero: '-100.00'	{"stage": "validation", "connector": "gamma", "mapping_config_id": "abe29951-4a34-40f4-985e-484a876ebc39"}	\N	f	\N	\N	2026-04-07 05:11:13.543365+00
00090858-9db9-4b7d-8d3e-e970c5f6b68b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	8daa394b-665b-4c99-a20c-09fe1d27087c	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-DATE", "external_player_id": "PLY-SPI-002", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "300.00", "occurred_at": "2026-99-99T99:99:99Z", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "device_id": "dev-spi-02", "source_system": "ConnectorGamma"}	validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'	{"stage": "validation", "connector": "gamma", "mapping_config_id": "abe29951-4a34-40f4-985e-484a876ebc39"}	\N	f	\N	\N	2026-04-07 05:11:13.543365+00
c7e8fc3e-6f0a-4f85-a7d1-2232e0b5d381	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	36536330-55e8-4e41-a3b0-ec3d2606c8aa	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "DELTA-ERR-NEG", "uid": "PLY-NET-005", "evt_type": "DEPOSIT", "ts": "2026-03-21T14:10:00Z", "val": -50.0, "ccy": "BRL", "device": "dev-shared-77", "pay_method": "PIX", "pay_token": "pix-delta-err-neg", "ip": "200.155.10.11", "session_id": "sess-delta-err-neg", "currency": "BRL"}	validation_failed: amount deve ser maior que zero: '-50.0'	{"stage": "validation", "connector": "delta", "mapping_config_id": "e2c8dd08-d54b-412e-99a0-b284a1c1c934"}	\N	f	\N	\N	2026-04-07 05:11:13.583686+00
f6e0da99-6a44-4ee9-a3a7-141a58fb6bba	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	36536330-55e8-4e41-a3b0-ec3d2606c8aa	ConnectorDelta	TRANSACTION	{"source_system": "ConnectorDelta", "id": "DELTA-ERR-NO-TS", "uid": "PLY-SPI-002", "evt_type": "DEPOSIT", "val": 300.0, "ccy": "BRL", "device": "dev-spi-02", "pay_method": "CARD", "pay_token": "card-delta-err-no-ts", "ip": "177.20.20.20", "session_id": "sess-delta-err-no-ts", "currency": "BRL"}	mapping_failed: Campo obrigatório 'occurred_at' é None após transform 'parseDate' (source='ts', raw='None')	{"stage": "mapping", "connector": "delta", "mapping_config_id": "e2c8dd08-d54b-412e-99a0-b284a1c1c934"}	\N	f	\N	\N	2026-04-07 05:11:13.583686+00
0259612a-f908-4046-98b5-f41596e39b82	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	36536330-55e8-4e41-a3b0-ec3d2606c8aa	ConnectorDelta	TRANSACTION	{"id":"DELTA-ERR-MALFORMED","uid":"PLY-PEP-006","evt_type":"DEPOSIT","ts":"2026-03-21T14:12:00Z","val":400.0,"ccy":"BRL"	Expecting ',' delimiter: line 1 column 121 (char 120)	{"line": 7, "connector": "delta"}	7	f	\N	\N	2026-04-07 05:11:13.583686+00
d2dc77f6-eb9b-40c7-8227-323ce8df86ee	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	20db7cb9-e140-410c-9f6c-5179bbef8d0c	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-NEG", "external_player_id": "PLY-RTR-003", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "-100.00", "occurred_at": "2026-03-21T13:30:00Z", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "device_id": "dev-rtr-03", "source_system": "ConnectorGamma"}	validation_failed: amount deve ser maior que zero: '-100.00'	{"line_number": 4}	4	f	\N	\N	2026-04-07 05:11:13.717413+00
018854e1-5ab4-4e64-a86f-16d6f3fb5711	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	20db7cb9-e140-410c-9f6c-5179bbef8d0c	ConnectorGamma	TRANSACTION	{"event_id": "GAMMA-ERR-DATE", "external_player_id": "PLY-SPI-002", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "300.00", "occurred_at": "2026-99-99T99:99:99Z", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "device_id": "dev-spi-02", "source_system": "ConnectorGamma"}	validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'	{"line_number": 5}	5	f	\N	\N	2026-04-07 05:11:13.732628+00
eccdbfd9-903f-4082-a54d-1b08a13b7715	d3108642-40e7-4da1-aa68-4a17aac45b10	75dd17b2-8856-4c59-9aec-4a1750d71d54	ConnectorDelta	TRANSACTION	"player_id,amount,currency,transaction_type,occurred_at"	Expecting value: line 1 column 1 (char 0)	{"line_number": 1}	1	f	\N	\N	2026-04-07 05:11:31.821716+00
af5b6680-d19c-464c-af70-cb00ff4a8bcb	d3108642-40e7-4da1-aa68-4a17aac45b10	75dd17b2-8856-4c59-9aec-4a1750d71d54	ConnectorDelta	TRANSACTION	"PLY-1775538688614,1250,BRL,DEPOSIT,2026-03-20T10:00:00Z"	Expecting value: line 1 column 1 (char 0)	{"line_number": 2}	2	f	\N	\N	2026-04-07 05:11:31.8444+00
6e79c730-29ae-4933-83ac-da76268a16a4	71825dca-3ce0-4230-a48d-da36c09148cd	1da7e721-9b47-4b0b-aba8-17ea4096b923	ConnectorDelta	TRANSACTION	"player_id,amount,currency,transaction_type,occurred_at"	Expecting value: line 1 column 1 (char 0)	{"line_number": 1}	1	f	\N	\N	2026-04-07 05:12:07.67312+00
c6bffec2-26b5-4adc-b639-17a914406f55	71825dca-3ce0-4230-a48d-da36c09148cd	1da7e721-9b47-4b0b-aba8-17ea4096b923	ConnectorDelta	TRANSACTION	"PLY-1775538724541,1250,BRL,DEPOSIT,2026-03-20T10:00:00Z"	Expecting value: line 1 column 1 (char 0)	{"line_number": 2}	2	f	\N	\N	2026-04-07 05:12:07.723865+00
\.


--
-- Data for Name: ingest_jobs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.ingest_jobs (id, tenant_id, source_system, mapping_config_id, file_name, file_size_bytes, file_path, status, total_records, processed_records, failed_records, error_message, created_by, created_at, updated_at, bytes_processed, duration_ms, error_sample, connector_type, reprocessed_from, mapping_version_id, ingest_mode, is_backfill) FROM stdin;
15eaccb4-2bed-4053-93d0-8ae045d6b548	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775532358051.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/15eaccb4-2bed-4053-93d0-8ae045d6b548/e2e-ingest-1775532358051.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:25:58.060137+00	2026-04-07 03:25:58.153873+00	183	24	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
44ab1413-e88b-480e-9702-10643c7e4c19	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T031812845262Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/44ab1413-e88b-480e-9702-10643c7e4c19/epsilon-webhook-20260407T031812845262Z.json	FAILED	0	0	1	webhook_validation_failed	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:18:12.836629+00	2026-04-07 03:18:12.864745+00	179	19	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775531892831\\",\\"external_player_id\\":\\"CPF-1775531892831\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
7e46afe9-65f4-42bd-a48a-f2ca57823a11	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	fictibet-canonical-1775536082724.ndjson	25232	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/7e46afe9-65f4-42bd-a48a-f2ca57823a11/fictibet-canonical-1775536082724.ndjson	DONE	51	51	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:28:02.735644+00	2026-04-07 04:28:02.94213+00	27077	95	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
acf913ae-ef3b-4c28-b90f-313fd77b38b5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775531924441.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/acf913ae-ef3b-4c28-b90f-313fd77b38b5/e2e-ingest-1775531924441.csv	DONE	1	1	0	\N	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:18:44.447952+00	2026-04-07 03:18:45.738325+00	183	17	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
6890387c-0c66-43c1-9f43-a2dede8292c4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T032441853181Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/6890387c-0c66-43c1-9f43-a2dede8292c4/epsilon-webhook-20260407T032441853181Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:24:41.838694+00	2026-04-07 03:24:41.879618+00	179	25	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775532281827\\",\\"external_player_id\\":\\"CPF-1775532281827\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
d46b65e7-be91-47d1-a1fd-42eb8461f0d1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775532889391.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/d46b65e7-be91-47d1-a1fd-42eb8461f0d1/e2e-ingest-1775532889391.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:34:49.410107+00	2026-04-07 03:34:49.521526+00	183	23	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
29757df7-1a10-450f-95d9-a0d6286385d4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775532285024.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/29757df7-1a10-450f-95d9-a0d6286385d4/e2e-ingest-1775532285024.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:24:45.072516+00	2026-04-07 03:24:45.17995+00	183	19	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
18004337-ff0e-46f8-9812-42cfc31b7450	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775532338651.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/18004337-ff0e-46f8-9812-42cfc31b7450/e2e-ingest-1775532338651.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:25:38.659747+00	2026-04-07 03:25:38.772917+00	183	30	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
78a97585-e09d-440c-8fc4-885fbf6d7ef8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775532449474.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/78a97585-e09d-440c-8fc4-885fbf6d7ef8/e2e-ingest-1775532449474.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:27:29.48995+00	2026-04-07 03:27:29.574292+00	183	21	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
f060f354-9cf7-4276-838f-ca57718352d1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T032726935246Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/f060f354-9cf7-4276-838f-ca57718352d1/epsilon-webhook-20260407T032726935246Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:27:26.918705+00	2026-04-07 03:27:27.068318+00	179	132	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775532446906\\",\\"external_player_id\\":\\"CPF-1775532446906\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
432447e3-909d-478a-bfd0-8c3784c2a058	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T033446729848Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/432447e3-909d-478a-bfd0-8c3784c2a058/epsilon-webhook-20260407T033446729848Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:34:46.705477+00	2026-04-07 03:34:46.756455+00	179	26	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775532886698\\",\\"external_player_id\\":\\"CPF-1775532886698\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
eb0bea4c-d8a1-4cdc-b59e-678654701dea	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T033930894687Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/eb0bea4c-d8a1-4cdc-b59e-678654701dea/epsilon-webhook-20260407T033930894687Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:39:30.882912+00	2026-04-07 03:39:30.913701+00	179	17	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775533170872\\",\\"external_player_id\\":\\"CPF-1775533170872\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
5c945734-ebf3-46b6-95fd-ace4e90c6af3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775533173565.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/5c945734-ebf3-46b6-95fd-ace4e90c6af3/e2e-ingest-1775533173565.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:39:33.579299+00	2026-04-07 03:39:33.671022+00	183	23	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
c0eaa201-2f2e-4a7e-97c2-c19eef0612d6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T035242375738Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/c0eaa201-2f2e-4a7e-97c2-c19eef0612d6/epsilon-webhook-20260407T035242375738Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:52:42.348185+00	2026-04-07 03:52:42.403415+00	179	27	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775533962339\\",\\"external_player_id\\":\\"CPF-1775533962339\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
9229b5f5-d87d-459c-96f2-4e1ead4ef201	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775533965435.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/9229b5f5-d87d-459c-96f2-4e1ead4ef201/e2e-ingest-1775533965435.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:52:45.450821+00	2026-04-07 03:52:45.572643+00	183	26	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
91f81af2-1d61-4d69-83da-59705d2b890d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	\N	delta-rate-limit-1775535182248.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/91f81af2-1d61-4d69-83da-59705d2b890d/delta-rate-limit-1775535182248.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:13:02.253286+00	2026-04-07 04:13:02.272533+00	132	\N	[]	FILE	\N	\N	incremental	f
8364b8d1-b246-4482-91a4-a2fde9512ab0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T042300268512Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/8364b8d1-b246-4482-91a4-a2fde9512ab0/epsilon-webhook-20260407T042300268512Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:00.262719+00	2026-04-07 04:23:00.287958+00	179	19	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775535780258\\",\\"external_player_id\\":\\"CPF-1775535780258\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
1057745b-07bc-4005-bc80-bfe8caff9332	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775535105479.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/1057745b-07bc-4005-bc80-bfe8caff9332/e2e-ingest-1775535105479.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:11:45.484859+00	2026-04-07 04:11:45.565214+00	183	15	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
fe56aa90-2ff0-41ed-acd3-fed498c7f3c9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T035541638552Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/fe56aa90-2ff0-41ed-acd3-fed498c7f3c9/epsilon-webhook-20260407T035541638552Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:55:41.627453+00	2026-04-07 03:55:41.6607+00	179	21	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775534141617\\",\\"external_player_id\\":\\"CPF-1775534141617\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
05616157-43a9-4bad-8b0a-781fbcd29f96	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	8c3c6e7f-1219-43ee-a385-18714534908c	fictibet-gamma-1775536083855.xml	1847	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/05616157-43a9-4bad-8b0a-781fbcd29f96/fictibet-gamma-1775536083855.xml	PARTIAL	5	3	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:28:03.861776+00	2026-04-07 04:28:03.935742+00	1847	\N	[{"raw": {"amount": "-100.00", "currency": "BRL", "event_id": "GAMMA-ERR-NEG", "device_id": "dev-rtr-03", "occurred_at": "2026-03-21T13:30:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "transaction_type": "DEPOSIT", "external_player_id": "PLY-RTR-003"}, "line": null, "reason": "validation_failed: amount deve ser maior que zero: '-100.00'"}, {"raw": {"amount": "300.00", "currency": "BRL", "event_id": "GAMMA-ERR-DATE", "device_id": "dev-spi-02", "occurred_at": "2026-99-99T99:99:99Z", "source_system": "ConnectorGamma", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "transaction_type": "DEPOSIT", "external_player_id": "PLY-SPI-002"}, "line": null, "reason": "validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'"}]	FILE	\N	8c3c6e7f-1219-43ee-a385-18714534908c	incremental	f
75a73414-57ca-4847-952c-46ddd064afbc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775534144335.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/75a73414-57ca-4847-952c-46ddd064afbc/e2e-ingest-1775534144335.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:55:44.350767+00	2026-04-07 03:55:44.437872+00	183	19	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
1da7e721-9b47-4b0b-aba8-17ea4096b923	71825dca-3ce0-4230-a48d-da36c09148cd	ConnectorDelta	\N	onboarding-1775538724541.csv	110	bronze/71825dca-3ce0-4230-a48d-da36c09148cd/ingest_jobs/1da7e721-9b47-4b0b-aba8-17ea4096b923/onboarding-1775538724541.csv	FAILED	2	0	2	\N	8cfc988d-8513-443c-8d90-da05dd2fac23	2026-04-07 05:12:07.559773+00	2026-04-07 05:12:07.774577+00	110	144	[{"raw": "player_id,amount,currency,transaction_type,occurred_at", "line": 1, "reason": "Expecting value: line 1 column 1 (char 0)"}, {"raw": "PLY-1775538724541,1250,BRL,DEPOSIT,2026-03-20T10:00:00Z", "line": 2, "reason": "Expecting value: line 1 column 1 (char 0)"}]	FILE	\N	\N	incremental	f
d5c1fe04-e334-498b-a066-4a0ba5896817	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T035834473119Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/d5c1fe04-e334-498b-a066-4a0ba5896817/epsilon-webhook-20260407T035834473119Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:58:34.462676+00	2026-04-07 03:58:34.501816+00	179	28	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775534314457\\",\\"external_player_id\\":\\"CPF-1775534314457\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
bce97a97-0e4e-4d87-81c8-18be97295f3a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775536633592.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/425e6629-f875-4f57-a61f-55355f7f9423/e2e-ingest-1775536633592.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:17.638069+00	2026-04-07 04:37:17.747312+00	183	36	[]	FILE	425e6629-f875-4f57-a61f-55355f7f9423	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
7c1cd255-7069-4f5c-88fe-73f7960e8b01	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775535105479.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/1057745b-07bc-4005-bc80-bfe8caff9332/e2e-ingest-1775535105479.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:11:49.404266+00	2026-04-07 04:11:49.485529+00	183	30	[]	FILE	1057745b-07bc-4005-bc80-bfe8caff9332	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
08ae5141-36be-4ad8-baed-05eec9019417	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775534317299.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/08ae5141-36be-4ad8-baed-05eec9019417/e2e-ingest-1775534317299.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:58:37.313573+00	2026-04-07 03:58:37.406866+00	183	21	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
8716f184-4703-4cc9-bc06-8709b0925a25	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T041135278062Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/8716f184-4703-4cc9-bc06-8709b0925a25/epsilon-webhook-20260407T041135278062Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:11:35.271242+00	2026-04-07 04:11:35.294235+00	179	15	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775535095266\\",\\"external_player_id\\":\\"CPF-1775535095266\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
8cb2a02f-7e7a-4559-80ad-b190f3d24ecf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T041222850720Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/8cb2a02f-7e7a-4559-80ad-b190f3d24ecf/epsilon-webhook-20260407T041222850720Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:12:22.84404+00	2026-04-07 04:12:22.86631+00	179	15	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775535142837\\",\\"external_player_id\\":\\"CPF-1775535142837\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
55b460d2-1a2e-48bb-b4bf-291a0f00f22d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775535146363.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/55b460d2-1a2e-48bb-b4bf-291a0f00f22d/e2e-ingest-1775535146363.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:12:26.369114+00	2026-04-07 04:12:26.47074+00	183	25	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
b594dede-5eb8-4eed-ba1c-920d4b4f4d57	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775535783587.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/b594dede-5eb8-4eed-ba1c-920d4b4f4d57/e2e-ingest-1775535783587.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:03.5919+00	2026-04-07 04:23:03.666736+00	183	16	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
1cbc1ef5-7403-4c15-bfbe-6f65a0b7dbbd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775535146363.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/55b460d2-1a2e-48bb-b4bf-291a0f00f22d/e2e-ingest-1775535146363.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:12:30.430608+00	2026-04-07 04:12:30.506766+00	183	26	[]	FILE	55b460d2-1a2e-48bb-b4bf-291a0f00f22d	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
2c02b5f2-e94f-44a2-b188-05f74424af80	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	b1c02615-d314-4302-b4bf-039afd7d2b8a	fictibet-delta-1775536083952.ndjson	1859	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/2c02b5f2-e94f-44a2-b188-05f74424af80/fictibet-delta-1775536083952.ndjson	PARTIAL	8	5	3	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:28:03.959286+00	2026-04-07 04:28:04.001197+00	1859	\N	[{"raw": {"id": "DELTA-ERR-NEG", "ip": "200.155.10.11", "ts": "2026-03-21T14:10:00Z", "ccy": "BRL", "uid": "PLY-NET-005", "val": -50.0, "device": "dev-shared-77", "currency": "BRL", "evt_type": "DEPOSIT", "pay_token": "pix-delta-err-neg", "pay_method": "PIX", "session_id": "sess-delta-err-neg", "source_system": "ConnectorDelta"}, "line": null, "reason": "validation_failed: amount deve ser maior que zero: '-50.0'"}, {"raw": {"id": "DELTA-ERR-NO-TS", "ip": "177.20.20.20", "ccy": "BRL", "uid": "PLY-SPI-002", "val": 300.0, "device": "dev-spi-02", "currency": "BRL", "evt_type": "DEPOSIT", "pay_token": "card-delta-err-no-ts", "pay_method": "CARD", "session_id": "sess-delta-err-no-ts", "source_system": "ConnectorDelta"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'occurred_at' é None após transform 'parseDate' (source='ts', raw='None')"}, {"raw": "{\\"id\\":\\"DELTA-ERR-MALFORMED\\",\\"uid\\":\\"PLY-PEP-006\\",\\"evt_type\\":\\"DEPOSIT\\",\\"ts\\":\\"2026-03-21T14:12:00Z\\",\\"val\\":400.0,\\"ccy\\":\\"BRL\\"", "line": 7, "reason": "Expecting ',' delimiter: line 1 column 121 (char 120)"}]	FILE	\N	b1c02615-d314-4302-b4bf-039afd7d2b8a	incremental	f
82351593-3512-4424-918b-4c5604baab78	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T041251138713Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/82351593-3512-4424-918b-4c5604baab78/epsilon-webhook-20260407T041251138713Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:12:51.134028+00	2026-04-07 04:12:51.150679+00	179	11	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775535171130\\",\\"external_player_id\\":\\"CPF-1775535171130\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
574be954-40d6-4e26-99b5-6362d2f03f66	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	\N	delta-rate-limit-1775535319362.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/574be954-40d6-4e26-99b5-6362d2f03f66/delta-rate-limit-1775535319362.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:19.366329+00	2026-04-07 04:15:19.388485+00	132	\N	[]	FILE	\N	\N	incremental	f
28634bd5-d625-458d-9643-6d3436d22f6c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T042804031177Z.json	2572	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/28634bd5-d625-458d-9643-6d3436d22f6c/epsilon-webhook-20260407T042804031177Z.json	DONE	6	6	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:28:04.025535+00	2026-04-07 04:28:04.065772+00	2572	34	[]	WEBHOOK	\N	\N	incremental	f
d59cf603-2fd3-49ff-ac49-7a7dd5ff5eb9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	\N	delta-rate-limit-1775535319499.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/d59cf603-2fd3-49ff-ac49-7a7dd5ff5eb9/delta-rate-limit-1775535319499.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:19.505777+00	2026-04-07 04:15:19.535757+00	132	\N	[]	FILE	\N	\N	incremental	f
130c3231-2b1a-436a-a6a6-489a318a4b7b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T041539454070Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/130c3231-2b1a-436a-a6a6-489a318a4b7b/epsilon-webhook-20260407T041539454070Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:39.448744+00	2026-04-07 04:15:39.469038+00	179	14	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775535339444\\",\\"external_player_id\\":\\"CPF-1775535339444\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
6847c2bb-1483-4c9f-9bae-2ba4dcbb0f4b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	8c3c6e7f-1219-43ee-a385-18714534908c	fictibet-gamma-1775536083855.xml	1847	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/05616157-43a9-4bad-8b0a-781fbcd29f96/fictibet-gamma-1775536083855.xml	DONE	5	5	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:28:04.151663+00	2026-04-07 04:28:04.50786+00	1847	183	[]	FILE	05616157-43a9-4bad-8b0a-781fbcd29f96	8c3c6e7f-1219-43ee-a385-18714534908c	incremental	f
08d2ff74-a8b7-4e82-a943-376827b5bc9e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	7a451cef-a120-45b9-bf95-eedeb21a4aeb	gamma-1775536086871.xml	687	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/08d2ff74-a8b7-4e82-a943-376827b5bc9e/gamma-1775536086871.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:28:06.876685+00	2026-04-07 04:28:06.894519+00	687	\N	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "gamma-bad-1", "device_id": "dev-gamma-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-GAMMA-2"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')"}]	FILE	\N	7a451cef-a120-45b9-bf95-eedeb21a4aeb	incremental	f
33507d8b-2711-4fef-bb43-7feca531c979	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775535342748.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/33507d8b-2711-4fef-bb43-7feca531c979/e2e-ingest-1775535342748.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:42.756325+00	2026-04-07 04:15:42.882486+00	183	45	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
9b779d04-1024-44f5-98f0-ad1d7a0b4947	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	08e6917b-e953-47e1-a6fe-c30cc97b8093	delta-1775536087258.ndjson	301	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/9b779d04-1024-44f5-98f0-ad1d7a0b4947/delta-1775536087258.ndjson	PARTIAL	3	1	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:28:07.262161+00	2026-04-07 04:28:07.280703+00	301	\N	[{"raw": {"id": "delta-bad-1775536087258", "ts": "2026-03-20T12:05:00Z", "ccy": "BRL", "uid": "CPF-DELTA-3", "val": "not-a-number", "currency": "BRL", "evt_type": "DEPOSIT", "source_system": "ConnectorDelta"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')"}, {"raw": "{\\"id\\":\\"delta-bad-json\\",\\"uid\\":\\"CPF-DELTA-2\\"", "line": 2, "reason": "Expecting ',' delimiter: line 1 column 43 (char 42)"}]	FILE	\N	08e6917b-e953-47e1-a6fe-c30cc97b8093	incremental	f
0c986984-0c44-4394-9306-d4af3d090498	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775535342748.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/33507d8b-2711-4fef-bb43-7feca531c979/e2e-ingest-1775535342748.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:46.590654+00	2026-04-07 04:15:46.655152+00	183	21	[]	FILE	33507d8b-2711-4fef-bb43-7feca531c979	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
7ed73e6e-70b2-4411-b4bf-866823838ea6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775535783587.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/b594dede-5eb8-4eed-ba1c-920d4b4f4d57/e2e-ingest-1775535783587.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:07.554229+00	2026-04-07 04:23:07.621965+00	183	23	[]	FILE	b594dede-5eb8-4eed-ba1c-920d4b4f4d57	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
4c4ced75-b234-4818-9f93-ec70e7fa8b12	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775535174261.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/4c4ced75-b234-4818-9f93-ec70e7fa8b12/e2e-ingest-1775535174261.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:12:54.270972+00	2026-04-07 04:12:54.397823+00	183	27	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
e14042b0-c894-448b-a1f3-fc8ab03283e2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	7de7afb5-f09e-4995-82ad-fcef870000c0	gamma-explicit-1775536087608.xml	261	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/e14042b0-c894-448b-a1f3-fc8ab03283e2/gamma-explicit-1775536087608.xml	FAILED	1	0	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:28:07.612368+00	2026-04-07 04:28:07.627572+00	261	\N	[{"raw": {"id": "gamma-map-1", "type": "DEPOSIT", "amount": "321.00", "currency": "BRL", "player_id": "CPF-GAMMA-MAP-1", "timestamp": "2026-03-20T10:00:00Z", "source_system": "ConnectorGamma"}, "line": null, "reason": "validation_failed: empty_required_fields=['external_transaction_id', 'occurred_at', 'player_cpf', 'type']"}]	FILE	\N	7de7afb5-f09e-4995-82ad-fcef870000c0	incremental	f
5996156b-53d2-456e-9468-080f8c1ad7b6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775535174261.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/4c4ced75-b234-4818-9f93-ec70e7fa8b12/e2e-ingest-1775535174261.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:12:58.5457+00	2026-04-07 04:12:58.616156+00	183	22	[]	FILE	4c4ced75-b234-4818-9f93-ec70e7fa8b12	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
881541fc-93c4-4df4-b346-7128e49c5d9c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	e06ad360-121c-4957-a0f0-1f891bf701e9	delta-rate-limit-1775535790831.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/881541fc-93c4-4df4-b346-7128e49c5d9c/delta-rate-limit-1775535790831.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:10.835834+00	2026-04-07 04:23:10.855529+00	132	\N	[]	FILE	\N	e06ad360-121c-4957-a0f0-1f891bf701e9	incremental	f
8ce3f80b-50cb-4aa6-81c8-b461bb0b5927	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	\N	delta-rate-limit-1775535182053.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/8ce3f80b-50cb-4aa6-81c8-b461bb0b5927/delta-rate-limit-1775535182053.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:13:02.058778+00	2026-04-07 04:13:02.086635+00	132	\N	[]	FILE	\N	\N	incremental	f
9f7a7e70-ca02-42c7-ba4b-00fd9a50646c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	b1c02615-d314-4302-b4bf-039afd7d2b8a	delta-1775535794330.ndjson	301	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/9f7a7e70-ca02-42c7-ba4b-00fd9a50646c/delta-1775535794330.ndjson	PARTIAL	3	1	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:14.334146+00	2026-04-07 04:23:14.35069+00	301	\N	[{"raw": {"id": "delta-bad-1775535794330", "ts": "2026-03-20T12:05:00Z", "ccy": "BRL", "uid": "CPF-DELTA-3", "val": "not-a-number", "currency": "BRL", "evt_type": "DEPOSIT", "source_system": "ConnectorDelta"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')"}, {"raw": "{\\"id\\":\\"delta-bad-json\\",\\"uid\\":\\"CPF-DELTA-2\\"", "line": 2, "reason": "Expecting ',' delimiter: line 1 column 43 (char 42)"}]	FILE	\N	b1c02615-d314-4302-b4bf-039afd7d2b8a	incremental	f
016a607c-65a6-4df5-bd60-be82e4bf5f8c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	\N	delta-rate-limit-1775535182092.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/016a607c-65a6-4df5-bd60-be82e4bf5f8c/delta-rate-limit-1775535182092.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:13:02.096756+00	2026-04-07 04:13:02.116506+00	132	\N	[]	FILE	\N	\N	incremental	f
2965b160-355c-4d36-aca2-d0738a24cde0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	99919d33-db29-4ca9-b102-1be5eebcbe36	gamma-explicit-1775536644877.xml	261	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/2965b160-355c-4d36-aca2-d0738a24cde0/gamma-explicit-1775536644877.xml	FAILED	1	0	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:24.882654+00	2026-04-07 04:37:24.901695+00	261	\N	[{"raw": {"id": "gamma-map-1", "type": "DEPOSIT", "amount": "321.00", "currency": "BRL", "player_id": "CPF-GAMMA-MAP-1", "timestamp": "2026-03-20T10:00:00Z", "source_system": "ConnectorGamma"}, "line": null, "reason": "validation_failed: empty_required_fields=['external_transaction_id', 'occurred_at', 'player_cpf', 'type']"}]	FILE	\N	99919d33-db29-4ca9-b102-1be5eebcbe36	incremental	f
d41c9d84-c3b0-4bbf-8777-713ed36d4c40	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	\N	delta-rate-limit-1775535182121.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/d41c9d84-c3b0-4bbf-8777-713ed36d4c40/delta-rate-limit-1775535182121.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:13:02.125942+00	2026-04-07 04:13:02.14313+00	132	\N	[]	FILE	\N	\N	incremental	f
d4884756-e37d-4b54-97c3-2d0271a068ad	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	8a2e4489-c083-4b26-90a6-436700c46286	gamma-explicit-1775535794834.xml	261	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/d4884756-e37d-4b54-97c3-2d0271a068ad/gamma-explicit-1775535794834.xml	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:14.849243+00	2026-04-07 04:23:14.895574+00	261	\N	[]	FILE	\N	8a2e4489-c083-4b26-90a6-436700c46286	incremental	f
b2393d59-e590-4ece-a7e4-9818b4d7e2eb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	\N	delta-rate-limit-1775535182147.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/b2393d59-e590-4ece-a7e4-9818b4d7e2eb/delta-rate-limit-1775535182147.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:13:02.152126+00	2026-04-07 04:13:02.170233+00	132	\N	[]	FILE	\N	\N	incremental	f
f3025397-f841-4e75-abb7-747f53bd7824	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	2aabcb5d-b776-4f6c-bed8-d21640ef6907	ingest-tenant-isolation-1775536648184.xml	683	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/f3025397-f841-4e75-abb7-747f53bd7824/ingest-tenant-isolation-1775536648184.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:28.189037+00	2026-04-07 04:37:28.212722+00	683	\N	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "iso-gamma-bad-1", "device_id": "dev-iso-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-ISO-2"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')"}]	FILE	\N	2aabcb5d-b776-4f6c-bed8-d21640ef6907	incremental	f
f23b875e-1c02-4688-b2ac-3884b0870fb7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	\N	delta-rate-limit-1775535182176.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/f23b875e-1c02-4688-b2ac-3884b0870fb7/delta-rate-limit-1775535182176.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:13:02.181098+00	2026-04-07 04:13:02.200427+00	132	\N	[]	FILE	\N	\N	incremental	f
3f373560-c6f8-4ca9-97a7-b6622c4c8d8b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	\N	delta-rate-limit-1775535182205.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/3f373560-c6f8-4ca9-97a7-b6622c4c8d8b/delta-rate-limit-1775535182205.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:13:02.21024+00	2026-04-07 04:13:02.228963+00	132	\N	[]	FILE	\N	\N	incremental	f
dd3877d6-0035-407b-9bf3-99e1e3da450a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	\N	delta-rate-limit-1775535349938.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/dd3877d6-0035-407b-9bf3-99e1e3da450a/delta-rate-limit-1775535349938.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:49.942025+00	2026-04-07 04:15:49.960808+00	132	\N	[]	FILE	\N	\N	incremental	f
aa9728d6-4c20-4606-a001-83d657ce81c0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	08e6917b-e953-47e1-a6fe-c30cc97b8093	fictibet-delta-1775536276059.ndjson	1859	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/aa9728d6-4c20-4606-a001-83d657ce81c0/fictibet-delta-1775536276059.ndjson	PARTIAL	8	5	3	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:31:16.065446+00	2026-04-07 04:31:16.092169+00	1859	\N	[{"raw": {"id": "DELTA-ERR-NEG", "ip": "200.155.10.11", "ts": "2026-03-21T14:10:00Z", "ccy": "BRL", "uid": "PLY-NET-005", "val": -50.0, "device": "dev-shared-77", "currency": "BRL", "evt_type": "DEPOSIT", "pay_token": "pix-delta-err-neg", "pay_method": "PIX", "session_id": "sess-delta-err-neg", "source_system": "ConnectorDelta"}, "line": null, "reason": "validation_failed: amount deve ser maior que zero: '-50.0'"}, {"raw": {"id": "DELTA-ERR-NO-TS", "ip": "177.20.20.20", "ccy": "BRL", "uid": "PLY-SPI-002", "val": 300.0, "device": "dev-spi-02", "currency": "BRL", "evt_type": "DEPOSIT", "pay_token": "card-delta-err-no-ts", "pay_method": "CARD", "session_id": "sess-delta-err-no-ts", "source_system": "ConnectorDelta"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'occurred_at' é None após transform 'parseDate' (source='ts', raw='None')"}, {"raw": "{\\"id\\":\\"DELTA-ERR-MALFORMED\\",\\"uid\\":\\"PLY-PEP-006\\",\\"evt_type\\":\\"DEPOSIT\\",\\"ts\\":\\"2026-03-21T14:12:00Z\\",\\"val\\":400.0,\\"ccy\\":\\"BRL\\"", "line": 7, "reason": "Expecting ',' delimiter: line 1 column 121 (char 120)"}]	FILE	\N	08e6917b-e953-47e1-a6fe-c30cc97b8093	incremental	f
b7e423ea-7a49-4e4d-b402-b2dddebbcd9c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	e06ad360-121c-4957-a0f0-1f891bf701e9	delta-rate-limit-1775535790739.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/b7e423ea-7a49-4e4d-b402-b2dddebbcd9c/delta-rate-limit-1775535790739.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:10.743692+00	2026-04-07 04:23:10.765709+00	132	\N	[]	FILE	\N	e06ad360-121c-4957-a0f0-1f891bf701e9	incremental	f
94e11696-5e2a-4674-8a32-73cf1df9b84d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	05eea43d-a38b-48c7-82aa-aea2dc323999	gamma-1775535353029.xml	681	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/94e11696-5e2a-4674-8a32-73cf1df9b84d/gamma-1775535353029.xml	DONE	2	2	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:53.039969+00	2026-04-07 04:15:53.088156+00	681	\N	[]	FILE	\N	05eea43d-a38b-48c7-82aa-aea2dc323999	incremental	f
e6e9a8a5-67ad-4dcf-9d83-f54f74e34c70	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	7de7afb5-f09e-4995-82ad-fcef870000c0	fictibet-gamma-1775536276017.xml	1847	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/e6e9a8a5-67ad-4dcf-9d83-f54f74e34c70/fictibet-gamma-1775536276017.xml	PARTIAL	5	3	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:31:16.022134+00	2026-04-07 04:31:16.046435+00	1847	\N	[{"raw": {"amount": "-100.00", "currency": "BRL", "event_id": "GAMMA-ERR-NEG", "device_id": "dev-rtr-03", "occurred_at": "2026-03-21T13:30:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "transaction_type": "DEPOSIT", "external_player_id": "PLY-RTR-003"}, "line": null, "reason": "validation_failed: amount deve ser maior que zero: '-100.00'"}, {"raw": {"amount": "300.00", "currency": "BRL", "event_id": "GAMMA-ERR-DATE", "device_id": "dev-spi-02", "occurred_at": "2026-99-99T99:99:99Z", "source_system": "ConnectorGamma", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "transaction_type": "DEPOSIT", "external_player_id": "PLY-SPI-002"}, "line": null, "reason": "validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'"}]	FILE	\N	7de7afb5-f09e-4995-82ad-fcef870000c0	incremental	f
b5244abd-7200-46ed-b00f-aa764fb1ed50	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	8f0e495d-f873-42d2-8e19-4377d7e7204b	gamma-explicit-1775535356100.xml	261	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/b5244abd-7200-46ed-b00f-aa764fb1ed50/gamma-explicit-1775535356100.xml	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:56.105656+00	2026-04-07 04:15:56.127926+00	261	\N	[]	FILE	\N	8f0e495d-f873-42d2-8e19-4377d7e7204b	incremental	f
7c3799e5-4292-4405-aff9-8c05aeabed2d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	cb718b5e-d567-4d9c-878a-e1451a5bb48d	gamma-1775535793936.xml	687	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/7c3799e5-4292-4405-aff9-8c05aeabed2d/gamma-1775535793936.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:13.940696+00	2026-04-07 04:23:13.96678+00	687	\N	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "gamma-bad-1", "device_id": "dev-gamma-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-GAMMA-2"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')"}]	FILE	\N	cb718b5e-d567-4d9c-878a-e1451a5bb48d	incremental	f
72e72c27-58d6-410c-897e-446f71f38326	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T041946883502Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/72e72c27-58d6-410c-897e-446f71f38326/epsilon-webhook-20260407T041946883502Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:46.876899+00	2026-04-07 04:19:46.896475+00	179	12	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775535586872\\",\\"external_player_id\\":\\"CPF-1775535586872\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
c116fcff-629c-4180-a356-4300e3da8cc0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	3dc6fe12-a285-449b-a53e-c54321fc3c3e	gamma-1775535600527.xml	687	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/c116fcff-629c-4180-a356-4300e3da8cc0/gamma-1775535600527.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:20:00.532876+00	2026-04-07 04:20:00.553184+00	687	\N	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "gamma-bad-1", "device_id": "dev-gamma-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-GAMMA-2"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')"}]	FILE	\N	3dc6fe12-a285-449b-a53e-c54321fc3c3e	incremental	f
5bd26391-6c35-45f1-8b88-14423092e6bc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	fictibet-canonical-1775536274912.ndjson	25232	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/5bd26391-6c35-45f1-8b88-14423092e6bc/fictibet-canonical-1775536274912.ndjson	DONE	51	51	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:31:14.925287+00	2026-04-07 04:31:15.075101+00	27077	61	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
bbc92a79-d346-4ec7-bf53-3536cff57de8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	d8438dea-52f8-4f19-b1ce-ce14c55ea1bc	ingest-tenant-isolation-1775535604890.xml	677	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/bbc92a79-d346-4ec7-bf53-3536cff57de8/ingest-tenant-isolation-1775535604890.xml	DONE	2	2	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:20:04.895694+00	2026-04-07 04:20:04.918388+00	677	\N	[]	FILE	\N	d8438dea-52f8-4f19-b1ce-ce14c55ea1bc	incremental	f
5126115f-ff90-4907-9d39-3d318fdb9b9f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	461ffb1b-9f2a-4691-8ec1-8dad30780ca7	ingest-tenant-isolation-1775535648628.xml	683	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/907f278e-3731-469f-ba41-7a861588376e/ingest-tenant-isolation-1775535648628.xml	DONE	2	2	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:20:48.72882+00	2026-04-07 04:20:48.799638+00	683	32	[]	FILE	907f278e-3731-469f-ba41-7a861588376e	461ffb1b-9f2a-4691-8ec1-8dad30780ca7	incremental	f
1074848a-c407-4139-b642-ba5c1509aaba	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	\N	delta-1775535354616.ndjson	290	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/1074848a-c407-4139-b642-ba5c1509aaba/delta-1775535354616.ndjson	PARTIAL	3	2	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:54.622209+00	2026-04-07 04:15:54.645622+00	290	\N	[{"raw": "{\\"id\\":\\"delta-bad-json\\",\\"uid\\":\\"CPF-DELTA-2\\"", "line": 2, "reason": "Expecting ',' delimiter: line 1 column 43 (char 42)"}]	FILE	\N	\N	incremental	f
81b205e1-df41-491e-bd1a-34cc4b552f27	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	8c3c6e7f-1219-43ee-a385-18714534908c	ingest-tenant-isolation-1775535798416.xml	683	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/81b205e1-df41-491e-bd1a-34cc4b552f27/ingest-tenant-isolation-1775535798416.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:18.421636+00	2026-04-07 04:23:18.442911+00	683	\N	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "iso-gamma-bad-1", "device_id": "dev-iso-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-ISO-2"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')"}]	FILE	\N	8c3c6e7f-1219-43ee-a385-18714534908c	incremental	f
13257e62-d073-488c-9e44-10b8c5bcdefb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	7c1e754f-5cd9-4d4c-80a1-5c583813f763	delta-1775535564739.ndjson	301	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/13257e62-d073-488c-9e44-10b8c5bcdefb/delta-1775535564739.ndjson	PARTIAL	3	1	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:24.744739+00	2026-04-07 04:19:24.766832+00	301	\N	[{"raw": {"id": "delta-bad-1775535564739", "ts": "2026-03-20T12:05:00Z", "ccy": "BRL", "uid": "CPF-DELTA-3", "val": "not-a-number", "currency": "BRL", "evt_type": "DEPOSIT", "source_system": "ConnectorDelta"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')"}, {"raw": "{\\"id\\":\\"delta-bad-json\\",\\"uid\\":\\"CPF-DELTA-2\\"", "line": 2, "reason": "Expecting ',' delimiter: line 1 column 43 (char 42)"}]	FILE	\N	7c1e754f-5cd9-4d4c-80a1-5c583813f763	incremental	f
94968976-a5b4-471e-88c8-73741dc93994	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	45ab6890-e15a-41e1-9421-9e8bd68214d0	gamma-explicit-1775535565183.xml	261	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/94968976-a5b4-471e-88c8-73741dc93994/gamma-explicit-1775535565183.xml	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:25.193633+00	2026-04-07 04:19:25.260755+00	261	\N	[]	FILE	\N	45ab6890-e15a-41e1-9421-9e8bd68214d0	incremental	f
9369ca19-bd7e-4e07-8059-36b9d8d26fca	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	8c3c6e7f-1219-43ee-a385-18714534908c	fictibet-gamma-1775535802836.xml	1847	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/9369ca19-bd7e-4e07-8059-36b9d8d26fca/fictibet-gamma-1775535802836.xml	DONE	5	5	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:22.841011+00	2026-04-07 04:23:22.865211+00	1847	\N	[]	FILE	\N	8c3c6e7f-1219-43ee-a385-18714534908c	incremental	f
907f278e-3731-469f-ba41-7a861588376e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	461ffb1b-9f2a-4691-8ec1-8dad30780ca7	ingest-tenant-isolation-1775535648628.xml	683	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/907f278e-3731-469f-ba41-7a861588376e/ingest-tenant-isolation-1775535648628.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:20:48.633189+00	2026-04-07 04:20:48.655419+00	683	\N	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "iso-gamma-bad-1", "device_id": "dev-iso-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-ISO-2"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')"}]	FILE	\N	461ffb1b-9f2a-4691-8ec1-8dad30780ca7	incremental	f
0f47f32e-9d95-4b20-a520-cc94d6176c26	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	fictibet-canonical-1775536341733.ndjson	25232	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/0f47f32e-9d95-4b20-a520-cc94d6176c26/fictibet-canonical-1775536341733.ndjson	DONE	51	51	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:32:21.741521+00	2026-04-07 04:32:26.938342+00	27077	51	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
2219e11c-d90f-486b-923e-00c521f65f44	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T043116122163Z.json	2572	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/2219e11c-d90f-486b-923e-00c521f65f44/epsilon-webhook-20260407T043116122163Z.json	DONE	6	6	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:31:16.115345+00	2026-04-07 04:31:16.148558+00	2572	25	[]	WEBHOOK	\N	\N	incremental	f
1968c7a0-ae80-4289-9ba3-0b8dde9ec599	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	7de7afb5-f09e-4995-82ad-fcef870000c0	fictibet-gamma-1775536276017.xml	1847	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/e6e9a8a5-67ad-4dcf-9d83-f54f74e34c70/fictibet-gamma-1775536276017.xml	DONE	5	5	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:31:16.201264+00	2026-04-07 04:31:16.275176+00	1847	27	[]	FILE	e6e9a8a5-67ad-4dcf-9d83-f54f74e34c70	7de7afb5-f09e-4995-82ad-fcef870000c0	incremental	f
3bd932ab-c48b-4d71-a1a4-0d69f419dab5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	7de7afb5-f09e-4995-82ad-fcef870000c0	fictibet-gamma-1775536347876.xml	1847	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/3bd932ab-c48b-4d71-a1a4-0d69f419dab5/fictibet-gamma-1775536347876.xml	PARTIAL	5	3	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:32:27.881191+00	2026-04-07 04:32:27.907622+00	1847	\N	[{"raw": {"amount": "-100.00", "currency": "BRL", "event_id": "GAMMA-ERR-NEG", "device_id": "dev-rtr-03", "occurred_at": "2026-03-21T13:30:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "transaction_type": "DEPOSIT", "external_player_id": "PLY-RTR-003"}, "line": null, "reason": "validation_failed: amount deve ser maior que zero: '-100.00'"}, {"raw": {"amount": "300.00", "currency": "BRL", "event_id": "GAMMA-ERR-DATE", "device_id": "dev-spi-02", "occurred_at": "2026-99-99T99:99:99Z", "source_system": "ConnectorGamma", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "transaction_type": "DEPOSIT", "external_player_id": "PLY-SPI-002"}, "line": null, "reason": "validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'"}]	FILE	\N	7de7afb5-f09e-4995-82ad-fcef870000c0	incremental	f
4a049cbd-9b25-48e8-b989-e7d3a8a0dc9f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	2aabcb5d-b776-4f6c-bed8-d21640ef6907	ingest-tenant-isolation-1775536648184.xml	683	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/f3025397-f841-4e75-abb7-747f53bd7824/ingest-tenant-isolation-1775536648184.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:28.276249+00	2026-04-07 04:37:28.35129+00	683	36	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "iso-gamma-bad-1", "device_id": "dev-iso-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-ISO-2"}, "line": 2, "reason": "validation_failed: empty_required_fields=['amount']; amount inválido: None"}]	FILE	f3025397-f841-4e75-abb7-747f53bd7824	2aabcb5d-b776-4f6c-bed8-d21640ef6907	incremental	f
1130b476-cc4f-4bf3-ac07-ed364e93bb85	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	943f8513-1141-4aae-8a5d-243a661b50b3	gamma-1775535564289.xml	687	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/1130b476-cc4f-4bf3-ac07-ed364e93bb85/gamma-1775535564289.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:24.294502+00	2026-04-07 04:19:24.323054+00	687	\N	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "gamma-bad-1", "device_id": "dev-gamma-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-GAMMA-2"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')"}]	FILE	\N	943f8513-1141-4aae-8a5d-243a661b50b3	incremental	f
25ad2b49-0244-449c-ad1f-83c36113f295	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	8c3c6e7f-1219-43ee-a385-18714534908c	ingest-tenant-isolation-1775535798416.xml	683	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/81b205e1-df41-491e-bd1a-34cc4b552f27/ingest-tenant-isolation-1775535798416.xml	DONE	2	2	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:18.516786+00	2026-04-07 04:23:18.599195+00	683	22	[]	FILE	81b205e1-df41-491e-bd1a-34cc4b552f27	8c3c6e7f-1219-43ee-a385-18714534908c	incremental	f
877a2161-a5b5-4306-ae7f-6e93d7d08844	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	08e6917b-e953-47e1-a6fe-c30cc97b8093	fictibet-delta-1775536347919.ndjson	1859	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/877a2161-a5b5-4306-ae7f-6e93d7d08844/fictibet-delta-1775536347919.ndjson	PARTIAL	8	5	3	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:32:27.925265+00	2026-04-07 04:32:27.945773+00	1859	\N	[{"raw": {"id": "DELTA-ERR-NEG", "ip": "200.155.10.11", "ts": "2026-03-21T14:10:00Z", "ccy": "BRL", "uid": "PLY-NET-005", "val": -50.0, "device": "dev-shared-77", "currency": "BRL", "evt_type": "DEPOSIT", "pay_token": "pix-delta-err-neg", "pay_method": "PIX", "session_id": "sess-delta-err-neg", "source_system": "ConnectorDelta"}, "line": null, "reason": "validation_failed: amount deve ser maior que zero: '-50.0'"}, {"raw": {"id": "DELTA-ERR-NO-TS", "ip": "177.20.20.20", "ccy": "BRL", "uid": "PLY-SPI-002", "val": 300.0, "device": "dev-spi-02", "currency": "BRL", "evt_type": "DEPOSIT", "pay_token": "card-delta-err-no-ts", "pay_method": "CARD", "session_id": "sess-delta-err-no-ts", "source_system": "ConnectorDelta"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'occurred_at' é None após transform 'parseDate' (source='ts', raw='None')"}, {"raw": "{\\"id\\":\\"DELTA-ERR-MALFORMED\\",\\"uid\\":\\"PLY-PEP-006\\",\\"evt_type\\":\\"DEPOSIT\\",\\"ts\\":\\"2026-03-21T14:12:00Z\\",\\"val\\":400.0,\\"ccy\\":\\"BRL\\"", "line": 7, "reason": "Expecting ',' delimiter: line 1 column 121 (char 120)"}]	FILE	\N	08e6917b-e953-47e1-a6fe-c30cc97b8093	incremental	f
09b7fe00-d037-4b61-9130-fb050952c886	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775535590217.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/09b7fe00-d037-4b61-9130-fb050952c886/e2e-ingest-1775535590217.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:50.224179+00	2026-04-07 04:19:50.326382+00	183	16	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
a327ee17-72e4-49fe-bdb3-6c5abc8ec049	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	7de7afb5-f09e-4995-82ad-fcef870000c0	fictibet-gamma-1775536347876.xml	1847	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/3bd932ab-c48b-4d71-a1a4-0d69f419dab5/fictibet-gamma-1775536347876.xml	PARTIAL	5	3	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:32:28.047286+00	2026-04-07 04:32:28.137758+00	1847	53	[{"raw": {"amount": "-100.00", "currency": "BRL", "event_id": "GAMMA-ERR-NEG", "device_id": "dev-rtr-03", "occurred_at": "2026-03-21T13:30:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "transaction_type": "DEPOSIT", "external_player_id": "PLY-RTR-003"}, "line": 4, "reason": "validation_failed: amount deve ser maior que zero: '-100.00'"}, {"raw": {"amount": "300.00", "currency": "BRL", "event_id": "GAMMA-ERR-DATE", "device_id": "dev-spi-02", "occurred_at": "2026-99-99T99:99:99Z", "source_system": "ConnectorGamma", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "transaction_type": "DEPOSIT", "external_player_id": "PLY-SPI-002"}, "line": 5, "reason": "validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'"}]	FILE	3bd932ab-c48b-4d71-a1a4-0d69f419dab5	7de7afb5-f09e-4995-82ad-fcef870000c0	incremental	f
1094740f-728d-42c3-89c1-2a851b72613a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T043227965533Z.json	2572	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/1094740f-728d-42c3-89c1-2a851b72613a/epsilon-webhook-20260407T043227965533Z.json	DONE	6	6	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:32:27.960577+00	2026-04-07 04:32:27.982738+00	2572	16	[]	WEBHOOK	\N	\N	incremental	f
f9a73c34-b121-40cd-a99b-5440f035a566	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775535590217.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/09b7fe00-d037-4b61-9130-fb050952c886/e2e-ingest-1775535590217.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:54.302057+00	2026-04-07 04:19:54.394601+00	183	24	[]	FILE	09b7fe00-d037-4b61-9130-fb050952c886	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
a1cc6745-708a-4c29-9c37-0dd36ea3ef5e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	7c1e754f-5cd9-4d4c-80a1-5c583813f763	delta-rate-limit-1775535597616.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/a1cc6745-708a-4c29-9c37-0dd36ea3ef5e/delta-rate-limit-1775535597616.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:57.620647+00	2026-04-07 04:19:57.63923+00	132	\N	[]	FILE	\N	7c1e754f-5cd9-4d4c-80a1-5c583813f763	incremental	f
f4ac9fba-10ae-4e4e-910d-3d0c9c574116	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	e06ad360-121c-4957-a0f0-1f891bf701e9	delta-1775535600958.ndjson	301	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/f4ac9fba-10ae-4e4e-910d-3d0c9c574116/delta-1775535600958.ndjson	PARTIAL	3	1	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:20:00.965116+00	2026-04-07 04:20:00.988483+00	301	\N	[{"raw": {"id": "delta-bad-1775535600958", "ts": "2026-03-20T12:05:00Z", "ccy": "BRL", "uid": "CPF-DELTA-3", "val": "not-a-number", "currency": "BRL", "evt_type": "DEPOSIT", "source_system": "ConnectorDelta"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')"}, {"raw": "{\\"id\\":\\"delta-bad-json\\",\\"uid\\":\\"CPF-DELTA-2\\"", "line": 2, "reason": "Expecting ',' delimiter: line 1 column 43 (char 42)"}]	FILE	\N	e06ad360-121c-4957-a0f0-1f891bf701e9	incremental	f
0c6c6b70-5f74-4fe7-a21b-0942ad7dc73c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	08e6917b-e953-47e1-a6fe-c30cc97b8093	delta-rate-limit-1775536640994.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/0c6c6b70-5f74-4fe7-a21b-0942ad7dc73c/delta-rate-limit-1775536640994.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:20.998669+00	2026-04-07 04:37:21.01689+00	132	\N	[]	FILE	\N	08e6917b-e953-47e1-a6fe-c30cc97b8093	incremental	f
bd1c1304-214b-4c8f-91e7-4553e2fa2915	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	d8438dea-52f8-4f19-b1ce-ce14c55ea1bc	gamma-explicit-1775535601324.xml	261	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/bd1c1304-214b-4c8f-91e7-4553e2fa2915/gamma-explicit-1775535601324.xml	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:20:01.328623+00	2026-04-07 04:20:01.348287+00	261	\N	[]	FILE	\N	d8438dea-52f8-4f19-b1ce-ce14c55ea1bc	incremental	f
eab1b55b-6e2e-4b6d-b31a-ebd98db9c71f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	fictibet-canonical-1775535801746.ndjson	25232	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/eab1b55b-6e2e-4b6d-b31a-ebd98db9c71f/fictibet-canonical-1775535801746.ndjson	DONE	51	51	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:21.756459+00	2026-04-07 04:23:21.872295+00	27077	49	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
f9e919ff-b9e4-4a26-93c7-91b36f8c97c1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T043709825565Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/f9e919ff-b9e4-4a26-93c7-91b36f8c97c1/epsilon-webhook-20260407T043709825565Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:09.818028+00	2026-04-07 04:37:09.839551+00	179	13	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775536629813\\",\\"external_player_id\\":\\"CPF-1775536629813\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
425e6629-f875-4f57-a61f-55355f7f9423	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775536633592.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/425e6629-f875-4f57-a61f-55355f7f9423/e2e-ingest-1775536633592.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:13.596817+00	2026-04-07 04:37:13.685239+00	183	17	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
24070daa-4247-489b-98e1-0b1c9e18eb57	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	08e6917b-e953-47e1-a6fe-c30cc97b8093	delta-rate-limit-1775536641084.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/24070daa-4247-489b-98e1-0b1c9e18eb57/delta-rate-limit-1775536641084.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:21.088793+00	2026-04-07 04:37:21.109489+00	132	\N	[]	FILE	\N	08e6917b-e953-47e1-a6fe-c30cc97b8093	incremental	f
44e584b7-98ac-42aa-af16-dea143ffa361	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	0f9a3081-659b-4260-b778-94204e484544	gamma-1775536644072.xml	687	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/44e584b7-98ac-42aa-af16-dea143ffa361/gamma-1775536644072.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:24.078597+00	2026-04-07 04:37:24.0977+00	687	\N	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "gamma-bad-1", "device_id": "dev-gamma-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-GAMMA-2"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')"}]	FILE	\N	0f9a3081-659b-4260-b778-94204e484544	incremental	f
90cc08da-1ef8-4626-86a1-c3e94abe0e99	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	b4739b52-e3d1-4d0a-b9bf-a91df33c5704	delta-1775536644469.ndjson	301	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/90cc08da-1ef8-4626-86a1-c3e94abe0e99/delta-1775536644469.ndjson	PARTIAL	3	1	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:24.473681+00	2026-04-07 04:37:24.496238+00	301	\N	[{"raw": {"id": "delta-bad-1775536644469", "ts": "2026-03-20T12:05:00Z", "ccy": "BRL", "uid": "CPF-DELTA-3", "val": "not-a-number", "currency": "BRL", "evt_type": "DEPOSIT", "source_system": "ConnectorDelta"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')"}, {"raw": "{\\"id\\":\\"delta-bad-json\\",\\"uid\\":\\"CPF-DELTA-2\\"", "line": 2, "reason": "Expecting ',' delimiter: line 1 column 43 (char 42)"}]	FILE	\N	b4739b52-e3d1-4d0a-b9bf-a91df33c5704	incremental	f
4ecf620d-ea4e-441d-b205-3867abfcc069	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	fictibet-canonical-1775536651296.ndjson	25232	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/4ecf620d-ea4e-441d-b205-3867abfcc069/fictibet-canonical-1775536651296.ndjson	DONE	51	51	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:31.303268+00	2026-04-07 04:37:31.398195+00	27077	44	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
667f060a-7b8e-4800-beb4-9ba0f6240c0b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	2aabcb5d-b776-4f6c-bed8-d21640ef6907	fictibet-gamma-1775536652356.xml	1847	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/667f060a-7b8e-4800-beb4-9ba0f6240c0b/fictibet-gamma-1775536652356.xml	PARTIAL	5	3	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:32.361222+00	2026-04-07 04:37:32.471727+00	1847	\N	[{"raw": {"amount": "-100.00", "currency": "BRL", "event_id": "GAMMA-ERR-NEG", "device_id": "dev-rtr-03", "occurred_at": "2026-03-21T13:30:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "transaction_type": "DEPOSIT", "external_player_id": "PLY-RTR-003"}, "line": null, "reason": "validation_failed: amount deve ser maior que zero: '-100.00'"}, {"raw": {"amount": "300.00", "currency": "BRL", "event_id": "GAMMA-ERR-DATE", "device_id": "dev-spi-02", "occurred_at": "2026-99-99T99:99:99Z", "source_system": "ConnectorGamma", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "transaction_type": "DEPOSIT", "external_player_id": "PLY-SPI-002"}, "line": null, "reason": "validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'"}]	FILE	\N	2aabcb5d-b776-4f6c-bed8-d21640ef6907	incremental	f
39c38617-5e13-4fe1-b5ac-334db866aab4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T043732553656Z.json	2572	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/39c38617-5e13-4fe1-b5ac-334db866aab4/epsilon-webhook-20260407T043732553656Z.json	DONE	6	6	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:32.546644+00	2026-04-07 04:37:32.577621+00	2572	23	[]	WEBHOOK	\N	\N	incremental	f
27c6afdb-de0a-4d37-8296-1c81a0b8893b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T044920587185Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/27c6afdb-de0a-4d37-8296-1c81a0b8893b/epsilon-webhook-20260407T044920587185Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:20.579222+00	2026-04-07 04:49:20.608277+00	179	20	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775537360575\\",\\"external_player_id\\":\\"CPF-1775537360575\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
98229380-6056-49dc-93b0-41cd580df9ca	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	b4739b52-e3d1-4d0a-b9bf-a91df33c5704	delta-rate-limit-1775537371114.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/98229380-6056-49dc-93b0-41cd580df9ca/delta-rate-limit-1775537371114.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:31.118757+00	2026-04-07 04:49:31.148363+00	132	\N	[]	FILE	\N	b4739b52-e3d1-4d0a-b9bf-a91df33c5704	incremental	f
b38f5fc3-1b8d-4145-8faa-302c23b183d8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	341ea838-8b1c-43de-93a3-6b7b2518efd6	gamma-1775537374156.xml	687	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/b38f5fc3-1b8d-4145-8faa-302c23b183d8/gamma-1775537374156.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:34.160935+00	2026-04-07 04:49:34.18063+00	687	\N	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "gamma-bad-1", "device_id": "dev-gamma-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-GAMMA-2"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')"}]	FILE	\N	341ea838-8b1c-43de-93a3-6b7b2518efd6	incremental	f
bb02d470-fd0d-4df9-9c0d-49422ae9f2cc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	f3d0cbec-d091-4935-b6c3-1d0cf4482ebc	delta-1775537374579.ndjson	301	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/bb02d470-fd0d-4df9-9c0d-49422ae9f2cc/delta-1775537374579.ndjson	PARTIAL	3	1	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:34.584717+00	2026-04-07 04:49:34.608239+00	301	\N	[{"raw": {"id": "delta-bad-1775537374579", "ts": "2026-03-20T12:05:00Z", "ccy": "BRL", "uid": "CPF-DELTA-3", "val": "not-a-number", "currency": "BRL", "evt_type": "DEPOSIT", "source_system": "ConnectorDelta"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')"}, {"raw": "{\\"id\\":\\"delta-bad-json\\",\\"uid\\":\\"CPF-DELTA-2\\"", "line": 2, "reason": "Expecting ',' delimiter: line 1 column 43 (char 42)"}]	FILE	\N	f3d0cbec-d091-4935-b6c3-1d0cf4482ebc	incremental	f
8fe20184-b38b-41a2-98ab-8edf85e27262	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	615f7ab8-3f2d-4d71-8b99-82b7c9cdd197	ingest-tenant-isolation-1775537378419.xml	683	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/632551de-470b-4f59-b6c8-bd8e6b27c5b2/ingest-tenant-isolation-1775537378419.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:38.523962+00	2026-04-07 04:49:38.60113+00	683	37	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "iso-gamma-bad-1", "device_id": "dev-iso-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-ISO-2"}, "line": 2, "reason": "validation_failed: empty_required_fields=['amount']; amount inválido: None"}]	FILE	632551de-470b-4f59-b6c8-bd8e6b27c5b2	615f7ab8-3f2d-4d71-8b99-82b7c9cdd197	incremental	f
ede2d78d-486b-49e7-bcb6-43b5508b5e0e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	b4739b52-e3d1-4d0a-b9bf-a91df33c5704	fictibet-delta-1775536652489.ndjson	1859	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/ede2d78d-486b-49e7-bcb6-43b5508b5e0e/fictibet-delta-1775536652489.ndjson	PARTIAL	8	5	3	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:32.496021+00	2026-04-07 04:37:32.525821+00	1859	\N	[{"raw": {"id": "DELTA-ERR-NEG", "ip": "200.155.10.11", "ts": "2026-03-21T14:10:00Z", "ccy": "BRL", "uid": "PLY-NET-005", "val": -50.0, "device": "dev-shared-77", "currency": "BRL", "evt_type": "DEPOSIT", "pay_token": "pix-delta-err-neg", "pay_method": "PIX", "session_id": "sess-delta-err-neg", "source_system": "ConnectorDelta"}, "line": null, "reason": "validation_failed: amount deve ser maior que zero: '-50.0'"}, {"raw": {"id": "DELTA-ERR-NO-TS", "ip": "177.20.20.20", "ccy": "BRL", "uid": "PLY-SPI-002", "val": 300.0, "device": "dev-spi-02", "currency": "BRL", "evt_type": "DEPOSIT", "pay_token": "card-delta-err-no-ts", "pay_method": "CARD", "session_id": "sess-delta-err-no-ts", "source_system": "ConnectorDelta"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'occurred_at' é None após transform 'parseDate' (source='ts', raw='None')"}, {"raw": "{\\"id\\":\\"DELTA-ERR-MALFORMED\\",\\"uid\\":\\"PLY-PEP-006\\",\\"evt_type\\":\\"DEPOSIT\\",\\"ts\\":\\"2026-03-21T14:12:00Z\\",\\"val\\":400.0,\\"ccy\\":\\"BRL\\"", "line": 7, "reason": "Expecting ',' delimiter: line 1 column 121 (char 120)"}]	FILE	\N	b4739b52-e3d1-4d0a-b9bf-a91df33c5704	incremental	f
b0613c8d-3ba7-4611-8bde-ac757394b6d8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775537363841.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/b0613c8d-3ba7-4611-8bde-ac757394b6d8/e2e-ingest-1775537363841.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:23.846069+00	2026-04-07 04:49:23.914712+00	183	15	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
f3e0eb5b-35b8-44fc-8082-a6270d8f40d3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	b4739b52-e3d1-4d0a-b9bf-a91df33c5704	delta-rate-limit-1775537371218.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/f3e0eb5b-35b8-44fc-8082-a6270d8f40d3/delta-rate-limit-1775537371218.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:31.222348+00	2026-04-07 04:49:31.24018+00	132	\N	[]	FILE	\N	b4739b52-e3d1-4d0a-b9bf-a91df33c5704	incremental	f
44d74062-24d2-490f-9f81-e228a035ebda	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	fictibet-canonical-1775537381549.ndjson	25232	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/44d74062-24d2-490f-9f81-e228a035ebda/fictibet-canonical-1775537381549.ndjson	DONE	51	51	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:41.55584+00	2026-04-07 04:49:41.670223+00	27077	43	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
ce188537-4f85-408b-835d-4d537518b883	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	615f7ab8-3f2d-4d71-8b99-82b7c9cdd197	fictibet-gamma-1775537382630.xml	1847	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/ce188537-4f85-408b-835d-4d537518b883/fictibet-gamma-1775537382630.xml	PARTIAL	5	3	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:42.63512+00	2026-04-07 04:49:42.656775+00	1847	\N	[{"raw": {"amount": "-100.00", "currency": "BRL", "event_id": "GAMMA-ERR-NEG", "device_id": "dev-rtr-03", "occurred_at": "2026-03-21T13:30:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "transaction_type": "DEPOSIT", "external_player_id": "PLY-RTR-003"}, "line": null, "reason": "validation_failed: amount deve ser maior que zero: '-100.00'"}, {"raw": {"amount": "300.00", "currency": "BRL", "event_id": "GAMMA-ERR-DATE", "device_id": "dev-spi-02", "occurred_at": "2026-99-99T99:99:99Z", "source_system": "ConnectorGamma", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "transaction_type": "DEPOSIT", "external_player_id": "PLY-SPI-002"}, "line": null, "reason": "validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'"}]	FILE	\N	615f7ab8-3f2d-4d71-8b99-82b7c9cdd197	incremental	f
22c78182-ea62-4550-b4c4-fdc7864b4b92	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T044942725230Z.json	2572	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/22c78182-ea62-4550-b4c4-fdc7864b4b92/epsilon-webhook-20260407T044942725230Z.json	DONE	6	6	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:42.718206+00	2026-04-07 04:49:42.743219+00	2572	17	[]	WEBHOOK	\N	\N	incremental	f
f60df468-d787-4980-b3ea-b022a705e77a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	2aabcb5d-b776-4f6c-bed8-d21640ef6907	fictibet-gamma-1775536652356.xml	1847	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/667f060a-7b8e-4800-beb4-9ba0f6240c0b/fictibet-gamma-1775536652356.xml	PARTIAL	5	3	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:32.618276+00	2026-04-07 04:37:32.705203+00	1847	52	[{"raw": {"amount": "-100.00", "currency": "BRL", "event_id": "GAMMA-ERR-NEG", "device_id": "dev-rtr-03", "occurred_at": "2026-03-21T13:30:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "transaction_type": "DEPOSIT", "external_player_id": "PLY-RTR-003"}, "line": 4, "reason": "validation_failed: amount deve ser maior que zero: '-100.00'"}, {"raw": {"amount": "300.00", "currency": "BRL", "event_id": "GAMMA-ERR-DATE", "device_id": "dev-spi-02", "occurred_at": "2026-99-99T99:99:99Z", "source_system": "ConnectorGamma", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "transaction_type": "DEPOSIT", "external_player_id": "PLY-SPI-002"}, "line": 5, "reason": "validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'"}]	FILE	667f060a-7b8e-4800-beb4-9ba0f6240c0b	2aabcb5d-b776-4f6c-bed8-d21640ef6907	incremental	f
e68b14b6-006f-4b5c-bed3-3ebca33d38a8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775537363841.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/b0613c8d-3ba7-4611-8bde-ac757394b6d8/e2e-ingest-1775537363841.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:27.955713+00	2026-04-07 04:49:28.032228+00	183	23	[]	FILE	b0613c8d-3ba7-4611-8bde-ac757394b6d8	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
d41ad5fd-00f3-4e24-ba31-e6d99baa476c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	e0e75f69-80d9-4337-8b92-0b550df47c66	gamma-explicit-1775537375048.xml	261	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/d41ad5fd-00f3-4e24-ba31-e6d99baa476c/gamma-explicit-1775537375048.xml	FAILED	1	0	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:35.054853+00	2026-04-07 04:49:35.075946+00	261	\N	[{"raw": {"id": "gamma-map-1", "type": "DEPOSIT", "amount": "321.00", "currency": "BRL", "player_id": "CPF-GAMMA-MAP-1", "timestamp": "2026-03-20T10:00:00Z", "source_system": "ConnectorGamma"}, "line": null, "reason": "validation_failed: empty_required_fields=['external_transaction_id', 'occurred_at', 'player_cpf', 'type']"}]	FILE	\N	e0e75f69-80d9-4337-8b92-0b550df47c66	incremental	f
632551de-470b-4f59-b6c8-bd8e6b27c5b2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	615f7ab8-3f2d-4d71-8b99-82b7c9cdd197	ingest-tenant-isolation-1775537378419.xml	683	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/632551de-470b-4f59-b6c8-bd8e6b27c5b2/ingest-tenant-isolation-1775537378419.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:38.423709+00	2026-04-07 04:49:38.445977+00	683	\N	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "iso-gamma-bad-1", "device_id": "dev-iso-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-ISO-2"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')"}]	FILE	\N	615f7ab8-3f2d-4d71-8b99-82b7c9cdd197	incremental	f
4392ead8-c8ab-459f-b9f2-afff06e7a8bd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	f3d0cbec-d091-4935-b6c3-1d0cf4482ebc	fictibet-delta-1775537382668.ndjson	1859	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/4392ead8-c8ab-459f-b9f2-afff06e7a8bd/fictibet-delta-1775537382668.ndjson	PARTIAL	8	5	3	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:42.673907+00	2026-04-07 04:49:42.696354+00	1859	\N	[{"raw": {"id": "DELTA-ERR-NEG", "ip": "200.155.10.11", "ts": "2026-03-21T14:10:00Z", "ccy": "BRL", "uid": "PLY-NET-005", "val": -50.0, "device": "dev-shared-77", "currency": "BRL", "evt_type": "DEPOSIT", "pay_token": "pix-delta-err-neg", "pay_method": "PIX", "session_id": "sess-delta-err-neg", "source_system": "ConnectorDelta"}, "line": null, "reason": "validation_failed: amount deve ser maior que zero: '-50.0'"}, {"raw": {"id": "DELTA-ERR-NO-TS", "ip": "177.20.20.20", "ccy": "BRL", "uid": "PLY-SPI-002", "val": 300.0, "device": "dev-spi-02", "currency": "BRL", "evt_type": "DEPOSIT", "pay_token": "card-delta-err-no-ts", "pay_method": "CARD", "session_id": "sess-delta-err-no-ts", "source_system": "ConnectorDelta"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'occurred_at' é None após transform 'parseDate' (source='ts', raw='None')"}, {"raw": "{\\"id\\":\\"DELTA-ERR-MALFORMED\\",\\"uid\\":\\"PLY-PEP-006\\",\\"evt_type\\":\\"DEPOSIT\\",\\"ts\\":\\"2026-03-21T14:12:00Z\\",\\"val\\":400.0,\\"ccy\\":\\"BRL\\"", "line": 7, "reason": "Expecting ',' delimiter: line 1 column 121 (char 120)"}]	FILE	\N	f3d0cbec-d091-4935-b6c3-1d0cf4482ebc	incremental	f
47385ab9-d4e3-4f38-abb4-8814c99f32a4	23f4e6fb-ac62-49d9-94d0-078f0aa8924d	ConnectorDelta	\N	onboarding-1775538617510.csv	110	bronze/23f4e6fb-ac62-49d9-94d0-078f0aa8924d/ingest_jobs/47385ab9-d4e3-4f38-abb4-8814c99f32a4/onboarding-1775538617510.csv	FAILED	2	0	2	\N	8cfc988d-8513-443c-8d90-da05dd2fac23	2026-04-07 05:10:20.941581+00	2026-04-07 05:10:21.059454+00	110	60	[{"raw": "player_id,amount,currency,transaction_type,occurred_at", "line": 1, "reason": "Expecting value: line 1 column 1 (char 0)"}, {"raw": "PLY-1775538617510,1250,BRL,DEPOSIT,2026-03-20T10:00:00Z", "line": 2, "reason": "Expecting value: line 1 column 1 (char 0)"}]	FILE	\N	\N	incremental	f
f04d3b6a-08ba-4fc3-ba4d-5a4f2dba409b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T051051369609Z.json	179	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/f04d3b6a-08ba-4fc3-ba4d-5a4f2dba409b/epsilon-webhook-20260407T051051369609Z.json	FAILED	0	0	1	webhook_validation_failed	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:10:51.347659+00	2026-04-07 05:10:51.407986+00	179	38	[{"raw": "{\\"event_id\\":\\"e2e-epsilon-error-1775538651343\\",\\"external_player_id\\":\\"CPF-1775538651343\\",\\"transaction_type\\":\\"DEPOSIT\\",\\"amount\\":\\"invalid-number\\",\\"occurred_at\\":\\"2026-03-20T12:00:00Z\\"}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
1b768d77-12b5-4d74-9ef1-3539824e7e8c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775538654523.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/1b768d77-12b5-4d74-9ef1-3539824e7e8c/e2e-ingest-1775538654523.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:10:54.527886+00	2026-04-07 05:10:54.611524+00	183	19	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
47b13f75-b83f-47a5-8d53-6e95e98e777c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	e2e-ingest-1775538654523.csv	140	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/1b768d77-12b5-4d74-9ef1-3539824e7e8c/e2e-ingest-1775538654523.csv	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:10:58.797317+00	2026-04-07 05:10:58.867228+00	183	21	[]	FILE	1b768d77-12b5-4d74-9ef1-3539824e7e8c	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
0c1cd880-3b01-47c2-9bcd-be7d10263b28	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	615f7ab8-3f2d-4d71-8b99-82b7c9cdd197	fictibet-gamma-1775537382630.xml	1847	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/ce188537-4f85-408b-835d-4d537518b883/fictibet-gamma-1775537382630.xml	PARTIAL	5	3	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:42.781752+00	2026-04-07 04:49:42.86555+00	1847	48	[{"raw": {"amount": "-100.00", "currency": "BRL", "event_id": "GAMMA-ERR-NEG", "device_id": "dev-rtr-03", "occurred_at": "2026-03-21T13:30:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "transaction_type": "DEPOSIT", "external_player_id": "PLY-RTR-003"}, "line": 4, "reason": "validation_failed: amount deve ser maior que zero: '-100.00'"}, {"raw": {"amount": "300.00", "currency": "BRL", "event_id": "GAMMA-ERR-DATE", "device_id": "dev-spi-02", "occurred_at": "2026-99-99T99:99:99Z", "source_system": "ConnectorGamma", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "transaction_type": "DEPOSIT", "external_player_id": "PLY-SPI-002"}, "line": 5, "reason": "validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'"}]	FILE	ce188537-4f85-408b-835d-4d537518b883	615f7ab8-3f2d-4d71-8b99-82b7c9cdd197	incremental	f
1a76f0c5-c357-446a-b9b8-71b8afb7e093	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	f3d0cbec-d091-4935-b6c3-1d0cf4482ebc	delta-rate-limit-1775538661983.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/1a76f0c5-c357-446a-b9b8-71b8afb7e093/delta-rate-limit-1775538661983.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:01.989824+00	2026-04-07 05:11:02.02176+00	132	\N	[]	FILE	\N	f3d0cbec-d091-4935-b6c3-1d0cf4482ebc	incremental	f
62bb073f-8d88-4565-94a4-e7cf13b63460	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	f3d0cbec-d091-4935-b6c3-1d0cf4482ebc	delta-rate-limit-1775538662099.ndjson	132	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/62bb073f-8d88-4565-94a4-e7cf13b63460/delta-rate-limit-1775538662099.ndjson	DONE	1	1	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:02.103613+00	2026-04-07 05:11:02.125722+00	132	\N	[]	FILE	\N	f3d0cbec-d091-4935-b6c3-1d0cf4482ebc	incremental	f
69d80e3e-0546-456a-b409-d9377e14dd37	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	af9d1e95-e27c-403e-bf65-133a96ab851e	gamma-1775538665018.xml	687	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/69d80e3e-0546-456a-b409-d9377e14dd37/gamma-1775538665018.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:05.023737+00	2026-04-07 05:11:05.042077+00	687	\N	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "gamma-bad-1", "device_id": "dev-gamma-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-GAMMA-2"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')"}]	FILE	\N	af9d1e95-e27c-403e-bf65-133a96ab851e	incremental	f
53944e7a-100f-4ef8-b446-1bf87eb50c9c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	e2c8dd08-d54b-412e-99a0-b284a1c1c934	delta-1775538665429.ndjson	301	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/53944e7a-100f-4ef8-b446-1bf87eb50c9c/delta-1775538665429.ndjson	PARTIAL	3	1	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:05.433482+00	2026-04-07 05:11:05.452188+00	301	\N	[{"raw": {"id": "delta-bad-1775538665429", "ts": "2026-03-20T12:05:00Z", "ccy": "BRL", "uid": "CPF-DELTA-3", "val": "not-a-number", "currency": "BRL", "evt_type": "DEPOSIT", "source_system": "ConnectorDelta"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='val', raw='not-a-number')"}, {"raw": "{\\"id\\":\\"delta-bad-json\\",\\"uid\\":\\"CPF-DELTA-2\\"", "line": 2, "reason": "Expecting ',' delimiter: line 1 column 43 (char 42)"}]	FILE	\N	e2c8dd08-d54b-412e-99a0-b284a1c1c934	incremental	f
be8da54c-f011-4259-b036-61b2407ffbf0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	057d6bef-dddd-405d-93e4-215b97dd9648	gamma-explicit-1775538665853.xml	261	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/be8da54c-f011-4259-b036-61b2407ffbf0/gamma-explicit-1775538665853.xml	FAILED	1	0	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:05.861671+00	2026-04-07 05:11:05.896265+00	261	\N	[{"raw": {"id": "gamma-map-1", "type": "DEPOSIT", "amount": "321.00", "currency": "BRL", "player_id": "CPF-GAMMA-MAP-1", "timestamp": "2026-03-20T10:00:00Z", "source_system": "ConnectorGamma"}, "line": null, "reason": "validation_failed: empty_required_fields=['external_transaction_id', 'occurred_at', 'player_cpf', 'type']"}]	FILE	\N	057d6bef-dddd-405d-93e4-215b97dd9648	incremental	f
2734c5f5-1202-4ced-9377-67a8ab54f6b8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	abe29951-4a34-40f4-985e-484a876ebc39	ingest-tenant-isolation-1775538669288.xml	683	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/2734c5f5-1202-4ced-9377-67a8ab54f6b8/ingest-tenant-isolation-1775538669288.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:09.292872+00	2026-04-07 05:11:09.354232+00	683	\N	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "iso-gamma-bad-1", "device_id": "dev-iso-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-ISO-2"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'amount' é None após transform 'coerceDecimal' (source='amount', raw='not-a-number')"}]	FILE	\N	abe29951-4a34-40f4-985e-484a876ebc39	incremental	f
bff67acd-99a6-4b60-b6e6-44b0b293a1da	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	abe29951-4a34-40f4-985e-484a876ebc39	ingest-tenant-isolation-1775538669288.xml	683	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/2734c5f5-1202-4ced-9377-67a8ab54f6b8/ingest-tenant-isolation-1775538669288.xml	PARTIAL	2	1	1	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:09.427501+00	2026-04-07 05:11:09.524544+00	683	49	[{"raw": {"amount": "not-a-number", "currency": "BRL", "event_id": "iso-gamma-bad-1", "device_id": "dev-iso-2", "occurred_at": "2026-03-20T10:05:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-iso-bad", "transaction_type": "DEPOSIT", "external_player_id": "CPF-ISO-2"}, "line": 2, "reason": "validation_failed: empty_required_fields=['amount']; amount inválido: None"}]	FILE	2734c5f5-1202-4ced-9377-67a8ab54f6b8	abe29951-4a34-40f4-985e-484a876ebc39	incremental	f
b7b86ccc-0db7-4dfe-b1ce-12ac40c392ea	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha	ebca723e-fe67-4940-a879-d1caad211d2d	fictibet-canonical-1775538672449.ndjson	25232	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/b7b86ccc-0db7-4dfe-b1ce-12ac40c392ea/fictibet-canonical-1775538672449.ndjson	DONE	51	51	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:12.45802+00	2026-04-07 05:11:12.562213+00	27077	50	[]	FILE	\N	ebca723e-fe67-4940-a879-d1caad211d2d	incremental	f
8daa394b-665b-4c99-a20c-09fe1d27087c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	abe29951-4a34-40f4-985e-484a876ebc39	fictibet-gamma-1775538673515.xml	1847	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/8daa394b-665b-4c99-a20c-09fe1d27087c/fictibet-gamma-1775538673515.xml	PARTIAL	5	3	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:13.520098+00	2026-04-07 05:11:13.543365+00	1847	\N	[{"raw": {"amount": "-100.00", "currency": "BRL", "event_id": "GAMMA-ERR-NEG", "device_id": "dev-rtr-03", "occurred_at": "2026-03-21T13:30:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "transaction_type": "DEPOSIT", "external_player_id": "PLY-RTR-003"}, "line": null, "reason": "validation_failed: amount deve ser maior que zero: '-100.00'"}, {"raw": {"amount": "300.00", "currency": "BRL", "event_id": "GAMMA-ERR-DATE", "device_id": "dev-spi-02", "occurred_at": "2026-99-99T99:99:99Z", "source_system": "ConnectorGamma", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "transaction_type": "DEPOSIT", "external_player_id": "PLY-SPI-002"}, "line": null, "reason": "validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'"}]	FILE	\N	abe29951-4a34-40f4-985e-484a876ebc39	incremental	f
36536330-55e8-4e41-a3b0-ec3d2606c8aa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorDelta	e2c8dd08-d54b-412e-99a0-b284a1c1c934	fictibet-delta-1775538673554.ndjson	1859	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/36536330-55e8-4e41-a3b0-ec3d2606c8aa/fictibet-delta-1775538673554.ndjson	PARTIAL	8	5	3	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:13.559743+00	2026-04-07 05:11:13.583686+00	1859	\N	[{"raw": {"id": "DELTA-ERR-NEG", "ip": "200.155.10.11", "ts": "2026-03-21T14:10:00Z", "ccy": "BRL", "uid": "PLY-NET-005", "val": -50.0, "device": "dev-shared-77", "currency": "BRL", "evt_type": "DEPOSIT", "pay_token": "pix-delta-err-neg", "pay_method": "PIX", "session_id": "sess-delta-err-neg", "source_system": "ConnectorDelta"}, "line": null, "reason": "validation_failed: amount deve ser maior que zero: '-50.0'"}, {"raw": {"id": "DELTA-ERR-NO-TS", "ip": "177.20.20.20", "ccy": "BRL", "uid": "PLY-SPI-002", "val": 300.0, "device": "dev-spi-02", "currency": "BRL", "evt_type": "DEPOSIT", "pay_token": "card-delta-err-no-ts", "pay_method": "CARD", "session_id": "sess-delta-err-no-ts", "source_system": "ConnectorDelta"}, "line": null, "reason": "mapping_failed: Campo obrigatório 'occurred_at' é None após transform 'parseDate' (source='ts', raw='None')"}, {"raw": "{\\"id\\":\\"DELTA-ERR-MALFORMED\\",\\"uid\\":\\"PLY-PEP-006\\",\\"evt_type\\":\\"DEPOSIT\\",\\"ts\\":\\"2026-03-21T14:12:00Z\\",\\"val\\":400.0,\\"ccy\\":\\"BRL\\"", "line": 7, "reason": "Expecting ',' delimiter: line 1 column 121 (char 120)"}]	FILE	\N	e2c8dd08-d54b-412e-99a0-b284a1c1c934	incremental	f
7b4f5c41-7691-4254-b8c5-0e9accc11ccb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorEpsilon	\N	epsilon-webhook-20260407T051113604593Z.json	2572	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/7b4f5c41-7691-4254-b8c5-0e9accc11ccb/epsilon-webhook-20260407T051113604593Z.json	DONE	6	6	0	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:13.599739+00	2026-04-07 05:11:13.625701+00	2572	20	[]	WEBHOOK	\N	\N	incremental	f
20db7cb9-e140-410c-9f6c-5179bbef8d0c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ConnectorGamma	abe29951-4a34-40f4-985e-484a876ebc39	fictibet-gamma-1775538673515.xml	1847	bronze/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ingest_jobs/8daa394b-665b-4c99-a20c-09fe1d27087c/fictibet-gamma-1775538673515.xml	PARTIAL	5	3	2	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:13.663729+00	2026-04-07 05:11:13.747962+00	1847	47	[{"raw": {"amount": "-100.00", "currency": "BRL", "event_id": "GAMMA-ERR-NEG", "device_id": "dev-rtr-03", "occurred_at": "2026-03-21T13:30:00Z", "source_system": "ConnectorGamma", "instrument_type": "PIX", "instrument_token": "pix-gamma-err-neg", "transaction_type": "DEPOSIT", "external_player_id": "PLY-RTR-003"}, "line": 4, "reason": "validation_failed: amount deve ser maior que zero: '-100.00'"}, {"raw": {"amount": "300.00", "currency": "BRL", "event_id": "GAMMA-ERR-DATE", "device_id": "dev-spi-02", "occurred_at": "2026-99-99T99:99:99Z", "source_system": "ConnectorGamma", "instrument_type": "CARD", "instrument_token": "card-gamma-err-date", "transaction_type": "DEPOSIT", "external_player_id": "PLY-SPI-002"}, "line": 5, "reason": "validation_failed: occurred_at inválido: '2026-99-99T99:99:99Z'"}]	FILE	8daa394b-665b-4c99-a20c-09fe1d27087c	abe29951-4a34-40f4-985e-484a876ebc39	incremental	f
75dd17b2-8856-4c59-9aec-4a1750d71d54	d3108642-40e7-4da1-aa68-4a17aac45b10	ConnectorDelta	\N	onboarding-1775538688614.csv	110	bronze/d3108642-40e7-4da1-aa68-4a17aac45b10/ingest_jobs/75dd17b2-8856-4c59-9aec-4a1750d71d54/onboarding-1775538688614.csv	FAILED	2	0	2	\N	8cfc988d-8513-443c-8d90-da05dd2fac23	2026-04-07 05:11:31.726758+00	2026-04-07 05:11:31.863558+00	110	76	[{"raw": "player_id,amount,currency,transaction_type,occurred_at", "line": 1, "reason": "Expecting value: line 1 column 1 (char 0)"}, {"raw": "PLY-1775538688614,1250,BRL,DEPOSIT,2026-03-20T10:00:00Z", "line": 2, "reason": "Expecting value: line 1 column 1 (char 0)"}]	FILE	\N	\N	incremental	f
\.


--
-- Data for Name: mapping_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.mapping_configs (id, tenant_id, name, source_system, entity_type, version, config_json, active, created_by, created_at, updated_at, parent_id, is_current, version_number, change_notes) FROM stdin;
ebca723e-fe67-4940-a879-d1caad211d2d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeAlpha Transaction Mapping	BackofficeAlpha	TRANSACTION	1.0	{"fields": [{"source": "transactionId", "target": "transaction_id", "transform": "copy"}, {"source": "playerId", "target": "player_id", "transform": "copy"}, {"source": "type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "transform": "copy"}, {"source": "paymentMethod", "target": "method", "transform": "copy"}, {"source": "status", "target": "status", "transform": "copy"}, {"source": "transactionDate", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "BackofficeAlpha"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	t	1	\N
7eb6a7c1-ea0d-445f-9203-536fab636c65	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	BackofficeBeta Transaction Mapping	BackofficeBeta	TRANSACTION	1.0	{"fields": [{"source": "txn_id", "target": "transaction_id", "transform": "copy"}, {"source": "user_id", "target": "player_id", "transform": "copy"}, {"source": "txn_type", "target": "type", "transform": "copy"}, {"source": "value", "target": "amount", "transform": "coerceDecimal"}, {"source": "ccy", "target": "currency", "transform": "copy"}, {"source": "method", "target": "method", "transform": "copy"}, {"source": "txn_status", "target": "status", "transform": "copy"}, {"source": "occurred_utc", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "BackofficeBeta"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	t	1	\N
88aadedb-dc4d-44c4-9843-857a3a50e2a8	40e341ad-cf4a-484b-9926-3d56cc58fa1f	BackofficeAlpha Transaction Mapping	BackofficeAlpha	TRANSACTION	1.0	{"fields": [{"source": "transactionId", "target": "transaction_id", "transform": "copy"}, {"source": "playerId", "target": "player_id", "transform": "copy"}, {"source": "type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "transform": "copy"}, {"source": "paymentMethod", "target": "method", "transform": "copy"}, {"source": "status", "target": "status", "transform": "copy"}, {"source": "transactionDate", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "BackofficeAlpha"}	t	e653024a-8bee-46b0-ae12-63177bb0dc61	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	t	1	\N
7e786bb6-fb6d-4904-bc12-7803299f141a	40e341ad-cf4a-484b-9926-3d56cc58fa1f	BackofficeBeta Transaction Mapping	BackofficeBeta	TRANSACTION	1.0	{"fields": [{"source": "txn_id", "target": "transaction_id", "transform": "copy"}, {"source": "user_id", "target": "player_id", "transform": "copy"}, {"source": "txn_type", "target": "type", "transform": "copy"}, {"source": "value", "target": "amount", "transform": "coerceDecimal"}, {"source": "ccy", "target": "currency", "transform": "copy"}, {"source": "method", "target": "method", "transform": "copy"}, {"source": "txn_status", "target": "status", "transform": "copy"}, {"source": "occurred_utc", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "BackofficeBeta"}	t	e653024a-8bee-46b0-ae12-63177bb0dc61	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	t	1	\N
2b6af9cb-8055-44b6-a447-51bc83acda07	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Saved Test 1775531995712	ConnectorGammaSavedTest-1775531995712	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:19:55.746833+00	2026-04-07 03:19:55.746833+00	\N	t	1	Criação via helper E2E
01f0dd80-1579-49a2-9bcf-b026e27c2fa6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Saved Test 1775532300122	ConnectorGammaSavedTest-1775532300122	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:25:00.146498+00	2026-04-07 03:25:00.146498+00	\N	t	1	Criação via helper E2E
99919d33-db29-4ca9-b102-1be5eebcbe36	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma explicit 1775536644859	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "transform": "copy"}, {"source": "transaction_type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:24.864774+00	2026-04-07 05:11:09.27718+00	\N	f	23	Explicit gamma mapping for e2e
758edf5e-25df-4564-88d4-581cc32df0dd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536362248	ConnectorGammaE2E-1775536362248	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:32:42.263654+00	2026-04-07 04:32:46.132145+00	\N	f	1	Versão inicial E2E
bbc9538d-0efc-4323-ade5-c6aa37d9f261	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536362248	ConnectorGammaE2E-1775536362248	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:32:42.287108+00	2026-04-07 04:32:46.132145+00	758edf5e-25df-4564-88d4-581cc32df0dd	f	2	Versão 2 E2E
3e3c7fc8-87f3-489d-be29-21c3aef49c23	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536559086	ConnectorGammaE2E-1775536559086	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:35:59.147247+00	2026-04-07 04:36:02.724637+00	2fb62465-721e-419c-8e1b-2faf4a06c491	f	2	Versão 2 E2E
980eb069-af3e-43b6-8b2c-8ab1b051dfe7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536559086	ConnectorGammaE2E-1775536559086	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:36:02.724637+00	2026-04-07 04:36:02.724637+00	2fb62465-721e-419c-8e1b-2faf4a06c491	t	3	Rollback para v1
3771a5eb-f802-4524-a2e5-7e02359381f9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Saved Test 1775532458213	ConnectorGammaSavedTest-1775532458213	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:27:38.240666+00	2026-04-07 03:27:38.240666+00	\N	t	1	Criação via helper E2E
5be5a510-df90-43c7-a283-da9c5553b70f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536362248	ConnectorGammaE2E-1775536362248	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:32:46.132145+00	2026-04-07 04:32:46.132145+00	758edf5e-25df-4564-88d4-581cc32df0dd	t	3	Rollback para v1
54b97c3c-4d73-41ef-9d6b-d5ab679fafe4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Saved Test 1775532909990	ConnectorGammaSavedTest-1775532909990	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:35:10.029655+00	2026-04-07 03:35:10.029655+00	\N	t	1	Criação via helper E2E
53b6e59a-b1be-4493-a5cb-49a722a27d02	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Saved Test 1775533181847	ConnectorGammaSavedTest-1775533181847	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:39:41.883243+00	2026-04-07 03:39:41.883243+00	\N	t	1	Criação via helper E2E
3d894a4d-69db-44cc-835b-9d70e7da9228	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Saved Test 1775533091649	ConnectorGammaSavedTest-1775533091649	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:38:11.671297+00	2026-04-07 03:38:11.671297+00	\N	t	1	Criação via helper E2E
e03db721-f3e2-48af-aaf8-9b8acca2726a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775537158468	ConnectorGammaE2E-1775537158468	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:45:58.520059+00	2026-04-07 04:46:02.530199+00	\N	f	1	Versão inicial E2E
1826d42a-e2f1-442f-8627-35d45d8bf28b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536553335	ConnectorGammaE2E-1775536553335	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:35:53.355361+00	2026-04-07 04:35:57.002453+00	\N	f	1	Versão inicial E2E
09c136e9-546d-4155-b4a5-ee994ef1f021	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775537158468	ConnectorGammaE2E-1775537158468	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:45:58.561234+00	2026-04-07 04:46:02.530199+00	e03db721-f3e2-48af-aaf8-9b8acca2726a	f	2	Versão 2 E2E
98df0d9d-56ce-45fa-8f95-798b461b844d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775537158468	ConnectorGammaE2E-1775537158468	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:46:02.530199+00	2026-04-07 04:46:02.530199+00	e03db721-f3e2-48af-aaf8-9b8acca2726a	t	3	Rollback para v1
ec748857-c8b2-4287-b29d-b951ab849083	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535672999	ConnectorGammaE2E-1775535672999	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:21:13.014335+00	2026-04-07 04:21:16.875813+00	\N	f	1	Versão inicial E2E
f1702643-5b75-4513-bc2b-12e8c2f3660e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535672999	ConnectorGammaE2E-1775535672999	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:21:13.032485+00	2026-04-07 04:21:16.875813+00	ec748857-c8b2-4287-b29d-b951ab849083	f	2	Versão 2 E2E
e7a03597-9bf9-410f-8895-874a4fc4d15c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535756629	ConnectorGammaE2E-1775535756629	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:22:36.679114+00	2026-04-07 04:22:40.385591+00	\N	f	1	Versão inicial E2E
bbf4d149-6880-487f-a95d-306d14297318	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536553335	ConnectorGammaE2E-1775536553335	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:35:53.378366+00	2026-04-07 04:35:57.002453+00	1826d42a-e2f1-442f-8627-35d45d8bf28b	f	2	Versão 2 E2E
4c1fda2e-7c62-4e59-9fb0-d68639efa314	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535672999	ConnectorGammaE2E-1775535672999	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:21:16.875813+00	2026-04-07 04:21:16.875813+00	ec748857-c8b2-4287-b29d-b951ab849083	t	3	Rollback para v1
e9f76ec5-fa13-431b-a7dd-fc3c836d412e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Saved Test 1775533985921	ConnectorGammaSavedTest-1775533985921	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:53:05.959865+00	2026-04-07 03:53:05.959865+00	\N	t	1	Criação via helper E2E
3943231b-0430-4e7b-af00-cb38f8d4e04d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535756629	ConnectorGammaE2E-1775535756629	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:22:36.69757+00	2026-04-07 04:22:40.385591+00	e7a03597-9bf9-410f-8895-874a4fc4d15c	f	2	Versão 2 E2E
59d0b94b-67a7-45ec-827e-82103fc9ebc9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535756629	ConnectorGammaE2E-1775535756629	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:22:40.385591+00	2026-04-07 04:22:40.385591+00	e7a03597-9bf9-410f-8895-874a4fc4d15c	t	3	Rollback para v1
f6cb9d4b-7d85-4196-93d4-aac00f77383d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536553335	ConnectorGammaE2E-1775536553335	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:35:57.002453+00	2026-04-07 04:35:57.002453+00	1826d42a-e2f1-442f-8627-35d45d8bf28b	t	3	Rollback para v1
479687c1-8d55-4b86-9a27-a19d69244841	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535773337	ConnectorGammaE2E-1775535773337	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:22:53.352659+00	2026-04-07 04:22:56.719512+00	\N	f	1	Versão inicial E2E
a2277ac4-6d79-42a2-b184-a15af521a83a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Saved Test 1775534064829	ConnectorGammaSavedTest-1775534064829	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:54:24.849366+00	2026-04-07 03:54:24.849366+00	\N	t	1	Criação via helper E2E
2fb62465-721e-419c-8e1b-2faf4a06c491	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536559086	ConnectorGammaE2E-1775536559086	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:35:59.111467+00	2026-04-07 04:36:02.724637+00	\N	f	1	Versão inicial E2E
2888dcf2-f6e7-4ea7-8a72-46f81e2b37be	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775537198139	ConnectorGammaE2E-1775537198139	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:46:38.186267+00	2026-04-07 04:46:41.825474+00	0f34d971-86ad-4ae3-b708-1f56b55ec280	f	2	Versão 2 E2E
3cb2099b-488e-4cf3-b7bd-01773d6aa772	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775538641265	ConnectorGammaE2E-1775538641265	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:10:41.296139+00	2026-04-07 05:10:46.460162+00	\N	f	1	Versão inicial E2E
7351248e-067a-4f8d-b179-b48b7dffc363	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535773337	ConnectorGammaE2E-1775535773337	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:22:53.37411+00	2026-04-07 04:22:56.719512+00	479687c1-8d55-4b86-9a27-a19d69244841	f	2	Versão 2 E2E
40243fd4-683b-45bf-a5d9-afb6f5c80cc0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536564777	ConnectorGammaE2E-1775536564777	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:36:04.793021+00	2026-04-07 04:36:08.288839+00	\N	f	1	Versão inicial E2E
17ae0b5a-864e-49c5-b163-6dc4dcf6ec64	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536564777	ConnectorGammaE2E-1775536564777	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:36:04.810153+00	2026-04-07 04:36:08.288839+00	40243fd4-683b-45bf-a5d9-afb6f5c80cc0	f	2	Versão 2 E2E
0f34d971-86ad-4ae3-b708-1f56b55ec280	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775537198139	ConnectorGammaE2E-1775537198139	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:46:38.161508+00	2026-04-07 04:46:41.825474+00	\N	f	1	Versão inicial E2E
5bb6f87b-ec6c-4d7c-94bb-d5939ed5ad46	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775537198139	ConnectorGammaE2E-1775537198139	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:46:41.825474+00	2026-04-07 04:46:41.825474+00	0f34d971-86ad-4ae3-b708-1f56b55ec280	t	3	Rollback para v1
88af65e9-e41c-4287-86f3-83fb1ede48d8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535773337	ConnectorGammaE2E-1775535773337	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:22:56.719512+00	2026-04-07 04:22:56.719512+00	479687c1-8d55-4b86-9a27-a19d69244841	t	3	Rollback para v1
92feae2c-483f-4983-9779-4e6fdf55da51	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Saved Test 1775534153225	ConnectorGammaSavedTest-1775534153225	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:55:53.249029+00	2026-04-07 03:55:53.249029+00	\N	t	1	Criação via helper E2E
25b9a8c6-377e-4830-8b55-2f7d8a8c531d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536564777	ConnectorGammaE2E-1775536564777	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:36:08.288839+00	2026-04-07 04:36:08.288839+00	40243fd4-683b-45bf-a5d9-afb6f5c80cc0	t	3	Rollback para v1
edd18c81-d271-4124-ba84-759c23e251e2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536575751	ConnectorGammaE2E-1775536575751	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:36:15.766724+00	2026-04-07 04:36:19.117216+00	\N	f	1	Versão inicial E2E
167795f4-e332-4bc6-8f9a-dd36cfc9fd18	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536570344	ConnectorGammaE2E-1775536570344	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:36:10.358654+00	2026-04-07 04:36:13.761673+00	\N	f	1	Versão inicial E2E
b608b2a3-6a0f-4183-9925-d1039a9aa92e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536575751	ConnectorGammaE2E-1775536575751	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:36:15.783485+00	2026-04-07 04:36:19.117216+00	edd18c81-d271-4124-ba84-759c23e251e2	f	2	Versão 2 E2E
d9014480-98ec-4bec-937b-cc61ba56130e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775537338128	ConnectorGammaE2E-1775537338128	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:48:58.15052+00	2026-04-07 04:49:01.736724+00	\N	f	1	Versão inicial E2E
77d07160-ca5a-484f-a42e-1cd05a389e0c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775537338128	ConnectorGammaE2E-1775537338128	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:48:58.17622+00	2026-04-07 04:49:01.736724+00	d9014480-98ec-4bec-937b-cc61ba56130e	f	2	Versão 2 E2E
5275fd46-5b5e-47b3-96a4-dc7a666e561d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Saved Test 1775534236453	ConnectorGammaSavedTest-1775534236453	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:57:16.483303+00	2026-04-07 03:57:16.483303+00	\N	t	1	Criação via helper E2E
7ff51d98-51aa-48cd-ab47-d3751f9cbdd5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775537338128	ConnectorGammaE2E-1775537338128	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:01.736724+00	2026-04-07 04:49:01.736724+00	d9014480-98ec-4bec-937b-cc61ba56130e	t	3	Rollback para v1
89cc1b2d-0040-4ebb-9e86-a626a1373aa7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536570344	ConnectorGammaE2E-1775536570344	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:36:10.377854+00	2026-04-07 04:36:13.761673+00	167795f4-e332-4bc6-8f9a-dd36cfc9fd18	f	2	Versão 2 E2E
83e4a2c5-6a60-45ea-b5ff-d957643c153e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536570344	ConnectorGammaE2E-1775536570344	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:36:13.761673+00	2026-04-07 04:36:13.761673+00	167795f4-e332-4bc6-8f9a-dd36cfc9fd18	t	3	Rollback para v1
b2ed2cf4-3a3a-4c35-947d-0bc9f03a8baa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536575751	ConnectorGammaE2E-1775536575751	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:36:19.117216+00	2026-04-07 04:36:19.117216+00	edd18c81-d271-4124-ba84-759c23e251e2	t	3	Rollback para v1
7906ee2b-dc3c-41e1-84bc-4e8eee203068	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775538641265	ConnectorGammaE2E-1775538641265	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:10:41.885065+00	2026-04-07 05:10:46.460162+00	f35f80f1-f054-4864-b5de-4d1a0ed78ad1	f	3	Versão 2 E2E
c71dd853-f9e3-41c4-b044-2b97794a5902	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Saved Test 1775534326896	ConnectorGammaSavedTest-1775534326896	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:58:46.93329+00	2026-04-07 03:58:46.93329+00	\N	t	1	Criação via helper E2E
d7e56a46-9cc0-4534-852a-de5149b2a552	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536622540	ConnectorGammaE2E-1775536622540	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:02.557806+00	2026-04-07 04:37:06.122508+00	\N	f	1	Versão inicial E2E
b1c02615-d314-4302-b4bf-039afd7d2b8a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Delta strict 1775535794306	ConnectorDelta	TRANSACTION	1.0	{"fields": [{"source": "id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "uid", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "evt_type", "target": "type", "required": true, "transform": "copy"}, {"source": "val", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "ccy", "target": "currency", "required": true, "transform": "copy"}, {"source": "ts", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:14.319949+00	2026-04-07 05:11:05.41786+00	\N	f	3	Strict delta mapping for e2e connector failures
6f6b8ac9-08d3-4dd9-91d0-aefc4b77abcf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping 1775532894799	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:34:56.077817+00	2026-04-07 05:11:09.27718+00	\N	f	3	Criado pela suíte E2E
94dde25e-5121-4392-bd54-f0c2edb167b6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775534691930	ConnectorGammaE2E-1775534691930	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:04:51.945932+00	2026-04-07 04:04:51.962161+00	\N	f	1	Versão inicial E2E
2be6a0a9-b37b-48e2-a116-d06d74d07300	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775534691930	ConnectorGammaE2E-1775534691930	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:04:51.962161+00	2026-04-07 04:04:51.962161+00	94dde25e-5121-4392-bd54-f0c2edb167b6	t	2	Versão 2 E2E
8a2e4489-c083-4b26-90a6-436700c46286	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma explicit 1775535794801	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "transform": "copy"}, {"source": "transaction_type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:14.81227+00	2026-04-07 05:11:09.27718+00	\N	f	18	Explicit gamma mapping for e2e
e22046f8-6198-4d11-8fde-c557caa5eb16	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775534929271	ConnectorGammaE2E-1775534929271	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:08:49.320051+00	2026-04-07 04:08:52.814933+00	f41ebca4-0ab0-424c-b389-9067c20d16f3	f	2	Versão 2 E2E
0d86158a-08b2-4262-97b0-1409ea22d1dd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535061256	ConnectorGammaE2E-1775535061256	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:11:01.29243+00	2026-04-07 04:11:05.024842+00	6e130f74-9620-4e7e-a22a-f1f884f455c4	f	2	Versão 2 E2E
ea192577-22da-4967-a3c3-0df164ecd4c2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535088240	ConnectorGammaE2E-1775535088240	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:11:28.273486+00	2026-04-07 04:11:31.766244+00	244015fc-bca0-4ca6-9ea7-4298f5dcecb1	f	2	Versão 2 E2E
51cdcef5-ac92-49b9-b40b-a6825e2b03c7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775534842113	ConnectorGammaE2E-1775534842113	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:07:22.147223+00	2026-04-07 04:07:25.993357+00	eb89cb56-90f3-4601-b5dc-446cd32bb75a	f	2	Versão 2 E2E
eb496226-34d0-4297-9656-3912dd2fc0a7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775537352300	ConnectorGammaE2E-1775537352300	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:12.317371+00	2026-04-07 04:49:15.796566+00	\N	f	1	Versão inicial E2E
f41ebca4-0ab0-424c-b389-9067c20d16f3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775534929271	ConnectorGammaE2E-1775534929271	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:08:49.299122+00	2026-04-07 04:08:52.814933+00	\N	f	1	Versão inicial E2E
94d45165-5929-4ef8-bd6c-cce5da03f720	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535164193	ConnectorGammaE2E-1775535164193	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:12:44.209096+00	2026-04-07 04:12:47.522017+00	\N	f	1	Versão inicial E2E
800d5827-8419-4b6c-b80b-95f99d97d96a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535164193	ConnectorGammaE2E-1775535164193	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:12:44.226277+00	2026-04-07 04:12:47.522017+00	94d45165-5929-4ef8-bd6c-cce5da03f720	f	2	Versão 2 E2E
eb89cb56-90f3-4601-b5dc-446cd32bb75a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775534842113	ConnectorGammaE2E-1775534842113	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:07:22.131079+00	2026-04-07 04:07:25.993357+00	\N	f	1	Versão inicial E2E
c6fb2002-cc6a-4618-9606-f602f31f4cd2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775534842113	ConnectorGammaE2E-1775534842113	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:07:25.993357+00	2026-04-07 04:07:25.993357+00	eb89cb56-90f3-4601-b5dc-446cd32bb75a	t	3	Rollback para v1
47768ddb-d061-4bb8-80b8-63122f6797c7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775534929271	ConnectorGammaE2E-1775534929271	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:08:52.814933+00	2026-04-07 04:08:52.814933+00	f41ebca4-0ab0-424c-b389-9067c20d16f3	t	3	Rollback para v1
4ef0447f-0b75-4ba5-ac29-3af76fdca4e9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536622540	ConnectorGammaE2E-1775536622540	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:02.576026+00	2026-04-07 04:37:06.122508+00	d7e56a46-9cc0-4534-852a-de5149b2a552	f	2	Versão 2 E2E
6e130f74-9620-4e7e-a22a-f1f884f455c4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535061256	ConnectorGammaE2E-1775535061256	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:11:01.274763+00	2026-04-07 04:11:05.024842+00	\N	f	1	Versão inicial E2E
e350d8ae-8180-434b-896c-1dc3cdff696a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535061256	ConnectorGammaE2E-1775535061256	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:11:05.024842+00	2026-04-07 04:11:05.024842+00	6e130f74-9620-4e7e-a22a-f1f884f455c4	t	3	Rollback para v1
4633e9e0-19af-41ea-a368-9aa20d80e910	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775536622540	ConnectorGammaE2E-1775536622540	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:06.122508+00	2026-04-07 04:37:06.122508+00	d7e56a46-9cc0-4534-852a-de5149b2a552	t	3	Rollback para v1
9520c2c3-cfe1-421c-aeef-3b81dbbbf4a5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775537352300	ConnectorGammaE2E-1775537352300	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:12.349711+00	2026-04-07 04:49:15.796566+00	eb496226-34d0-4297-9656-3912dd2fc0a7	f	2	Versão 2 E2E
244015fc-bca0-4ca6-9ea7-4298f5dcecb1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535088240	ConnectorGammaE2E-1775535088240	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:11:28.255037+00	2026-04-07 04:11:31.766244+00	\N	f	1	Versão inicial E2E
dae0d5fb-bcdc-4f2b-a6a8-265181bfc239	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775537352300	ConnectorGammaE2E-1775537352300	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:15.796566+00	2026-04-07 04:49:15.796566+00	eb496226-34d0-4297-9656-3912dd2fc0a7	t	3	Rollback para v1
7ceda743-24a3-4c46-868a-3678a4b1215d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535088240	ConnectorGammaE2E-1775535088240	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:11:31.766244+00	2026-04-07 04:11:31.766244+00	244015fc-bca0-4ca6-9ea7-4298f5dcecb1	t	3	Rollback para v1
f35f80f1-f054-4864-b5de-4d1a0ed78ad1	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775538641265	ConnectorGammaE2E-1775538641265	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:10:41.859285+00	2026-04-07 05:10:46.460162+00	\N	f	2	Versão inicial E2E
cd41481d-173e-4e11-8a7b-62190486d86e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775538641265	ConnectorGammaE2E-1775538641265	TRANSACTION	4.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:10:46.460162+00	2026-04-07 05:10:46.460162+00	f35f80f1-f054-4864-b5de-4d1a0ed78ad1	t	4	Rollback para v2
7c1e754f-5cd9-4d4c-80a1-5c583813f763	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Delta strict 1775535564714	ConnectorDelta	TRANSACTION	1.0	{"fields": [{"source": "id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "uid", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "evt_type", "target": "type", "required": true, "transform": "copy"}, {"source": "val", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "ccy", "target": "currency", "required": true, "transform": "copy"}, {"source": "ts", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:24.719945+00	2026-04-07 05:11:05.41786+00	\N	f	1	Strict delta mapping for e2e connector failures
e06ad360-121c-4957-a0f0-1f891bf701e9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Delta strict 1775535600930	ConnectorDelta	TRANSACTION	1.0	{"fields": [{"source": "id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "uid", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "evt_type", "target": "type", "required": true, "transform": "copy"}, {"source": "val", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "ccy", "target": "currency", "required": true, "transform": "copy"}, {"source": "ts", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:20:00.944773+00	2026-04-07 05:11:05.41786+00	\N	f	2	Strict delta mapping for e2e connector failures
e2c8dd08-d54b-412e-99a0-b284a1c1c934	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Delta strict 1775538665403	ConnectorDelta	TRANSACTION	1.0	{"fields": [{"source": "id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "uid", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "evt_type", "target": "type", "required": true, "transform": "copy"}, {"source": "val", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "ccy", "target": "currency", "required": true, "transform": "copy"}, {"source": "ts", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:05.41786+00	2026-04-07 05:11:05.41786+00	\N	t	7	Strict delta mapping for e2e connector failures
461ffb1b-9f2a-4691-8ec1-8dad30780ca7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Tenant A Gamma strict 1775535648608	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "transaction_type", "target": "type", "required": true, "transform": "copy"}, {"source": "amount", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "required": true, "transform": "copy"}, {"source": "occurred_at", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:20:48.614047+00	2026-04-07 05:11:09.27718+00	\N	f	16	Strict gamma mapping for tenant isolation e2e
92c882d5-9991-4e9f-9f4c-9ce6494114aa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535164193	ConnectorGammaE2E-1775535164193	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:12:47.522017+00	2026-04-07 04:12:47.522017+00	94d45165-5929-4ef8-bd6c-cce5da03f720	t	3	Rollback para v1
6d65983e-968f-4d75-a778-6eccb277a50a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535331719	ConnectorGammaE2E-1775535331719	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:31.738929+00	2026-04-07 04:15:35.375381+00	\N	f	1	Versão inicial E2E
593cd872-4f04-4076-9ee4-1a996383d182	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535331719	ConnectorGammaE2E-1775535331719	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:31.755048+00	2026-04-07 04:15:35.375381+00	6d65983e-968f-4d75-a778-6eccb277a50a	f	2	Versão 2 E2E
124f89da-c9dd-4b0f-9b30-82de99bf746e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535331719	ConnectorGammaE2E-1775535331719	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:35.375381+00	2026-04-07 04:15:35.375381+00	6d65983e-968f-4d75-a778-6eccb277a50a	t	3	Rollback para v1
b4739b52-e3d1-4d0a-b9bf-a91df33c5704	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Delta strict 1775536644439	ConnectorDelta	TRANSACTION	1.0	{"fields": [{"source": "id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "uid", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "evt_type", "target": "type", "required": true, "transform": "copy"}, {"source": "val", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "ccy", "target": "currency", "required": true, "transform": "copy"}, {"source": "ts", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:24.453551+00	2026-04-07 05:11:05.41786+00	\N	f	5	Strict delta mapping for e2e connector failures
f3d0cbec-d091-4935-b6c3-1d0cf4482ebc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Delta strict 1775537374552	ConnectorDelta	TRANSACTION	1.0	{"fields": [{"source": "id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "uid", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "evt_type", "target": "type", "required": true, "transform": "copy"}, {"source": "val", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "ccy", "target": "currency", "required": true, "transform": "copy"}, {"source": "ts", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:34.556987+00	2026-04-07 05:11:05.41786+00	\N	f	6	Strict delta mapping for e2e connector failures
08e6917b-e953-47e1-a6fe-c30cc97b8093	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Delta strict 1775536087242	ConnectorDelta	TRANSACTION	1.0	{"fields": [{"source": "id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "uid", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "evt_type", "target": "type", "required": true, "transform": "copy"}, {"source": "val", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "ccy", "target": "currency", "required": true, "transform": "copy"}, {"source": "ts", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:28:07.247674+00	2026-04-07 05:11:05.41786+00	\N	f	4	Strict delta mapping for e2e connector failures
e0e75f69-80d9-4337-8b92-0b550df47c66	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma explicit 1775537375028	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "transform": "copy"}, {"source": "transaction_type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:35.034756+00	2026-04-07 05:11:09.27718+00	\N	f	26	Explicit gamma mapping for e2e
d36d47fe-e88b-4611-9c19-774fc489df15	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535579227	ConnectorGammaE2E-1775535579227	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:39.243087+00	2026-04-07 04:19:42.894572+00	\N	f	1	Versão inicial E2E
f3b4774a-248b-4a08-a2ae-4fa0b9d413e3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535579227	ConnectorGammaE2E-1775535579227	TRANSACTION	3.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:42.894572+00	2026-04-07 04:19:42.894572+00	d36d47fe-e88b-4611-9c19-774fc489df15	t	3	Rollback para v1
6af350c3-956a-49b6-976a-410f6ddc7fd7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping Versioned 1775535579227	ConnectorGammaE2E-1775535579227	TRANSACTION	2.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:39.262571+00	2026-04-07 04:19:42.894572+00	d36d47fe-e88b-4611-9c19-774fc489df15	f	2	Versão 2 E2E
7de7afb5-f09e-4995-82ad-fcef870000c0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma explicit 1775536087594	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "transform": "copy"}, {"source": "transaction_type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:28:07.598755+00	2026-04-07 05:11:09.27718+00	\N	f	21	Explicit gamma mapping for e2e
943f8513-1141-4aae-8a5d-243a661b50b3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma strict 1775535564267	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "transaction_type", "target": "type", "required": true, "transform": "copy"}, {"source": "amount", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "required": true, "transform": "copy"}, {"source": "occurred_at", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:24.275747+00	2026-04-07 05:11:09.27718+00	\N	f	12	Strict gamma mapping for e2e connector failures
615f7ab8-3f2d-4d71-8b99-82b7c9cdd197	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Tenant A Gamma strict 1775537378403	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "transaction_type", "target": "type", "required": true, "transform": "copy"}, {"source": "amount", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "required": true, "transform": "copy"}, {"source": "occurred_at", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:38.408319+00	2026-04-07 05:11:09.27718+00	\N	f	27	Strict gamma mapping for tenant isolation e2e
05eea43d-a38b-48c7-82aa-aea2dc323999	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping 1775534322654	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:58:44.178608+00	2026-04-07 05:11:09.27718+00	\N	f	10	Criado pela suíte E2E
bb212b1a-30e8-44e2-bf64-dfb3f1685019	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping 1775534060841	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:54:22.327444+00	2026-04-07 05:11:09.27718+00	\N	f	7	Criado pela suíte E2E
cc9f353e-b979-4d96-9981-2243000f67fd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping 1775534149256	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:55:50.778812+00	2026-04-07 05:11:09.27718+00	\N	f	8	Criado pela suíte E2E
07839d93-5761-4e7b-9b35-8a3015fc35cb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping 1775534232257	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:57:13.811647+00	2026-04-07 05:11:09.27718+00	\N	f	9	Criado pela suíte E2E
2f435957-6614-4134-bf69-66397461266a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping 1775532296357	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:24:57.785726+00	2026-04-07 05:11:09.27718+00	\N	f	1	Criado pela suíte E2E
8f0e495d-f873-42d2-8e19-4377d7e7204b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma explicit 1775535356082	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "transform": "copy"}, {"source": "transaction_type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:15:56.088108+00	2026-04-07 05:11:09.27718+00	\N	f	11	Explicit gamma mapping for e2e
841e1263-a4f8-48f6-bb36-6f650324cc95	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping 1775533087776	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:38:09.039749+00	2026-04-07 05:11:09.27718+00	\N	f	4	Criado pela suíte E2E
90df2c7f-535f-49c7-ad30-f6a639333986	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping 1775533178077	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:39:39.455366+00	2026-04-07 05:11:09.27718+00	\N	f	5	Criado pela suíte E2E
45ab6890-e15a-41e1-9421-9e8bd68214d0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma explicit 1775535565152	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "transform": "copy"}, {"source": "transaction_type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:19:25.158179+00	2026-04-07 05:11:09.27718+00	\N	f	13	Explicit gamma mapping for e2e
d8438dea-52f8-4f19-b1ce-ce14c55ea1bc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma explicit 1775535601306	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "transform": "copy"}, {"source": "transaction_type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:20:01.31149+00	2026-04-07 05:11:09.27718+00	\N	f	15	Explicit gamma mapping for e2e
8c3c6e7f-1219-43ee-a385-18714534908c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Tenant A Gamma strict 1775535798399	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "transaction_type", "target": "type", "required": true, "transform": "copy"}, {"source": "amount", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "required": true, "transform": "copy"}, {"source": "occurred_at", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:18.404141+00	2026-04-07 05:11:09.27718+00	\N	f	19	Strict gamma mapping for tenant isolation e2e
3dc6fe12-a285-449b-a53e-c54321fc3c3e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma strict 1775535600508	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "transaction_type", "target": "type", "required": true, "transform": "copy"}, {"source": "amount", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "required": true, "transform": "copy"}, {"source": "occurred_at", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:20:00.514111+00	2026-04-07 05:11:09.27718+00	\N	f	14	Strict gamma mapping for e2e connector failures
2aabcb5d-b776-4f6c-bed8-d21640ef6907	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Tenant A Gamma strict 1775536648168	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "transaction_type", "target": "type", "required": true, "transform": "copy"}, {"source": "amount", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "required": true, "transform": "copy"}, {"source": "occurred_at", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:28.173349+00	2026-04-07 05:11:09.27718+00	\N	f	24	Strict gamma mapping for tenant isolation e2e
341ea838-8b1c-43de-93a3-6b7b2518efd6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma strict 1775537374134	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "transaction_type", "target": "type", "required": true, "transform": "copy"}, {"source": "amount", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "required": true, "transform": "copy"}, {"source": "occurred_at", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:49:34.140621+00	2026-04-07 05:11:09.27718+00	\N	f	25	Strict gamma mapping for e2e connector failures
b17c0c7d-2b1b-4bc4-ab79-7604fbc8e47c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping 1775532454551	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:27:35.883108+00	2026-04-07 05:11:09.27718+00	\N	f	2	Criado pela suíte E2E
af9d1e95-e27c-403e-bf65-133a96ab851e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma strict 1775538664997	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "transaction_type", "target": "type", "required": true, "transform": "copy"}, {"source": "amount", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "required": true, "transform": "copy"}, {"source": "occurred_at", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:05.003059+00	2026-04-07 05:11:09.27718+00	\N	f	28	Strict gamma mapping for e2e connector failures
0f9a3081-659b-4260-b778-94204e484544	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma strict 1775536644046	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "transaction_type", "target": "type", "required": true, "transform": "copy"}, {"source": "amount", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "required": true, "transform": "copy"}, {"source": "occurred_at", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:37:24.053453+00	2026-04-07 05:11:09.27718+00	\N	f	22	Strict gamma mapping for e2e connector failures
7a451cef-a120-45b9-bf95-eedeb21a4aeb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma strict 1775536086843	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "transaction_type", "target": "type", "required": true, "transform": "copy"}, {"source": "amount", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "required": true, "transform": "copy"}, {"source": "occurred_at", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:28:06.849665+00	2026-04-07 05:11:09.27718+00	\N	f	20	Strict gamma mapping for e2e connector failures
cb718b5e-d567-4d9c-878a-e1451a5bb48d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma strict 1775535793919	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "transaction_type", "target": "type", "required": true, "transform": "copy"}, {"source": "amount", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "required": true, "transform": "copy"}, {"source": "occurred_at", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:23:13.925049+00	2026-04-07 05:11:09.27718+00	\N	f	17	Strict gamma mapping for e2e connector failures
a23a9f40-8a48-4b28-87fe-189a7f01d7d9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E Mapping 1775533970423	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"params": {}, "source": "event_id", "target": "event_id", "required": false, "transform": "copy"}, {"params": {}, "source": "external_player_id", "target": "external_player_id", "required": false, "transform": "copy"}, {"params": {"WD": "WITHDRAWAL", "BET": "BET", "DEP": "DEPOSIT"}, "source": "transaction_type", "target": "transaction_type", "required": false, "transform": "mapEnum"}, {"params": {}, "source": "amount", "target": "amount", "required": false, "transform": "coerceDecimal"}, {"params": {"format": "iso8601"}, "source": "occurred_at", "target": "occurred_at", "required": false, "transform": "parseDate"}, {"params": {}, "source": "currency", "target": "currency", "required": false, "transform": "copy"}, {"params": {}, "source": "device_id", "target": "device_id", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_type", "target": "instrument_type", "required": false, "transform": "copy"}, {"params": {}, "source": "instrument_token", "target": "instrument_token", "required": false, "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:52:51.708749+00	2026-04-07 05:11:09.27718+00	\N	f	6	Criado pela suíte E2E
057d6bef-dddd-405d-93e4-215b97dd9648	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Gamma explicit 1775538665824	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "transform": "copy"}, {"source": "transaction_type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:05.832382+00	2026-04-07 05:11:09.27718+00	\N	f	29	Explicit gamma mapping for e2e
abe29951-4a34-40f4-985e-484a876ebc39	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Tenant A Gamma strict 1775538669271	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "required": true, "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "required": true, "transform": "copy"}, {"source": "transaction_type", "target": "type", "required": true, "transform": "copy"}, {"source": "amount", "target": "amount", "required": true, "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "required": true, "transform": "copy"}, {"source": "occurred_at", "target": "occurred_at", "required": true, "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:09.27718+00	2026-04-07 05:11:09.27718+00	\N	t	30	Strict gamma mapping for tenant isolation e2e
\.


--
-- Data for Name: model_inference_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_inference_logs (id, tenant_id, player_id, model_id, model_variant, anomaly_score, is_anomaly, request_id, scored_at) FROM stdin;
\.


--
-- Data for Name: model_registry; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.model_registry (id, tenant_id, model_name, model_version, algorithm, dataset_window_days, metrics, trained_at, created_at, model_type, status, dataset_window_start, dataset_window_end, promoted_by, promoted_at, is_challenger, champion_id, artifact_uri, is_active, training_rows, trained_by, feature_columns) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.notifications (id, tenant_id, user_id, type, title, body, entity_type, entity_id, read, read_at, created_at, is_read, reference_type, reference_id) FROM stdin;
\.


--
-- Data for Name: player_kyc_events; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.player_kyc_events (id, tenant_id, player_id, entity_type, subtype, provider, document_type, pep_flag, income_declared, exclusion_source, exclusion_scope, exclusion_duration_days, old_deposit_limit, new_deposit_limit, previous_status, new_status, reason, ingest_mode, backfill_job_id, occurred_at, created_at) FROM stdin;
\.


--
-- Data for Name: player_list_entries; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.player_list_entries (id, list_id, tenant_id, player_id, external_player_id, cpf_hash, notes, added_by, added_at, value, value_type, player_list_id) FROM stdin;
21d42435-2e2a-4493-95f5-532b67b054bf	275b4c55-d5ab-4a42-8ed3-80a9322a408c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	4633153f-6cca-40b2-b0f7-30df770677ec	EXT-OPERADOR_A-001	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-04 09:08:16.001152+00	EXT-OPERADOR_A-001	EXTERNAL_ID	275b4c55-d5ab-4a42-8ed3-80a9322a408c
35c672f1-5807-4d6a-9863-441a86a1648e	275b4c55-d5ab-4a42-8ed3-80a9322a408c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	464e8bab-c13c-4d14-b512-f008f997e437	EXT-OPERADOR_A-002	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-04 09:08:16.001152+00	EXT-OPERADOR_A-002	EXTERNAL_ID	275b4c55-d5ab-4a42-8ed3-80a9322a408c
581bba4e-c6b1-4832-8fd7-f59d60e75c3c	275b4c55-d5ab-4a42-8ed3-80a9322a408c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	d5bcf2ee-3cce-4588-b12f-fac85a059270	EXT-OPERADOR_A-003	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-04 09:08:16.001152+00	EXT-OPERADOR_A-003	EXTERNAL_ID	275b4c55-d5ab-4a42-8ed3-80a9322a408c
0f7a21ef-509d-4a5c-a602-2c21db2350b8	b16173a7-1306-4cf7-8fed-dc65dabf79b7	40e341ad-cf4a-484b-9926-3d56cc58fa1f	28468030-6f88-44de-b31b-f628e9a6011d	EXT-OPERADOR_B-001	\N	\N	e653024a-8bee-46b0-ae12-63177bb0dc61	2026-04-04 09:08:16.001152+00	EXT-OPERADOR_B-001	EXTERNAL_ID	b16173a7-1306-4cf7-8fed-dc65dabf79b7
fad00cbb-dba1-4cf0-adfb-a1034e1f0856	b16173a7-1306-4cf7-8fed-dc65dabf79b7	40e341ad-cf4a-484b-9926-3d56cc58fa1f	adf6f239-4e9c-4649-9bec-8dd930aaca18	EXT-OPERADOR_B-002	\N	\N	e653024a-8bee-46b0-ae12-63177bb0dc61	2026-04-04 09:08:16.001152+00	EXT-OPERADOR_B-002	EXTERNAL_ID	b16173a7-1306-4cf7-8fed-dc65dabf79b7
65933c73-0ec3-4293-b5f4-01b4c916e413	b16173a7-1306-4cf7-8fed-dc65dabf79b7	40e341ad-cf4a-484b-9926-3d56cc58fa1f	3deb2da5-9d7b-4ebf-8a28-ead586a31793	EXT-OPERADOR_B-003	\N	\N	e653024a-8bee-46b0-ae12-63177bb0dc61	2026-04-04 09:08:16.001152+00	EXT-OPERADOR_B-003	EXTERNAL_ID	b16173a7-1306-4cf7-8fed-dc65dabf79b7
2b877631-3733-4b37-879a-0bbf02a7cd8e	ca3df0be-8eb7-4d0f-be7f-9f85774e505a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:25:05.98609+00	12345678900	CPF	ca3df0be-8eb7-4d0f-be7f-9f85774e505a
cf217910-ac4f-48df-ab81-c89b8f14815f	ca3df0be-8eb7-4d0f-be7f-9f85774e505a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:25:05.98609+00	99999999999	CPF	ca3df0be-8eb7-4d0f-be7f-9f85774e505a
278dc538-8128-4d49-9a8e-df5a4fa2a09c	6771112b-e53a-4487-b6a5-36df24490af4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:27:43.702253+00	12345678900	CPF	6771112b-e53a-4487-b6a5-36df24490af4
2dcec6f6-f9ab-4a1a-ba29-b7730c537ce4	6771112b-e53a-4487-b6a5-36df24490af4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:27:43.702253+00	99999999999	CPF	6771112b-e53a-4487-b6a5-36df24490af4
79bfbb75-5ae9-45dc-8bc0-9af01eef4416	a3c7c220-e848-4cea-abf4-bda581a90d19	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:35:15.365256+00	12345678900	CPF	a3c7c220-e848-4cea-abf4-bda581a90d19
22d54301-1401-4bc5-afea-188ba9e5ebac	a3c7c220-e848-4cea-abf4-bda581a90d19	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:35:15.365256+00	99999999999	CPF	a3c7c220-e848-4cea-abf4-bda581a90d19
e088d546-126f-4955-b257-36168a474f57	54af9eba-196e-44ef-8b1b-76cf929342d3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:39:47.039584+00	12345678900	CPF	54af9eba-196e-44ef-8b1b-76cf929342d3
26b03883-886f-4783-9ee5-338d9458edbe	54af9eba-196e-44ef-8b1b-76cf929342d3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:39:47.039584+00	99999999999	CPF	54af9eba-196e-44ef-8b1b-76cf929342d3
c1895dd1-9de4-4a61-9149-8a8518eb84a5	26153a7b-84f8-4e7d-9762-4a25147eea9c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:53:12.111476+00	12345678900	CPF	26153a7b-84f8-4e7d-9762-4a25147eea9c
048fc15c-a7d2-4199-a5d5-f1d8f63d394b	26153a7b-84f8-4e7d-9762-4a25147eea9c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:53:12.111476+00	99999999999	CPF	26153a7b-84f8-4e7d-9762-4a25147eea9c
1846a2f7-3c3e-4963-b0bc-4ac9f778b8a5	a908dfec-1fcf-46f2-9895-58de4ca6cd9a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:56:10.45375+00	12345678900	CPF	a908dfec-1fcf-46f2-9895-58de4ca6cd9a
d82c881f-79c9-45be-a63d-fa49a82857b4	a908dfec-1fcf-46f2-9895-58de4ca6cd9a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:56:10.45375+00	99999999999	CPF	a908dfec-1fcf-46f2-9895-58de4ca6cd9a
eb066483-8a10-40d1-8516-0e9ac15b9a41	c42697f7-c1c1-4217-81dc-f2e72abf0d9e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:58:52.896814+00	12345678900	CPF	c42697f7-c1c1-4217-81dc-f2e72abf0d9e
e2ac65b8-3ec9-453b-a62d-85bf2f9bcfdb	c42697f7-c1c1-4217-81dc-f2e72abf0d9e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	\N	\N	\N	\N	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 03:58:52.896814+00	99999999999	CPF	c42697f7-c1c1-4217-81dc-f2e72abf0d9e
\.


--
-- Data for Name: player_lists; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.player_lists (id, tenant_id, name, list_type, description, active, source, created_by, updated_by, created_at, updated_at) FROM stdin;
275b4c55-d5ab-4a42-8ed3-80a9322a408c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	pep_watchlist	WATCH_LIST	Jogadores identificados como PEP ou conexão com PEP	t	MANUAL	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00
46930a97-5e61-41be-afaa-c52417e026fd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	internal_suspects	CUSTOM	Lista interna de suspeitos identificados em investigações anteriores	t	MANUAL	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00
b16173a7-1306-4cf7-8fed-dc65dabf79b7	40e341ad-cf4a-484b-9926-3d56cc58fa1f	pep_watchlist	WATCH_LIST	Jogadores identificados como PEP ou conexão com PEP	t	MANUAL	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00
f9d79ccf-b969-4405-9b32-24d43f538c59	40e341ad-cf4a-484b-9926-3d56cc58fa1f	internal_suspects	CUSTOM	Lista interna de suspeitos identificados em investigações anteriores	t	MANUAL	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00
ca3df0be-8eb7-4d0f-be7f-9f85774e505a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E List 1775532305557	WATCH_LIST	Lista criada pela suíte E2E	t	MANUAL	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-07 03:25:05.786686+00	2026-04-07 03:25:05.786686+00
6771112b-e53a-4487-b6a5-36df24490af4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E List 1775532463052	WATCH_LIST	Lista criada pela suíte E2E	t	MANUAL	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-07 03:27:43.247278+00	2026-04-07 03:27:43.247278+00
a3c7c220-e848-4cea-abf4-bda581a90d19	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E List 1775532914932	WATCH_LIST	Lista criada pela suíte E2E	t	MANUAL	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-07 03:35:15.154194+00	2026-04-07 03:35:15.154194+00
54af9eba-196e-44ef-8b1b-76cf929342d3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E List 1775533186625	WATCH_LIST	Lista criada pela suíte E2E	t	MANUAL	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-07 03:39:46.838859+00	2026-04-07 03:39:46.838859+00
26153a7b-84f8-4e7d-9762-4a25147eea9c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E List 1775533991655	WATCH_LIST	Lista criada pela suíte E2E	t	MANUAL	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-07 03:53:11.892446+00	2026-04-07 03:53:11.892446+00
a908dfec-1fcf-46f2-9895-58de4ca6cd9a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E List 1775534169922	WATCH_LIST	Lista criada pela suíte E2E	t	MANUAL	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-07 03:56:10.23481+00	2026-04-07 03:56:10.23481+00
c42697f7-c1c1-4217-81dc-f2e72abf0d9e	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	E2E List 1775534332384	WATCH_LIST	Lista criada pela suíte E2E	t	MANUAL	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-07 03:58:52.673257+00	2026-04-07 03:58:52.673257+00
\.


--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.players (id, tenant_id, external_player_id, cpf_encrypted, name_encrypted, birth_date, pep_flag, declared_income_monthly, profession, risk_score, last_scored_at, created_at, updated_at, registered_since, status, external_id, risk_band, cpf_hmac, self_exclusion_flag, deposit_limit_daily, features, cluster_id, cluster_size) FROM stdin;
28468030-6f88-44de-b31b-f628e9a6011d	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-001	\\x6741414141414270304e5542516538425a376d796d4845614441356833783649665545304c3067706c7975792d6873614471786c31746367495f555352734d557755304a6d59686965396978666d49343551394e567630756d566655626b393977773d3d	\\x6741414141414270304e55425f306e6341474b4c4a6e7243515061504e37737039634e416b746b39484f4843593863364c68314c477741656363306866485952587a57306d7133686273476e4e4d32667174652d384d5f586a4d2d544b734533772d325154305f4149686463486f337954673856654b6b3d	\N	t	20000.00	Teacher	0.0203	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	8e7bc9ed8ade6c5c2b70e331f95c884b740c2ba7f551cf909e926adce1b07a1b	f	\N	{}	\N	0
adf6f239-4e9c-4649-9bec-8dd930aaca18	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-002	\\x6741414141414270304e55426a364a766668346355343244682d7744456a7747656261534d31623552556d565f555037326775544f466456726572397654364f4c5f5a47664967375a343847436475645a64473345415649436462506a525a534a773d3d	\\x6741414141414270304e55427970516f497857536e4f5f504c56566142426f504d3234624c734b69526f7675356e75706d5a6e41737578424555674a636e6458474b503874386a733369726a694566307137493846737a38486777486b646b546335646b495f6d633731726a72346f714d664f472d726b3d	\N	t	10000.00	\N	0.1804	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	250500189490150172bf959ab21dff798d0b0a7fe85276efb67bb821004650de	f	\N	{}	\N	0
3deb2da5-9d7b-4ebf-8a28-ead586a31793	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-003	\\x6741414141414270304e5542694553304354736e6d4a32524e7a577666785f71683438644848765f4241464e57767a6a4a6a554d3157587863546c4d6235576644664452693879467371674e6b5932787273723841374945727a614c777a2d7341773d3d	\\x6741414141414270304e5542644647396d4c34416446476939494742326f37306c2d52696c6b637449417535766d497250734c715a6974646f43487557353537534d585351644a454867737377353863635865756868424d39744d6c6e486261414b30555f50546e5477677651745a47323935367859413d	\N	t	20000.00	\N	0.0187	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	8c7424dfaf602358e7a76f29d050fef4c30cec0afe6d9fae5c9a2c01169e39ec	f	\N	{}	\N	0
80fbe818-191f-4c2d-9472-18ec2429d42f	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-004	\\x6741414141414270304e5542586a4f52462d6a35625734535f41627255654d72396755396a5154324e3052594561507059536a7478345646333957373943717870337036565445674b796f6178694c36584c6f7570424c364e3735755f4566586e413d3d	\\x6741414141414270304e55425972594433714362356c557a6d476844566366454a6d5f655a4e7636776e625572326e576b4b476c7a4c4e517966556c634e466171393751434b784d552d725030714c7231506857396a4c3675755f5f613647684c58794f6467506a324a796e596254686d69726a4a53673d	\N	f	\N	Trader	0.1929	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	4c4d005ba64ddeef8bbeaf79f8b96cb4eea43f455d7b246d7797c000a7b433cd	f	\N	{}	\N	0
36b86460-2fc6-46e7-8472-1d29a4310d30	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-005	\\x6741414141414270304e5542694b4e576b6e34786a6571745846736973355358744f453152316d3771546869524436724c6f3854666f4948444d47466c78516b63784b566e6854756a4d786377496a717377646b304a5a6551493566446d497a54673d3d	\\x6741414141414270304e554278535f5038637135723450336b637370354f34495341556769634a686145596349664a3078466572504f4559544b4c4d49636e757753794c397945724137416d703363484c4f44504652343368774e44354b63614d4c556a555368624c39394e58467a4e6c3375476334673d	\N	f	2000.00	\N	0.0824	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	deeeb455afb6b0283f8117ab552b91617c07f8e1feba0665ad114837bfdccc82	f	\N	{}	\N	0
8a3bbddc-8235-4943-b82b-1bd7b540cf79	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-006	\\x6741414141414270304e554274533451664a70734a7372357046726d514a674c78783172476e6b34733361386e774b364f3949585652304243435a69753945675a7351647a3273794e39313655436f436b57754b3670357573524c6b5758594f4c773d3d	\\x6741414141414270304e55424f5738387750785f494179716e546b78575949436d434c306a465f61714f3264686e704c763378444d65624257546270506467766d4f47744e7861596c347045645f58655666334d5f52766f49415a424a5873622d455177357248332d6570734c674731614b4d684343773d	\N	f	2000.00	Engineer	0.1730	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	4414113d3eb264285fabaddf158d0b4f14cafa1dd717decba77ba38972403265	f	\N	{}	\N	0
d20108d3-67fd-4236-93c1-5406557b0d13	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-007	\\x6741414141414270304e554238754932766e504b496d71576d6a4b6d475873356d4870716f394a582d2d6577537756357152455a454c54514f32487361704b317035307636316d627234477a544b6a7a7a576a456a414b633744317938555a534f413d3d	\\x6741414141414270304e5542327471575a5f376133764d62527948447a394d4d44766c5a6e3161796977772d545f54495369484345565a66384241496d4559676a337835627347665a4537364f66754b317657795673696f4e466b4254636e37362d496b4d6d725f4d4557376b65712d4d3750364537553d	\N	f	20000.00	Trader	0.1738	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	4ab914f8a203cf411b0a113f955ddf5cf3b4acf416a2b7f56f8bf9a599b1f6fa	f	\N	{}	\N	0
e9bedee0-6206-47b0-b91b-df24f2a64b08	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-008	\\x6741414141414270304e5542645137637639365f697134533744537a53696173414748716d57396a72616777344d6d30504245787736455a644b4b4c64504b615571466c4b6a7a5734766a786865432d2d6564416b723231764639332d78436c31673d3d	\\x6741414141414270304e55426839316f6434712d3065356a57395f2d6842785052765f2d3058673551456a5135533944317477505f79564c7436634755503578667a69426f6b57727a514a754463476b59466c56704f6254316c5f7443495858593473464374476c565a5a73787a5f65744f7a47367a413d	\N	f	5000.00	Trader	0.0154	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	c9f04c8be0b5467870fac2ea0bd5f994209f594b49114f9a4648ccbb5fe2866b	f	\N	{}	\N	0
7b15e705-e4d9-4894-bbaf-38891cff7fd7	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-009	\\x6741414141414270304e554256566967706c4c37756956724a2d76646965527872716456506c33594b4a745755565049574b537363646d594d57785834314e5f575171506f4c544571464d4d656b4d42775079585347476f5178794431466b6f58513d3d	\\x6741414141414270304e5542676a684f495652377a67777a78394d4951734d33507a6c45635845566868426248394f375879487134426a7652616a2d6e6e776874516167716461775a684430785961417341797959694e4655694a4255684a64564e5164525f36534c545272496d564f337a50555365593d	\N	f	10000.00	Engineer	0.2521	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	1d067c8946d5b2178e142f25c47d5b2d47e24de7d206d68b34899b71cd67c96c	f	\N	{}	\N	0
03491eba-eb2c-419f-a9f2-f91b91040c9e	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-010	\\x6741414141414270304e55425556494f30663844627a554d4a68394b597164457848737172665a4f382d4c31744169424a445172674c69594233557031527a704979515a6a736d4d64564e4c7354435537466754356f6a73784a724f39425a6964773d3d	\\x6741414141414270304e55427a6759564b7643615250584f78784d316952322d53794f7173315856597430657356503943626c64533046665559614f44586c6a3364376865357870684e6a59702d3439444e664d556174563473587645426e792d4534704e4e72796948504a3943427a553852597951633d	\N	f	\N	\N	0.0643	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	14c8de35bf75989c017be2f85c4b27ba167e69d6cffc45363363679e198a4931	f	\N	{}	\N	0
4b971265-bd5f-4827-90eb-37a3895a9b30	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-011	\\x6741414141414270304e5542777564494d79707164354b344555763149314e76455570575a734a6b697956793159796f47654a4d5f53417341636453367041394c3462682d5833773070334157382d6a4d5a6d6865726c5558654e34706b474570513d3d	\\x6741414141414270304e55424d376d2d554e376a665549363155755171356f54326f465462714e74776c614f396c5150364362424362744d7a6c4939707978636e644b364746435f6d77745455574e55655f466c6c75324f535961664546357532555038426f4365754e464e78366d4f642d743970596f3d	\N	f	20000.00	Teacher	0.2328	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	9997b2dcd5e9b91794756c76e2ac77f21f07d7f4dc548adca745ef9c9880150b	f	\N	{}	\N	0
6e08b457-55a1-4b31-8429-f6ecac396946	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-012	\\x6741414141414270304e5542486d4c694575576d64374674766f626f6964394a416b6a697966505441476a6e56556949366e7a39554c45506a355543375547684941685043797a7a544c47684c4b52342d70525f3870736e6d5f6b335668653631773d3d	\\x6741414141414270304e55424a6d665f6154307269616c49346d6f3275536c546545486c4336304c565a667846554a4155556a5f795651384a4631494d5a337151494137494d56724461506a56687756546e554f73325968626c73514579364f4a75504671425f436b637037627a4a6f476357695272593d	\N	f	2000.00	Engineer	0.0315	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	56254a46c03d47de80869253a9f3503d78d25350ce2ede750b7d1f591f94f11d	f	\N	{}	\N	0
da136dc6-b1aa-4b75-9068-8bb8bf7a2b5d	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-013	\\x6741414141414270304e55424f397071556e6f6459496b375066414669496f7265705a6e56773331724f324f3135325363485f584e7a4b42306d324e4759584430716b4a4973423467444c564b4e663759474179424f50554b745952413655336c513d3d	\\x6741414141414270304e5542674b6a5731574a4d49444a50764546635352312d494a56503538574a635059326169595a5a616b505967706a59455a4d6f6d4e61655a6f6a69514f413874656965536d5a774b736c736c4e7343777262774e5171634a6a704d68587458675f6557644f4b576a2d4b5253413d	\N	f	2000.00	Trader	0.1118	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	b2a5348dfeea30d127b4352ca10bd34eca93e05595276d5e2f3f61e40abe75e1	f	\N	{}	\N	0
17ce5208-9cd7-4f12-a21c-97b269008113	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-014	\\x6741414141414270304e55424a383955585f525548455a64784142455546364b73494972535a6956523277307130756c7377354c65704647427161764452594f764d5a314d6349566c446d47424f57436f7a7962516a536247745544414a784c48773d3d	\\x6741414141414270304e55426b535363484a48504e5f756e66534d65736656774356306c6d723150344a55526e6a3757645844704e555f43386534425372755f35714567524b2d6a634d452d58536f626c39366f575067326f4b2d4c456d5a466234586a2d52346938466752552d4c46517a4e5f4472493d	\N	f	20000.00	Trader	0.1527	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	93875a9eb5a0ad7ee8285a919e55576288f470c5bb2297d089d69c9eb866c47d	f	\N	{}	\N	0
f7f5b4c2-824b-4f70-a7ca-626a7b1d4af7	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-015	\\x6741414141414270304e5542554b317333595666725278414d4a6c446476744231683238356f6e30652d7734695a504f676b78652d7374694c57795f5267722d5370615a6779786659782d536b337a6671385463647441344c6465616c43786a42773d3d	\\x6741414141414270304e554265754b68444c65334458464f796e6f64595275456b6148563977426d5676393037545730464863464e4a707379307433416e4c594358476a706e596b59797a474452636364314e6856386c302d46484d365947587337765535326a76487a365a314e3057516a74534f55303d	\N	f	2000.00	Engineer	0.2805	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	42aa8fe8f00ccc777b7d3bf705c34845ed9a7ec97e98ef2b4c7af1877fa7e165	f	\N	{}	\N	0
99b87c66-3094-4ec2-a693-54cc8ee41b72	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-016	\\x6741414141414270304e5542504c4a5a4a34383770567a46614a615a76725667495164427972703875514d696d6c664e71346b66655831655446695663714e704a6b6b797257647538466a71534353745550644938682d30644943594358326e68773d3d	\\x6741414141414270304e554239576a357770786d744a4e746b436b4477415458696f546a55522d39654939794e504e347a634d6f6a455f6153327148716f6b683451545330724b66354b2d486b75655867716d62437a59356a754d55646a70482d6a6652686c6a616830436e686d48786432775065446f3d	\N	f	5000.00	Trader	0.0477	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	0ba9daf2d3d5409be1a7ede78e281f00ab96e03eb9f02a4ebc9c73890ae4fccd	f	\N	{}	\N	0
f6b4823a-1569-4bc5-a3a9-3561406b253a	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-017	\\x6741414141414270304e5542787371504d4a4148514b414f6c684d796d7479775245707a6b5950784a6d4c4e4e6a344873706d442d42684d66332d72555753754c4362376d484a4f694b6e577037336c7843616c32516948744d3454457675336b413d3d	\\x6741414141414270304e5542716a6738524754323638775854426738724d525a5662693432654d726734615557365f4d484636654a536759516a4a52624c63474d374b77716a365142572d6c714435454e6c426851584e6768545961494d766c70447552545f556b766d6874493746714d33534a6472493d	\N	f	\N	Engineer	0.0123	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	719a71e5c5ddecc44087e35b209bcae2669cb1da1866a7386a3ae55f8bb8dffc	f	\N	{}	\N	0
8bf9406a-06a1-4976-82a2-94cc7683302a	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-018	\\x6741414141414270304e5542745a6d5445384d437049445566746574314946664343436a3231424a65314d62366a5f517a6a74694467687741486a534171593057596d41545734485442614d357a514662554168494e37764867326264554a7649413d3d	\\x6741414141414270304e55424356306e64616630336e526f304d4d4263675737445053353641316b6279682d586c54354f687654436a50357350327669736e6863343469385173694535544345746c4254753672566255584b6549495275434e6e42654d69373869693978336879767a5657396d526e553d	\N	f	20000.00	Engineer	0.0871	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	5a1cd7927ce13a6c01a4af2021a181feb849fc65b2614f0c484f369b7bc1afd4	f	\N	{}	\N	0
081ebf17-5122-4079-9fc4-d9e298862132	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-019	\\x6741414141414270304e5542457a434f335f4135456771447770426a675350613365426842455930486b55496c5a37575852656357305f5a6c743879576c4f4b35566d496647753350562d3348536c35495165437736526b496f5a6b4a594b7655513d3d	\\x6741414141414270304e5542724e526147567632643663372d6a4b72764539645773414f475143594363646e584e545067443543396d666c30395064496669692d6e6a4753575171584c5359707031706657305430544f5735626e69317a77554b614b5252502d69706551636b756b6b355152444e38453d	\N	f	5000.00	\N	0.1132	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	e9952e4cc8089002506925643c72e4459c9b242ccc872553c8293b83f1286b27	f	\N	{}	\N	0
9b09a839-3185-4aa5-8357-0a0e2c287122	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-020	\\x6741414141414270304e5542614f4f63372d6a624863356e47435439355748636a7a666c5f53615f544541444a4e7848715f667461596a426f416a4c44456d6a334264666f79557341417a536642314b5032626b3761584e4b5947543439374267773d3d	\\x6741414141414270304e554246783055324941754638685a6e5459344d7955397341597a724d46334e7374656d6b65336f746c5f5a65594e78557431557a434a707036614c6c793530395a544c626850776c6744754c6a506e776f6d6964414461517764734a4e7a4c70587750442d74773635326c5f303d	\N	f	20000.00	\N	0.1854	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	81c90fc7a5b7f65a48eff57459d2812a457fae728e890d0575afdb6fb1f0c283	f	\N	{}	\N	0
42a510dc-620a-468e-8a78-a15ff3eb8e3a	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-021	\\x6741414141414270304e55425751347254596b5a6a384b62437470672d6b56584e696c354a68636d424b366a70775f486e6d51462d547952684a6d6b65685564504c654350575158666373626c64306d563171736741344f6f766f4b4345756478673d3d	\\x6741414141414270304e5542376a6f54704d6e36523663476e34394873447a45716633707854745a523550714c754c34495062564f32444c6f4f4a4d6579656f4d65376e71337742565037324938777479544d4f664e7057724f346a6752374274667358716a61497a5635757a4c2d44522d51575f56773d	\N	f	10000.00	\N	0.1866	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	e9cda66bceb9d68382901e3789d8c5d3ac7089acacb15fc9ac6815d3ad2db4ec	f	\N	{}	\N	0
7648d00b-8ec8-4bef-ae1d-06073d8ad238	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-022	\\x6741414141414270304e55423234555050677158367474644949556c76477451627962436a4c31313754416764656b507139596371334a7749666a704336393433303232527258344b573775474a7837495a52486f4c547436325759724d744d33413d3d	\\x6741414141414270304e554263777a644e596e574c5f797679774670384f33576e636433485765616f326d75523577514758347162515f58315244694e635f6b5454377634515372627a49316c4b4f51317532576b2d3246676e64772d374c534f33644b4364376f5a6647564670733644345f35522d6b3d	\N	f	5000.00	Engineer	0.2788	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	44d948d0dd0754bb1eb37a8891ac81fd86083827e7341daadbd0abd5cdd19f46	f	\N	{}	\N	0
8eb443f4-2f6c-47bd-8d27-a29a27ee9e7f	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-023	\\x6741414141414270304e55426a7a755863386e7669434663776871616c557468376c4b7a4b4564475f6d5661327459657735634a485a70717465725572457762386870715473687a43433568774f7239395f737833555653334b664467784f3067513d3d	\\x6741414141414270304e5542546978346354487143664c2d7a695a56524b4c4b394354496b44343148496c38426d763659346d426b615a5f30735151466e48784264763633683457304541676e3272725046516f32735a5f57476547655650575462676451466462776f4a7158634966554d7a374b58493d	\N	f	\N	Teacher	0.0497	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	8418cdcb86568e3250fbb8b8dc8ba2c2965e6450511c66aa7b900fabc5bee012	f	\N	{}	\N	0
c6a9f2d6-4c1e-462e-a2d2-7eb4f6d772de	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-024	\\x6741414141414270304e554242706c734452724e694c584d5332503134537a5f70795255396968695669427a6e427a316f72355276416e5a467752676c6a527558676d642d2d2d3953393376623557415a585934344c6e2d3231464f345370326b513d3d	\\x6741414141414270304e5542306c45355f39794d785a704430555a544a67783664656a6b457956445372654b36465673376d396e6c744171524d4d543467464f5f5454734a4369717275374a564147723935306f44344e4e336e614838707a6c6e55424151764e784c57304654756c6e7a6e424d574d413d	\N	f	2000.00	Teacher	0.1121	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	c56a1ac011e06b723a79e5d94cfbc5d83a870b7d5b5229e7760cbe5e548c9530	f	\N	{}	\N	0
31359e19-43fa-4314-badd-73485c918c33	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-025	\\x6741414141414270304e55424b357553574b53324d71526272526368615665306a69492d437948483549584b6f5372373938343148384947554530622d3959314539577737737945714776487a414350693835746a68637975744e455859774e32413d3d	\\x6741414141414270304e55426f62324d4b59775f75344a323974797375314e685a4e7878524e4d6a384e32623273576d66336b72627778464e3875396554576e303464425268457a63597a4c324c3270367079317a33444353626c4a3362506666384359437a545f44775f5448324a773638344b4f76733d	\N	f	10000.00	\N	0.1484	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	c5117e7594bb34a41954017a28c8ac8b514bf67143f3cd1f22a3851e04f594a2	f	\N	{}	\N	0
6cd2417f-99d8-4d85-9286-b75f4d1f4be0	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-026	\\x6741414141414270304e55424572514e4943345870706650635772455f474b4c2d737261496f6f4a457743473030447444345f35383534365a336d55586b783377564f4b7a4d70544744583863354a6f4f6c48696830506e626c65733948474a38773d3d	\\x6741414141414270304e55424f6c437173616e366552554172306575427758416a727a426b4c5a48634b756c5a53445564616d58444d535a5142543565686f355f6e4265315437545a7330715f486341497a6d65525952356f4f4a55436c535a567878636832776255366c34316f5755696a4a3957326f3d	\N	f	2000.00	Trader	0.1298	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	62cbf9a5cad25d4cb1b75379128368815a85e2eac00e74adf0df1e5082b27267	f	\N	{}	\N	0
72557b5a-8736-43fb-b077-352e24ba11c5	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-027	\\x6741414141414270304e5542535568784e77566945523463674c717330455251413141475f49706f6f496b474c65346b2d4e45333252325251656c675049686c2d446e366d324a313339716a47654d5a4676667a344e7a5f4645762d30395a4f78413d3d	\\x6741414141414270304e5542726230675849654d364d58765572583350744233486d5268704a7179736743675552724447476b4e324b30714c6b794c4567742d4a73475f424e2d67516f444958527a567053444e4b70796f7a39787559475048395a5470574443595a30562d56636575624e546d616b6b3d	\N	f	5000.00	Teacher	0.0780	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	7f314b3eae6f21eda7b79966be34eb3d42dadd5220cf09b6d8fa9380ecda82ad	f	\N	{}	\N	0
92fdb13e-1b6a-4faf-8e4b-f08e35abb972	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-028	\\x6741414141414270304e5542334e745a482d4f674271676377546d476d5a79546a2d5654786b6b593041476d56573576627672744b4a47436f2d324d656355355279644945334c747249384656584f3351726c534333506a6248315561784d4533773d3d	\\x6741414141414270304e55425557494532666d77486b5379466b6b6477644877334c6953636a54654a4f4b635577714c677151552d76314f41746d4b2d685038583358463238774f68533361644a6e44495962596f545766644670315369363943474b345a4145307a596e774e6430376b41334769786f3d	\N	f	10000.00	Engineer	0.2206	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	333593ff67a8d1cb8cffe35744f4373e59e19cfdbceeac62d5ff0bb9c4f384c3	f	\N	{}	\N	0
6d11dd2d-ad27-45ef-b184-a90e384b74c3	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-029	\\x6741414141414270304e5542314c6a3846756f70663969694b375f41456a4d612d74584249486b3636734e42626b456d59516b617a6e6773547a664649464a414e48567568514a79397932485239336f696565345f4d793358497a31586b366976673d3d	\\x6741414141414270304e55424d72763376445a6a5a314c65623355776c42796e62546848514f31626969753542576a49313168465f555f5f4753355350732d4f4d716342724762445a4d5475644a4f6239384159724a587378686a5946395f376f47736d6449667736373570465435633965697359646f3d	\N	f	20000.00	Trader	0.2581	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	3b04eb5dd8114ef8ef5fa8f3f0806fbf81a67b5e08d1b87fbf58f77f92e3551a	f	\N	{}	\N	0
95ca8b98-bf42-4c78-bd9c-3aa870889d58	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-030	\\x6741414141414270304e55424a5a7847445470304433694c4e386959654d644f544f4a3165705745746a54384b4e2d3154726261674f63576e322d3564706a754461464975545936616a5867414469324f43794f43517234633133625530633457413d3d	\\x6741414141414270304e55426d547131674769554f394951556f617539696f6c5f5767557766517077523357304d47766b5068447749364c6650363070686c334d724446614165555061494f785553704e795a6452396d58374d3255735a4b69484a6b5267597a672d7436686e7657706a5a41554a66453d	\N	f	10000.00	\N	0.0800	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	3b1448864deee9b2b1850c5b31e2f2f6ba2be65a3afbeec77ab738831b062a24	f	\N	{}	\N	0
e42cb2f6-13f6-4b29-a930-0543c08bbed7	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-031	\\x6741414141414270304e5542304370513249794d37787776776f744175763875304a44645137316b33794d3450523447694856785036636d6155434d37586a5a6c31363961676f5972766c4b70694b7145424f595450777a2d6a6662524b766c44773d3d	\\x6741414141414270304e55424c6c5035506a556b3632692d652d504435416d3573616559544630335f303746744d6d35464f6351456873736f52786964546876654776544834794572384c6d53762d336947747a643947655a753970544e705f35415048574f53376c494735756961346e2d66554d426f3d	\N	f	10000.00	\N	0.0104	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	538f9116ad82f9993d9048f6c764247c3178bc4fa01be53890d35a26f70310ed	f	\N	{}	\N	0
ee74feb4-0404-4137-958f-02e7530e1f5b	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-032	\\x6741414141414270304e554265446751514968594c4b36702d437975792d4c787a414874615f505864354a616664524f4b6f436451622d365154616572715f70753954317735636e686d535841493775654e33547a62315f68714f46617a767570413d3d	\\x6741414141414270304e5542327142326156536b596c2d383141497a556977353047455f56454e5859426141724b55337141474e6572493976555874546c584d4532774d7579624c344d624b754d4f71346e2d6f53687076794d666e315546787754524c33555144695a424461504e4362423763634e303d	\N	f	2000.00	Trader	0.2126	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	8c28b0a22d8732c46439b2dae161037439c6f0c8201770cd1866db3e71dbd236	f	\N	{}	\N	0
654b1865-e431-4e9f-94fa-4eacb7488457	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-033	\\x6741414141414270304e55427166513676754d354c55363274725734744e77595a6c794833745563777367304648644e704a64616e374451734d774f544e544b765f4f414e584d7751537478364c6330675065494a3451585a50507a45442d7444773d3d	\\x6741414141414270304e55426e7268675156617359535465706c6e50586538365a3942646e7174714b424a4a3277493550774e714a793653514d657570506d6f6239654e58433068474b41544c355037496e45594f64416e6a786d71354754424f6635336f72375a34426d71455f6374315151313174773d	\N	f	5000.00	Teacher	0.2648	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	058b9b78327098a5c5e4f1c791ba28c3ac856429ed17dc96af4e42c295e5f17a	f	\N	{}	\N	0
974fea06-fcae-4e6d-ba06-fac8ec213222	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-034	\\x6741414141414270304e5542366e79556d38414f50392d496a4970454364634a656935363972776e35306b635172792d667142354848436d64695477324b6c6d49765541776f4f7a6c78704842645932354f7772575963454b4c55767a55774a5a673d3d	\\x6741414141414270304e554273713751756a4d547751645861634a344e433366634e68427a6a4741786a464a6a395a55386a5679316d3259377366615a3449486a524b6b73536358455a4472554d3265724730694f79394c61702d6a42513133514e424655455a4d314c544a5244616656687a5548556b3d	\N	f	\N	\N	0.1878	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	c892e76ca22e0a858c08c5c0dacf8e940e5adadb41940e721f8de9a0509b57eb	f	\N	{}	\N	0
8d0d610e-db16-4e7c-bda1-ceb62ad975a3	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-035	\\x6741414141414270304e554233674f374568553733304c737736564656533665394f35436c397556675055664a767a7938782d326b59737a3371513274586e4a63493439574f624b574668424a342d2d55387037746c5059336345557a72354741413d3d	\\x6741414141414270304e554279555636454c66614c7a5139326e6a6a6e7a4870666d49774255392d4f73655063766730795946326331594b307873327242476b37514636496964564d44706c346c4473375579417963345f64474c475f713558646176766775474b463734722d76774e4c2d30493259733d	\N	f	10000.00	Trader	0.1309	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	0d950305432509013a35c2b6c9f1a9d1b29f2b3738bd52f269c0e1cabbd5920b	f	\N	{}	\N	0
32118496-b6e1-4e62-a2ce-1f8c9ef081d1	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-036	\\x6741414141414270304e5542314445586f50594873335144385578635a5f335770707845316a515a4b38394d736a56536d766649676b3558396a5558745746742d4d386f6a327a6830464c4b5f45734259335663564a6c566f5667504c6a444179773d3d	\\x6741414141414270304e554251686d4f765351596b6e524c7069326a37724b724e49335f7850334d7046586d5244646d486853394d526c67534e58446f756d6147525f437432326c38476f34374e78716243616539504b39775a754878646837376657724c4655325f336c546d314b6a72705f754b69453d	\N	f	2000.00	\N	0.2214	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	58cf4af10f284e49116dcb4fe49c66239e259ad05821a5ae12d9ea2426b0dce8	f	\N	{}	\N	0
84e47ea8-6c33-43cd-b918-88710aef16bc	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-037	\\x6741414141414270304e55424454456f666173576567526a536430754655423833554d754c306278413676414537574130414e6a4a5978484f4a576a74354c3353383637344d717938486b694c796b5371325f6367393345716e4c706c6e412d4b773d3d	\\x6741414141414270304e5542515470774856707075536a677574494a416d7a686c444d45475264512d5731552d31745f36714f6a5f397135656649736a4a67547467634d50785756484435414c386f374735504446513575354f6c38594b7a4b304d364a656333534d52355f5950304b4f45574668414d3d	\N	f	2000.00	\N	0.2812	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	b8c0c688fcf3f539c63c6af0731aba6ddef2140bfd7595f1efb95713acb6c5bb	f	\N	{}	\N	0
623a5740-7913-415a-b1b6-8eb75db5d2f7	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-038	\\x6741414141414270304e554246453669774158726154756b383376325847306c586152725a78575151616c5575587a684a587451325a6c36436d7133635332414442726847702d4c6a384e446237635747743573354d5673516e73643036576963673d3d	\\x6741414141414270304e554269523962626455367630493662356853457a505a544e4d54505f64367934305f705142594c6653556441546470566f55556b525f654a414971324a556e5941424651367a4a42495a307647687946624356436254425137416e6b494c6b4f7451736937707941794f474f593d	\N	f	10000.00	Engineer	0.0692	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	f55b559c4759619dec5f0afbe9db6e0ad8e1b720128a20bd54061af464d42f35	f	\N	{}	\N	0
72772cee-340e-4f7d-9528-a2b67e35fbb4	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-039	\\x6741414141414270304e55423936437035426e53695a49553747614937734c6171474c387a793561554d385a7a6d70633852365143756250494265565a50786e682d4b4470352d6754754975554a646634577a4c7935415f5f636f64454a47414a673d3d	\\x6741414141414270304e554275524e567761433974705a357278317576365a357a6c45363159424a796574526c59596c65644464716a4849785434575363397443755a52356e4d663073495a4272466b544d757449647253583137463574646147633130536e76426a58474a5344776f4f4b6f6e6c38303d	\N	f	2000.00	Trader	0.2382	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	7e0467d0697172efc0f04b3e853827f419700e00a08cc18646b7f1d9f77a157b	f	\N	{}	\N	0
741dd2d9-fe33-4c72-b47b-2a467d7d40bf	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-040	\\x6741414141414270304e55424d564f546a756276774756587267615641324b346272414243466d557254445252493146645136785f697654307a716e53666f30714d4d467642306d6168385f305a6f63614e4332316e785a48473931344d696a69773d3d	\\x6741414141414270304e554273416a554e6250337632744747434e387932627a5672565532615955536c5846416b46715477505a653633524d745036512d31305a625a6f6566414e715444466955744335513853465a69467073375758353955574376426836367765384d6f3877784b4632755a3471493d	\N	f	2000.00	Trader	0.2189	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	718a5402a5e50a2e98bb3414c08eb9a8e0acd65668de245cb11ce71b14d2b4ed	f	\N	{}	\N	0
d446775c-d88e-4847-817f-0b9e76e91b78	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-041	\\x6741414141414270304e554243644c574434525f5a595866455f59373241504b38725a716b326268345f66704e5a5f515277665766424541383561367947317a6f5f6d6c7455526e41476247746a712d4379585141677866634f4645727661536b413d3d	\\x6741414141414270304e5542765a35676f664b6457577348467947756b4e4b335552573553694e51474e504a656a31717939577a5241384d30375a696a77564c6131675f483137726a494b5953526e73565059595646445f6e6f705578316b4c774b436332645a746d49354e4b3458596f73374a4165553d	\N	f	\N	\N	0.0781	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	9b054afe08d8a6b94a2737ee1a068fb4c6a3ff623b165f1c2564357d22add60d	f	\N	{}	\N	0
33891fe5-799d-41f9-8314-010d4d9cd9e0	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-042	\\x6741414141414270304e554276315f384f69556176757977386974734b79436e625f6b70376e68516d3633716b59506d67667169443955627768745554374c39546935543141633136786c657a31575958502d34344e56375355434f514235704a513d3d	\\x6741414141414270304e554231424b31465f2d6a467779616f4b58494734396158523777655035376f594367684572754a6a4376386a6d3875756a7a374d59526b436251436b49614875766a7557574d456252307373344e55645049345434716f58794c73425853735254484b5951526e576333436f553d	\N	f	20000.00	Engineer	0.2638	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	9f28d0456686ce6205ec5b97053ef2ff7319fc56b131db5f294b2300440cfec9	f	\N	{}	\N	0
54b8fef6-a6d3-4718-916f-6056a632cd34	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-043	\\x6741414141414270304e554235687156376255594b714741394355466361734e36703765755550664d3057566a585a7656302d377a38574c66534f6a55667975504d2d556c495150336367457961696a34446e5f34516d32333262386a43756e31673d3d	\\x6741414141414270304e5542536c46374e4c7873486b69683043326a6e3530574f57437747724339587172686d556851434d31642d7a565268484b7849776d62387564385f5478394452354445397a6f71776c6d55354275426b76394e745173644c4f306d487332754a7a793865725853756136736a303d	\N	f	20000.00	Trader	0.0937	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	72ccaaeef7767bc972b808fda329f141392206cefb5c846a8106fd0513e6f5be	f	\N	{}	\N	0
c812b83a-b1fe-4c27-ada3-dd33b21d84d9	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-044	\\x6741414141414270304e55425a5a30742d436e436837353038722d4b734572434130544f72354c7852524d57703256794639693977364e4b745a6165657834546d30454d496e5a6e5630564175796d48574e6459516469556e4c74665669344d4f513d3d	\\x6741414141414270304e5542765a307a7a313637786a784242796931675146465874586c345246324e3472457866755a6f6177584875304578626e49696549536b7935516a465a74636353392d507776566239325a5665617630304e536b6f527a676d414b564f3231614f4d69335977437a766f6c79493d	\N	f	10000.00	\N	0.2292	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	0a64b629f0474d0add422c12c91faf4053c95c598ea4294c331ac51f8696bbf6	f	\N	{}	\N	0
bc510585-dfe3-4f24-aa97-5a574adbb00d	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-045	\\x6741414141414270304e554272663771456178675f72763259382d70776157376a663432784f774e6d574a74544c746471733578356947714f38554d3055356136706954317370584e5478416d4a3961706646714868465169364b7a7378587463773d3d	\\x6741414141414270304e55424b4b42786153646546634638595a304d74737a34496f6945596b5037525668754d5f36704b62536a34564f644e644571386c494678436278586377457547327a555544587a70495f6e504b3732474733746d64556d49635a6c5056456d76786e4b596a44707777386759553d	\N	f	2000.00	Engineer	0.2508	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	e7833445a432553d13ccbdc4b9ec8bc41c1b2c5c06496c87117b73f549b2bfcf	f	\N	{}	\N	0
b941f387-ea4a-4374-9288-003872bfba13	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-046	\\x6741414141414270304e55424565614e4e324e7450465747583438646650435154456557416c6c7a724d2d5a7577677038666c4d59503230796361426c514635656b537450365944486267426d6e6b4c556c6873636d5539452d794f6641744141673d3d	\\x6741414141414270304e5542794d73656a485271765f4342302d535462495256395a5a6a305a33416a56687158757279797a4779465a4e3358475158455435436c595f61764c6343704964385a47515f702d35333751307257677342396a454e587848564c7173457069373172747679796f48394541633d	\N	f	10000.00	Teacher	0.1458	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	3efb651db791afeb39582f2d3eb2d40a673cce846e986e7d0fd679dbae00487b	f	\N	{}	\N	0
1a39793c-0e07-45db-9a01-95e93d14e3ea	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-047	\\x6741414141414270304e55424678456749506133554a47515831674358354f7249676b44397a307a477a7a613851394a7977506c373474756c35795748737953724b41395a736e58594248676776636c655f5475472d767a784646732d57753732673d3d	\\x6741414141414270304e5542354e5a587a6471764a51646a32324450634b536d384338647a4a4763325867695a546d6e383534676666723878703331662d46726134724a6c78525573466f377149593039753457467933666c6a6c46623445737057704f74744b6f655a395878453377386633524c4b773d	\N	f	10000.00	Teacher	0.0470	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	00fed658928a18f3a3fb52395aa1e07d76daa5dbf7b3c03151830dad0aac5694	f	\N	{}	\N	0
cc19fb0d-3b39-4364-a809-ca1c7dcd8340	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-048	\\x6741414141414270304e55423032763237384b516d70456f737432665446567a37696c633854364f4d785070323664593269697763476137515a665f71333667374d5f61584e53486737487a694e715231516f6d6b706d4f6b304d6d745743696c413d3d	\\x6741414141414270304e55427341327a502d675f344d5748677664676946524b47486b464d686148567a566d767161453479754c794643663437617441546872476435484c522d646862734642444c747653476b5078625f754a3338396c41505639646565636e554e373768337462337668776c6641453d	\N	f	10000.00	Trader	0.1897	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	c1c33ac71a998f82976208b74716be5380793b0651ebf4101171b5fbc42b907a	f	\N	{}	\N	0
2726fa5b-877b-4fb2-bc7a-59d89c515401	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-049	\\x6741414141414270304e5542326d50585744344e6f56754143764438645a4453375454653436374a6966684c323744416971456f4f5232646158557570545667547043545741317a38537369656f38376d794164435a462d6d5a4d4c62524c5948673d3d	\\x6741414141414270304e554256454c6831557250314244384f514d5165434430584d67306249546f54726241654d4d6d7854357579534970675454467a4c544b6c38656c7734514d4578353552685f52576452427064766f586378766c575258744a575372577555433652505f6856766a674a343054773d	\N	f	20000.00	Teacher	0.2336	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	e0df8ef5f33fc0aea326f168351e3d43a25ef0292f1f8f61debc995cf0b69ec2	f	\N	{}	\N	0
38ce26fb-0e29-4413-b425-0e4c1fae8ae5	40e341ad-cf4a-484b-9926-3d56cc58fa1f	EXT-OPERADOR_B-050	\\x6741414141414270304e55424f6868395f7a76525238564835476141394a7359593137435178394b486668422d4e793377356c73726f69557342523963794f6d494d493834446e46494e37467a42754259674635642d7849624676425647763065413d3d	\\x6741414141414270304e554252414a345f4e5a746558505833556c67515256324257426878643158536773325a4f6f7a3974486a426649366733545779755972306e34735958393156516754465f706c6a35597537755a597a586e645f6e6e7068366971516d6d5f38774836543759555448736774796f3d	\N	f	5000.00	\N	0.0886	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	ACTIVE	\N	LOW	94b24658fb2ef202e9a6ad7585d9c8ad5739a6a6abb1040174471404e55f1754	f	\N	{}	\N	0
4633153f-6cca-40b2-b0f7-30df770677ec	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-001	\\x6741414141414270304e55414d596c69636d7851594b503030494a7a37324b7744364171634b6b5047437a59467634595657732d504d683434686b477775754d5252494d6f4a62736f2d7976365643465f6a744e756b4f5463464a636a69504951773d3d	\\x6741414141414270304e554168315838546339304e4674477443746e486a6642535a6d3251726a4b7074763161667661615873726c706a6f626e4732466e34596a62666e346662415437354a653248365a716a776778746331634742435355346f5278536f77306f7632737676722d454174673937796f3d	\N	t	2000.00	\N	0.3000	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	c94797656091d350019dd8d99393138599dc10824b5c71b79d37e08817a12b92	f	\N	{}	\N	0
464e8bab-c13c-4d14-b512-f008f997e437	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-002	\\x6741414141414270304e5541504d6853564b314649377733736b616877766f765049464d4367516d484e495851444c554f4c414c696c47674c4b42796436514b4c45696748437463547a6a70444f524a71316c375f546642536a7a6d44506d6e71513d3d	\\x6741414141414270304e55414872654d6f2d424350697371586f2d796d6b316f664932667638517571697964546569323450736d6b6c73775949524952416f413557766f34712d674e5377544f45734b657433567133374d55436c71354a4151354b4733377567535a7249657954616d615f436b6666343d	\N	t	10000.00	\N	0.3036	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	c0fcdb3a1706738921a60056601782c6ef9ec7dc614bfb017bc7528fa5f4fb03	f	\N	{}	\N	0
d5bcf2ee-3cce-4588-b12f-fac85a059270	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-003	\\x6741414141414270304e5541773257463943673272305f6d4e617259595548677478687037366c6c3457316130786f53763855305438764a5139364462536b6c44794d69746d335673653870487865365a697566536564564836344c6942483745513d3d	\\x6741414141414270304e5541627467456c57376e5937597949516c5967665852394577335450576e7779535972533650654c58766f4d3551545858772d624c472d58325a796b3441346454746a316f307731442d5a384d4f4556463668776e53647a454c745664436f6d5f335463456577385138695f6f3d	\N	t	\N	\N	0.3000	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	9f8b50d7f585d9536cd03a9011134ca577bc7de6711346716e688bfb3cb30696	f	\N	{}	\N	0
144de474-f551-4a16-9497-cc9307d98461	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-004	\\x6741414141414270304e55416841725f69614d36343643655a53585050676a554c647a694652677770743431674156425673533949476a3838585173654878506d7a6b514a545465634873626b68452d6d41462d747a3242345256344952554553513d3d	\\x6741414141414270304e554143644d6646386b63574961474978644a5854652d6737615276512d377258387a6344665f467458704270536c394d435046716c533476795042346a4664365230425231474450665a42347436663965734e377a4a5654745155594c3353795643686478647a4c71776468733d	\N	f	20000.00	Trader	0.7640	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	645a0691ba6d0545846ac81c871ee40df4a36480ec57158a11b1bff52c6ca65b	f	\N	{}	\N	0
2cda0391-69a4-45af-a1ba-8ad624b51c43	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-005	\\x6741414141414270304e5541525551364a42524c77397a48536957314a5a67665a5854346c675055765476707144484a4c5f71714963787550624f423873683264436f3942714a34686366704364496f7076316b436a4d4853424c6c4562767942673d3d	\\x6741414141414270304e5541654169324d4461666165534344456e5079445a3448315155306a4a6c4844317974686d5554362d6b626d7544525243362d31614f47617071316443765f5936497a5f6d7343783566655352645a4777494f504f5342484c526c4f4f4776737647544b6c64495535676466513d	\N	f	2000.00	Teacher	0.0192	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	566eb095b125df5e5d91634631da82e47e6533155b703882d1f61d9c20042b40	f	\N	{}	\N	0
b5efeae4-6e9c-4201-82ff-ac5ba7b1a51d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-006	\\x6741414141414270304e554153564b315f61622d32676c52612d41323144793244477372635a79584747367553333567327678734f6f5432754e795f6351635756716f35346a7570316c5669704a6339794256374e444e7170655666636a5f3561673d3d	\\x6741414141414270304e554146704470734e61674d6e564353342d6c414a5555626c544547334d46745f646a76316763343952384c367a4a6861785564555934747658424955436b384f645358696632585a7161544e4437547933723534655437705a7a47434658437854425a776835736149514c65453d	\N	f	10000.00	Engineer	0.1241	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	0476e1b5caeca5f935aaa637cc98e5d0897363cc4675e55427dd7dffa3a4453a	f	\N	{}	\N	0
ed9d7124-7a13-4483-beb1-aba17781ba65	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-007	\\x6741414141414270304e55413144585849623261526b4a55535a5f507a33756d615756677a727269703736717763623663494151377a743258616145444c683254636a6e64544a3844394251477a4c646657484157356c4e52366258302d447157513d3d	\\x6741414141414270304e55414353516c486a61757356327167397344714579325973434f356c43496b5f674c497a79324a655f7468564159414e6242786f51574d68444361645f6365743462674131687943363257636463336e4f3643696a5971324a4e575261643875485144536d5447357a33524e633d	\N	f	2000.00	Teacher	0.1988	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	f10455b548e25c36e8160f22f96221a930f95832fcd76307a68be6d18f345c42	f	\N	{}	\N	0
57de7bbc-286b-4bbc-bedb-cfd5efc713aa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-008	\\x6741414141414270304e55416271485f30764361425152326a6a6f58776e6d546c585530596d50533037312d4354726f7072766f4c50697249486c3276392d724763625f50345a4f624c4b2d5467736265414e4432577a45477937587254644d2d413d3d	\\x6741414141414270304e554173796a4b45636d696d564867696b746837506535597a6b686b544f713846675730653837796d5f5a387476504641657a66444433466436754339376a4b4c50674758525165342d356b5962424a61446835737352686f54756f5a5a5f62334a3165506b4d6d6142776745593d	\N	f	20000.00	Engineer	0.0999	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	ed09db182316ce9dda9802f654441e278820f4f510d46464220ccc149512251c	f	\N	{}	\N	0
59bf7724-e9cb-4cff-af7f-9c602560ff36	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-009	\\x6741414141414270304e5541723076494454754278766f374d4e72584b446e4c66396658754d62472d57785745343666484f5a694141505334424a657366706650514d536667373133365050774a486149464c585a6a4a4a7a2d4a66686b633169773d3d	\\x6741414141414270304e5541446379686d4b73703239446f444b76426b674f54516c78346b2d617047376563312d5f6a6b3170714b30715751434261784d78643045464936424b7a365f38796c5232562d6e5768424d5a50657649796a68346c6a532d384735572d345f484434737537496a394c4c65553d	\N	f	20000.00	\N	0.0255	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	61fed5918347589f0beacc903c246e9205b0eb3558b17df24c54983e7469d46b	f	\N	{}	\N	0
390d4498-d1cb-48ef-869a-2e1781a0afc4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-010	\\x6741414141414270304e55413372717655752d6c615433323646356639734f6453737a4b3063324c412d65482d53344c6550317838645a624866644f676f4f2d466355772d3447684f5267325a3572577a4c68797679354c415456345179716758513d3d	\\x6741414141414270304e55416374585a42674636464a523643666d6f50556c454e50415246556b4d6d64325a5855673658667541544b5144677450366d563463494d6b5544476e5f694c5f696d3474434e624751476e4e65636b6f6a5158316464567872494735727948673636312d66796651476254513d	\N	f	5000.00	Trader	0.0246	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	b767979a95d8c7ac6335df2293eb1355250d9fc8697060d32d2ac553311d4248	f	\N	{}	\N	0
f715c098-933e-466a-9554-a6a04e96162f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-011	\\x6741414141414270304e5541537749515f316c745170384432646262426f4b414e4755446f4145534552664d37576e646c6377627038594a6762536a48735252586b724e305f49636b2d65593356566972374f6b61415a4a775936365f386f6979673d3d	\\x6741414141414270304e5541772d5470446b6761674957555051326b437a5031574c7a7335333837526658594b7557453936687352676d3467694d4775535245593472576a4838686e31585352536f77623277344b7130326136525141644436415379762d686f53644e516a5136684455497a5a4f70413d	\N	f	10000.00	Trader	0.0936	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	fc96baf0539ac2aad7180da73b9c9ca5bff7388e7d813bd654cf05c8e0633779	f	\N	{}	\N	0
bd82739d-cb10-4d31-bb9c-ee8cabe21881	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-012	\\x6741414141414270304e5541526d4a5968567a43665156384c3333573465346536464d544179316174735430397744795736544d6d576e43557573466b734f634170685270306475466a5377627a683867303634536d78595554484d73314f586f513d3d	\\x6741414141414270304e5541416a6632596d4a416c7a6c4941717136556d735332494e6778357765525356317a5735716170436d6250574d77704b4350726c414d326d53613578395938576263527a6e6537775a4571594c496e7544634b526c7432524a7146424c5242786d596d714c654f766f4347553d	\N	f	5000.00	\N	0.2169	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	6a7235967437de79d0d045fb23a4d2a9d99a565dcb47c2eb579fdcff53b77c38	f	\N	{}	\N	0
4a98014d-2a51-4be8-96a9-e9aed146fefe	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-013	\\x6741414141414270304e554144696b6d72736c45774462484b556e744c5f6a31754c4c79754f514c45735f49483878353134594548616a59747739506f33486179455a6c33692d4b707365756e6d564c34764455455052364667466c4b51344630773d3d	\\x6741414141414270304e55416d717146625f5970666b34774434724a4f384e4438426b494546385441776159345a71455a393138514a52656f514b483545387777744b775053384259426d70416842305f39414e332d45334d326f387157686b733172526276546e75674a49556d47324f647a506850553d	\N	f	\N	Teacher	0.0724	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	3d956ac76decb65314c5cd66cbab98dd5a42e052141c770db3e3c5b2b3411af3	f	\N	{}	\N	0
49769e58-fff5-4c0c-b67b-38f1fb55e1dd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-014	\\x6741414141414270304e55414453414c6d43673853564f636a5669687268674f5f32795a4635307a69386c315879596259374a373771644c4b335a337a495f6f37787070566e51416375665055742d35685259464668586b7773635f6e566e765a773d3d	\\x6741414141414270304e55416164453173782d334d685f59777a37422d55316d7770655973577a2d76315356545f5f4f4b3854417861555069476e583230745645677347775f452d7572537a467a3554696c654b326b65516f544d37674b39554c5645436e4f6969666b5670414b7378436d4e68486c493d	\N	f	2000.00	\N	0.0210	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	d8371e502392d3159a208917a7c095c583fc57dfb95031a3d346d9870c75cc06	f	\N	{}	\N	0
c3003d37-554a-43b3-ae9b-7b0dbbf4c786	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-015	\\x6741414141414270304e5541624231785f3870737675654247334d5a726a4f55537a6e3776784476674f57576a7762724159647251446968386a44423653593959766d4c7573355454746d6e4a5f4f665157644148694c7442456f545373723543673d3d	\\x6741414141414270304e55413273785a643151646f78364e5355506842535932792d332d6a61695744504761766a6d596d365954384e354977372d3477397766465a582d766246736d4b646d67386c7235745a75394f326c42424b6841473047435971555974374848686f656a4a6965624251766938673d	\N	f	10000.00	\N	0.1261	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	8c8faa382e4f42f8a6fb52590e0bde487f15189fce138c026e1c349fabfceb44	f	\N	{}	\N	0
f6e84129-2254-4b4b-9a61-b5f13e723d10	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-016	\\x6741414141414270304e5541333653566565735737776f317451553754695968717771742d494579422d4c76364862496b32663647455a635a637642726f3652766938506b56555255684d34734d347965634878506947684538792d6533433732673d3d	\\x6741414141414270304e55416e79726c774c3848424e6f444d5f716e33546e5f326962695667474a59705745464a4457583274666a55503535367549427078797556523734744159445150794161773931445873424842686f7a6a427142705143612d374d7a72664d736754614d7162627359506d4b513d	\N	f	10000.00	\N	0.0474	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	c00df4920eb24e5b776b748ced690dec91166485a43e5c9c0b974db247a16463	f	\N	{}	\N	0
cc758c21-3a97-4074-9ad5-d9739b95ba92	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-017	\\x6741414141414270304e5541594770796c796f4e56634d776231786e6362484b33445f6d4e5935724e456a306c66567772325f39356d58554b39524e52636e53763544673569413273344b58414d46484c6c705052714559493966566f70626874513d3d	\\x6741414141414270304e55414c3734744d666f544f314f4975356645486d55356649545a47315a764f4f637161534361302d784e556232675179544d7564457871355877536358594d395f5246714c4556645741303771305549414f423138414a38674965334647714f46736d52624d48547645444f773d	\N	f	\N	\N	0.2087	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	e08ba3ccadc4498fe21b6d67666eba7e8059c38b78f3a77dfebdf73648f98486	f	\N	{}	\N	0
c6bc3a6f-0620-4e22-9686-5dfb2bf07e22	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-018	\\x6741414141414270304e554139754d4e6d6d464572336e4435575a355952376f6a58674d497245743278387446795958694749496b794f666c74676354755066784367434c4a36747054656d46324e6834645a56436e33536168506d6e594e4f49673d3d	\\x6741414141414270304e554145736d6c6a5775766c77585f792d58532d736d567564564d684f2d4656646a666e75683043356637437a385149353070764c7156737464635639736e544e5375445559633465642d68756b674a71414564754f4b4c6d467a5677526a62586f703039485f66355f35696b513d	\N	f	\N	\N	0.0162	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	998c1c3131c005ade4f5ad9b77253b0def04c6fe5b2f24fe937e976b39bf4f13	f	\N	{}	\N	0
236e9da4-70ba-4956-aaaf-ad8ded9d4204	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-019	\\x6741414141414270304e55415f6935305273776c426e523253304738467166734b6d71507874567735445446624d686832326e5a3148485161684e61484a776f6e324a786855594b39673156383262776a32743850382d613159704f384876466c773d3d	\\x6741414141414270304e55415a54557a373256343138774144616551646176435162496b435a30474a307874677334456863637246466349704161674d744a464f73316652357a4969476d6d766b3338466c5941316d45426552342d55616a4a465a5f3935565767386944514639786f585745327858453d	\N	f	10000.00	\N	0.0785	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	e944380eb2c95a3c07d294968f733a9e1eec3720459dba9147d089ebf31a11fd	f	\N	{}	\N	0
83bb0f34-7864-45ea-aa96-67519cc494ac	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-020	\\x6741414141414270304e554174366c6a7451317a4c67784661776b33304465705a726271785048422d74465442696b62344735566270445271785672732d4c657749663378676d63776644516b3162547368344f6479626e64544a4d32752d3875413d3d	\\x6741414141414270304e554179706244305562704c35694f644b6338594747486f38776a4a52316f794e426f7137724a693748554a444d7567786b384e37455471446e78593649615f74743730684d6b50655a423477504e5264626863596669535a4a6c446c4f6e376c493037444a575f5131543267733d	\N	f	20000.00	\N	0.2538	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	f15b89e2e90a812d26600e0704207df4ac96745a7d702a7100976f020f5eeca2	f	\N	{}	\N	0
0c5c4323-2124-4ca0-b6ac-9b99fb60c69b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-021	\\x6741414141414270304e55416449554d4a343353455570654f4237625247494f6267754934744f464963505a5f77377661774979334a304f3358736b2d65436578704f5136444965556a724d38433257483536314569516f667268396242747339413d3d	\\x6741414141414270304e55414272764b353231305230726a6330343258625a63596f7569304856325972314d7a544f37516465345875446a6246734651435248664456584f5a56627742786a38716e43425238536773767669434532566630784f494c2d547a4e6c33354f5f6b50366533773161584d303d	\N	f	5000.00	Teacher	0.1513	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	ee6da8e8fbf93d998ff1a716f3e73f2d13349cb6c416460d9d22d58f69434c86	f	\N	{}	\N	0
740d1ef4-80e8-483c-a21b-41ccc34d5456	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-022	\\x6741414141414270304e55415f57366d30593955506170507a3061716b524a73436f41567859676975704c6d46446e3833336f636a3151594c31373871705f486e7646526a614942414b3551664231595f474c79584536677a727551755874355f513d3d	\\x6741414141414270304e5541314f336872743643315a6c4d6b4c726d48574a4376564b79314f65352d45445a713348425159466a465361395470655a4a657769392d596a457a5139546864495a3863787a70364f4a3656586865776f5a4d584c6d577337364b2d5150587a5431333872743258615834553d	\N	f	10000.00	Trader	0.1489	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	3fc3eb77cb9c2c86da8fecf67228adfe384fe12bcdcb999267fe1270e317726a	f	\N	{}	\N	0
7fa3178e-f1ee-47c5-80fd-bef10179eeb6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-023	\\x6741414141414270304e5541745a4b63417830546c685344543532347a2d652d704e576a71744f7077515f646f617138746b37556b624f4e3534477a46326a484e736f475849692d327039383954376e4c5f77504669687a516c56305157686a77773d3d	\\x6741414141414270304e55416553545a536b32526f7653716e53584c544f435135484753395964384c5164325a6f784c6e474a346b75364b4a356a7966756176416850567054516d66344134443639637378487362336d30374f3958727042447376595231752d4a785f4561596730383672487956354d3d	\N	f	\N	Teacher	0.0631	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	69c4b8d98e3db326c2c1ff2f4ef90608f9ed7f81c5fef65039c34f7db22db2d7	f	\N	{}	\N	0
6cccea33-25c5-4cc1-8864-23bc303afda4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-024	\\x6741414141414270304e554147763869626c4f6a6f6b37614e516261466176566f446663715457354765764b38686d34616873784237594a787a6a4b3042714571553761494e3761757664483932416f6f487446336b44446b75784f6961586371513d3d	\\x6741414141414270304e55414d67317377337a536f4b656c587266414c676a7a5353777a685048516c70496263756351636f71594b58675f67564a435273436861706c76454b3239734d685a2d753131626e4b787a6e66376a50385535524f6c7741706e37703957633342306b594f346d5070415934343d	\N	f	10000.00	Engineer	0.0254	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	919092898863859c805b420a5a6615438c8980d9e0e38fd51fd376e26f109380	f	\N	{}	\N	0
46dff2c5-594c-45e5-8273-1d3dbd459399	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-025	\\x6741414141414270304e5541426c72436673696d64515f453367497875475f334b756333566a316d6534726f757631657830744172444e7375696a754c33634b78323749784b366f614e566358356c523849396d2d4a3935572d4a42594b386d5f773d3d	\\x6741414141414270304e5541544e4a59437474644a775a636457695f433852384b47724c4658306a36756f637667675133346a706f4c6a52346651764a514f5f356d48394439737451664e70487062457a614738724659435344495256376d6b495f6c435873517457743768756f76755557666e4367673d	\N	f	20000.00	Teacher	0.2292	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	f3f05e20c04f9834a99c7202ba319e841aadfe9e2792d8652310ea92a8d6c19e	f	\N	{}	\N	0
f8f48c30-b524-47d0-a495-f87f47968470	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-026	\\x6741414141414270304e55416e35715832764b527244724273344b67736f51714a7a4b343465633079676b67534f6d59536663434661336149354d784a4f48327a45373750677568474c33494d6a78447167502d6335666f747443545146485461513d3d	\\x6741414141414270304e5541784a7979715275436956342d7574467156415172577147756f623746737067467168646f31484d5162514666536730373163645f36784637676b49416338685953744a694236453158507452467962434a4171776f4f466b51394a595234784e4950774653593176784c513d	\N	f	20000.00	\N	0.2696	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	98b1fa3bd554cb6114801bf0b1bfb4a7f837347c63bc96fb4bc5501f8057827f	f	\N	{}	\N	0
9f6f12e8-c86a-426b-a876-be5967ea6516	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-027	\\x6741414141414270304e554172715a357450656c385f423659353369524a72744448675a6a324374797671556b754d54525f4149544f6d6a5078765f61586530742d48664b49324734325a4470397642773959315261707a447269745262666333773d3d	\\x6741414141414270304e55416a342d3064515a62693571424d453247396b336e49754a534974465649364a52656363734d56646d5443587158464b71316d7a7554367764554b6e4d745575417366524d51425f525a526e6177575a6b435765685f394949303556423635666d3141774c4d54345a3463673d	\N	f	\N	Teacher	0.0996	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	660b29da2d23b538d5ba16f15a16af65c3ccf257a1eac57a6c172aedd00519bb	f	\N	{}	\N	0
98ef6f0d-ff1b-42fc-94c9-b1f82eaf16f7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-028	\\x6741414141414270304e5541316d643376334150397a79524365626f4153786f357a4d4a677631384f5149687578366643416e594a5363625a4241454438666f596875706d463547756f64767259526f5254354f6a53747148567a34733877576f413d3d	\\x6741414141414270304e55416350553772626e64424e56486b79656d416d364a4e42494d7044794c685655572d5735503544575464665f385a3452315a657a2d4a654e6b4e46324175457055646b68617a67784544364644745a774455374e4a5f32554251447157446931785836395f314a61385a4b383d	\N	f	5000.00	Trader	0.0147	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	56c44b03d17d622eecb858f501e5c59597b5f8198a92ba626827215db1be4811	f	\N	{}	\N	0
37e6775c-f310-4bc3-bb55-625bd697effe	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-029	\\x6741414141414270304e5541755f4850756273393449587841627158366839412d7959644e70715742315f6c363952316738684d4637373675366b4e374a62704354576d647163326d6b59465f78464b73444c77456f435966364b6539786a2d4a413d3d	\\x6741414141414270304e5541424b7a78515a5a4362656c37676f7272434d64777851323579644a716e4a4a554739436a56627a4155476772554f4c32617936706c4d4d77714c57696a314732663741784f49517167526675735a53375737782d4b58586e3564795a6d574678696b30435f4b394a7076733d	\N	f	10000.00	Engineer	0.1733	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	b72443e4dc4d476f1eba12bab532a22830eb3f419eac9bcf81aa7279f024225d	f	\N	{}	\N	0
fc97de3a-3dc6-48b9-8189-4b5325f7eba8	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-030	\\x6741414141414270304e5541713467696741307537316a78784751525f4d4170366944316d467073414a33414831436e304c616c6a53624a486e447636695049734e577062754e4f454a577332386a37436571505f633858623232576a44586f52413d3d	\\x6741414141414270304e5541542d437a746e6d4564476c6f634b564e58754b66463547774b724530475f6461716143626f5748506f5f4c3744764e486d774f64573975786a4a636471493239713150736c38495759307a7541744272397543303650315f39623072484b417439445a30744d75565659303d	\N	f	20000.00	\N	0.0100	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	9016b429f2f8afe2e7fd1d8cae74465870144e950d6ad6c8886c3abab0441190	f	\N	{}	\N	0
185e3ef9-2067-4db9-85a2-3d54035bdec5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-031	\\x6741414141414270304e554137695564617965332d6f325f47624b6d58793678743537754f697645766f4d6f685778467a344e5a61316773664969784d7779754e346f5734493531586d597542373041433262674a4359764b5666576d42765f5a673d3d	\\x6741414141414270304e5541525645716f6757305148367367792d4c64597a35785a516759377a516748485643683176306764366b305f68334173433870586a5f545f337248373942333436783738675f6a594e714f5f317565325138543934346d524938336e4974736676394669316b545979416b593d	\N	f	5000.00	Engineer	0.0317	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	cf486838a3cdffeb5f5f81604dcbe62870b01bbe2507c3d90b9403c2191c7c43	f	\N	{}	\N	0
f42d1c18-11f8-427c-b31c-008bb2294c06	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-032	\\x6741414141414270304e554163573573676d5039486b72726f327641623679625367645273724971595f4b536d5256503647584876666458434473784d2d544b786d6a4b7344472d504369395475696377613055347770734b5f4e7079696e5576513d3d	\\x6741414141414270304e55415a556648667272755930576b546349356a6b64753550344539626d5336354437533442774a4268414e537338455a49317237543574594b584248527131394171645a634e6c743655344d39515479315a75756f415a474b4736683663766b616f6b59424d755630476338453d	\N	f	\N	\N	0.1225	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	6b2abef45d3a79beb5bd73133c159ae018c81efcfcf9883693c83ff1e04501fc	f	\N	{}	\N	0
7198c27f-2bd6-41a9-a907-22f6d17508fd	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-033	\\x6741414141414270304e55416b6f764b5f695368745143415a4e526a6f3052577876684269363659375f524d63696c4c796b4c615932755848644347754a5f74564f6230646d4d5476465674302d436232316574435834494f4e4f4a634f546d38773d3d	\\x6741414141414270304e55417765783549575851433137505f65624d59664f6c66744c6b6a775848486a2d637a465a50756e4d7a324c5437755172435744563275786566753255556c46526767684d4d2d5333536f417175614a4e6964774e786f336449357a4f456e71497871557435664c584a5f53513d	\N	f	\N	Engineer	0.2673	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	10111fc62a3efbadf34852716a04cc6a100f3019f03c6a73fe5b6cc60110fb1f	f	\N	{}	\N	0
3fa9fe86-85db-4d38-812c-d36ec7ac456c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-034	\\x6741414141414270304e554150795a7a6d626b4a30667a695a6b2d636a5142785668594b6a4a6f7279556e63306b3779544f6c33477166307939642d756e504d3356544166776e414765445f653249666b4c39334d6d5f7a4a3833436d73416774673d3d	\\x6741414141414270304e55416f5339526a7a615a4965666d6d6a3762514d36665943706a55484c365741352d674a6463357274634b634875336c615f58485f694e6972325f4a3036677a69386b7349784c484973493073426b784f6537316874526b75616e4f686151437275545237473456646b6b59493d	\N	f	2000.00	\N	0.0125	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	57bbc9b61a11e9a34b5c09a982d9e0f05fe11b718f82d647e34a87513236069b	f	\N	{}	\N	0
4281e7a6-dea9-4402-b7f9-360a176b76c4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-035	\\x6741414141414270304e55415335684871414b4f383558346d785a53734435477a37544a736f575f7137497538707938456a646c6a7a70345930765a35356c717a7a544a564b4e5574584764314e387543436a385546734d334936333265625632413d3d	\\x6741414141414270304e55413875615749635239574f634c4b756c58476f586b75773956754f4849616a5251393375486f545346643238574c5f4f30644251373951665f2d52484a5877764233794163744b30305f4f70417154623569344c505048326a4a30627942556b5f757a31346f3276435973413d	\N	f	10000.00	Teacher	0.1664	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	cfd954e722d683bbf8067ef173320089a59f0b5fc4d8c3cd45f207f7b3989641	f	\N	{}	\N	0
bfa14c25-ca7d-4e46-91cd-fc76addb7483	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-036	\\x6741414141414270304e55414855334f464257646e4931335469324d536d56525a4f4c7a36435031636c66426542464a457675346c424974457230346e53793174476f5432374e4c762d636f6f4f72626a4454574e37326f305f4a777163624243773d3d	\\x6741414141414270304e55415858445941347934334c34426645646d7930554e335872585131504633625a4233576f447741586864534946446d776e746c374b4c6f62346a306a3163755374414d665162464d4948786e546f485555745a636a32304d5772516257797a7064466e3463434462455072303d	\N	f	\N	Trader	0.0405	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	6d091a2d7daeb298f9b48dbab584392b594d838c0121d32026d6acec99c04eb9	f	\N	{}	\N	0
36ea0edb-ea8c-4f9b-8ba4-18042f35e6be	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-037	\\x6741414141414270304e5541747a6d69457562566558432d4c474852515631666949513249696832496e4a4d375231632d6c4f6e56574f54487556307944676d53684a41506b6a306c665737676f463841386c57685a5f5f2d505437767752647a673d3d	\\x6741414141414270304e554167475738783855326a752d6e534a56527943305561776c4a4a43484a46516c6d6131555052376843486d766c387934775a7557646854796f4a2d65466638653853305831377959444570494d30636c553262475a3347504236433076634679374f5558794475572d7250773d	\N	f	2000.00	Teacher	0.0302	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	af638bfe220ef5891d6358159f2aa80cfc6b912252fd415441e7e984fb004dc4	f	\N	{}	\N	0
f2fd7c99-b403-4e05-8be2-126a7c1a92d9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-038	\\x6741414141414270304e554172475a6856675078716175454678617a777a34554662394e706b3242624c78796b6779704d646b4973696355625a304b7056726e647575344937426d75506575626d733042503041726f695a784f45545469507462673d3d	\\x6741414141414270304e5541793065513078517056307573536142355459457969783744642d5f654f416e306670786f794a557a5f355144356c327134595868702d715957616c31793969434f6a7241414f556a6d6438666a7538576b39415074484655344d3063395f6b302d4138575f35674e4a79513d	\N	f	20000.00	Teacher	0.2764	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	7f9e915395cc597195da08656e3e5826a4ca7c8a6525fa32566216fd2750909d	f	\N	{}	\N	0
c95bd7ab-c683-462e-bbf4-7281f86b9a8b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-039	\\x6741414141414270304e5541596c414b57416d766e5f694a346145446b6377644b4271733870564a664d6e643259485458304e324c4c6f5355536e357545337546436434336f5f6263647951695773653741374d536a4870517a57343946525430773d3d	\\x6741414141414270304e55416239476f50544b2d49766b6b447363364d384b7973575454794f72574d69356331676f31737844356f64683830796e36414c686470765275783939445863522d79475a6f744b426954635845796d6b54346b367663454e6574324839767953774252474e7477355a766c513d	\N	f	20000.00	Engineer	0.2802	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	e6934462cd1bc547bafb21b602d588f7dcc03a08893fa309ded53860d429c2d5	f	\N	{}	\N	0
bd0f3f24-a8ef-41ce-98a3-3952f121ccbb	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-040	\\x6741414141414270304e5541726d53573659517a5f44366a3834484d6e62655f78744155536f72536f46674e4c6a6a6b6b3730794e6d436b524967562d595f6a683652615057786d543774655931744a7473595856524345324d48755165744d6e513d3d	\\x6741414141414270304e554132483261656d44527a3847617570715a7a7a6954573952665f69537537485632516b4237485731326e4377554f654667764b7977536837797a50755555616172564b552d6d7443394a717375587a547858636b4b5868786b6a773444344a614762337942465949797950673d	\N	f	20000.00	Engineer	0.0413	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	0a1aa6fbc4e583388b0038609dd9cd2168b0b4c7f07f412161acd47e75b57a4a	f	\N	{}	\N	0
281b10bc-cc72-4db0-be40-088f407d4c17	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-041	\\x6741414141414270304e55412d492d5a7433354f4146784b324b3456344c6949345148317a59325f366e76644a374567427a724736723765414d5f756f6a6c3450695a356e4c72654a5f7a50577644374748626c7958326270655f4f6c32555055773d3d	\\x6741414141414270304e5541676e4e53714e6f37626964766337326547776f467042722d6d70513746796333556b7135426f6f4b365145346f344d4b4a6354384e454b4d35615330575361326a574c7a562d51576f587670317869386155786a544d65484f73397579435134374131644c664a47596d343d	\N	f	5000.00	Engineer	0.2075	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	8551a400c4feffef5e9941d5589a67c29e7c25e7289abffb59b66a9f1395a821	f	\N	{}	\N	0
369da274-67fa-4eb5-a07c-149352bebd52	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-042	\\x6741414141414270304e55416238486949727838774841534b6c4b746f395a7167624c727464684b48666d554272364b42483539706b6f436943515f336b655a33786f785539564a6b347459787835375561543676757763585161576d4f2d4155773d3d	\\x6741414141414270304e55417675682d56797774306f704c4a755f754444645f38564f634f7564704b787544354c75654651706d41343244346f30674879622d4542496665614e616b6c5f715f3337663642586b50333277464474354a36556c5a6847384854734b337672376e6f38794376497a4a72553d	\N	f	5000.00	Teacher	0.2264	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	4545c10a3b7ff8f2a1e5786310e16f0ee0bc9716af68f09f4ca3f58b85bc6603	f	\N	{}	\N	0
8b3173ae-09e2-4ec1-b4c6-7eb547feff60	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-043	\\x6741414141414270304e55413656445f743379396236742d714642485f4170794637676c475850414954597863483776664d386f56465247475f667a6354724c664741334e3362613148336f6368785641692d576b65374d6c396a6f65346d6d54773d3d	\\x6741414141414270304e55417845366c64514e7263544b674f5a664533477365763731435f6d54465750516b426f6250335f485f644c7a6a7a542d45645637574b6179393039464c69715078376246354e716d45513759484775577177656b7a507552546b55683558487778664a49377a494a305f4b4d3d	\N	f	10000.00	\N	0.1882	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	ffd439da797128654b4897c0998dd5c1bb4f6e402995b42532a9cc17c4c0d4b6	f	\N	{}	\N	0
2c81f247-7e3f-4f9f-9d29-2cafd06f0366	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-044	\\x6741414141414270304e5541734c6c683946496e536c4b56594d3557356c7676756377647867646657674d4b3256644f4448666e6d6b2d6d684272485251474d4551545a515673656330614c52694478766d4e4b504f7377316f63686f6e483965773d3d	\\x6741414141414270304e5541514b47552d32725a524d4f3342696838354a434970365379515130385f5645646a6647545243365245527750594f635634522d666274454677584e6a72363143697a72485a424b755530774e533948764668562d78776f65796c4d4b54566c42452d7276636b7a6f3750303d	\N	f	20000.00	\N	0.1089	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	d8d31fb54200dbc70cf460c131523b30b07427eae930621bdcb8cbc9cfb349fc	f	\N	{}	\N	0
a3b2f9b7-7718-4195-9cdf-558c222258f9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-045	\\x6741414141414270304e5541536a5471385672414b4f754c4f656d466b5864586174456c635a4e5861416e596449744336595579562d536d6350796e6847576c344f7a735643456f4f4b724e524e5673394571746f6b6f633842566671644e6b44513d3d	\\x6741414141414270304e554137314c6c73766c4747786b63576846466e51506f4d5931573970624f455f694365545a33536f4a6c59725639636d4f762d4f707752794946686f6b325f732d4b7479794e2d4d365874334466417861467a4a64433570715a4f304762494f7561614f4843545930796266303d	\N	f	10000.00	\N	0.0760	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	40792d0c09ad03af3f627d3d1e67a548af495893d95acce03d3138b90508a68c	f	\N	{}	\N	0
602ea0f8-b754-4d5b-a568-3a3581b1939d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-046	\\x6741414141414270304e5541724675652d36326d58494a665471385f64674a78345a7850774e42504c58636f734f52356d36526d4f674538334f77694f4e674e43466344596a39357173365a4a4a30436f67734c5334567a5a5439536b49766c6f773d3d	\\x6741414141414270304e55414d34744150445975424b5130546255702d72774958512d7950354564534e5149566e75755046724a6352705558417565394147786f635f6d61337076674876415a50497352776476365a526e4d473341677050416a5a46747a6a5837707449346e507778416c47454849413d	\N	f	5000.00	Teacher	0.0952	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	5e63fce07dc9c34831ae12e6226f515a213fd58e83b859ae78e475cf813acc7b	f	\N	{}	\N	0
6f890e39-a39e-416c-9b4d-f0f81db271ca	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-047	\\x6741414141414270304e55414473316d766a4a6770754e4e4b434e66552d5871424e367974453956744737627a544f625f5178596332446a386374754934655573734d503251645a6c43544a43423045663261725f4e3836365a2d465f63456e49773d3d	\\x6741414141414270304e554171575641734934625a2d7632644a657a4e56345869563453414b6d79484a7638484156556b4457742d30424c4b354b744665523868526f79676a4132626c4b72565a7a644d644a7a6f3044314847647268564d7638324c654f5558686e324e43722d504c665130526666343d	\N	f	\N	Engineer	0.1212	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	462a6f3d27fb4495c130085e46327e07e2331aca02bd2745fbc16728653ff69b	f	\N	{}	\N	0
8a7ef1ce-9ad1-48d2-b304-f7f3dad020e0	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-048	\\x6741414141414270304e55416e50517655586538316c57663779376e70374c71504c395959636e365f346d483553774153756265637a46677937306a516967485f79426a356237446237574d7131674d58634d52725354636b32713934396d3338513d3d	\\x6741414141414270304e5541434958437730364c78787a3746666141313278664b4253654854596a395857424f5f5f6a33786e4466354d464c6e6c41437134474f66434c4e787271797542645747784e56396630556d4664424a363131552d6e4138684268744f54376237686a744c2d70324c6f7236593d	\N	f	5000.00	Engineer	0.1672	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	79f23b85f17bbb726fb5562230013d4faae0d66b0a1a971a2d58c97045d097a4	f	\N	{}	\N	0
4c05b35d-1526-48a6-b941-5482d761dd28	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-049	\\x6741414141414270304e5541524c46494f68455a6d5348464f615346584c5a66724e51365436715839674c4a6a4d7742585557346144313845397462754748332d424f463875636a585a7063355f31522d4d3444303547583076704e6f37546667513d3d	\\x6741414141414270304e55417578696b66584e686a376c4847794b636e556e4450376158357a4637576f2d4e726d656b4865534a655577686e4933345a49423566354552366d74727a78325332306778535068395870495371413858695759467a6d4a2d78614834415f774f62786d3444396e344a72633d	\N	f	2000.00	Teacher	0.0336	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	7f6638d8b4aef1992bcab85a6a447299239bef1f73c64ccab16ee2e237a2dbe0	f	\N	{}	\N	0
a1cc8e2c-76ed-496e-b508-c8dd5402789d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	EXT-OPERADOR_A-050	\\x6741414141414270304e554146496b4841486a79315850692d5863557066426556575533434872665f624b534f674a6c2d334272777570655f35317a6165414153645f374a665465764d4e4f6f6f50746d6c5249714a4d59316868495066364851773d3d	\\x6741414141414270304e55415655526d666935506a303575644e49575037436d353454713865373279596773464338396a5933557a4877614b6c692d4d63796a4a395f7068724468427a6d41344274567654724857525a4e784f334144536f6f6341654652736377364f6c496c57413535414f616579383d	\N	f	20000.00	\N	0.2497	\N	2026-04-04 09:08:16.001152+00	2026-04-07 04:00:00.001918+00	\N	ACTIVE	\N	LOW	8f64087b86a34d70acb8aa4b090f70a4895ddd14f53d40469c9cb847e901c4ab	f	\N	{}	\N	0
\.


--
-- Data for Name: report_packages; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.report_packages (id, tenant_id, case_id, player_id, payload, format, created_by, created_at, pdf_path, status, analyst_narrative, decision) FROM stdin;
66572478-754e-47b0-af54-8de0489872a9	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	d48c68fe-fad6-4d61-94b1-451938885a6d	4633153f-6cca-40b2-b0f7-30df770677ec	{"case": {"id": "d48c68fe-fad6-4d61-94b1-451938885a6d", "title": "Smoke Fase 1 e2e 20260404T104059Z", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-04-04T10:40:59.600383+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 1500.0, "valor_apostas": 2200.0, "occurrence_codes": [1425], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Fluxo automatizado de validacao do dossie com evidência anexada e integridade confirmada.", "occurrence_descriptions": {"1425": "Art. 25-XVI — Uso de plataforma bet exchange para LD/FTP"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.90", "name": "Player 1 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 2000.0}, "decision": "REPORT", "reportId": "a8db01a8-fe3b-4c62-ad4e-b04e085268a3", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "a8db01a8-fe3b-4c62-ad4e-b04e085268a3", "caseNumber": "CASE-20260404-D48C68FE", "attachments": [{"sha256": "017144b7b656699d8a1c0fa5217fd8bfc2fd3fe3a5764ab46a4ec76de66cd19d", "eventId": "e7f7c5ab-18f8-4ed0-a8bc-ec5290b32362", "fileName": "tmp.L9xKHjsnJ1", "sizeBytes": 96, "uploadedAt": "2026-04-04T10:40:59.825735+00:00", "contentType": "text/plain", "description": "Smoke evidence attachment", "downloadPath": "/cases/d48c68fe-fad6-4d61-94b1-451938885a6d/evidence/e7f7c5ab-18f8-4ed0-a8bc-ec5290b32362/download", "storageBackend": "minio"}], "generatedAt": "2026-04-04T10:41:00.149824+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-04T10:41:00.149824+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [{"type": "DEPOSIT", "amount": 6500.0, "status": "SETTLED", "occurredAt": "2026-04-04T09:05:00+00:00", "transactionId": "af00aca2-509f-4e54-8026-613fd0466ad5", "paymentInstrument": "{\\"holder_document\\": \\"11122233344\\"}"}, {"type": "DEPOSIT", "amount": 6500.0, "status": "SETTLED", "occurredAt": "2026-04-04T09:01:00+00:00", "transactionId": "61572f11-91ef-4427-939a-e9f3b5b9cbcc", "paymentInstrument": "{\\"holder_document\\": \\"11122233344\\"}"}], "analystNarrative": "Smoke test do fluxo de investigacao com evidência real e cadeia de custodia validada.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/a8db01a8-fe3b-4c62-ad4e-b04e085268a3.pdf", "pdf_sha256": "bc37d97e18b7efae772824037d6a5e0c1b3f52f6f80627413bb12a7b3cdd0342", "generated_at": "2026-04-04T10:41:00.149824+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 1, "attachments_sha256": ["017144b7b656699d8a1c0fa5217fd8bfc2fd3fe3a5764ab46a4ec76de66cd19d"], "pdf_storage_backend": "minio", "report_payload_sha256": "680cae2557619cff023175c15e2817a268c8aa70c8ff6f8286203a8e51d9b4f5"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 13000.0, "primaryInstruments": ["{\\"holder_document\\": \\"11122233344\\"}"], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "Smoke test do fluxo de investigacao com evidência real e cadeia de custodia validada.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 13000.0, "max_single_amount_brl": 6500.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"bucket": "betaml-evidence", "sha256": "017144b7b656699d8a1c0fa5217fd8bfc2fd3fe3a5764ab46a4ec76de66cd19d", "file_name": "tmp.L9xKHjsnJ1", "size_bytes": 96, "description": "Smoke evidence attachment", "object_name": "cases/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/d48c68fe-fad6-4d61-94b1-451938885a6d/20260404T104059Z_6feee16da42042f9b361348807236d24_tmp.L9xKHjsnJ1", "uploaded_at": "2026-04-04T10:40:59.825735+00:00", "content_type": "text/plain", "storage_backend": "minio"}, "event_type": "EVIDENCE_UPLOAD", "recorded_at": "2026-04-04T10:40:59.804390+00:00"}]}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-04 10:41:00.136006+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/a8db01a8-fe3b-4c62-ad4e-b04e085268a3.pdf	FILED	Smoke test do fluxo de investigacao com evidência real e cadeia de custodia validada.	REPORT
41455333-4890-4190-9c5e-0ecf8b1f7394	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	b4213734-3133-47e5-952d-1abac9728fe2	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "b4213734-3133-47e5-952d-1abac9728fe2", "title": "E2E Workflow Case 1775531742561", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-04-07T03:15:42.567831+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "6c12850c-de05-49ba-9ae0-2d91f630e016", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "6c12850c-de05-49ba-9ae0-2d91f630e016", "caseNumber": "CASE-20260407-B4213734", "attachments": [], "generatedAt": "2026-04-07T03:15:43.839840+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T03:15:43.839840+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/6c12850c-de05-49ba-9ae0-2d91f630e016.pdf", "pdf_sha256": "5d83499762aa38af1a9c4ff267c7a1c05936e9cbedaef1da9193c50dbafeea30", "generated_at": "2026-04-07T03:15:43.839840+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "c2f668930b322df3a1227372a013b322588d63902c0ab19a3d80510803c08c14"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}, "event_type": "NOTE", "recorded_at": "2026-04-07T03:15:43.624484+00:00"}]}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:15:43.825332+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/6c12850c-de05-49ba-9ae0-2d91f630e016.pdf	FINAL		CLOSE
4dca2ba4-5a42-4792-9475-2f1fd4e669b5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	e73da2b6-9649-48ca-bf4b-4ccf9871f227	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "e73da2b6-9649-48ca-bf4b-4ccf9871f227", "title": "E2E Workflow Case 1775531861256", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-04-07T03:17:41.260695+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "7b032d8c-35ed-4be7-91b2-4c28c7cd7a4d", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "7b032d8c-35ed-4be7-91b2-4c28c7cd7a4d", "caseNumber": "CASE-20260407-E73DA2B6", "attachments": [], "generatedAt": "2026-04-07T03:17:42.560439+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T03:17:42.560439+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/7b032d8c-35ed-4be7-91b2-4c28c7cd7a4d.pdf", "pdf_sha256": "64329ae2044f5712dd7154e7926b8c48f56e14ad56c60ad9189b9b33217f6574", "generated_at": "2026-04-07T03:17:42.560439+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "b797234aafe24441d643ae8141d41cc8d6d2857e413d227f444758b81d1892e8"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}, "event_type": "NOTE", "recorded_at": "2026-04-07T03:17:42.403622+00:00"}]}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:17:42.553882+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/7b032d8c-35ed-4be7-91b2-4c28c7cd7a4d.pdf	FINAL		CLOSE
6f59338d-e7cb-47c6-bc5e-fd8c4ab5ca7d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	daf0619d-d49a-44d9-91ff-f72e37bc8a5e	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "daf0619d-d49a-44d9-91ff-f72e37bc8a5e", "title": "E2E Workflow Case 1775532423073", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-04-07T03:27:03.078159+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "abd4d4ca-c6ba-4a06-b928-3dd1c335058d", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "abd4d4ca-c6ba-4a06-b928-3dd1c335058d", "caseNumber": "CASE-20260407-DAF0619D", "attachments": [], "generatedAt": "2026-04-07T03:27:04.353222+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T03:27:04.353222+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/abd4d4ca-c6ba-4a06-b928-3dd1c335058d.pdf", "pdf_sha256": "17bc8e0a440901b85a7b35b0c1c7f4856f1bf462458b5a435095f53470a68a39", "generated_at": "2026-04-07T03:27:04.353222+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "64bcfaacb09ac114c1a32d816c1a4b8b3295975cd7983f8172a781dbbf3dc0c3"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}, "event_type": "NOTE", "recorded_at": "2026-04-07T03:27:04.148967+00:00"}]}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:27:04.341508+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/abd4d4ca-c6ba-4a06-b928-3dd1c335058d.pdf	FINAL		CLOSE
eb1d9e5c-ae4e-4ca0-b2ea-4a8711af9fbf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	29a33c2e-9730-4576-abc3-fd77bd81a53f	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "29a33c2e-9730-4576-abc3-fd77bd81a53f", "title": "E2E Workflow Case 1775532861447", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-04-07T03:34:21.451256+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "55deb976-0de5-4e86-b0a2-508ac5071ebe", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "55deb976-0de5-4e86-b0a2-508ac5071ebe", "caseNumber": "CASE-20260407-29A33C2E", "attachments": [], "generatedAt": "2026-04-07T03:34:22.675855+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T03:34:22.675855+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/55deb976-0de5-4e86-b0a2-508ac5071ebe.pdf", "pdf_sha256": "08d880ceba365dcbf806cd11bcbb6845e7e5d70432e3b791da6edada5706ba93", "generated_at": "2026-04-07T03:34:22.675855+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "bd7a9d84926697de6084736a43ed272d8ca8c0cecbd7f53916e595989ec59263"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}, "event_type": "NOTE", "recorded_at": "2026-04-07T03:34:22.513532+00:00"}]}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:34:22.665415+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/55deb976-0de5-4e86-b0a2-508ac5071ebe.pdf	FINAL		CLOSE
e108b45c-abb9-45ec-a50d-e84ed5ea35aa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	43759d5b-e04e-47c8-86e9-62e51ff47593	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "43759d5b-e04e-47c8-86e9-62e51ff47593", "title": "E2E Workflow Case 1775533146299", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-04-07T03:39:06.304256+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "0638fb1d-e159-4942-a4e9-686da414c132", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "0638fb1d-e159-4942-a4e9-686da414c132", "caseNumber": "CASE-20260407-43759D5B", "attachments": [], "generatedAt": "2026-04-07T03:39:07.596228+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T03:39:07.596228+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/0638fb1d-e159-4942-a4e9-686da414c132.pdf", "pdf_sha256": "81ef7319aa454c1e57fa0c4bab13d8f455579697f7c49105c1cfd10b540d0351", "generated_at": "2026-04-07T03:39:07.596228+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "379924fa13763b1019fdb241bd2e82c19ed9d090ea3b415823b92450c1470fd5"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}, "event_type": "NOTE", "recorded_at": "2026-04-07T03:39:07.401565+00:00"}]}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:39:07.589651+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/0638fb1d-e159-4942-a4e9-686da414c132.pdf	FINAL		CLOSE
89c5d727-f108-492d-8598-acf424bc5055	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	90ee3ad8-5f7a-45ee-9a30-6fa1507af0ec	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "90ee3ad8-5f7a-45ee-9a30-6fa1507af0ec", "title": "E2E Workflow Case 1775533935835", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-04-07T03:52:15.839928+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "f6bd79e4-a1b2-46aa-bcd0-647d36bce39b", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "f6bd79e4-a1b2-46aa-bcd0-647d36bce39b", "caseNumber": "CASE-20260407-90EE3AD8", "attachments": [], "generatedAt": "2026-04-07T03:52:17.039618+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T03:52:17.039618+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/f6bd79e4-a1b2-46aa-bcd0-647d36bce39b.pdf", "pdf_sha256": "4dd897cb8c5cb0505aa56b78f01e72316ededbe5682a8ce2ede2d50d668b01ce", "generated_at": "2026-04-07T03:52:17.039618+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "5a34351e106764eace63f49f1002e2b9b2e359e21769b8d87fe34a8d65a14cf0"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}, "event_type": "NOTE", "recorded_at": "2026-04-07T03:52:16.876909+00:00"}]}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:52:17.030033+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/f6bd79e4-a1b2-46aa-bcd0-647d36bce39b.pdf	FINAL		CLOSE
856940fe-d023-40ad-8daa-0f8d6fb6ad5f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	d71eec3c-f7fb-4689-826f-d4e3c7fb4a65	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "d71eec3c-f7fb-4689-826f-d4e3c7fb4a65", "title": "E2E Workflow Case 1775534113929", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-04-07T03:55:13.934418+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "d3fc41e9-bf1b-4949-b980-5def09e89fa3", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "d3fc41e9-bf1b-4949-b980-5def09e89fa3", "caseNumber": "CASE-20260407-D71EEC3C", "attachments": [], "generatedAt": "2026-04-07T03:55:15.241687+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T03:55:15.241687+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/d3fc41e9-bf1b-4949-b980-5def09e89fa3.pdf", "pdf_sha256": "145c5102fc12f449a3071e82cb612c025be23ff22da8b1565729daa5f61d5e94", "generated_at": "2026-04-07T03:55:15.241687+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "c4213c7c06d3c834c00352e7e29c3118edd1d81e69eaa551f5aed55599e94248"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}, "event_type": "NOTE", "recorded_at": "2026-04-07T03:55:15.034526+00:00"}]}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:55:15.235409+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/d3fc41e9-bf1b-4949-b980-5def09e89fa3.pdf	FINAL		CLOSE
4c4577cf-b7a6-44d6-acd8-0b52c049e0b3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	6f8474c4-ddcc-44cd-b47b-7bc0f1cbf5c9	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "6f8474c4-ddcc-44cd-b47b-7bc0f1cbf5c9", "title": "E2E Workflow Case 1775534286179", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-04-07T03:58:06.184283+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "4aa97796-1885-4efd-a689-8682cbfccc15", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "4aa97796-1885-4efd-a689-8682cbfccc15", "caseNumber": "CASE-20260407-6F8474C4", "attachments": [], "generatedAt": "2026-04-07T03:58:07.757075+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T03:58:07.757075+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/4aa97796-1885-4efd-a689-8682cbfccc15.pdf", "pdf_sha256": "8c6f4d9603dbbc8fe3e525fcfc91a6a46017907a666ba237433e895236c33853", "generated_at": "2026-04-07T03:58:07.757075+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "0b1eec4e44012e1c7a6f2f26b35a79e628bb2428942e221bcd95a8a58689e78c"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"author": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "comment": "Comentário E2E para validar a timeline do caso.", "mentions": []}, "event_type": "NOTE", "recorded_at": "2026-04-07T03:58:07.505037+00:00"}]}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 03:58:07.748728+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/4aa97796-1885-4efd-a689-8682cbfccc15.pdf	FINAL		CLOSE
584dd595-91d1-4765-b35e-8edcd1f6302f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	5d2a65d5-de6e-4c5c-b70b-fc9e9de0315a	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "5d2a65d5-de6e-4c5c-b70b-fc9e9de0315a", "title": "E2E Report Export 1775536656799", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-04-07T04:37:36.803766+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "598c2407-8ab0-4503-8a98-5234a2ecfaa2", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "598c2407-8ab0-4503-8a98-5234a2ecfaa2", "caseNumber": "CASE-20260407-5D2A65D5", "attachments": [], "generatedAt": "2026-04-07T04:37:36.849367+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T04:37:36.849367+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Exportação E2E de JSON e PDF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/598c2407-8ab0-4503-8a98-5234a2ecfaa2.pdf", "pdf_sha256": "2f5805fb4ad45bdf73c2864e54fbee851b20cbe1e3806dd30de5ed95333b15fa", "generated_at": "2026-04-07T04:37:36.849367+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "ca31757a4df58fc9574a3ab180a3918f8da2d01c08e986fced97bb954b151a3e"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "Exportação E2E de JSON e PDF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:37:36.831169+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/598c2407-8ab0-4503-8a98-5234a2ecfaa2.pdf	FINAL	Exportação E2E de JSON e PDF.	CLOSE
862088d6-c243-4a16-a2c0-09db833d3ec3	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	5ea5229f-6e09-4c30-8c47-16c797039bef	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "5ea5229f-6e09-4c30-8c47-16c797039bef", "title": "E2E Auditor Export 1775536657452", "status": "OPEN", "severity": "MEDIUM", "opened_at": "2026-04-07T04:37:37.457159+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "5f97e445-660b-4876-9a1f-a3371bc2d615", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "5f97e445-660b-4876-9a1f-a3371bc2d615", "caseNumber": "CASE-20260407-5EA5229F", "attachments": [], "generatedAt": "2026-04-07T04:37:37.488950+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T04:37:37.488950+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Validação de permissão de exportação para auditor.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/5f97e445-660b-4876-9a1f-a3371bc2d615.pdf", "pdf_sha256": "12a737b25b487180b60aa8932b54221b9fd33e6e22acb09f2119728941c5113b", "generated_at": "2026-04-07T04:37:37.488950+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "64e758641ccc274c5efca7620cb410c36672ddbb1136b0c269dfce2dfab90078"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "Validação de permissão de exportação para auditor.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:37:37.480986+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/5f97e445-660b-4876-9a1f-a3371bc2d615.pdf	FINAL	Validação de permissão de exportação para auditor.	CLOSE
88eab46f-3f06-4586-91b4-5ec04a641faf	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	441cc147-981f-4e3a-9415-9af11b1aa905	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "441cc147-981f-4e3a-9415-9af11b1aa905", "title": "E2E Report Export 1775536889795", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-04-07T04:41:29.800057+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "476c6d48-c2d7-4e4d-9be4-af19c7ad74eb", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "476c6d48-c2d7-4e4d-9be4-af19c7ad74eb", "caseNumber": "CASE-20260407-441CC147", "attachments": [], "generatedAt": "2026-04-07T04:41:29.824920+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T04:41:29.824920+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Exportação E2E de JSON e PDF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/476c6d48-c2d7-4e4d-9be4-af19c7ad74eb.pdf", "pdf_sha256": "d110bc65095a26fceaf818b33a3b6de4af34023b71dd0a12ef809c1b4e695fff", "generated_at": "2026-04-07T04:41:29.824920+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "89af9cfbf0f264955afbbc4bee411f9cc0a991d761719efd1ffc44ab5fc1e947"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "Exportação E2E de JSON e PDF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:41:29.813773+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/476c6d48-c2d7-4e4d-9be4-af19c7ad74eb.pdf	FINAL	Exportação E2E de JSON e PDF.	CLOSE
d969a955-3a13-4440-9866-ec9c18ddd2e5	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	468ac1e7-13d8-4b71-a76b-ac47b9de7567	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "468ac1e7-13d8-4b71-a76b-ac47b9de7567", "title": "E2E Auditor Export 1775536890399", "status": "OPEN", "severity": "MEDIUM", "opened_at": "2026-04-07T04:41:30.403748+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "fd1ab90b-9473-44c6-8d1e-a7657a0ce5a0", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "fd1ab90b-9473-44c6-8d1e-a7657a0ce5a0", "caseNumber": "CASE-20260407-468AC1E7", "attachments": [], "generatedAt": "2026-04-07T04:41:30.421830+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T04:41:30.421830+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Validação de permissão de exportação para auditor.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/fd1ab90b-9473-44c6-8d1e-a7657a0ce5a0.pdf", "pdf_sha256": "007a33f2145c85ae7ade529c7384c56b7bee22d9e5d083606368579ab3b93a5e", "generated_at": "2026-04-07T04:41:30.421830+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "457a0bab1efba1813c5146cacdb518703c742b3d5ba1830c9ffd5bd0b28436b0"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "Validação de permissão de exportação para auditor.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:41:30.417455+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/fd1ab90b-9473-44c6-8d1e-a7657a0ce5a0.pdf	FINAL	Validação de permissão de exportação para auditor.	CLOSE
50be8c2d-fa5b-4166-8a57-78c3777ba48d	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	43b747b8-5e26-476f-8e2a-53f894d1041a	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "43b747b8-5e26-476f-8e2a-53f894d1041a", "title": "E2E Audit Export 1775537027939", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-04-07T04:43:47.945394+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 12500.0, "valor_apostas": 9800.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Comunicação regulatória E2E para validar exportações e trilha de auditoria.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "REPORT", "reportId": "3abb3fcb-b6d7-4803-bf59-97e0bd2c4f6f", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "3abb3fcb-b6d7-4803-bf59-97e0bd2c4f6f", "caseNumber": "CASE-20260407-43B747B8", "attachments": [], "generatedAt": "2026-04-07T04:43:48.019596+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T04:43:48.019596+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Narrativa regulatória gerada pela suíte E2E para validar exportações.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/3abb3fcb-b6d7-4803-bf59-97e0bd2c4f6f.pdf", "pdf_sha256": "129f78b2a805f280a2ef0de900dd3de2dfeabb839992ec146761156f1a948a07", "generated_at": "2026-04-07T04:43:48.019596+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "667c3b36c61bb048fc883092eedd661f853be8db706686f4e0dba781595750f2"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "Narrativa regulatória gerada pela suíte E2E para validar exportações.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-04-07T04:43:47.967224+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-04-07T04:43:47.983148+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-04-07T04:43:47.997074+00:00"}]}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:43:48.014574+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/3abb3fcb-b6d7-4803-bf59-97e0bd2c4f6f.pdf	FINAL	Narrativa regulatória gerada pela suíte E2E para validar exportações.	REPORT
defa2505-d8b0-4728-bfe8-b017af5ca885	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	09fb76ee-85d5-4706-bb22-301996504548	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "09fb76ee-85d5-4706-bb22-301996504548", "title": "E2E Audit Export 1775537129376", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-04-07T04:45:29.382368+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 12500.0, "valor_apostas": 9800.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Comunicação regulatória E2E para validar exportações e trilha de auditoria.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "REPORT", "reportId": "119d42c0-6495-4a28-a6d6-e26b247b9fda", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "119d42c0-6495-4a28-a6d6-e26b247b9fda", "caseNumber": "CASE-20260407-09FB76EE", "attachments": [], "generatedAt": "2026-04-07T04:45:29.464700+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T04:45:29.464700+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Narrativa regulatória gerada pela suíte E2E para validar exportações.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/119d42c0-6495-4a28-a6d6-e26b247b9fda.pdf", "pdf_sha256": "cce477e95f45f7dff0433b57eedb469c0188aecd2a974199d02e4b1003f49752", "generated_at": "2026-04-07T04:45:29.464700+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "cb7d6ade34969b7ebc33089ba568b970e34714143cea5881a3c2afe91327a079"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "Narrativa regulatória gerada pela suíte E2E para validar exportações.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-04-07T04:45:29.400360+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-04-07T04:45:29.416863+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-04-07T04:45:29.435685+00:00"}]}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:45:29.456389+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/119d42c0-6495-4a28-a6d6-e26b247b9fda.pdf	FINAL	Narrativa regulatória gerada pela suíte E2E para validar exportações.	REPORT
908994f0-b260-478e-927d-803cebd6a005	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	216f8b56-54a1-42aa-b69f-cb19a82a689a	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "216f8b56-54a1-42aa-b69f-cb19a82a689a", "title": "E2E Report Export 1775537386902", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-04-07T04:49:46.906942+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "ba3cefd0-3548-49e6-970c-1574a9e0f5c5", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "ba3cefd0-3548-49e6-970c-1574a9e0f5c5", "caseNumber": "CASE-20260407-216F8B56", "attachments": [], "generatedAt": "2026-04-07T04:49:46.942981+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T04:49:46.942981+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Exportação E2E de JSON e PDF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ba3cefd0-3548-49e6-970c-1574a9e0f5c5.pdf", "pdf_sha256": "14ebdea1a92190836eeb5d8825d01ad7a0ffed0f137b668814c76275858a0c8b", "generated_at": "2026-04-07T04:49:46.942981+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "89c5b5337184a3667ac4eb3acf29387449e1a4f269849efac28afcbbac1ab456"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "Exportação E2E de JSON e PDF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:49:46.929672+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/ba3cefd0-3548-49e6-970c-1574a9e0f5c5.pdf	FINAL	Exportação E2E de JSON e PDF.	CLOSE
77397113-347a-40a9-9b9c-a5bc199262c7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	08150300-1e4c-420b-b78b-b08f5ace85a5	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "08150300-1e4c-420b-b78b-b08f5ace85a5", "title": "E2E Auditor Export 1775537387355", "status": "OPEN", "severity": "MEDIUM", "opened_at": "2026-04-07T04:49:47.374659+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "dafc5b90-1e19-483f-aedb-814d900d25ab", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "dafc5b90-1e19-483f-aedb-814d900d25ab", "caseNumber": "CASE-20260407-08150300", "attachments": [], "generatedAt": "2026-04-07T04:49:47.419749+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T04:49:47.419749+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Validação de permissão de exportação para auditor.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/dafc5b90-1e19-483f-aedb-814d900d25ab.pdf", "pdf_sha256": "7bb0034b919e06814f0a78ef7f90734a5a5e7006802bb873b70dc78e89860219", "generated_at": "2026-04-07T04:49:47.419749+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "8abbbc0976a88a612513bd70c90ac0528b157e19624c8a1368398331108f1de4"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "Validação de permissão de exportação para auditor.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:49:47.40483+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/dafc5b90-1e19-483f-aedb-814d900d25ab.pdf	FINAL	Validação de permissão de exportação para auditor.	CLOSE
385291a2-4755-498b-940a-4d293da609ed	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	95a6b4ac-f960-4fb7-a7ab-d106bcf625e0	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "95a6b4ac-f960-4fb7-a7ab-d106bcf625e0", "title": "E2E Audit Export 1775537393760", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-04-07T04:49:53.765242+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 12500.0, "valor_apostas": 9800.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Comunicação regulatória E2E para validar exportações e trilha de auditoria.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "REPORT", "reportId": "83016b0c-b9f0-4c55-b153-e9eea80497b7", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "83016b0c-b9f0-4c55-b153-e9eea80497b7", "caseNumber": "CASE-20260407-95A6B4AC", "attachments": [], "generatedAt": "2026-04-07T04:49:53.836217+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T04:49:53.836217+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Narrativa regulatória gerada pela suíte E2E para validar exportações.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/83016b0c-b9f0-4c55-b153-e9eea80497b7.pdf", "pdf_sha256": "ccdff1b80752992e71f4fa293dd06c9fd8f6aa07aba4f2d039e6ee6434a88086", "generated_at": "2026-04-07T04:49:53.836217+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "9642bd2855eb6f2d505a427b91e76687702a16dd3de14cec36d85bdbc98f91e5"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "Narrativa regulatória gerada pela suíte E2E para validar exportações.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-04-07T04:49:53.780876+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-04-07T04:49:53.795481+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-04-07T04:49:53.809726+00:00"}]}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 04:49:53.825388+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/83016b0c-b9f0-4c55-b153-e9eea80497b7.pdf	FINAL	Narrativa regulatória gerada pela suíte E2E para validar exportações.	REPORT
f9f7543d-2687-4b43-8a9c-12a597ddca31	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ed136fe5-5990-4a83-b5dd-b217d7cdc020	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "ed136fe5-5990-4a83-b5dd-b217d7cdc020", "title": "E2E Report Export 1775538678055", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-04-07T05:11:18.060058+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "427bddb4-0471-4b5c-b46a-da1f0b32fa85", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "427bddb4-0471-4b5c-b46a-da1f0b32fa85", "caseNumber": "CASE-20260407-ED136FE5", "attachments": [], "generatedAt": "2026-04-07T05:11:18.105284+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T05:11:18.105284+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Exportação E2E de JSON e PDF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/427bddb4-0471-4b5c-b46a-da1f0b32fa85.pdf", "pdf_sha256": "45eefde0ee00921d14c813cefaf1e1cc24390a55a09f6a0271b0e5a77025d789", "generated_at": "2026-04-07T05:11:18.105284+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "5717ba3d499823eefa58c6021967a8db89c71a7b03a0d38d34468d43aac35e3a"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "Exportação E2E de JSON e PDF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 05:11:18.087472+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/427bddb4-0471-4b5c-b46a-da1f0b32fa85.pdf	FINAL	Exportação E2E de JSON e PDF.	CLOSE
e6203490-ae88-4da7-a33d-b3c81e640a06	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	ef28e581-2794-4286-9627-108a7278a3a0	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "ef28e581-2794-4286-9627-108a7278a3a0", "title": "E2E Auditor Export 1775538678666", "status": "OPEN", "severity": "MEDIUM", "opened_at": "2026-04-07T05:11:18.671793+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "27be5112-edd1-40d2-aa73-2fc8d2f74786", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "27be5112-edd1-40d2-aa73-2fc8d2f74786", "caseNumber": "CASE-20260407-EF28E581", "attachments": [], "generatedAt": "2026-04-07T05:11:18.714926+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T05:11:18.714926+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Validação de permissão de exportação para auditor.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/27be5112-edd1-40d2-aa73-2fc8d2f74786.pdf", "pdf_sha256": "d9c21b17f406245909b176841945ea858b897c468f1a8544a4e7546340557c34", "generated_at": "2026-04-07T05:11:18.714926+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "6020e2bd3aa9724a59334d4be53a0cc2a93e75178dedab05b5b966d849896a68"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "Validação de permissão de exportação para auditor.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 05:11:18.705184+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/27be5112-edd1-40d2-aa73-2fc8d2f74786.pdf	FINAL	Validação de permissão de exportação para auditor.	CLOSE
5cea27d3-001d-486c-b9a2-7ff8f7436a73	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	e9e5d372-aac2-4a13-aaf7-e15fd25faaaf	464e8bab-c13c-4d14-b512-f008f997e437	{"case": {"id": "e9e5d372-aac2-4a13-aaf7-e15fd25faaaf", "title": "E2E Audit Export 1775538684952", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-04-07T05:11:24.956478+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 12500.0, "valor_apostas": 9800.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Comunicação regulatória E2E para validar exportações e trilha de auditoria.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.57", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": null, "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "REPORT", "reportId": "f5bc91f2-19dd-46b1-9f3a-519406ee305b", "tenantId": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "report_id": "f5bc91f2-19dd-46b1-9f3a-519406ee305b", "caseNumber": "CASE-20260407-E9E5D372", "attachments": [], "generatedAt": "2026-04-07T05:11:25.035861+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-04-07T05:11:25.035861+00:00", "generated_by": "b02e2d51-3a22-4029-9b70-fb5b6028d4bc", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Narrativa regulatória gerada pela suíte E2E para validar exportações.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/f5bc91f2-19dd-46b1-9f3a-519406ee305b.pdf", "pdf_sha256": "e55e7c8a89a4da79f77ba3ba656cae4ac004b0b59e590fb5426f124f68f4254f", "generated_at": "2026-04-07T05:11:25.035861+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "320770a080a61b5e634ef8cb572709148ffc1ca4608b206c3bec5adcd0478f69"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee", "tenant_name": "OperadorA"}, "analyst_narrative": "Narrativa regulatória gerada pela suíte E2E para validar exportações.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-04-07T05:11:24.991105+00:00"}, {"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-04-07T05:11:24.973059+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-04-07T05:11:25.007729+00:00"}]}	JSON	b02e2d51-3a22-4029-9b70-fb5b6028d4bc	2026-04-07 05:11:25.023909+00	minio://betaml-reports/reports/4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee/f5bc91f2-19dd-46b1-9f3a-519406ee305b.pdf	FINAL	Narrativa regulatória gerada pela suíte E2E para validar exportações.	REPORT
\.


--
-- Data for Name: rule_definitions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rule_definitions (id, tenant_id, name, description, status, severity, scope, condition_dsl, params, version, created_by, updated_by, created_at, updated_at, weight) FROM stdin;
b754243e-f006-4551-ae19-4f9bdc607e4c	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Spike vs Baseline (Z-Score)	Depósito atual com z-score alto versus baseline do jogador	ACTIVE	HIGH	TRANSACTION	zscore(features.deposit_sum_24h, features.baseline_avg_daily_deposit, features.baseline_stddev_deposit) >= params.zscore_threshold and transaction.type == "DEPOSIT"	{"zscore_threshold": 3}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
32c815b2-5fe3-4136-a864-6b9f7e35acd7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Structuring (Muitos depósitos pequenos 24h)	Múltiplos depósitos pequenos em 24h (fracionamento)	ACTIVE	HIGH	TRANSACTION	features.deposit_count_24h >= params.count_threshold and features.deposit_sum_24h >= params.sum_threshold and transaction.type == "DEPOSIT"	{"sum_threshold": 5000, "count_threshold": 5}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
6ce71ab4-5778-4430-a798-c63e1df39145	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Instrumento novo + valor alto	Uso de instrumento de pagamento nunca visto + valor elevado	ACTIVE	MEDIUM	TRANSACTION	features.new_payment_instrument_flag == true and transaction.amount >= params.amount_threshold	{"amount_threshold": 2000}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
5add0460-a73a-4f95-ac05-3f4ff0984798	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	PEP com desvio alto	Jogador PEP com depósito acima do income declarado	ACTIVE	CRITICAL	TRANSACTION	player.pep_flag == true and transaction.amount >= params.pep_threshold	{"pep_threshold": 5000}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
57980b02-e8ae-4313-83f5-3e7c665b04a4	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Conta bancária compartilhada	Mesma conta bancária usada por múltiplos players	ACTIVE	HIGH	TRANSACTION	features.shared_bank_account_count >= params.shared_threshold	{"shared_threshold": 2}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
cc86ac86-0bb5-44bb-af11-9eefa587a4b7	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Mesmo device em múltiplos CPFs	Mesmo dispositivo usado por múltiplos joueurs distintos	ACTIVE	HIGH	DEVICE_EVENT	features.shared_device_count >= params.device_threshold	{"device_threshold": 3}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
e8e3f876-a902-4391-b138-538aa1afbe1b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Alta razão saque/depósito 7d	Razão entre saques e depósitos em 7d acima do threshold	ACTIVE	MEDIUM	TRANSACTION	ratio(features.withdrawal_sum_7d, features.deposit_sum_7d) >= params.ratio_threshold and features.deposit_sum_7d >= params.min_volume	{"min_volume": 1000, "ratio_threshold": "0.9"}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
8ce33a42-0900-4b4c-b4c4-7fedebffa7c6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Spike de stake em apostas 7d	Stake de aposta muito acima da média histórica	ACTIVE	MEDIUM	BET	bet.stakeAmount >= params.stake_min and features.bet_stake_sum_7d >= params.volume_threshold	{"stake_min": 1000, "volume_threshold": 10000}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
1bcc193b-bbd7-4e15-a3f2-832945aa4b66	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Chargebacks acima do normal	Múltiplos chargebacks em 30 dias	ACTIVE	HIGH	TRANSACTION	features.chargeback_count_30d >= params.cb_threshold and transaction.type == "CHARGEBACK"	{"cb_threshold": 2}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
11de3b51-7b15-49a4-b6e7-c0a50f710eb2	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Depósitos falhos + sucesso grande	Várias tentativas falhas seguidas de depósito bem-sucedido alto	ACTIVE	MEDIUM	TRANSACTION	features.failed_deposit_count_24h >= params.failed_threshold and transaction.amount >= params.amount_threshold and transaction.status == "SETTLED"	{"amount_threshold": 3000, "failed_threshold": 3}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
fb2cfc97-d4bf-4e5b-af0d-84903b6415aa	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Round-tripping (depósito → aposta mínima → saque)	Padrão de lavagem: depósito, aposta simbólica, saque rápido	ACTIVE	CRITICAL	TRANSACTION	transaction.type == "WITHDRAWAL" and ratio(features.withdrawal_sum_24h, features.deposit_sum_24h) >= params.round_trip_ratio and features.bet_stake_sum_24h <= params.max_stake	{"max_stake": 50, "round_trip_ratio": "0.8"}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
2d4322ce-8994-4062-9eb6-047d2cd48d50	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Saque rápido após depósito	Saque alto realizado logo após depósito relevante no mesmo dia	ACTIVE	HIGH	TRANSACTION	transaction.type == "WITHDRAWAL" and features.deposit_sum_24h >= params.min_deposit and ratio(features.withdrawal_sum_24h, features.deposit_sum_24h) >= params.ratio_threshold	{"min_deposit": 1000, "ratio_threshold": "0.7"}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
fb449c1a-2e7f-4459-aa2b-353c355633b6	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Incompatibilidade renda/volume 30d	Volume de depósitos nos últimos 30d incompatível com a renda mensal declarada (Res. COAF 40/2021 Art. 2 — indício de lavagem por volume atípico)	ACTIVE	HIGH	TRANSACTION	transaction.type == "DEPOSIT" and player.declared_income_monthly != null and features.income_ratio_30d >= params.ratio_threshold	{"ratio_threshold": 3.0}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
0261f7f2-da77-4bc5-9302-f80d272f7255	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Alta frequência em slots (24h)	Volume anômalo de rodadas de slots em 24h — possível automação ou lavagem via jogos de baixo RTP	ACTIVE	MEDIUM	BET	bet.productType == "SLOT" and features.slot_session_count_24h >= params.threshold	{"threshold": 200}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
82fb72ee-b453-475b-af4c-c350f767812a	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Diversificação de produto suspeita (7d)	Jogador usando muitas modalidades distintas em 7d — possível dispersão para dificultar rastreamento	ACTIVE	MEDIUM	BET	features.bet_product_diversity_7d >= params.max_types	{"max_types": 4}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
2324acc0-bbad-49dc-b4c1-a931101bd44f	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Casino chip washing	Padrão de lavagem em casino ao vivo: apostas mínimas + saque alto (chips → cash)	ACTIVE	HIGH	BET	bet.productType == "CASINO_LIVE" and features.casino_session_count_24h >= params.min_sessions and bet.stakeAmount <= params.max_stake	{"max_stake": 25, "min_sessions": 50}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
163f7e74-bde6-4316-87e9-e427acdde71b	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	Alta frequência em casino ao vivo (24h)	Volume anômalo de sessões de casino ao vivo em 24h	ACTIVE	MEDIUM	BET	bet.productType == "CASINO_LIVE" and features.casino_session_count_24h >= params.threshold	{"threshold": 150}	1	2c9dc0c7-cc53-4e4d-857b-a267c9355532	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
669e39d9-70e0-45c0-953d-8bfb8a4a8617	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Spike vs Baseline (Z-Score)	Depósito atual com z-score alto versus baseline do jogador	ACTIVE	HIGH	TRANSACTION	zscore(features.deposit_sum_24h, features.baseline_avg_daily_deposit, features.baseline_stddev_deposit) >= params.zscore_threshold and transaction.type == "DEPOSIT"	{"zscore_threshold": 3}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
9d0ae942-31dc-413c-90c8-db33dfa755f9	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Structuring (Muitos depósitos pequenos 24h)	Múltiplos depósitos pequenos em 24h (fracionamento)	ACTIVE	HIGH	TRANSACTION	features.deposit_count_24h >= params.count_threshold and features.deposit_sum_24h >= params.sum_threshold and transaction.type == "DEPOSIT"	{"sum_threshold": 5000, "count_threshold": 5}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
df8baf96-ac48-493e-97eb-12018a588413	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Instrumento novo + valor alto	Uso de instrumento de pagamento nunca visto + valor elevado	ACTIVE	MEDIUM	TRANSACTION	features.new_payment_instrument_flag == true and transaction.amount >= params.amount_threshold	{"amount_threshold": 2000}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
7b13cf11-cdd1-46c0-9ff8-c664e0d6c743	40e341ad-cf4a-484b-9926-3d56cc58fa1f	PEP com desvio alto	Jogador PEP com depósito acima do income declarado	ACTIVE	CRITICAL	TRANSACTION	player.pep_flag == true and transaction.amount >= params.pep_threshold	{"pep_threshold": 5000}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
fa3d3f5f-8d76-4b49-86e0-64393703b8f4	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Conta bancária compartilhada	Mesma conta bancária usada por múltiplos players	ACTIVE	HIGH	TRANSACTION	features.shared_bank_account_count >= params.shared_threshold	{"shared_threshold": 2}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
093bdb83-e7a4-4243-858c-e584bb6780bb	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Mesmo device em múltiplos CPFs	Mesmo dispositivo usado por múltiplos joueurs distintos	ACTIVE	HIGH	DEVICE_EVENT	features.shared_device_count >= params.device_threshold	{"device_threshold": 3}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
a783a028-57be-4fe3-ae1f-cf7f96fb88ea	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Alta razão saque/depósito 7d	Razão entre saques e depósitos em 7d acima do threshold	ACTIVE	MEDIUM	TRANSACTION	ratio(features.withdrawal_sum_7d, features.deposit_sum_7d) >= params.ratio_threshold and features.deposit_sum_7d >= params.min_volume	{"min_volume": 1000, "ratio_threshold": "0.9"}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
b68c81d5-4796-4460-b474-6af08f49d76e	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Spike de stake em apostas 7d	Stake de aposta muito acima da média histórica	ACTIVE	MEDIUM	BET	bet.stakeAmount >= params.stake_min and features.bet_stake_sum_7d >= params.volume_threshold	{"stake_min": 1000, "volume_threshold": 10000}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
c7952e46-f32e-46ca-ac01-92026b5f561f	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Chargebacks acima do normal	Múltiplos chargebacks em 30 dias	ACTIVE	HIGH	TRANSACTION	features.chargeback_count_30d >= params.cb_threshold and transaction.type == "CHARGEBACK"	{"cb_threshold": 2}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
4a4a4a38-0f49-4c08-acbf-fecbc7cf27b7	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Depósitos falhos + sucesso grande	Várias tentativas falhas seguidas de depósito bem-sucedido alto	ACTIVE	MEDIUM	TRANSACTION	features.failed_deposit_count_24h >= params.failed_threshold and transaction.amount >= params.amount_threshold and transaction.status == "SETTLED"	{"amount_threshold": 3000, "failed_threshold": 3}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
9e393a81-e39b-46ac-8e86-de792f3bdfc8	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Round-tripping (depósito → aposta mínima → saque)	Padrão de lavagem: depósito, aposta simbólica, saque rápido	ACTIVE	CRITICAL	TRANSACTION	transaction.type == "WITHDRAWAL" and ratio(features.withdrawal_sum_24h, features.deposit_sum_24h) >= params.round_trip_ratio and features.bet_stake_sum_24h <= params.max_stake	{"max_stake": 50, "round_trip_ratio": "0.8"}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
f70802e0-2621-4aba-ae06-9422efe34dbe	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Saque rápido após depósito	Saque alto realizado logo após depósito relevante no mesmo dia	ACTIVE	HIGH	TRANSACTION	transaction.type == "WITHDRAWAL" and features.deposit_sum_24h >= params.min_deposit and ratio(features.withdrawal_sum_24h, features.deposit_sum_24h) >= params.ratio_threshold	{"min_deposit": 1000, "ratio_threshold": "0.7"}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
4b043d3d-66b5-4a01-9cd8-3c647186d502	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Incompatibilidade renda/volume 30d	Volume de depósitos nos últimos 30d incompatível com a renda mensal declarada (Res. COAF 40/2021 Art. 2 — indício de lavagem por volume atípico)	ACTIVE	HIGH	TRANSACTION	transaction.type == "DEPOSIT" and player.declared_income_monthly != null and features.income_ratio_30d >= params.ratio_threshold	{"ratio_threshold": 3.0}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
4b90edc2-b638-4c98-9b67-e4067a0b051e	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Alta frequência em slots (24h)	Volume anômalo de rodadas de slots em 24h — possível automação ou lavagem via jogos de baixo RTP	ACTIVE	MEDIUM	BET	bet.productType == "SLOT" and features.slot_session_count_24h >= params.threshold	{"threshold": 200}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
53f5705d-c9e7-4b4e-80e1-5c05b38c903b	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Diversificação de produto suspeita (7d)	Jogador usando muitas modalidades distintas em 7d — possível dispersão para dificultar rastreamento	ACTIVE	MEDIUM	BET	features.bet_product_diversity_7d >= params.max_types	{"max_types": 4}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
a093140e-b372-41b5-ac5e-bfde62b85971	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Casino chip washing	Padrão de lavagem em casino ao vivo: apostas mínimas + saque alto (chips → cash)	ACTIVE	HIGH	BET	bet.productType == "CASINO_LIVE" and features.casino_session_count_24h >= params.min_sessions and bet.stakeAmount <= params.max_stake	{"max_stake": 25, "min_sessions": 50}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
dccf74a4-66e3-45ac-a346-23357ba74208	40e341ad-cf4a-484b-9926-3d56cc58fa1f	Alta frequência em casino ao vivo (24h)	Volume anômalo de sessões de casino ao vivo em 24h	ACTIVE	MEDIUM	BET	bet.productType == "CASINO_LIVE" and features.casino_session_count_24h >= params.threshold	{"threshold": 150}	1	e653024a-8bee-46b0-ae12-63177bb0dc61	\N	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.500
3805092b-77f2-4eaf-9279-c41d019c7d29	23f4e6fb-ac62-49d9-94d0-078f0aa8924d	Spike de Depósito	Detecta depósito de alto valor combinado com frequência elevada nas últimas 24h.	ACTIVE	HIGH	TRANSACTION	transaction.type == "DEPOSIT" and transaction.amount > 10000 and features.deposit_count_24h >= 3	{}	1	8cfc988d-8513-443c-8d90-da05dd2fac23	\N	2026-04-07 05:10:21.159085+00	2026-04-07 05:10:21.159085+00	0.500
6b543bdf-c077-4bd8-a931-1f3027d66e8d	d3108642-40e7-4da1-aa68-4a17aac45b10	Spike de Depósito	Detecta depósito de alto valor combinado com frequência elevada nas últimas 24h.	ACTIVE	HIGH	TRANSACTION	transaction.type == "DEPOSIT" and transaction.amount > 10000 and features.deposit_count_24h >= 3	{}	1	8cfc988d-8513-443c-8d90-da05dd2fac23	\N	2026-04-07 05:11:31.97926+00	2026-04-07 05:11:31.97926+00	0.500
3814106b-58ff-49ab-acde-4d5108b13340	71825dca-3ce0-4230-a48d-da36c09148cd	Spike de Depósito	Detecta depósito de alto valor combinado com frequência elevada nas últimas 24h.	ACTIVE	HIGH	TRANSACTION	transaction.type == "DEPOSIT" and transaction.amount > 10000 and features.deposit_count_24h >= 3	{}	1	8cfc988d-8513-443c-8d90-da05dd2fac23	\N	2026-04-07 05:12:07.876622+00	2026-04-07 05:12:07.876622+00	0.500
\.


--
-- Data for Name: rule_execution_logs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rule_execution_logs (id, tenant_id, rule_id, rule_version, source_event_id, player_id, matched, evaluation_ms, context_snapshot, created_at) FROM stdin;
\.


--
-- Data for Name: rule_macros; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.rule_macros (id, tenant_id, name, body_dsl, description, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: schema_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.schema_migrations (filename, checksum, applied_at) FROM stdin;
\.


--
-- Data for Name: scoring_configs; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.scoring_configs (id, tenant_id, rule_weight, ml_weight, network_weight, auto_case_threshold, sla_critical_hours, sla_high_hours, sla_medium_hours, sla_low_hours, ingest_rate_limit_tpm, data_retention_raw_years, data_retention_silver_years, data_retention_gold_years, updated_by, created_at, updated_at, risk_band_low_threshold, risk_band_high_threshold, income_volume_ratio_threshold, low_threshold, medium_threshold, high_threshold, critical_threshold, is_active, data_retention_days, ml_challenger_pct) FROM stdin;
38e8bb3d-6a24-40bb-b295-e9764a872669	40e341ad-cf4a-484b-9926-3d56cc58fa1f	0.400	0.400	0.200	0.7500	4	24	72	168	100000	5	5	3	e653024a-8bee-46b0-ae12-63177bb0dc61	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	1825	0
d60f8978-5e0c-4a46-b082-07efe75dac91	9f428c2a-354c-435a-933d-0fcbbf39802a	0.400	0.400	0.200	0.7500	4	24	72	168	1000	5	5	3	78206c93-bddd-4a6c-98ae-b81a97357d29	2026-04-07 05:10:12.325651+00	2026-04-07 05:10:12.325651+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	730	0
51ae091b-ad4e-4d3f-a0fa-330a5268bd7d	23f4e6fb-ac62-49d9-94d0-078f0aa8924d	0.400	0.400	0.200	0.7500	4	24	72	168	1000	5	5	3	23c8e0f1-83ef-475c-b515-cd754eef90c2	2026-04-07 05:10:20.475717+00	2026-04-07 05:10:20.475717+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	730	0
ae97ee23-536b-47b3-8c4d-a45bbc806176	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	0.400	0.400	0.200	0.7500	4	24	72	168	100000	5	5	3	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-04 09:08:16.001152+00	2026-04-07 05:11:02.092596+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	1825	0
ec9211d6-b0df-458f-b3c1-3ae76494feff	d3108642-40e7-4da1-aa68-4a17aac45b10	0.400	0.400	0.200	0.7500	4	24	72	168	1000	5	5	3	e5791c05-da35-4764-8fb7-091897573cc6	2026-04-07 05:11:31.253621+00	2026-04-07 05:11:31.253621+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	730	0
936ea7d6-cb14-481e-9ea0-df3dd39c7cff	ace787b5-e77f-4947-a83d-5e3333d063ed	0.400	0.400	0.200	0.7500	4	24	72	168	1000	5	5	3	8bdb370f-db79-4c6a-abbc-e3d6bc111a98	2026-04-07 05:11:59.246302+00	2026-04-07 05:11:59.246302+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	730	0
b5fcc25e-29c2-48af-95e6-330452db878a	71825dca-3ce0-4230-a48d-da36c09148cd	0.400	0.400	0.200	0.7500	4	24	72	168	1000	5	5	3	e9fc5972-81b8-4cff-89a8-16098eb9e947	2026-04-07 05:12:07.055717+00	2026-04-07 05:12:07.055717+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	730	0
\.


--
-- Data for Name: system_flags; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.system_flags (key, value, updated_by, updated_at) FROM stdin;
maintenance_mode	false	\N	2026-04-04 09:08:01.093909+00
4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee:ingest_rate_limit_per_min	"300"	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 04:13:02.243648+00
4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee:maintenance_mode	{"enabled": false}	2c9dc0c7-cc53-4e4d-857b-a267c9355532	2026-04-07 05:11:22.015523+00
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.tenants (id, name, slug, active, settings, risk_score_threshold, created_at, updated_at, cnpj, plan_tier) FROM stdin;
4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	OperadorA	operador_a	t	{}	0.75	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	standard
40e341ad-cf4a-484b-9926-3d56cc58fa1f	OperadorB	operador_b	t	{}	0.75	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	standard
9f428c2a-354c-435a-933d-0fcbbf39802a	Operador E2E 1775538611988	operador-e2e-1775538611988	t	{"cnpj": "12345678000195"}	0.75	2026-04-07 05:10:12.325651+00	2026-04-07 05:10:12.325651+00	\N	standard
23f4e6fb-ac62-49d9-94d0-078f0aa8924d	Operador E2E 1775538617510	operador-e2e-1775538617510	t	{"cnpj": "12345678000195"}	0.75	2026-04-07 05:10:20.475717+00	2026-04-07 05:10:20.475717+00	\N	standard
d3108642-40e7-4da1-aa68-4a17aac45b10	Operador E2E 1775538688614	operador-e2e-1775538688614	t	{"cnpj": "12345678000195"}	0.75	2026-04-07 05:11:31.253621+00	2026-04-07 05:11:31.253621+00	\N	standard
ace787b5-e77f-4947-a83d-5e3333d063ed	Operador E2E 1775538718617	operador-e2e-1775538718617	t	{"cnpj": "12345678000195"}	0.75	2026-04-07 05:11:59.246302+00	2026-04-07 05:11:59.246302+00	\N	standard
71825dca-3ce0-4230-a48d-da36c09148cd	Operador E2E 1775538724541	operador-e2e-1775538724541	t	{"cnpj": "12345678000195"}	0.75	2026-04-07 05:12:07.055717+00	2026-04-07 05:12:07.055717+00	\N	standard
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.users (id, tenant_id, username, email, password_hash, role, active, created_at, updated_at, refresh_token_jti, roles) FROM stdin;
e9fc5972-81b8-4cff-89a8-16098eb9e947	71825dca-3ce0-4230-a48d-da36c09148cd	tenant_admin_1775538724541	tenant-admin-1775538724541@example.com	$2b$12$KjYoqt2XBLNlEZAz0R.Us.fCfwCkfSD2c1B/2MqHEWN7Ocdg6Mkpe	ADMIN	t	2026-04-07 05:12:07.055717+00	2026-04-07 05:12:07.055717+00	\N	[]
4793f0a7-dc8b-4d8a-bf23-8e75bf81fb98	40e341ad-cf4a-484b-9926-3d56cc58fa1f	analyst_b	analyst_b@betaml.dev	$2b$12$DoJarCIR4WXP9Pbb/GSCWuVGMpo/QdE9m3gVjHw3adr5SJJmSwvrm	AML_ANALYST	t	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	[]
567c1041-1ce8-4a59-8b60-58b3d796a96d	40e341ad-cf4a-484b-9926-3d56cc58fa1f	auditor_b	auditor_b@betaml.dev	$2b$12$Wxu3Ub9y6L2916t9FcDZHejx8plrrGUjnrdXIGZqZ3D27pdOH1TXu	AUDITOR	t	2026-04-04 09:08:16.001152+00	2026-04-04 09:08:16.001152+00	\N	[]
8bdb370f-db79-4c6a-abbc-e3d6bc111a98	ace787b5-e77f-4947-a83d-5e3333d063ed	tenant_admin_1775538718617	tenant-admin-1775538718617@example.com	$2b$12$RcgeZOyHmspaHq1GphDzfOnLfSKuKMfv6A2KnZ37.BcjeKZDHDEX.	ADMIN	t	2026-04-07 05:11:59.246302+00	2026-04-07 05:11:59.246302+00	\N	[]
8cfc988d-8513-443c-8d90-da05dd2fac23	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	superadmin	superadmin@betaml.dev	$2b$12$fH65tDqJQB2RUdSk1XblkOAngwm9SzKLe5ymb856oEa5uTRVRiuWO	ADMIN	t	2026-04-07 05:03:44.01654+00	2026-04-07 05:12:05.558747+00	97d465c6-d185-473e-a388-7be061330022	["BetAML_SuperAdmin"]
b02e2d51-3a22-4029-9b70-fb5b6028d4bc	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	analyst_a	analyst_a@betaml.dev	$2b$12$kUfR.m5GnMaJB3UQNRxeKeAmb5hdpLh3.lRfWfskDp2mccgOvqJyq	AML_ANALYST	t	2026-04-04 09:08:16.001152+00	2026-04-07 05:22:57.328513+00	e376ad72-97e5-4db4-b983-a18456b23d9a	[]
a295ceae-bac0-4c7f-8fe8-e8431d651700	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	auditor_a	auditor_a@betaml.dev	$2b$12$cx/qS7kiczTDi22dLHffieeWJ5FGbY3zovVIpCLtAxLXuWd6px5sK	AUDITOR	t	2026-04-04 09:08:16.001152+00	2026-04-07 05:23:01.826121+00	821bee99-6e17-435c-847f-4b818846797a	[]
78206c93-bddd-4a6c-98ae-b81a97357d29	9f428c2a-354c-435a-933d-0fcbbf39802a	tenant_admin_1775538611988	tenant-admin-1775538611988@example.com	$2b$12$jD6m26kA6gKqPympt4DEguRj/iYyfm50LheqDTSZKG2yRGd1Jxkuy	ADMIN	t	2026-04-07 05:10:12.325651+00	2026-04-07 05:10:12.325651+00	\N	[]
23c8e0f1-83ef-475c-b515-cd754eef90c2	23f4e6fb-ac62-49d9-94d0-078f0aa8924d	tenant_admin_1775538617510	tenant-admin-1775538617510@example.com	$2b$12$YkMvfS/8.CePRcEIDGVZTe1WnBcEhBkdYW85HqgnyRdGfbXFji1vO	ADMIN	t	2026-04-07 05:10:20.475717+00	2026-04-07 05:10:20.475717+00	\N	[]
e653024a-8bee-46b0-ae12-63177bb0dc61	40e341ad-cf4a-484b-9926-3d56cc58fa1f	admin_b	admin_b@betaml.dev	$2b$12$cRsD7AWV54yIufBIhG.G8Ovt//zH29HeCmjJA88/aj9ssqt/VqLVO	ADMIN	t	2026-04-04 09:08:16.001152+00	2026-04-07 05:11:08.98827+00	28d91d3a-5072-4aca-8bd8-18ea995e5895	[]
2c9dc0c7-cc53-4e4d-857b-a267c9355532	4f0733e6-1f72-4012-8cf1-9a7e12b5a1ee	admin_a	admin_a@betaml.dev	$2b$12$upIAxp6DvR2NiWl765oti.jgbEjVKsFj7sg3dctoLPLk6gxeZhaOy	ADMIN	t	2026-04-04 09:08:16.001152+00	2026-04-07 05:11:21.668707+00	232a82ad-c18c-4095-9b06-3091e159bd3d	[]
e5791c05-da35-4764-8fb7-091897573cc6	d3108642-40e7-4da1-aa68-4a17aac45b10	tenant_admin_1775538688614	tenant-admin-1775538688614@example.com	$2b$12$i57r.AyecvfLZFq4BTphgO.kN06cbvWTIlSJGe/gHaTbQRkDkUS.i	ADMIN	t	2026-04-07 05:11:31.253621+00	2026-04-07 05:11:31.253621+00	\N	[]
\.


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bets bets_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bets
    ADD CONSTRAINT bets_pkey PRIMARY KEY (id);


--
-- Name: case_events case_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events
    ADD CONSTRAINT case_events_pkey PRIMARY KEY (id);


--
-- Name: cases cases_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_pkey PRIMARY KEY (id);


--
-- Name: compound_rules compound_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compound_rules
    ADD CONSTRAINT compound_rules_pkey PRIMARY KEY (id);


--
-- Name: device_events device_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_events
    ADD CONSTRAINT device_events_pkey PRIMARY KEY (id);


--
-- Name: external_validation_requests external_validation_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_validation_requests
    ADD CONSTRAINT external_validation_requests_pkey PRIMARY KEY (id);


--
-- Name: feature_snapshots feature_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_snapshots
    ADD CONSTRAINT feature_snapshots_pkey PRIMARY KEY (id);


--
-- Name: feature_snapshots feature_snapshots_tenant_id_player_id_feature_date_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_snapshots
    ADD CONSTRAINT feature_snapshots_tenant_id_player_id_feature_date_key UNIQUE (tenant_id, player_id, feature_date);


--
-- Name: financial_transactions financial_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_pkey PRIMARY KEY (id);


--
-- Name: ingest_errors ingest_errors_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingest_errors
    ADD CONSTRAINT ingest_errors_pkey PRIMARY KEY (id);


--
-- Name: ingest_jobs ingest_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingest_jobs
    ADD CONSTRAINT ingest_jobs_pkey PRIMARY KEY (id);


--
-- Name: mapping_configs mapping_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapping_configs
    ADD CONSTRAINT mapping_configs_pkey PRIMARY KEY (id);


--
-- Name: model_inference_logs model_inference_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_inference_logs
    ADD CONSTRAINT model_inference_logs_pkey PRIMARY KEY (id);


--
-- Name: model_registry model_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: player_kyc_events player_kyc_events_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_kyc_events
    ADD CONSTRAINT player_kyc_events_pkey PRIMARY KEY (id);


--
-- Name: player_list_entries player_list_entries_list_id_cpf_hash_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_list_id_cpf_hash_key UNIQUE (list_id, cpf_hash);


--
-- Name: player_list_entries player_list_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_pkey PRIMARY KEY (id);


--
-- Name: player_lists player_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_lists
    ADD CONSTRAINT player_lists_pkey PRIMARY KEY (id);


--
-- Name: player_lists player_lists_tenant_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_lists
    ADD CONSTRAINT player_lists_tenant_id_name_key UNIQUE (tenant_id, name);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: players players_tenant_id_external_player_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_tenant_id_external_player_id_key UNIQUE (tenant_id, external_player_id);


--
-- Name: report_packages report_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_packages
    ADD CONSTRAINT report_packages_pkey PRIMARY KEY (id);


--
-- Name: rule_definitions rule_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_definitions
    ADD CONSTRAINT rule_definitions_pkey PRIMARY KEY (id);


--
-- Name: rule_execution_logs rule_execution_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_execution_logs
    ADD CONSTRAINT rule_execution_logs_pkey PRIMARY KEY (id);


--
-- Name: rule_macros rule_macros_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_macros
    ADD CONSTRAINT rule_macros_pkey PRIMARY KEY (id);


--
-- Name: rule_macros rule_macros_tenant_id_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_macros
    ADD CONSTRAINT rule_macros_tenant_id_name_key UNIQUE (tenant_id, name);


--
-- Name: schema_migrations schema_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.schema_migrations
    ADD CONSTRAINT schema_migrations_pkey PRIMARY KEY (filename);


--
-- Name: scoring_configs scoring_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scoring_configs
    ADD CONSTRAINT scoring_configs_pkey PRIMARY KEY (id);


--
-- Name: scoring_configs scoring_configs_tenant_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scoring_configs
    ADD CONSTRAINT scoring_configs_tenant_id_key UNIQUE (tenant_id);


--
-- Name: system_flags system_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_flags
    ADD CONSTRAINT system_flags_pkey PRIMARY KEY (key);


--
-- Name: tenants tenants_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_name_key UNIQUE (name);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_tenant_id_email_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_email_key UNIQUE (tenant_id, email);


--
-- Name: users users_tenant_id_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_username_key UNIQUE (tenant_id, username);


--
-- Name: idx_alerts_backfill_job; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_backfill_job ON public.alerts USING btree (tenant_id, backfill_job_id) WHERE (backfill_job_id IS NOT NULL);


--
-- Name: idx_alerts_case_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_case_id ON public.alerts USING btree (case_id) WHERE (case_id IS NOT NULL);


--
-- Name: idx_alerts_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_created ON public.alerts USING btree (created_at DESC);


--
-- Name: idx_alerts_ingest_mode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_ingest_mode ON public.alerts USING btree (tenant_id, ingest_mode, created_at DESC);


--
-- Name: idx_alerts_player; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_player ON public.alerts USING btree (player_id);


--
-- Name: idx_alerts_tenant_label_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_tenant_label_created ON public.alerts USING btree (tenant_id, label, created_at) WHERE (label IS NOT NULL);


--
-- Name: idx_alerts_tenant_player; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_tenant_player ON public.alerts USING btree (tenant_id, player_id);


--
-- Name: idx_alerts_tenant_severity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_tenant_severity ON public.alerts USING btree (tenant_id, severity);


--
-- Name: idx_alerts_tenant_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_tenant_status ON public.alerts USING btree (tenant_id, status);


--
-- Name: idx_alerts_tenant_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_alerts_tenant_status_created ON public.alerts USING btree (tenant_id, status, created_at DESC);


--
-- Name: idx_api_keys_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_hash ON public.api_keys USING btree (key_hash);


--
-- Name: idx_api_keys_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_api_keys_tenant ON public.api_keys USING btree (tenant_id);


--
-- Name: idx_audit_logs_pii_accessed; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_pii_accessed ON public.audit_logs USING btree (tenant_id, pii_accessed) WHERE (pii_accessed IS NOT NULL);


--
-- Name: idx_audit_logs_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_tenant ON public.audit_logs USING btree (tenant_id, created_at DESC);


--
-- Name: idx_audit_logs_tenant_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_tenant_created ON public.audit_logs USING btree (tenant_id, created_at DESC);


--
-- Name: idx_audit_logs_tenant_entity; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_tenant_entity ON public.audit_logs USING btree (tenant_id, entity_type);


--
-- Name: idx_audit_logs_tenant_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_audit_logs_tenant_user ON public.audit_logs USING btree (tenant_id, user_id);


--
-- Name: idx_bets_product_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bets_product_type ON public.bets USING btree (product_type);


--
-- Name: idx_bets_tenant_occurred; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bets_tenant_occurred ON public.bets USING btree (tenant_id, occurred_at DESC);


--
-- Name: idx_bets_tenant_player; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bets_tenant_player ON public.bets USING btree (tenant_id, player_id);


--
-- Name: idx_bets_tenant_player_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bets_tenant_player_ts ON public.bets USING btree (tenant_id, player_id, occurred_at DESC);


--
-- Name: idx_bets_tenant_product; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bets_tenant_product ON public.bets USING btree (tenant_id, product_type);


--
-- Name: idx_bets_tenant_settled; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bets_tenant_settled ON public.bets USING btree (tenant_id, settled_at) WHERE (settled_at IS NOT NULL);


--
-- Name: idx_bets_tenant_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_bets_tenant_status ON public.bets USING btree (tenant_id, status);


--
-- Name: idx_case_events_case_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_case_events_case_type ON public.case_events USING btree (case_id, event_type, created_at DESC);


--
-- Name: INDEX idx_case_events_case_type; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_case_events_case_type IS 'Module 5 — case timeline: events by case + type + time';


--
-- Name: idx_cases_auto_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_auto_created ON public.cases USING btree (tenant_id, auto_created);


--
-- Name: idx_cases_backfill_job; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_backfill_job ON public.cases USING btree (tenant_id, backfill_job_id) WHERE (backfill_job_id IS NOT NULL);


--
-- Name: idx_cases_open_player; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_open_player ON public.cases USING btree (tenant_id, player_id, status, created_at DESC) WHERE (status = ANY (ARRAY['OPEN'::text, 'IN_REVIEW'::text, 'INVESTIGATING'::text, 'PENDING_REVIEW'::text]));


--
-- Name: idx_cases_player; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_player ON public.cases USING btree (player_id);


--
-- Name: idx_cases_sla; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_sla ON public.cases USING btree (tenant_id, sla_due_at) WHERE (status <> ALL (ARRAY['CLOSED'::text, 'CLOSED_SAR'::text, 'CLOSED_SAT'::text]));


--
-- Name: idx_cases_sla_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_sla_active ON public.cases USING btree (tenant_id, sla_due_at, status) WHERE ((status <> ALL (ARRAY['CLOSED'::text, 'REPORTED'::text])) AND (sla_due_at IS NOT NULL));


--
-- Name: INDEX idx_cases_sla_active; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_cases_sla_active IS 'Module 5 — SLA dashboard: active cases sorted by deadline';


--
-- Name: idx_cases_sla_due; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_sla_due ON public.cases USING btree (tenant_id, sla_due_at) WHERE (status <> ALL (ARRAY['CLOSED'::text, 'REPORTED'::text, 'ARCHIVED'::text]));


--
-- Name: idx_cases_tenant_assigned; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_tenant_assigned ON public.cases USING btree (tenant_id, assigned_to) WHERE (assigned_to IS NOT NULL);


--
-- Name: idx_cases_tenant_priority; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_tenant_priority ON public.cases USING btree (tenant_id, priority);


--
-- Name: idx_cases_tenant_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_tenant_status ON public.cases USING btree (tenant_id, status);


--
-- Name: idx_cases_tenant_status_sla; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_cases_tenant_status_sla ON public.cases USING btree (tenant_id, status, sla_due_at DESC NULLS LAST);


--
-- Name: idx_compound_rules_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compound_rules_active ON public.compound_rules USING btree (tenant_id, is_active);


--
-- Name: idx_compound_rules_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_compound_rules_tenant ON public.compound_rules USING btree (tenant_id, is_active);


--
-- Name: idx_dev_tenant_device; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dev_tenant_device ON public.device_events USING btree (tenant_id, device_hash) WHERE (device_hash IS NOT NULL);


--
-- Name: idx_dev_tenant_ip; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dev_tenant_ip ON public.device_events USING btree (tenant_id, ip_hash) WHERE (ip_hash IS NOT NULL);


--
-- Name: idx_dev_tenant_occurred; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dev_tenant_occurred ON public.device_events USING btree (tenant_id, occurred_at DESC);


--
-- Name: idx_dev_tenant_player; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_dev_tenant_player ON public.device_events USING btree (tenant_id, player_id);


--
-- Name: idx_device_events_device_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_events_device_hash ON public.device_events USING btree (tenant_id, device_hash, player_id) WHERE (device_hash IS NOT NULL);


--
-- Name: idx_device_events_ip_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_device_events_ip_hash ON public.device_events USING btree (tenant_id, ip_hash, player_id) WHERE (ip_hash IS NOT NULL);


--
-- Name: idx_feature_snapshots_player; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feature_snapshots_player ON public.feature_snapshots USING btree (player_id, feature_date DESC);


--
-- Name: idx_feature_snapshots_tenant_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feature_snapshots_tenant_created ON public.feature_snapshots USING btree (tenant_id, created_at);


--
-- Name: idx_feature_snapshots_tenant_player_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feature_snapshots_tenant_player_date ON public.feature_snapshots USING btree (tenant_id, player_id, snapshot_date DESC NULLS LAST);


--
-- Name: idx_feature_snapshots_tenant_player_snapshot_date; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feature_snapshots_tenant_player_snapshot_date ON public.feature_snapshots USING btree (tenant_id, player_id, snapshot_date DESC);


--
-- Name: idx_feature_snapshots_version; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_feature_snapshots_version ON public.feature_snapshots USING btree (tenant_id, player_id, feature_version);


--
-- Name: idx_financial_transactions_bank_account_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_transactions_bank_account_hash ON public.financial_transactions USING btree (tenant_id, bank_account_hash, player_id) WHERE (bank_account_hash IS NOT NULL);


--
-- Name: idx_financial_transactions_payment_instrument; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_transactions_payment_instrument ON public.financial_transactions USING btree (tenant_id, payment_instrument, player_id) WHERE (payment_instrument IS NOT NULL);


--
-- Name: idx_financial_transactions_tenant_player_ts; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_transactions_tenant_player_ts ON public.financial_transactions USING btree (tenant_id, player_id, occurred_at DESC);


--
-- Name: idx_financial_transactions_tenant_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_transactions_tenant_status ON public.financial_transactions USING btree (tenant_id, status);


--
-- Name: idx_financial_transactions_tenant_type; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_financial_transactions_tenant_type ON public.financial_transactions USING btree (tenant_id, type);


--
-- Name: idx_ft_bank_hash; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ft_bank_hash ON public.financial_transactions USING btree (bank_account_hash) WHERE (bank_account_hash IS NOT NULL);


--
-- Name: idx_ft_instrument; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ft_instrument ON public.financial_transactions USING btree (payment_instrument) WHERE (payment_instrument IS NOT NULL);


--
-- Name: idx_ft_tenant_occurred; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ft_tenant_occurred ON public.financial_transactions USING btree (tenant_id, occurred_at DESC);


--
-- Name: idx_ft_tenant_player; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ft_tenant_player ON public.financial_transactions USING btree (tenant_id, player_id);


--
-- Name: idx_ft_tenant_type_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ft_tenant_type_status ON public.financial_transactions USING btree (tenant_id, type, status);


--
-- Name: idx_ingest_errors_job; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ingest_errors_job ON public.ingest_errors USING btree (ingest_job_id);


--
-- Name: idx_ingest_errors_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ingest_errors_tenant ON public.ingest_errors USING btree (tenant_id, resolved);


--
-- Name: idx_ingest_errors_tenant_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ingest_errors_tenant_created ON public.ingest_errors USING btree (tenant_id, created_at);


--
-- Name: idx_ingest_errors_tenant_job; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ingest_errors_tenant_job ON public.ingest_errors USING btree (tenant_id, ingest_job_id);


--
-- Name: idx_ingest_errors_tenant_resolved; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ingest_errors_tenant_resolved ON public.ingest_errors USING btree (tenant_id, resolved) WHERE (resolved = false);


--
-- Name: idx_ingest_jobs_ingest_mode; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ingest_jobs_ingest_mode ON public.ingest_jobs USING btree (tenant_id, ingest_mode, created_at DESC);


--
-- Name: idx_ingest_jobs_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ingest_jobs_tenant ON public.ingest_jobs USING btree (tenant_id, status);


--
-- Name: idx_ingest_jobs_tenant_source; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ingest_jobs_tenant_source ON public.ingest_jobs USING btree (tenant_id, source_system);


--
-- Name: idx_ingest_jobs_tenant_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_ingest_jobs_tenant_status_created ON public.ingest_jobs USING btree (tenant_id, status, created_at DESC);


--
-- Name: idx_model_inference_model; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_inference_model ON public.model_inference_logs USING btree (tenant_id, model_id, scored_at DESC);


--
-- Name: idx_model_inference_tenant_time; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_inference_tenant_time ON public.model_inference_logs USING btree (tenant_id, scored_at DESC);


--
-- Name: idx_model_inference_variant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_inference_variant ON public.model_inference_logs USING btree (tenant_id, model_variant, scored_at DESC);


--
-- Name: idx_model_registry_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_registry_active ON public.model_registry USING btree (tenant_id, is_active, algorithm);


--
-- Name: idx_model_registry_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_model_registry_tenant ON public.model_registry USING btree (tenant_id, status);


--
-- Name: idx_notifications_reference; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_reference ON public.notifications USING btree (reference_type, reference_id) WHERE (reference_type IS NOT NULL);


--
-- Name: idx_notifications_tenant_read_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_tenant_read_created ON public.notifications USING btree (tenant_id, is_read, created_at DESC);


--
-- Name: idx_notifications_unread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_unread ON public.notifications USING btree (user_id) WHERE (read = false);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user ON public.notifications USING btree (user_id, is_read, created_at DESC);


--
-- Name: idx_notifications_user_unread; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_notifications_user_unread ON public.notifications USING btree (user_id, is_read, created_at DESC) WHERE (is_read = false);


--
-- Name: INDEX idx_notifications_user_unread; Type: COMMENT; Schema: public; Owner: -
--

COMMENT ON INDEX public.idx_notifications_user_unread IS 'Module 5 — notification bell: unread count per user';


--
-- Name: idx_pkyc_backfill; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pkyc_backfill ON public.player_kyc_events USING btree (tenant_id, backfill_job_id) WHERE (backfill_job_id IS NOT NULL);


--
-- Name: idx_pkyc_player; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pkyc_player ON public.player_kyc_events USING btree (tenant_id, player_id, occurred_at DESC);


--
-- Name: idx_pkyc_subtype; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_pkyc_subtype ON public.player_kyc_events USING btree (tenant_id, entity_type, subtype, occurred_at DESC);


--
-- Name: idx_player_list_entries_cpf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_player_list_entries_cpf ON public.player_list_entries USING btree (cpf_hash);


--
-- Name: idx_player_list_entries_list; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_player_list_entries_list ON public.player_list_entries USING btree (list_id);


--
-- Name: idx_player_list_entries_unique_val; Type: INDEX; Schema: public; Owner: -
--

CREATE UNIQUE INDEX idx_player_list_entries_unique_val ON public.player_list_entries USING btree (list_id, value) WHERE (value IS NOT NULL);


--
-- Name: idx_player_list_entries_val; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_player_list_entries_val ON public.player_list_entries USING btree (tenant_id, value);


--
-- Name: idx_player_lists_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_player_lists_tenant ON public.player_lists USING btree (tenant_id, list_type);


--
-- Name: idx_players_cluster_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_players_cluster_id ON public.players USING btree (tenant_id, cluster_id) WHERE (cluster_id IS NOT NULL);


--
-- Name: idx_players_risk_band; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_players_risk_band ON public.players USING btree (tenant_id, risk_band);


--
-- Name: idx_players_risk_score; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_players_risk_score ON public.players USING btree (tenant_id, risk_score DESC);


--
-- Name: idx_players_status_not_erased; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_players_status_not_erased ON public.players USING btree (tenant_id, status) WHERE (status <> 'ERASED'::text);


--
-- Name: idx_players_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_players_tenant ON public.players USING btree (tenant_id, external_player_id);


--
-- Name: idx_players_tenant_cpf; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_players_tenant_cpf ON public.players USING btree (tenant_id, cpf_encrypted);


--
-- Name: idx_players_tenant_cpf_hmac; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_players_tenant_cpf_hmac ON public.players USING btree (tenant_id, cpf_hmac) WHERE (cpf_hmac IS NOT NULL);


--
-- Name: idx_players_tenant_customer_id; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_players_tenant_customer_id ON public.players USING btree (tenant_id, external_player_id);


--
-- Name: idx_players_tenant_risk_score; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_players_tenant_risk_score ON public.players USING btree (tenant_id, risk_score DESC NULLS LAST);


--
-- Name: idx_players_tenant_status; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_players_tenant_status ON public.players USING btree (tenant_id, status);


--
-- Name: idx_report_packages_case; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_report_packages_case ON public.report_packages USING btree (case_id);


--
-- Name: idx_report_packages_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_report_packages_tenant ON public.report_packages USING btree (tenant_id, created_at DESC);


--
-- Name: idx_report_packages_tenant_status_created; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_report_packages_tenant_status_created ON public.report_packages USING btree (tenant_id, status, created_at);


--
-- Name: idx_rule_definitions_tenant_active; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rule_definitions_tenant_active ON public.rule_definitions USING btree (tenant_id, status) WHERE (status = 'ACTIVE'::text);


--
-- Name: idx_rule_exec_tenant_event; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_rule_exec_tenant_event ON public.rule_execution_logs USING btree (tenant_id, source_event_id);


--
-- Name: idx_scoring_config_tenant; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_scoring_config_tenant ON public.scoring_configs USING btree (tenant_id);


--
-- Name: idx_users_refresh_token_jti; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_refresh_token_jti ON public.users USING btree (refresh_token_jti);


--
-- Name: idx_users_roles; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX idx_users_roles ON public.users USING gin (roles);


--
-- Name: audit_logs trg_prevent_audit_log_update_delete; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER trg_prevent_audit_log_update_delete BEFORE DELETE OR UPDATE ON public.audit_logs FOR EACH ROW EXECUTE FUNCTION public.prevent_audit_log_mutation();


--
-- Name: alerts alerts_compound_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_compound_rule_id_fkey FOREIGN KEY (compound_rule_id) REFERENCES public.compound_rules(id);


--
-- Name: alerts alerts_labeled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_labeled_by_fkey FOREIGN KEY (labeled_by) REFERENCES public.users(id);


--
-- Name: alerts alerts_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: alerts alerts_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.rule_definitions(id);


--
-- Name: alerts alerts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: alerts alerts_triaged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_triaged_by_fkey FOREIGN KEY (triaged_by) REFERENCES public.users(id);


--
-- Name: api_keys api_keys_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: api_keys api_keys_revoked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_revoked_by_fkey FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: api_keys api_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: bets bets_ingest_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bets
    ADD CONSTRAINT bets_ingest_job_id_fkey FOREIGN KEY (ingest_job_id) REFERENCES public.ingest_jobs(id) ON DELETE SET NULL;


--
-- Name: bets bets_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bets
    ADD CONSTRAINT bets_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE SET NULL;


--
-- Name: bets bets_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.bets
    ADD CONSTRAINT bets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: case_events case_events_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events
    ADD CONSTRAINT case_events_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: case_events case_events_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events
    ADD CONSTRAINT case_events_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: case_events case_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.case_events
    ADD CONSTRAINT case_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: cases cases_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: cases cases_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id);


--
-- Name: cases cases_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: cases cases_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: cases cases_source_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_source_alert_id_fkey FOREIGN KEY (source_alert_id) REFERENCES public.alerts(id);


--
-- Name: cases cases_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: compound_rules compound_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compound_rules
    ADD CONSTRAINT compound_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: compound_rules compound_rules_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compound_rules
    ADD CONSTRAINT compound_rules_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: compound_rules compound_rules_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.compound_rules
    ADD CONSTRAINT compound_rules_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: device_events device_events_ingest_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_events
    ADD CONSTRAINT device_events_ingest_job_id_fkey FOREIGN KEY (ingest_job_id) REFERENCES public.ingest_jobs(id) ON DELETE SET NULL;


--
-- Name: device_events device_events_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_events
    ADD CONSTRAINT device_events_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE SET NULL;


--
-- Name: device_events device_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.device_events
    ADD CONSTRAINT device_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: external_validation_requests external_validation_requests_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_validation_requests
    ADD CONSTRAINT external_validation_requests_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE CASCADE;


--
-- Name: external_validation_requests external_validation_requests_requested_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_validation_requests
    ADD CONSTRAINT external_validation_requests_requested_by_fkey FOREIGN KEY (requested_by) REFERENCES public.users(id);


--
-- Name: external_validation_requests external_validation_requests_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.external_validation_requests
    ADD CONSTRAINT external_validation_requests_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: feature_snapshots feature_snapshots_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_snapshots
    ADD CONSTRAINT feature_snapshots_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE CASCADE;


--
-- Name: feature_snapshots feature_snapshots_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.feature_snapshots
    ADD CONSTRAINT feature_snapshots_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: financial_transactions financial_transactions_ingest_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_ingest_job_id_fkey FOREIGN KEY (ingest_job_id) REFERENCES public.ingest_jobs(id) ON DELETE SET NULL;


--
-- Name: financial_transactions financial_transactions_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE SET NULL;


--
-- Name: financial_transactions financial_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: alerts fk_alerts_case; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT fk_alerts_case FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE SET NULL;


--
-- Name: ingest_errors ingest_errors_ingest_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingest_errors
    ADD CONSTRAINT ingest_errors_ingest_job_id_fkey FOREIGN KEY (ingest_job_id) REFERENCES public.ingest_jobs(id) ON DELETE SET NULL;


--
-- Name: ingest_errors ingest_errors_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingest_errors
    ADD CONSTRAINT ingest_errors_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: ingest_errors ingest_errors_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingest_errors
    ADD CONSTRAINT ingest_errors_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: ingest_jobs ingest_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingest_jobs
    ADD CONSTRAINT ingest_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: ingest_jobs ingest_jobs_mapping_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingest_jobs
    ADD CONSTRAINT ingest_jobs_mapping_config_id_fkey FOREIGN KEY (mapping_config_id) REFERENCES public.mapping_configs(id);


--
-- Name: ingest_jobs ingest_jobs_mapping_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingest_jobs
    ADD CONSTRAINT ingest_jobs_mapping_version_id_fkey FOREIGN KEY (mapping_version_id) REFERENCES public.mapping_configs(id);


--
-- Name: ingest_jobs ingest_jobs_reprocessed_from_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingest_jobs
    ADD CONSTRAINT ingest_jobs_reprocessed_from_fkey FOREIGN KEY (reprocessed_from) REFERENCES public.ingest_jobs(id);


--
-- Name: ingest_jobs ingest_jobs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.ingest_jobs
    ADD CONSTRAINT ingest_jobs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: mapping_configs mapping_configs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapping_configs
    ADD CONSTRAINT mapping_configs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: mapping_configs mapping_configs_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapping_configs
    ADD CONSTRAINT mapping_configs_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.mapping_configs(id);


--
-- Name: mapping_configs mapping_configs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.mapping_configs
    ADD CONSTRAINT mapping_configs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: model_inference_logs model_inference_logs_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_inference_logs
    ADD CONSTRAINT model_inference_logs_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.model_registry(id) ON DELETE SET NULL;


--
-- Name: model_inference_logs model_inference_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_inference_logs
    ADD CONSTRAINT model_inference_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: model_registry model_registry_champion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_champion_id_fkey FOREIGN KEY (champion_id) REFERENCES public.model_registry(id);


--
-- Name: model_registry model_registry_promoted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_promoted_by_fkey FOREIGN KEY (promoted_by) REFERENCES public.users(id);


--
-- Name: model_registry model_registry_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: notifications notifications_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: player_list_entries player_list_entries_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id);


--
-- Name: player_list_entries player_list_entries_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.player_lists(id) ON DELETE CASCADE;


--
-- Name: player_list_entries player_list_entries_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE SET NULL;


--
-- Name: player_list_entries player_list_entries_player_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_player_list_id_fkey FOREIGN KEY (player_list_id) REFERENCES public.player_lists(id) ON DELETE CASCADE;


--
-- Name: player_list_entries player_list_entries_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: player_lists player_lists_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_lists
    ADD CONSTRAINT player_lists_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: player_lists player_lists_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_lists
    ADD CONSTRAINT player_lists_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: player_lists player_lists_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.player_lists
    ADD CONSTRAINT player_lists_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: players players_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: report_packages report_packages_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_packages
    ADD CONSTRAINT report_packages_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(id);


--
-- Name: report_packages report_packages_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_packages
    ADD CONSTRAINT report_packages_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: report_packages report_packages_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_packages
    ADD CONSTRAINT report_packages_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: report_packages report_packages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.report_packages
    ADD CONSTRAINT report_packages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: rule_definitions rule_definitions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_definitions
    ADD CONSTRAINT rule_definitions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: rule_definitions rule_definitions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_definitions
    ADD CONSTRAINT rule_definitions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: rule_definitions rule_definitions_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_definitions
    ADD CONSTRAINT rule_definitions_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: rule_execution_logs rule_execution_logs_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_execution_logs
    ADD CONSTRAINT rule_execution_logs_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.rule_definitions(id);


--
-- Name: rule_execution_logs rule_execution_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_execution_logs
    ADD CONSTRAINT rule_execution_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: rule_macros rule_macros_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_macros
    ADD CONSTRAINT rule_macros_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: rule_macros rule_macros_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.rule_macros
    ADD CONSTRAINT rule_macros_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: scoring_configs scoring_configs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scoring_configs
    ADD CONSTRAINT scoring_configs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: scoring_configs scoring_configs_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.scoring_configs
    ADD CONSTRAINT scoring_configs_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: system_flags system_flags_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.system_flags
    ADD CONSTRAINT system_flags_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: alerts; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.alerts ENABLE ROW LEVEL SECURITY;

--
-- Name: alerts alerts_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY alerts_tenant_isolation ON public.alerts USING ((tenant_id = public.current_tenant_id()));


--
-- Name: api_keys; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.api_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs audit_logs_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY audit_logs_tenant_isolation ON public.audit_logs USING ((tenant_id = public.current_tenant_id()));


--
-- Name: bets; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.bets ENABLE ROW LEVEL SECURITY;

--
-- Name: case_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.case_events ENABLE ROW LEVEL SECURITY;

--
-- Name: case_events case_events_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY case_events_tenant_isolation ON public.case_events USING ((tenant_id = public.current_tenant_id()));


--
-- Name: cases; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.cases ENABLE ROW LEVEL SECURITY;

--
-- Name: cases cases_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY cases_tenant_isolation ON public.cases USING ((tenant_id = public.current_tenant_id()));


--
-- Name: compound_rules; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.compound_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: compound_rules compound_rules_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY compound_rules_tenant_isolation ON public.compound_rules USING ((tenant_id = public.current_tenant_id()));


--
-- Name: device_events; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.device_events ENABLE ROW LEVEL SECURITY;

--
-- Name: feature_snapshots; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.feature_snapshots ENABLE ROW LEVEL SECURITY;

--
-- Name: feature_snapshots feature_snapshots_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY feature_snapshots_tenant_isolation ON public.feature_snapshots USING ((tenant_id = public.current_tenant_id()));


--
-- Name: financial_transactions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.financial_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: ingest_errors; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ingest_errors ENABLE ROW LEVEL SECURITY;

--
-- Name: ingest_jobs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.ingest_jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: ingest_jobs ingest_jobs_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY ingest_jobs_tenant_isolation ON public.ingest_jobs USING ((tenant_id = public.current_tenant_id()));


--
-- Name: mapping_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.mapping_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: mapping_configs mapping_configs_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY mapping_configs_tenant_isolation ON public.mapping_configs USING ((tenant_id = public.current_tenant_id()));


--
-- Name: model_inference_logs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.model_inference_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: model_registry; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.model_registry ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications notifications_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY notifications_tenant_isolation ON public.notifications USING ((tenant_id = public.current_tenant_id()));


--
-- Name: player_list_entries; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.player_list_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: player_list_entries player_list_entries_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY player_list_entries_tenant_isolation ON public.player_list_entries USING ((tenant_id = public.current_tenant_id()));


--
-- Name: player_lists; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.player_lists ENABLE ROW LEVEL SECURITY;

--
-- Name: player_lists player_lists_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY player_lists_tenant_isolation ON public.player_lists USING ((tenant_id = public.current_tenant_id()));


--
-- Name: players; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.players ENABLE ROW LEVEL SECURITY;

--
-- Name: players players_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY players_tenant_isolation ON public.players USING ((tenant_id = public.current_tenant_id()));


--
-- Name: report_packages; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.report_packages ENABLE ROW LEVEL SECURITY;

--
-- Name: report_packages report_packages_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY report_packages_tenant_isolation ON public.report_packages USING ((tenant_id = public.current_tenant_id()));


--
-- Name: rule_definitions; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.rule_definitions ENABLE ROW LEVEL SECURITY;

--
-- Name: rule_definitions rules_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY rules_tenant_isolation ON public.rule_definitions USING ((tenant_id = public.current_tenant_id()));


--
-- Name: scoring_configs; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.scoring_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: scoring_configs scoring_configs_tenant_isolation; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY scoring_configs_tenant_isolation ON public.scoring_configs USING ((tenant_id = public.current_tenant_id()));


--
-- Name: alerts tenant_isolation_alerts; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_alerts ON public.alerts USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: api_keys tenant_isolation_api_keys; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_api_keys ON public.api_keys USING ((tenant_id = public.current_tenant_id()));


--
-- Name: audit_logs tenant_isolation_audit_logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_audit_logs ON public.audit_logs USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: bets tenant_isolation_bets; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_bets ON public.bets USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: case_events tenant_isolation_case_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_case_events ON public.case_events USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: cases tenant_isolation_cases; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_cases ON public.cases USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: device_events tenant_isolation_device_events; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_device_events ON public.device_events USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: financial_transactions tenant_isolation_financial_transactions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_financial_transactions ON public.financial_transactions USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: ingest_errors tenant_isolation_ingest_errors; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_ingest_errors ON public.ingest_errors USING ((tenant_id = public.current_tenant_id()));


--
-- Name: ingest_jobs tenant_isolation_ingest_jobs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_ingest_jobs ON public.ingest_jobs USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: model_inference_logs tenant_isolation_model_inference_logs; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_model_inference_logs ON public.model_inference_logs USING ((tenant_id = public.current_tenant_id()));


--
-- Name: model_registry tenant_isolation_model_registry; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_model_registry ON public.model_registry USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: notifications tenant_isolation_notifications; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_notifications ON public.notifications USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: players tenant_isolation_players; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_players ON public.players USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: report_packages tenant_isolation_report_packages; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_report_packages ON public.report_packages USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: rule_definitions tenant_isolation_rule_definitions; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_rule_definitions ON public.rule_definitions USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: tenants tenant_isolation_tenants_delete; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_tenants_delete ON public.tenants FOR DELETE USING ((id = public.current_tenant_id()));


--
-- Name: tenants tenant_isolation_tenants_insert; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_tenants_insert ON public.tenants FOR INSERT WITH CHECK (((id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenants tenant_isolation_tenants_select; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_tenants_select ON public.tenants FOR SELECT USING (((id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenants tenant_isolation_tenants_update; Type: POLICY; Schema: public; Owner: -
--

CREATE POLICY tenant_isolation_tenants_update ON public.tenants FOR UPDATE USING ((id = public.current_tenant_id()));


--
-- Name: tenants; Type: ROW SECURITY; Schema: public; Owner: -
--

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

--
-- PostgreSQL database dump complete
--

\unrestrict jXqiBorBcIYkIV1mdT62bi59sfLliKFPuQTtipMCeWmbdUiZYfGDBQi0UkYmpiQ

