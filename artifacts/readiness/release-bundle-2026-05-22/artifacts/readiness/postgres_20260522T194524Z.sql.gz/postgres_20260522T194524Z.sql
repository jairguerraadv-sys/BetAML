--
-- PostgreSQL database dump
--

\restrict N5v3rYPncnYLJxIWdPnbA1xM8nKtHNLAjIaezEYy8ozLxqQDTTBIY65Oecq952C

-- Dumped from database version 16.14
-- Dumped by pg_dump version 16.14

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: pgcrypto; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS pgcrypto WITH SCHEMA public;


--
-- Name: EXTENSION pgcrypto; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION pgcrypto IS 'cryptographic functions';


--
-- Name: uuid-ossp; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS "uuid-ossp" WITH SCHEMA public;


--
-- Name: EXTENSION "uuid-ossp"; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION "uuid-ossp" IS 'generate universally unique identifiers (UUIDs)';


--
-- Name: current_tenant_id(); Type: FUNCTION; Schema: public; Owner: betaml
--

CREATE FUNCTION public.current_tenant_id() RETURNS uuid
    LANGUAGE sql STABLE
    AS $$
    SELECT NULLIF(current_setting('app.current_tenant', TRUE), '')::UUID;
$$;


ALTER FUNCTION public.current_tenant_id() OWNER TO betaml;

--
-- Name: prevent_audit_log_mutation(); Type: FUNCTION; Schema: public; Owner: betaml
--

CREATE FUNCTION public.prevent_audit_log_mutation() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
BEGIN
    RAISE EXCEPTION 'audit_logs is immutable: operation % is not allowed', TG_OP;
END;
$$;


ALTER FUNCTION public.prevent_audit_log_mutation() OWNER TO betaml;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: alembic_version; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.alembic_version (
    version_num character varying(32) NOT NULL
);


ALTER TABLE public.alembic_version OWNER TO betaml;

--
-- Name: alerts; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.alerts (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    rule_id uuid,
    alert_type text DEFAULT 'RULE'::text NOT NULL,
    severity text NOT NULL,
    status text DEFAULT 'OPEN'::text NOT NULL,
    title text NOT NULL,
    description text,
    evidence jsonb DEFAULT '{}'::jsonb NOT NULL,
    anomaly_score numeric(5,4),
    source_event_id text,
    case_id uuid,
    triaged_by uuid,
    triaged_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    label text,
    labeled_by uuid,
    labeled_at timestamp with time zone,
    rule_weight numeric(4,3) DEFAULT 0.4,
    ml_weight numeric(4,3) DEFAULT 0.4,
    network_weight numeric(4,3) DEFAULT 0.2,
    composite_score numeric(5,4),
    score_breakdown jsonb DEFAULT '{}'::jsonb,
    compound_rule_id uuid,
    label_note text,
    ingest_mode character varying(20) DEFAULT 'incremental'::character varying NOT NULL,
    backfill_job_id text,
    priority text DEFAULT 'MEDIUM'::text NOT NULL,
    sla_due_at timestamp with time zone,
    triage_note text,
    CONSTRAINT alerts_alert_type_check CHECK ((alert_type = ANY (ARRAY['RULE'::text, 'ANOMALY'::text, 'COMPOSITE'::text, 'ML_ANOMALY'::text, 'NETWORK'::text, 'INCOME_INCOMPATIBILITY'::text, 'AML_SUSPICIOUS'::text, 'AML_HIGH_RISK'::text]))),
    CONSTRAINT alerts_label_check CHECK ((label = ANY (ARRAY['TRUE_POSITIVE'::text, 'FALSE_POSITIVE'::text, 'UNKNOWN'::text]))),
    CONSTRAINT alerts_priority_check CHECK ((priority = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text, 'CRITICAL'::text]))),
    CONSTRAINT alerts_severity_check CHECK ((severity = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text, 'CRITICAL'::text]))),
    CONSTRAINT alerts_status_check CHECK ((status = ANY (ARRAY['OPEN'::text, 'IN_REVIEW'::text, 'CONFIRMED'::text, 'DISMISSED'::text, 'FALSE_POSITIVE'::text, 'CLOSED'::text])))
);

ALTER TABLE ONLY public.alerts FORCE ROW LEVEL SECURITY;


ALTER TABLE public.alerts OWNER TO betaml;

--
-- Name: COLUMN alerts.backfill_job_id; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON COLUMN public.alerts.backfill_job_id IS 'ID do IngestJob de backfill/reprocess que originou este alerta. Preenchido quando ingest_mode IN (''backfill'', ''reprocess'').';


--
-- Name: api_keys; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.api_keys (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    key_hash text NOT NULL,
    key_prefix text NOT NULL,
    source_system text,
    permissions jsonb DEFAULT '["ingest"]'::jsonb NOT NULL,
    active boolean DEFAULT true NOT NULL,
    last_used_at timestamp with time zone,
    expires_at timestamp with time zone,
    created_by uuid,
    revoked_by uuid,
    revoked_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.api_keys FORCE ROW LEVEL SECURITY;


ALTER TABLE public.api_keys OWNER TO betaml;

--
-- Name: audit_logs; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.audit_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid,
    action text NOT NULL,
    entity_type text NOT NULL,
    entity_id text,
    before jsonb,
    after jsonb,
    ip_address text,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    pii_accessed text
);

ALTER TABLE ONLY public.audit_logs FORCE ROW LEVEL SECURITY;


ALTER TABLE public.audit_logs OWNER TO betaml;

--
-- Name: COLUMN audit_logs.pii_accessed; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON COLUMN public.audit_logs.pii_accessed IS 'Campo de PII acessado — cpf, cpf_masked, full_name, etc. (LGPD Art. 37 rastreabilidade)';


--
-- Name: bets; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.bets (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    external_bet_id text,
    source_system text NOT NULL,
    bet_type text DEFAULT 'SPORTS'::text NOT NULL,
    stake_amount numeric(15,2) NOT NULL,
    potential_payout numeric(15,2),
    actual_payout numeric(15,2),
    odds numeric(10,4),
    currency text DEFAULT 'BRL'::text NOT NULL,
    status text DEFAULT 'OPEN'::text NOT NULL,
    event_name text,
    market_name text,
    selection_name text,
    source_event_id text,
    ingest_job_id uuid,
    raw_payload jsonb DEFAULT '{}'::jsonb,
    occurred_at timestamp with time zone NOT NULL,
    settled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    product_type text DEFAULT 'SPORTSBOOK'::text NOT NULL,
    game_id text,
    game_name text,
    game_provider text,
    game_category text,
    rtp_teorico numeric(6,4)
);


ALTER TABLE public.bets OWNER TO betaml;

--
-- Name: case_events; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.case_events (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    case_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    event_type text NOT NULL,
    content jsonb DEFAULT '{}'::jsonb NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT case_events_event_type_check CHECK ((event_type = ANY (ARRAY['NOTE'::text, 'COMMENT'::text, 'STATUS_CHANGE'::text, 'ALERT_LINKED'::text, 'ALERT_LINKED_TO_EXISTING_CASE'::text, 'AUTO_CREATED'::text, 'AUTO_CREATED_FROM_ALERT'::text, 'REPORT_GENERATED'::text, 'REPORT_SUBMITTED'::text, 'ASSIGNED'::text, 'ASSIGNMENT'::text, 'CLOSED'::text, 'EVIDENCE_ADDED'::text, 'EVIDENCE_UPLOAD'::text])))
);

ALTER TABLE ONLY public.case_events FORCE ROW LEVEL SECURITY;


ALTER TABLE public.case_events OWNER TO betaml;

--
-- Name: cases; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.cases (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    title text NOT NULL,
    description text,
    status text DEFAULT 'OPEN'::text NOT NULL,
    severity text DEFAULT 'HIGH'::text NOT NULL,
    assigned_to uuid,
    created_by uuid,
    closed_by uuid,
    closed_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    reference_number text,
    sla_due_at timestamp with time zone,
    priority text DEFAULT 'MEDIUM'::text,
    auto_created boolean DEFAULT false NOT NULL,
    auto_created_reason text,
    source_alert_id uuid,
    backfill_job_id text,
    ingest_mode character varying(20) DEFAULT 'incremental'::character varying NOT NULL,
    CONSTRAINT cases_priority_check CHECK ((priority = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text, 'CRITICAL'::text]))),
    CONSTRAINT cases_severity_check CHECK ((severity = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text, 'CRITICAL'::text]))),
    CONSTRAINT cases_status_check CHECK ((status = ANY (ARRAY['OPEN'::text, 'INVESTIGATING'::text, 'PENDING_REVIEW'::text, 'CLOSED'::text, 'REPORTED'::text])))
);

ALTER TABLE ONLY public.cases FORCE ROW LEVEL SECURITY;


ALTER TABLE public.cases OWNER TO betaml;

--
-- Name: COLUMN cases.backfill_job_id; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON COLUMN public.cases.backfill_job_id IS 'ID do IngestJob de backfill/reprocess que originou este caso automaticamente.';


--
-- Name: compound_rules; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.compound_rules (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    n_threshold integer,
    severity_mode text DEFAULT 'MAX'::text NOT NULL,
    fixed_severity text,
    version integer DEFAULT 1 NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    logic text,
    component_rule_ids jsonb DEFAULT '[]'::jsonb NOT NULL,
    score_weights jsonb DEFAULT '{}'::jsonb NOT NULL,
    min_score_threshold numeric(5,4),
    CONSTRAINT compound_rules_fixed_severity_check CHECK ((fixed_severity = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text, 'CRITICAL'::text]))),
    CONSTRAINT compound_rules_severity_mode_check CHECK ((severity_mode = ANY (ARRAY['MAX'::text, 'MIN'::text, 'FIXED'::text]))),
    CONSTRAINT compound_rules_status_check CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'INACTIVE'::text, 'DRAFT'::text])))
);

ALTER TABLE ONLY public.compound_rules FORCE ROW LEVEL SECURITY;


ALTER TABLE public.compound_rules OWNER TO betaml;

--
-- Name: device_events; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.device_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    external_evt_id text,
    source_system text NOT NULL,
    action text NOT NULL,
    device_id text,
    device_type text,
    device_hash text,
    ip_address text,
    ip_hash text,
    country_code text,
    user_agent text,
    session_id text,
    source_event_id text,
    ingest_job_id uuid,
    raw_payload jsonb DEFAULT '{}'::jsonb,
    occurred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.device_events OWNER TO betaml;

--
-- Name: external_validation_requests; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.external_validation_requests (
    id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid NOT NULL,
    provider character varying(40) DEFAULT 'mock_identity'::character varying NOT NULL,
    validation_type character varying(40) DEFAULT 'CPF_IDENTITY'::character varying NOT NULL,
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    request_payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    response_payload jsonb DEFAULT '{}'::jsonb,
    external_request_id text,
    error_message text,
    requested_by uuid,
    requested_at timestamp with time zone DEFAULT now() NOT NULL,
    completed_at timestamp with time zone,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.external_validation_requests FORCE ROW LEVEL SECURITY;


ALTER TABLE public.external_validation_requests OWNER TO betaml;

--
-- Name: feature_snapshots; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.feature_snapshots (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid NOT NULL,
    feature_date date NOT NULL,
    features jsonb DEFAULT '{}'::jsonb NOT NULL,
    drift_score numeric(5,4),
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    snapshot_date date,
    feature_version integer DEFAULT 2 NOT NULL
);

ALTER TABLE ONLY public.feature_snapshots FORCE ROW LEVEL SECURITY;


ALTER TABLE public.feature_snapshots OWNER TO betaml;

--
-- Name: financial_transactions; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.financial_transactions (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    external_tx_id text,
    source_system text NOT NULL,
    type text NOT NULL,
    amount numeric(15,2) NOT NULL,
    currency text DEFAULT 'BRL'::text NOT NULL,
    status text DEFAULT 'PENDING'::text NOT NULL,
    payment_method text,
    payment_instrument text,
    bank_account_hash text,
    source_event_id text,
    ingest_job_id uuid,
    raw_payload jsonb DEFAULT '{}'::jsonb,
    occurred_at timestamp with time zone NOT NULL,
    settled_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    payment_method_flagged boolean DEFAULT false NOT NULL,
    CONSTRAINT chk_payment_method CHECK ((payment_method = ANY (ARRAY['PIX'::text, 'TED'::text, 'DEBIT'::text, 'CARD_DEBIT'::text, 'CARD_CREDIT'::text, 'WALLET'::text, 'OTHER'::text, 'CARD'::text]))),
    CONSTRAINT chk_transaction_type CHECK ((type = ANY (ARRAY['DEPOSIT'::text, 'WITHDRAWAL'::text, 'REVERSAL'::text, 'BONUS'::text, 'FREE_BET'::text, 'CASHOUT'::text, 'ADJUSTMENT'::text, 'CHARGEBACK'::text])))
);


ALTER TABLE public.financial_transactions OWNER TO betaml;

--
-- Name: ingest_errors; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.ingest_errors (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    ingest_job_id uuid,
    source_system text NOT NULL,
    entity_type text,
    raw_payload text NOT NULL,
    error_reason text NOT NULL,
    error_detail jsonb DEFAULT '{}'::jsonb NOT NULL,
    line_number integer,
    resolved boolean DEFAULT false NOT NULL,
    resolved_by uuid,
    resolved_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.ingest_errors FORCE ROW LEVEL SECURITY;


ALTER TABLE public.ingest_errors OWNER TO betaml;

--
-- Name: ingest_jobs; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.ingest_jobs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    source_system text NOT NULL,
    mapping_config_id uuid,
    file_name text,
    file_size_bytes bigint,
    file_path text,
    status text DEFAULT 'QUEUED'::text NOT NULL,
    total_records integer,
    processed_records integer DEFAULT 0,
    failed_records integer DEFAULT 0,
    error_message text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    bytes_processed bigint DEFAULT 0,
    duration_ms bigint,
    error_sample jsonb DEFAULT '[]'::jsonb,
    connector_type text DEFAULT 'FILE'::text,
    reprocessed_from uuid,
    mapping_version_id uuid,
    ingest_mode character varying(20) DEFAULT 'incremental'::character varying NOT NULL,
    is_backfill boolean DEFAULT false NOT NULL,
    CONSTRAINT ingest_jobs_connector_type_check CHECK ((connector_type = ANY (ARRAY['FILE'::text, 'WEBHOOK'::text, 'WEBSOCKET'::text, 'NDJSON'::text, 'XML'::text]))),
    CONSTRAINT ingest_jobs_status_check CHECK ((status = ANY (ARRAY['QUEUED'::text, 'PROCESSING'::text, 'DONE'::text, 'FAILED'::text, 'PARTIAL'::text])))
);

ALTER TABLE ONLY public.ingest_jobs FORCE ROW LEVEL SECURITY;


ALTER TABLE public.ingest_jobs OWNER TO betaml;

--
-- Name: mapping_configs; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.mapping_configs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    source_system text NOT NULL,
    entity_type text NOT NULL,
    version text DEFAULT '1.0'::text NOT NULL,
    config_json jsonb NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    parent_id uuid,
    is_current boolean DEFAULT true NOT NULL,
    version_number integer DEFAULT 1 NOT NULL,
    change_notes text
);

ALTER TABLE ONLY public.mapping_configs FORCE ROW LEVEL SECURITY;


ALTER TABLE public.mapping_configs OWNER TO betaml;

--
-- Name: model_inference_logs; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.model_inference_logs (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    model_id uuid,
    model_variant text NOT NULL,
    anomaly_score numeric(5,4) NOT NULL,
    is_anomaly boolean DEFAULT false NOT NULL,
    request_id text,
    scored_at timestamp with time zone DEFAULT now() NOT NULL
);

ALTER TABLE ONLY public.model_inference_logs FORCE ROW LEVEL SECURITY;


ALTER TABLE public.model_inference_logs OWNER TO betaml;

--
-- Name: model_registry; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.model_registry (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    model_name text NOT NULL,
    model_version text NOT NULL,
    algorithm text NOT NULL,
    dataset_window_days integer,
    metrics jsonb DEFAULT '{}'::jsonb NOT NULL,
    trained_at timestamp with time zone DEFAULT now() NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    model_type text DEFAULT 'ANOMALY'::text,
    status text DEFAULT 'STAGING'::text,
    dataset_window_start timestamp with time zone,
    dataset_window_end timestamp with time zone,
    promoted_by uuid,
    promoted_at timestamp with time zone,
    is_challenger boolean DEFAULT false,
    champion_id uuid,
    artifact_uri text,
    is_active boolean DEFAULT false NOT NULL,
    training_rows integer,
    trained_by text,
    feature_columns jsonb DEFAULT '[]'::jsonb,
    CONSTRAINT model_registry_model_type_check CHECK ((model_type = ANY (ARRAY['ANOMALY'::text, 'STRUCTURING'::text, 'NETWORK'::text, 'RECURRENCE'::text]))),
    CONSTRAINT model_registry_status_check CHECK ((status = ANY (ARRAY['STAGING'::text, 'PRODUCTION'::text, 'ARCHIVED'::text])))
);


ALTER TABLE public.model_registry OWNER TO betaml;

--
-- Name: notifications; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.notifications (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    user_id uuid NOT NULL,
    type text NOT NULL,
    title text NOT NULL,
    body text,
    entity_type text,
    entity_id text,
    read boolean DEFAULT false NOT NULL,
    read_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    is_read boolean DEFAULT false NOT NULL,
    reference_type text,
    reference_id text,
    CONSTRAINT notifications_type_check CHECK ((type = ANY (ARRAY['ALERT_CRITICAL'::text, 'CASE_ASSIGNED'::text, 'SLA_WARNING'::text, 'MODEL_DRIFT'::text, 'FEATURE_DRIFT'::text, 'DLQ_PENDING'::text, 'MENTION'::text, 'SYSTEM'::text])))
);

ALTER TABLE ONLY public.notifications FORCE ROW LEVEL SECURITY;


ALTER TABLE public.notifications OWNER TO betaml;

--
-- Name: player_kyc_events; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.player_kyc_events (
    id uuid DEFAULT gen_random_uuid() NOT NULL,
    tenant_id uuid NOT NULL,
    player_id text NOT NULL,
    entity_type character varying(40) NOT NULL,
    subtype character varying(60) NOT NULL,
    provider text,
    document_type text,
    pep_flag boolean DEFAULT false NOT NULL,
    income_declared numeric(18,2),
    exclusion_source text,
    exclusion_scope text,
    exclusion_duration_days integer,
    old_deposit_limit numeric(18,2),
    new_deposit_limit numeric(18,2),
    previous_status text,
    new_status text,
    reason text,
    ingest_mode character varying(20) DEFAULT 'incremental'::character varying NOT NULL,
    backfill_job_id text,
    occurred_at timestamp with time zone NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    event_type character varying(40),
    status character varying(20) DEFAULT 'PENDING'::character varying NOT NULL,
    payload jsonb DEFAULT '{}'::jsonb NOT NULL,
    response jsonb DEFAULT '{}'::jsonb,
    error_message text,
    processed_at timestamp with time zone
);


ALTER TABLE public.player_kyc_events OWNER TO betaml;

--
-- Name: TABLE player_kyc_events; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON TABLE public.player_kyc_events IS 'Eventos de ciclo de vida do player: KYC, jogo responsável (auto-exclusão SIGAP/operador) e alterações de status. Portaria SPA/MF 1.143/2024.';


--
-- Name: player_list_entries; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.player_list_entries (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    list_id uuid NOT NULL,
    tenant_id uuid NOT NULL,
    player_id uuid,
    external_player_id text,
    cpf_hash text,
    notes text,
    added_by uuid,
    added_at timestamp with time zone DEFAULT now() NOT NULL,
    value text,
    value_type text,
    player_list_id uuid
);

ALTER TABLE ONLY public.player_list_entries FORCE ROW LEVEL SECURITY;


ALTER TABLE public.player_list_entries OWNER TO betaml;

--
-- Name: player_lists; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.player_lists (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    list_type text NOT NULL,
    description text,
    active boolean DEFAULT true NOT NULL,
    source text DEFAULT 'MANUAL'::text NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    CONSTRAINT player_lists_list_type_check CHECK ((list_type = ANY (ARRAY['WHITELIST'::text, 'BLACKLIST'::text, 'WATCH_LIST'::text, 'CUSTOM'::text]))),
    CONSTRAINT player_lists_source_check CHECK ((source = ANY (ARRAY['MANUAL'::text, 'AUTO'::text, 'INTEGRATION'::text])))
);

ALTER TABLE ONLY public.player_lists FORCE ROW LEVEL SECURITY;


ALTER TABLE public.player_lists OWNER TO betaml;

--
-- Name: players; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.players (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    external_player_id text NOT NULL,
    cpf_encrypted bytea NOT NULL,
    name_encrypted bytea NOT NULL,
    birth_date date,
    pep_flag boolean DEFAULT false NOT NULL,
    declared_income_monthly numeric(15,2),
    profession text,
    risk_score numeric(5,4) DEFAULT 0.0 NOT NULL,
    last_scored_at timestamp with time zone,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    registered_since date,
    status text DEFAULT 'ACTIVE'::text,
    external_id text,
    risk_band text DEFAULT 'LOW'::text NOT NULL,
    cpf_hmac character varying(64),
    self_exclusion_flag boolean DEFAULT false NOT NULL,
    deposit_limit_daily numeric(15,2),
    features jsonb DEFAULT '{}'::jsonb NOT NULL,
    cluster_id integer,
    cluster_size integer DEFAULT 0 NOT NULL,
    CONSTRAINT chk_player_status CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'INACTIVE'::text, 'BLOCKED'::text, 'ERASED'::text, 'PENDING_REVIEW'::text, 'WATCHLIST'::text, 'SELF_EXCLUDED'::text, 'PENDING_KYC'::text]))),
    CONSTRAINT players_risk_band_check CHECK ((risk_band = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text]))),
    CONSTRAINT players_status_check CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'INACTIVE'::text, 'BLOCKED'::text, 'PENDING'::text, 'SELF_EXCLUDED'::text, 'PENDING_KYC'::text, 'ERASED'::text, 'SUSPENDED'::text, 'BLOCKED_BY_OPERATOR'::text, 'REACTIVATED'::text, 'CLOSED_BY_PLAYER'::text, 'CLOSED_BY_OPERATOR'::text])))
);

ALTER TABLE ONLY public.players FORCE ROW LEVEL SECURITY;


ALTER TABLE public.players OWNER TO betaml;

--
-- Name: COLUMN players.self_exclusion_flag; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON COLUMN public.players.self_exclusion_flag IS 'Apostador com autoexclusão ativa no SIGAP — apostas devem ser bloqueadas (Portaria 1.231/2024)';


--
-- Name: COLUMN players.deposit_limit_daily; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON COLUMN public.players.deposit_limit_daily IS 'Limite de depósito diário declarado voluntariamente pelo apostador durante KYC';


--
-- Name: COLUMN players.features; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON COLUMN public.players.features IS 'JSONB com features ML calculadas pelo ML Trainer (anomaly_score, recurrence_score, network features etc.)';


--
-- Name: COLUMN players.cluster_id; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON COLUMN public.players.cluster_id IS 'ID do cluster DBSCAN detectado pelo network_clustering. NULL = sem cluster.';


--
-- Name: COLUMN players.cluster_size; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON COLUMN public.players.cluster_size IS 'Tamanho do cluster de rede ao qual o player pertence. 0 = isolado.';


--
-- Name: report_packages; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.report_packages (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    case_id uuid NOT NULL,
    player_id uuid,
    payload jsonb NOT NULL,
    format text DEFAULT 'JSON'::text NOT NULL,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    pdf_path text,
    status text DEFAULT 'DRAFT'::text,
    analyst_narrative text,
    decision text,
    xml_path text,
    xml_sha256 text,
    coaf_protocol_number text,
    filed_at timestamp with time zone,
    CONSTRAINT report_packages_decision_check CHECK ((decision = ANY (ARRAY['REPORT'::text, 'CLOSE'::text, 'MONITOR'::text]))),
    CONSTRAINT report_packages_format_check CHECK ((format = ANY (ARRAY['JSON'::text, 'CSV'::text]))),
    CONSTRAINT report_packages_status_check CHECK ((status = ANY (ARRAY['DRAFT'::text, 'FINAL'::text, 'PENDING_REVIEW'::text, 'FILED'::text, 'REJECTED'::text, 'ARCHIVED'::text])))
);

ALTER TABLE ONLY public.report_packages FORCE ROW LEVEL SECURITY;


ALTER TABLE public.report_packages OWNER TO betaml;

--
-- Name: rule_definitions; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.rule_definitions (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    description text,
    status text DEFAULT 'ACTIVE'::text NOT NULL,
    severity text DEFAULT 'MEDIUM'::text NOT NULL,
    scope text DEFAULT 'TRANSACTION'::text NOT NULL,
    condition_dsl text NOT NULL,
    params jsonb DEFAULT '{}'::jsonb NOT NULL,
    version integer DEFAULT 1 NOT NULL,
    created_by uuid,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    weight numeric(4,3) DEFAULT 0.5 NOT NULL,
    CONSTRAINT rule_definitions_scope_check CHECK ((scope = ANY (ARRAY['TRANSACTION'::text, 'BET'::text, 'PLAYER'::text, 'DEVICE_EVENT'::text]))),
    CONSTRAINT rule_definitions_severity_check CHECK ((severity = ANY (ARRAY['LOW'::text, 'MEDIUM'::text, 'HIGH'::text, 'CRITICAL'::text]))),
    CONSTRAINT rule_definitions_status_check CHECK ((status = ANY (ARRAY['ACTIVE'::text, 'INACTIVE'::text, 'DRAFT'::text])))
);

ALTER TABLE ONLY public.rule_definitions FORCE ROW LEVEL SECURITY;


ALTER TABLE public.rule_definitions OWNER TO betaml;

--
-- Name: rule_execution_logs; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.rule_execution_logs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    rule_id uuid NOT NULL,
    rule_version integer NOT NULL,
    source_event_id text NOT NULL,
    player_id uuid,
    matched boolean NOT NULL,
    evaluation_ms integer,
    context_snapshot jsonb,
    created_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rule_execution_logs OWNER TO betaml;

--
-- Name: rule_macros; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.rule_macros (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    name text NOT NULL,
    body_dsl text NOT NULL,
    description text,
    created_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.rule_macros OWNER TO betaml;

--
-- Name: scoring_configs; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.scoring_configs (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    rule_weight numeric(4,3) DEFAULT 0.4 NOT NULL,
    ml_weight numeric(4,3) DEFAULT 0.4 NOT NULL,
    network_weight numeric(4,3) DEFAULT 0.2 NOT NULL,
    auto_case_threshold numeric(5,4) DEFAULT 0.75 NOT NULL,
    sla_critical_hours integer DEFAULT 4 NOT NULL,
    sla_high_hours integer DEFAULT 24 NOT NULL,
    sla_medium_hours integer DEFAULT 72 NOT NULL,
    sla_low_hours integer DEFAULT 168 NOT NULL,
    ingest_rate_limit_tpm integer DEFAULT 1000 NOT NULL,
    data_retention_raw_years integer DEFAULT 5 NOT NULL,
    data_retention_silver_years integer DEFAULT 5 NOT NULL,
    data_retention_gold_years integer DEFAULT 3 NOT NULL,
    updated_by uuid,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    risk_band_low_threshold numeric(5,4) DEFAULT 0.35 NOT NULL,
    risk_band_high_threshold numeric(5,4) DEFAULT 0.70 NOT NULL,
    income_volume_ratio_threshold numeric(5,2) DEFAULT 1.50 NOT NULL,
    low_threshold numeric(5,2) DEFAULT 30.0 NOT NULL,
    medium_threshold numeric(5,2) DEFAULT 60.0 NOT NULL,
    high_threshold numeric(5,2) DEFAULT 80.0 NOT NULL,
    critical_threshold numeric(5,2) DEFAULT 95.0 NOT NULL,
    is_active boolean DEFAULT true NOT NULL,
    data_retention_days integer DEFAULT 1825 NOT NULL,
    ml_challenger_pct integer DEFAULT 0 NOT NULL
);

ALTER TABLE ONLY public.scoring_configs FORCE ROW LEVEL SECURITY;


ALTER TABLE public.scoring_configs OWNER TO betaml;

--
-- Name: system_flags; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.system_flags (
    key text NOT NULL,
    value jsonb DEFAULT 'null'::jsonb NOT NULL,
    updated_by uuid,
    updated_at timestamp with time zone DEFAULT now() NOT NULL
);


ALTER TABLE public.system_flags OWNER TO betaml;

--
-- Name: tenants; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.tenants (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    name text NOT NULL,
    slug text NOT NULL,
    active boolean DEFAULT true NOT NULL,
    settings jsonb DEFAULT '{}'::jsonb NOT NULL,
    risk_score_threshold numeric(5,2) DEFAULT 0.75 NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    cnpj character varying(14),
    plan_tier character varying(20) DEFAULT 'standard'::character varying NOT NULL,
    CONSTRAINT tenants_plan_tier_check CHECK (((plan_tier)::text = ANY ((ARRAY['starter'::character varying, 'standard'::character varying, 'professional'::character varying, 'enterprise'::character varying])::text[])))
);

ALTER TABLE ONLY public.tenants FORCE ROW LEVEL SECURITY;


ALTER TABLE public.tenants OWNER TO betaml;

--
-- Name: COLUMN tenants.cnpj; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON COLUMN public.tenants.cnpj IS 'CNPJ do operador (14 dígitos sem pontuação) — obrigatório para geração de XML COAF (MIFD v3)';


--
-- Name: users; Type: TABLE; Schema: public; Owner: betaml
--

CREATE TABLE public.users (
    id uuid DEFAULT public.uuid_generate_v4() NOT NULL,
    tenant_id uuid NOT NULL,
    username text NOT NULL,
    email text NOT NULL,
    password_hash text NOT NULL,
    role character varying(50) NOT NULL,
    active boolean DEFAULT true NOT NULL,
    created_at timestamp with time zone DEFAULT now() NOT NULL,
    updated_at timestamp with time zone DEFAULT now() NOT NULL,
    refresh_token_jti text,
    roles jsonb DEFAULT '[]'::jsonb,
    CONSTRAINT users_role_check CHECK (((role)::text = ANY (ARRAY['ADMIN'::text, 'AML_ANALYST'::text, 'AUDITOR'::text])))
);


ALTER TABLE public.users OWNER TO betaml;

--
-- Name: COLUMN users.refresh_token_jti; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON COLUMN public.users.refresh_token_jti IS 'JTI do refresh token ativo (rotacionado a cada /auth/refresh, NULL quando revogado no logout)';


--
-- Data for Name: alembic_version; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.alembic_version (version_num) FROM stdin;
20260522_000006
\.


--
-- Data for Name: alerts; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.alerts (id, tenant_id, player_id, rule_id, alert_type, severity, status, title, description, evidence, anomaly_score, source_event_id, case_id, triaged_by, triaged_at, created_at, updated_at, label, labeled_by, labeled_at, rule_weight, ml_weight, network_weight, composite_score, score_breakdown, compound_rule_id, label_note, ingest_mode, backfill_job_id, priority, sla_due_at, triage_note) FROM stdin;
060cae02-d76e-458b-b9bb-f824c1419f29	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	\N	COMPOSITE	CRITICAL	OPEN	Round-tripping detectado — EXT-OPERADOR_A-004	Depósito R$20.000 → aposta R$20 → saque R$19.500 em 2h	{"ratio": 0.975, "triggered_at": "2026-05-19T23:57:46.977064+00:00", "deposit_sum_24h": 20000, "bet_stake_sum_24h": 20, "withdrawal_sum_24h": 19500}	0.9100	5f4c6e46-3986-4d18-a3cf-030b2b391ed1	84bd3a0e-e274-45ec-aedd-491722778caa	\N	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	\N	\N	0.400	0.400	0.200	0.9100	{}	\N	\N	incremental	\N	MEDIUM	\N	\N
bdcdbf4f-b451-49e1-aa27-c1d06d1d22fa	98c56b0f-fa44-47cd-a8d9-9479174e3140	defd8826-200c-43b0-8ac6-1f57a384bb36	\N	RULE	HIGH	OPEN	Structuring detectado — EXT-OPERADOR_B-001	8 depósitos de R$900 em 24h (total R$7.200)	{"triggered_at": "2026-05-19T23:57:48.975943+00:00", "threshold_sum": 5000, "deposit_sum_24h": 7200, "threshold_count": 5, "deposit_count_24h": 8}	\N	f37356e7-a594-481b-9bdf-f9d8b5ac78c1	\N	\N	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	\N	\N	0.400	0.400	0.200	0.7500	{}	\N	\N	incremental	\N	MEDIUM	\N	\N
d3cc946e-5a61-47bd-a1f2-84d9c466de12	98c56b0f-fa44-47cd-a8d9-9479174e3140	0e146917-2e26-47c4-ba5e-3506cac9644c	\N	RULE	CRITICAL	OPEN	PEP com depósito acima do threshold — EXT-OPERADOR_B-002	Jogador PEP depositou R$15.000 (acima do threshold de R$5.000)	{"amount": 15000, "pep_flag": true, "threshold": 5000, "triggered_at": "2026-05-19T23:57:48.976103+00:00"}	\N	544a3bef-4bc3-4c27-9736-16276d4a6ff6	\N	\N	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	\N	\N	0.400	0.400	0.200	0.9500	{}	\N	\N	incremental	\N	MEDIUM	\N	\N
9f7282ac-7014-4c06-8db0-35d196ac6c5c	98c56b0f-fa44-47cd-a8d9-9479174e3140	c3d5fa96-9a4e-4f70-aa98-0e36d66ffb42	\N	RULE	HIGH	OPEN	Múltiplos CPFs no mesmo device — EXT-OPERADOR_B-003	Device dev-shared-001 associado a 5 CPFs distintos	{"device_id": "dev-shared-001", "threshold": 3, "triggered_at": "2026-05-19T23:57:48.976220+00:00", "shared_device_count": 5}	\N	9efc595e-859d-46a5-b381-0a93531ba680	\N	\N	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	\N	\N	0.400	0.400	0.200	0.7500	{}	\N	\N	incremental	\N	MEDIUM	\N	\N
471813f0-bec0-4212-9683-764e1f39623b	98c56b0f-fa44-47cd-a8d9-9479174e3140	295626b4-138e-4166-8bcb-f9fc7e4febd4	\N	COMPOSITE	CRITICAL	OPEN	Round-tripping detectado — EXT-OPERADOR_B-004	Depósito R$20.000 → aposta R$20 → saque R$19.500 em 2h	{"ratio": 0.975, "triggered_at": "2026-05-19T23:57:48.976469+00:00", "deposit_sum_24h": 20000, "bet_stake_sum_24h": 20, "withdrawal_sum_24h": 19500}	0.9100	da64c229-4e96-46f1-9a27-36057d4ca374	85596b71-cf3b-4eb5-a2d3-5e50ef34b018	\N	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	\N	\N	0.400	0.400	0.200	0.9100	{}	\N	\N	incremental	\N	MEDIUM	\N	\N
efd29b69-2355-4637-8f52-b685eaafc776	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	f71ed380-a936-4b4d-a075-1b3fd6e022c2	\N	RULE	HIGH	IN_REVIEW	Structuring detectado — EXT-OPERADOR_A-001	8 depósitos de R$900 em 24h (total R$7.200)	{"triggered_at": "2026-05-19T23:57:46.976335+00:00", "threshold_sum": 5000, "deposit_sum_24h": 7200, "threshold_count": 5, "deposit_count_24h": 8}	\N	a1d9dfa6-d7f7-4dad-886e-46114c7495c0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:04.673402+00	2026-05-19 23:57:44.872891+00	2026-05-22 15:55:04.662993+00	\N	\N	\N	0.400	0.400	0.200	0.7500	{}	\N	\N	incremental	\N	MEDIUM	\N	Triagem automática via teste de integração
36d6e3a5-cf34-4e62-aff3-77ecb0909deb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	\N	RULE	HIGH	OPEN	Múltiplos CPFs no mesmo device — EXT-OPERADOR_A-003	Device dev-shared-001 associado a 5 CPFs distintos	{"device_id": "dev-shared-001", "threshold": 3, "triggered_at": "2026-05-19T23:57:46.976945+00:00", "shared_device_count": 5}	\N	0cdd7e85-8429-4046-8edb-e95204452a6d	0d802281-da37-43c1-91b8-aba355578826	\N	\N	2026-05-19 23:57:44.872891+00	2026-05-22 16:02:21.229123+00	\N	\N	\N	0.400	0.400	0.200	0.7500	{}	\N	\N	incremental	\N	MEDIUM	\N	\N
4ab2f20e-a686-4195-868f-4d58751c20eb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	5f4b66dd-66b9-49d7-ac79-10c15f7b9e71	\N	RULE	CRITICAL	IN_REVIEW	PEP com depósito acima do threshold — EXT-OPERADOR_A-002	Jogador PEP depositou R$15.000 (acima do threshold de R$5.000)	{"amount": 15000, "pep_flag": true, "threshold": 5000, "triggered_at": "2026-05-19T23:57:46.976756+00:00"}	\N	26ef7bdd-f6a8-451a-8963-a5a992915019	688ad55f-fba1-435e-b491-16e933d1f2ff	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:20.711086+00	2026-05-19 23:57:44.872891+00	2026-05-22 16:02:20.703457+00	\N	\N	\N	0.400	0.400	0.200	0.9500	{}	\N	\N	incremental	\N	MEDIUM	\N	Triagem automática via teste de integração
\.


--
-- Data for Name: api_keys; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.api_keys (id, tenant_id, name, key_hash, key_prefix, source_system, permissions, active, last_used_at, expires_at, created_by, revoked_by, revoked_at, created_at) FROM stdin;
4174dbf1-d7da-4c60-b4da-81e69b932862	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	test-key-integration	cfb196fa41c6d1eff22092e875af70dda27d69f8620c1d2f102062c33ea7e41e	btml_335	\N	["ingest"]	f	2026-05-22 15:46:56.007576+00	\N	\N	\N	\N	2026-05-22 15:46:55.929541+00
39d01f74-9314-44fd-a440-4bf725e902fc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	test-key-integration	7dea35864aa0c22e75ea29fa289d25f1408425eb0079ff5de82037648c3c8648	btml_335	\N	["ingest"]	f	2026-05-22 15:55:07.460458+00	\N	\N	\N	\N	2026-05-22 15:55:07.903108+00
d1523547-6b60-4f86-9382-30b59d8e3779	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	test-key-integration	e99d2e978391ec16fb1f07430ac8ea9015974ce10fc0678e1a337907492f5073	btml_335	\N	["ingest"]	f	2026-05-22 16:02:22.595955+00	\N	\N	\N	\N	2026-05-22 16:02:22.550569+00
\.


--
-- Data for Name: audit_logs; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.audit_logs (id, tenant_id, user_id, action, entity_type, entity_id, before, after, ip_address, created_at, pii_accessed) FROM stdin;
1283b307-c9f4-4923-b07d-f1c91fe4fc4c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:58:20.825967+00	\N
534c36a4-2d66-44b5-9a49-b86e72a50f03	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-19 23:58:21.507601+00	\N
0fb46160-f373-4380-9dac-75a626a3a6ed	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:19:48.692021+00	\N
a5507dd5-9a41-495f-a09f-1bf9620be6b7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	2c953fd3-0c49-4d47-a956-4038ec338b9d	null	{"title": "E2E COAF Protocol 1779235101622", "severity": "HIGH", "player_id": "5f4b66dd-66b9-49d7-ac79-10c15f7b9e71", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-19 23:58:21.72704+00	\N
258f55b1-b9ac-43c1-b500-9a2cf9f93e99	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	2c953fd3-0c49-4d47-a956-4038ec338b9d	null	{"new_status": "INVESTIGATING"}	\N	2026-05-19 23:58:22.059132+00	\N
3cdd34bd-dda0-4791-89df-8db62f4d0c19	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	2c953fd3-0c49-4d47-a956-4038ec338b9d	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-19 23:58:22.191056+00	\N
ff60cd5b-3f10-40c1-8c5b-df68f7da4218	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	2c953fd3-0c49-4d47-a956-4038ec338b9d	null	{"new_status": "CLOSED"}	\N	2026-05-19 23:58:22.285746+00	\N
336101fd-4bcc-40da-9410-30ec9c2f5dd9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:55:58.845389+00	\N
fa03c5b2-af8f-40c5-94e5-096f36c44769	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:58:30.522837+00	\N
7ed01133-dd9f-43fd-b9d3-c8765ad2e144	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-19 23:58:31.151839+00	\N
9943c3d0-c107-47d3-ac28-d2c82f818428	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "APPROVED", "provider": "OFAC", "event_type": "SANCTIONS_CHECK", "player_status": "SELF_EXCLUDED"}	\N	2026-05-20 00:19:48.831639+00	\N
81e6a4ac-4ced-4f4e-baa5-7f7aac923037	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	e377d705-472f-4060-b62b-17963b5c48cc	null	{"title": "E2E COAF Protocol 1779235111212", "severity": "HIGH", "player_id": "5f4b66dd-66b9-49d7-ac79-10c15f7b9e71", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-19 23:58:31.267551+00	\N
68fa6620-c49a-4200-be68-74c9e980a4b7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e377d705-472f-4060-b62b-17963b5c48cc	null	{"new_status": "INVESTIGATING"}	\N	2026-05-19 23:58:31.351849+00	\N
2d109a6d-06a0-45c1-b217-b3b59994fdb2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e377d705-472f-4060-b62b-17963b5c48cc	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-19 23:58:31.409466+00	\N
8488a88a-4c8c-43eb-902d-2fbbf121a986	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e377d705-472f-4060-b62b-17963b5c48cc	null	{"new_status": "CLOSED"}	\N	2026-05-19 23:58:31.489159+00	\N
4e1cd77f-9803-4b2f-b6ef-fb2de9635db6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "PENDING", "provider": "Lista PEP", "event_type": "PEP_CHECK", "player_status": "SELF_EXCLUDED"}	\N	2026-05-20 00:19:48.918854+00	\N
e1e2caa0-0b51-4e67-ab33-7fb7f96afa15	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:58:37.005887+00	\N
93ce0a2d-7601-4234-ba0d-9241a2238c5b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-19 23:58:37.634048+00	\N
ba744548-8b7e-445f-a2f3-3287a29e110c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:19:49.889502+00	\N
4eab54af-6ebe-4577-b19e-27b3a3f29800	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	f0818532-66b1-471c-9902-4d8f359c1d26	null	{"title": "E2E COAF Protocol 1779235117645", "severity": "HIGH", "player_id": "5f4b66dd-66b9-49d7-ac79-10c15f7b9e71", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-19 23:58:37.778644+00	\N
66ade7b7-56a8-463a-90f7-4760399ef60e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	f0818532-66b1-471c-9902-4d8f359c1d26	null	{"new_status": "INVESTIGATING"}	\N	2026-05-19 23:58:37.867516+00	\N
89abde42-d7e3-41cd-80ff-6c3970c3223f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	f0818532-66b1-471c-9902-4d8f359c1d26	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-19 23:58:37.958859+00	\N
4c75a938-52d5-47ce-8f5d-b3de14575aca	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	f0818532-66b1-471c-9902-4d8f359c1d26	null	{"new_status": "CLOSED"}	\N	2026-05-19 23:58:38.018299+00	\N
df6c238a-7600-49e7-8794-76afc4efd645	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:19:50.553531+00	\N
e332d0ea-8335-405c-8053-7b9799205dc4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:58:43.234255+00	\N
9b82490a-b4fd-4bf5-b6ec-a991ae2eda91	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	cdef2fe6-dea8-4b0f-b76f-948d085e810f	null	{"title": "E2E COAF Protocol 1779236390712", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:19:50.765927+00	\N
957e3f86-7b14-4858-9555-b97787f37f1a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	ab6ef6d1-6c92-4989-9f8c-5d6aaf90cf15	null	{"title": "E2E COAF Protocol 1779235123318", "severity": "HIGH", "player_id": "5f4b66dd-66b9-49d7-ac79-10c15f7b9e71", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-19 23:58:43.361733+00	\N
0ad23b32-9fc6-40d1-aa27-4658c1eedef5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	ab6ef6d1-6c92-4989-9f8c-5d6aaf90cf15	null	{"new_status": "INVESTIGATING"}	\N	2026-05-19 23:58:43.432497+00	\N
29e861f1-35ab-4b6c-8c05-356a82035df2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	ab6ef6d1-6c92-4989-9f8c-5d6aaf90cf15	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-19 23:58:43.50319+00	\N
e4ca4a1d-5246-4a32-841d-00fc05909026	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	ab6ef6d1-6c92-4989-9f8c-5d6aaf90cf15	null	{"new_status": "CLOSED"}	\N	2026-05-19 23:58:43.566404+00	\N
294c05aa-2ee3-463e-bf04-e9c93e02bc5c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	cdef2fe6-dea8-4b0f-b76f-948d085e810f	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:19:50.886103+00	\N
c541819b-b0e4-4630-9ed4-2b9ab8dca7a7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:58:49.402643+00	\N
b93b5089-fe4b-400b-8f15-5411482adf1a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-19 23:58:50.040118+00	\N
7f7f4562-d182-46df-a3bd-11c31f70df6f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	cdef2fe6-dea8-4b0f-b76f-948d085e810f	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:19:50.996605+00	\N
faddf276-753f-443a-a3bf-cb0b9fe311b6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	a6d4286f-e75c-4ff3-b6b6-ac1b626b7030	null	{"title": "E2E COAF Protocol 1779235130094", "severity": "HIGH", "player_id": "5f4b66dd-66b9-49d7-ac79-10c15f7b9e71", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-19 23:58:50.161092+00	\N
5a8cddc3-9982-4012-bd9f-0a10c270aeec	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	cdef2fe6-dea8-4b0f-b76f-948d085e810f	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:19:51.072989+00	\N
918a6567-3687-4a44-9046-9129ac22c8dc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:27:14.899308+00	\N
feefa41d-3c9a-4978-bf29-4328d05c2b3d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	a6d4286f-e75c-4ff3-b6b6-ac1b626b7030	null	{"new_status": "INVESTIGATING"}	\N	2026-05-19 23:58:50.241048+00	\N
c50ae7e3-6237-44d2-868b-81bfd29be9bf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	a6d4286f-e75c-4ff3-b6b6-ac1b626b7030	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-19 23:58:50.295881+00	\N
7d035b28-0e89-42f2-b438-e39344540e14	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	a6d4286f-e75c-4ff3-b6b6-ac1b626b7030	null	{"new_status": "CLOSED"}	\N	2026-05-19 23:58:50.384589+00	\N
eb77fc9f-1c8e-40a3-bd8d-bf06643fabc8	98c56b0f-fa44-47cd-a8d9-9479174e3140	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	LOGIN	User	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	null	null	172.18.0.1	2026-05-22 15:55:59.430082+00	\N
18799d0f-c932-44e7-a8ad-c2b8dd50189b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:59:02.340989+00	\N
8ce686b7-1a8b-4b2d-9c9f-ebf55bb5c1f0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-19 23:59:03.031575+00	\N
33f03937-6186-49b9-9568-2593acc34bed	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	032940ff-c161-4765-a4bd-65a41bb7f0db	null	{"title": "E2E COAF Protocol 1779235143064", "severity": "HIGH", "player_id": "5f4b66dd-66b9-49d7-ac79-10c15f7b9e71", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-19 23:59:03.153799+00	\N
534cca43-3bac-4d8c-af01-3860d0887175	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	032940ff-c161-4765-a4bd-65a41bb7f0db	null	{"new_status": "INVESTIGATING"}	\N	2026-05-19 23:59:03.227676+00	\N
38540b22-89cb-491d-83aa-4a6fad48aac3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	032940ff-c161-4765-a4bd-65a41bb7f0db	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-19 23:59:03.295078+00	\N
065f6926-08f7-4ddd-aa50-058a29481d2b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	032940ff-c161-4765-a4bd-65a41bb7f0db	null	{"new_status": "CLOSED"}	\N	2026-05-19 23:59:03.365636+00	\N
2f5c7195-0895-480c-bbc7-3137efb76a70	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	cdef2fe6-dea8-4b0f-b76f-948d085e810f	null	{"filed_at": "2026-05-20T00:19:51.684260+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/cdef2fe6-dea8-4b0f-b76f-948d085e810f/coaf-b30cf1c1-b049-4e85-bf83-d21067594b51.xml", "xml_sha256": "91113dca14f93ce58d0a13817b323b5c87727fc94f21e1a6dc4f39f9797d46cc", "case_status": "REPORTED", "tracking_id": "490b93df-6b2e-4d44-83c3-083678a42d8e", "report_package_id": "b30cf1c1-b049-4e85-bf83-d21067594b51"}	\N	2026-05-20 00:19:51.6504+00	\N
56769b42-54da-4916-aa34-09e4d0a84c9d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:59:14.081372+00	\N
969bba33-12de-4a63-8544-d9669f0b9ecc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-19 23:59:15.199106+00	\N
b63b4bf0-a3f9-4848-a4c5-579209132572	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	eb453a94-9f9a-442b-be31-2b886c4ba711	null	{"title": "E2E COAF Protocol 1779235155248", "severity": "HIGH", "player_id": "5f4b66dd-66b9-49d7-ac79-10c15f7b9e71", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-19 23:59:15.372375+00	\N
10291181-1702-4518-ab47-f00eb457933e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	eb453a94-9f9a-442b-be31-2b886c4ba711	null	{"new_status": "INVESTIGATING"}	\N	2026-05-19 23:59:15.509399+00	\N
ceb6f612-ec18-4d0f-961c-375441d85ede	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	eb453a94-9f9a-442b-be31-2b886c4ba711	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-19 23:59:15.593396+00	\N
ef07bbb3-acc0-4ce8-abac-e1af498f071d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	eb453a94-9f9a-442b-be31-2b886c4ba711	null	{"new_status": "CLOSED"}	\N	2026-05-19 23:59:15.668782+00	\N
d75a2448-ed6f-4fb8-8e87-ab677b0dce68	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:59:25.427623+00	\N
476c05f4-7864-4abe-b7bb-75ba7db2d5ac	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-19 23:59:26.101252+00	\N
ad20b51f-6503-4590-8260-e17079666590	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	898955fd-f537-4a4a-9cc3-e490d5f343b5	null	{"filed_at": "2026-05-20T00:19:54.088320+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/898955fd-f537-4a4a-9cc3-e490d5f343b5/coaf-a72577c1-e3aa-4f1f-96ed-6cd4c56119eb.xml", "xml_sha256": "8ff56664c0f2b810946dd52215263adffbf7cc53271f36a9742b8cbf3ec89ef6", "case_status": "REPORTED", "tracking_id": "8b64bf09-42da-4b6a-955d-d9500dc322c6", "report_package_id": "a72577c1-e3aa-4f1f-96ed-6cd4c56119eb"}	\N	2026-05-20 00:19:54.069161+00	\N
8abf215e-525b-4b3e-a96a-23fa6a93be47	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	93321cb0-c1d2-4c42-bd47-84f0d1da6bdf	null	{"filed_at": "2026-05-20T00:19:56.430319+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/93321cb0-c1d2-4c42-bd47-84f0d1da6bdf/coaf-a809ca82-9296-4055-be34-06469524a9f8.xml", "xml_sha256": "f6cd087287e6a6dead2dfb8473ee327e0d1852414fdef9d40aa96760b348b8c2", "case_status": "REPORTED", "tracking_id": "8ba99dcc-5ab5-44e5-a9c8-13aea8ae2ae0", "report_package_id": "a809ca82-9296-4055-be34-06469524a9f8"}	\N	2026-05-20 00:19:56.413894+00	\N
5db48bb3-584b-4ff5-b4b3-900e4d628d02	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:19:58.913656+00	\N
6490b350-6b13-4095-85b9-7404e26f3f6b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:19:59.500608+00	\N
11406b13-712f-4d29-9ceb-c5eb5f878d9d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	803539be-379f-4992-a510-c1f50278372e	null	{"title": "E2E COAF Protocol 1779236399614", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:19:59.638006+00	\N
4616df6f-41e0-4fdd-98a4-2b630a5bdf5e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	803539be-379f-4992-a510-c1f50278372e	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:19:59.744167+00	\N
db0aa687-90d9-4a0b-be7c-7b3e2e3475c7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:00:06.45165+00	\N
c1428d33-2778-4427-8bb3-85d046125bcb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	803539be-379f-4992-a510-c1f50278372e	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:19:59.819504+00	\N
c7e0e067-4072-4eaf-a95f-f8926d7ebbbe	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:00:11.270857+00	\N
2c04d075-e679-42de-8006-fb8baffb793a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	803539be-379f-4992-a510-c1f50278372e	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:19:59.88484+00	\N
b0a782c7-9cd6-4edb-b06c-e84032520eee	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:00:24.244444+00	\N
a22d83be-10e1-47e2-ad5a-bf51b3972215	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	803539be-379f-4992-a510-c1f50278372e	null	{"decision": "FILE_SAR", "report_id": "cfc4cb2b-1b18-467a-984a-25abe611024e", "pdf_sha256": "e7a9c1eb4e42fb01968e3d89a9235c05da6c50e7998a27f6b7763ffd36c56fc7", "payload_sha256": "99f8c460ed8eea33842f8c5fdb815ec6117a6be56d7dc8a67f94377fe2f894ce"}	\N	2026-05-20 00:19:59.965276+00	\N
f0907349-a276-47a0-bf63-72d49baa780e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	cdef2fe6-dea8-4b0f-b76f-948d085e810f	null	{"decision": "FILE_SAR", "report_id": "1874f73d-c44c-4434-a86c-49ed8d0f927d", "pdf_sha256": "a949f23285f55d5b50099356bcac9d981a54527a7b88ea7257cb7e5833f5eb3a", "payload_sha256": "f8f7373a019d5519c368dca8b7c4c46a040e67c2d8b9cd30ed64d42fb5ea3e13"}	\N	2026-05-20 00:19:51.148951+00	\N
e93b0ef2-5aa3-4a82-82a1-9c3373a71f77	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	REGISTER_COAF_PROTOCOL	ReportPackage	b30cf1c1-b049-4e85-bf83-d21067594b51	null	{"case_id": "cdef2fe6-dea8-4b0f-b76f-948d085e810f", "coaf_protocol_number": "COAF-E2E-1779236391733"}	\N	2026-05-20 00:19:51.806936+00	\N
889431f2-595d-4443-861e-8b8f4317c9d1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	e21505cc-cb01-4958-a794-e6f59fbe8ee6	null	{"title": "E2E COAF Protocol 1779235166159", "severity": "HIGH", "player_id": "5f4b66dd-66b9-49d7-ac79-10c15f7b9e71", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-19 23:59:26.248043+00	\N
5a599c9e-e04b-459a-8d0d-8b770c77becf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e21505cc-cb01-4958-a794-e6f59fbe8ee6	null	{"new_status": "INVESTIGATING"}	\N	2026-05-19 23:59:26.347495+00	\N
2f4c8a31-92e2-4d9a-afcb-bfde68270212	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e21505cc-cb01-4958-a794-e6f59fbe8ee6	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-19 23:59:26.424256+00	\N
9314da1a-952a-4a98-8e41-b22c5641cad5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e21505cc-cb01-4958-a794-e6f59fbe8ee6	null	{"new_status": "CLOSED"}	\N	2026-05-19 23:59:26.493701+00	\N
97bc30e9-152a-4341-ad9e-308bea2843bb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:19:52.671378+00	\N
6600bacf-e690-4ec7-8f13-2599628fea31	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:59:32.978142+00	\N
84432554-df38-448e-9954-50f8543bd3bf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:19:53.31346+00	\N
a00e708a-36fe-4219-9cdd-18446d0744bc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:59:38.274736+00	\N
ad034c50-5b14-4b57-a1f2-ec2b7c754331	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	898955fd-f537-4a4a-9cc3-e490d5f343b5	null	{"title": "E2E COAF Protocol 1779236393362", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:19:53.450425+00	\N
3c7f619e-6314-433a-a37d-2bfccef3f83a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:59:43.812265+00	\N
41f82c6d-e7e8-4fa7-a0d1-30a2e092fe54	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	898955fd-f537-4a4a-9cc3-e490d5f343b5	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:19:53.546892+00	\N
ba43045b-b11d-401b-ae28-c4238fd44d5b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:59:49.441418+00	\N
c69df605-c29e-40d3-98db-31fc6a7f8207	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:59:55.250414+00	\N
e3397fa2-2b3c-4638-b844-59a140c92ca5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-19 23:59:56.086856+00	\N
d42519b5-bb3c-40ca-b579-2194d0a31409	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	898955fd-f537-4a4a-9cc3-e490d5f343b5	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:19:53.62998+00	\N
f9755a07-76ae-40bd-892d-f3f3f7550f6f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:00:01.495779+00	\N
a7724cb1-1a2d-4a8c-8865-d9d0c0f287a2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	898955fd-f537-4a4a-9cc3-e490d5f343b5	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:19:53.704904+00	\N
471bab8d-0b37-494a-8fb1-8c21459a8a11	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	898955fd-f537-4a4a-9cc3-e490d5f343b5	null	{"decision": "FILE_SAR", "report_id": "186db93f-4e0b-4200-ac83-40e6b7528116", "pdf_sha256": "f44e5a22691b920732809159ed2c44c87c198ec78acea836c1663d38186450a2", "payload_sha256": "5f7cd05a2fc57e448dace0a49f21330da29d7458e4126f00d61ef9ee229f1e37"}	\N	2026-05-20 00:19:53.7989+00	\N
f45b6919-3c39-4007-a22f-c97a97cad0c5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:19:55.114631+00	\N
a68afb56-faf1-483b-83b8-25e0920fcb3a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:19:55.843585+00	\N
2d70202b-eb30-4cb0-9062-5ba799660def	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.20	2026-05-20 00:00:35.834941+00	\N
1c8f40cc-7f10-4022-93c7-599178e1b224	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:01:14.450573+00	\N
9d49eab3-af56-4e8a-a3aa-eaf3668ed9f0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	93321cb0-c1d2-4c42-bd47-84f0d1da6bdf	null	{"title": "E2E COAF Protocol 1779236395867", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:19:55.993806+00	\N
ba5e0f8a-0a62-4fc5-afa6-484b4f75ed1d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:01:17.404357+00	\N
40a96f1d-e65b-4ee3-8d8e-afd6ab1f8ec8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:01:53.812337+00	\N
79955d69-4ce9-452b-ba77-76680f89c5b8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	93321cb0-c1d2-4c42-bd47-84f0d1da6bdf	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:19:56.091513+00	\N
44cf616c-bb2f-424f-aea6-464c0694c3b6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	93321cb0-c1d2-4c42-bd47-84f0d1da6bdf	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:19:56.174683+00	\N
753c94ac-22fc-448e-959e-04d55685f749	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:02:04.072504+00	\N
97704d2f-7887-4e06-ab99-ec5e870dc20f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	93321cb0-c1d2-4c42-bd47-84f0d1da6bdf	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:19:56.231601+00	\N
eda4b664-4798-4122-b92b-bc6cef24a6a6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.20	2026-05-20 00:02:09.687831+00	\N
4d97ec96-576f-4d90-916a-1cf8a4b8928d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:02:42.305986+00	\N
a00c4c7d-b1ef-42fd-91b7-0557e75c77d3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:28:41.443447+00	\N
82f598d1-18de-4bdf-9a20-e56c5221e7bc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.20	2026-05-20 00:02:47.607656+00	\N
8f082578-3315-43ca-9eb4-5c5b5a5d7fb5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:03:25.067533+00	\N
8be8ab3c-91c4-451f-84fc-4c44434a98f2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:04:03.337773+00	\N
637c9b85-44b9-4a5f-bc6c-f271203aca67	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:04:18.691208+00	\N
1fd3f215-2185-47d1-93fd-bb58bc341ca7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	93321cb0-c1d2-4c42-bd47-84f0d1da6bdf	null	{"decision": "FILE_SAR", "report_id": "12cc65c6-decb-4aea-ace8-a6c5a6fe9533", "pdf_sha256": "9d571811b6fa9234cedf989272424f96d96d4ec13fcc769982afe2cb9c82892a", "payload_sha256": "498412647a7549b3a2a6f325c7874d33827bcbbc07c466c3a4c291c2fde465f4"}	\N	2026-05-20 00:19:56.291796+00	\N
d9d82f7f-16eb-45ba-aaa3-c3c3d240d92b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:19:57.200709+00	\N
8fad1694-1a90-4332-aa9f-f4a7e9f24ca5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	5014b829-e438-4d15-8647-28ee47547247	null	{"title": "E2E COAF Protocol 1779236397180", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:19:57.311373+00	\N
6c8487d7-b990-49b1-b571-b6c302307e34	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	5014b829-e438-4d15-8647-28ee47547247	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:19:57.393337+00	\N
471311a8-59f7-40ad-9f69-4d685dd0277f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	5014b829-e438-4d15-8647-28ee47547247	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:19:57.471599+00	\N
0d172771-307e-4138-af80-90c52248dd70	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	5014b829-e438-4d15-8647-28ee47547247	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:19:57.528351+00	\N
4a5b317f-490b-4c86-8c0d-add7c62c1978	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	5014b829-e438-4d15-8647-28ee47547247	null	{"decision": "FILE_SAR", "report_id": "d8b40707-cc26-4d60-b3b2-087920615564", "pdf_sha256": "4e9350a675b8496549c0b679cfd8699df0a2c4be444d97f38a59ad4d5ea218ae", "payload_sha256": "d17223a818708de83185c3c6bda81aac245d9e76c8b9a6fa8d10199da248bcb0"}	\N	2026-05-20 00:19:57.592075+00	\N
c6b88941-1901-42eb-960e-62bb202baf17	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:19:58.279661+00	\N
42a63c1e-975e-4548-aebb-eded37c7710a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	LOGIN	User	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	null	null	172.18.0.1	2026-05-22 15:56:02.998175+00	\N
464cd2c0-385a-4a0f-b21d-672e2113c54d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	803539be-379f-4992-a510-c1f50278372e	null	{"filed_at": "2026-05-20T00:20:00.252513+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/803539be-379f-4992-a510-c1f50278372e/coaf-9694ef42-b209-4c01-a091-a265c18a3c37.xml", "xml_sha256": "dd1e3b11b3f34a9a7b588547b2a7d0ec4f81982490db541a2278204397523b5a", "case_status": "REPORTED", "tracking_id": "06d41c60-8ac4-4c7c-aec5-0180117abf8e", "report_package_id": "9694ef42-b209-4c01-a091-a265c18a3c37"}	\N	2026-05-20 00:20:00.231714+00	\N
5fc58a23-968a-45c6-8730-1395d2e227ce	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:20:05.819493+00	\N
125b4c3b-75d2-4c29-a67b-eda9b36f74d4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:20:06.891947+00	\N
510a5801-44ff-4009-a31b-7d26b7100ca0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	95c36d67-1b75-4e86-bd3a-b317c80e50af	null	{"title": "E2E COAF Protocol 1779236407084", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:20:07.17746+00	\N
522fca69-b6de-4bc6-bcca-cdf59de42d90	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	95c36d67-1b75-4e86-bd3a-b317c80e50af	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:20:07.26663+00	\N
104be3ef-0e2a-40a7-879d-d8a15ba36c6b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	95c36d67-1b75-4e86-bd3a-b317c80e50af	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:20:07.380074+00	\N
34e58e8d-d664-4ba1-8500-61d2717ac80d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	95c36d67-1b75-4e86-bd3a-b317c80e50af	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:20:07.501992+00	\N
f82880c3-30b0-4fb8-bf04-e6b67915d784	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	95c36d67-1b75-4e86-bd3a-b317c80e50af	null	{"decision": "FILE_SAR", "report_id": "01487da8-2dd9-46e2-9990-0254381d86d8", "pdf_sha256": "4d8b7a931c0c52a77c155cd3317a9f732f545796366f8745fdfd8217eafd0b82", "payload_sha256": "1353c15efe511933f45ff5d5c1f980ad81af23afcc7af8b14642b3f1ecf2406e"}	\N	2026-05-20 00:20:07.599454+00	\N
3951569e-3d62-4c5b-bd97-586dfb659e5e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	95c36d67-1b75-4e86-bd3a-b317c80e50af	null	{"filed_at": "2026-05-20T00:20:07.885992+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/95c36d67-1b75-4e86-bd3a-b317c80e50af/coaf-a89b0764-3613-432f-b99f-9926168ff629.xml", "xml_sha256": "f8330a71e33b9404c86a65efc79034e571b675ae3204f25c4c53b7da8507c745", "case_status": "REPORTED", "tracking_id": "fe24529f-48be-4438-8a32-b518469944f0", "report_package_id": "a89b0764-3613-432f-b99f-9926168ff629"}	\N	2026-05-20 00:20:07.851384+00	\N
5da0564e-3f38-4153-b1d7-8e24dc63e7ec	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:28:42.159563+00	\N
bd6903ff-3f28-45ef-b838-c12943726891	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	CREATE_TENANT	Tenant	960eb25d-b7ff-49bb-983b-c980d18aea6e	\N	{"slug": "test-slug-c55a7f87", "admin_username": "u_test-s"}	\N	2026-05-22 15:56:03.019484+00	\N
4911cf32-54eb-4256-8249-d441f22df071	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	3a3f6cae-cf66-47a1-b02d-142bf667665e	null	{"filed_at": "2026-05-20T00:28:43.528658+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/3a3f6cae-cf66-47a1-b02d-142bf667665e/coaf-0c6f08ab-62a2-4856-bb8e-3fb9a4a68aee.xml", "xml_sha256": "5800bb392930606bc9c22141a5e54a84f661b83d11f18cc2365a7b9329b4ae48", "case_status": "REPORTED", "tracking_id": "50958dca-0c13-4994-9eea-9cdc404c68a4", "report_package_id": "0c6f08ab-62a2-4856-bb8e-3fb9a4a68aee"}	\N	2026-05-20 00:28:43.474042+00	\N
baeeec25-e7a9-4649-b907-ca46b7b09590	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:56:04.324922+00	\N
b8c62b89-125e-43d0-86e8-6c577e8838ba	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	0a2b0872-efcd-4bca-b668-3bfad54a5b93	null	{"filed_at": "2026-05-20T00:28:46.397848+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/0a2b0872-efcd-4bca-b668-3bfad54a5b93/coaf-67a9a2d1-f687-449e-8d75-cdeadf38b345.xml", "xml_sha256": "7793d100c508533c1a60405f706df1c583e98c117e940c3b46bff721e8626320", "case_status": "REPORTED", "tracking_id": "e442c448-9c06-47e7-b93b-10dfba7abb0f", "report_package_id": "67a9a2d1-f687-449e-8d75-cdeadf38b345"}	\N	2026-05-20 00:28:46.381072+00	\N
708bd898-72f1-4126-9ebc-f26064e974f4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:56:12.147981+00	\N
67113037-b8f5-4087-81ff-7e44937b915a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	a6c823d3-7622-4ffb-a61b-7ebcea535e95	null	{"filed_at": "2026-05-20T00:28:48.780468+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/a6c823d3-7622-4ffb-a61b-7ebcea535e95/coaf-92b2998b-e991-4c67-8883-748249c35390.xml", "xml_sha256": "62541e18eedf2a6b4aa096507e9d4f9b9f377ae4719c3a55f57603313dced81d", "case_status": "REPORTED", "tracking_id": "a8d75f11-cfa4-4618-ae26-5a563865605d", "report_package_id": "92b2998b-e991-4c67-8883-748249c35390"}	\N	2026-05-20 00:28:48.727586+00	\N
3ec7856c-2c88-4230-869e-d221ebda65a1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:28:51.791733+00	\N
4b85c178-3293-4764-9410-8bef0dd4a1d8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:28:52.418108+00	\N
6671b062-4a1d-4b5f-96c6-a583d40919dc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:04:33.961889+00	\N
ac829bac-d8a9-47d6-bdae-f39a3b165138	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:04:47.005386+00	\N
50d227ec-5770-4c95-80a4-5698e41dfb69	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	REGISTER_COAF_PROTOCOL	ReportPackage	9694ef42-b209-4c01-a091-a265c18a3c37	null	{"case_id": "803539be-379f-4992-a510-c1f50278372e", "coaf_protocol_number": "COAF-AUDIT-1779236400362"}	\N	2026-05-20 00:20:00.396844+00	\N
43e282bb-c65f-494a-8928-058cc5fa55e4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:56:14.565484+00	\N
e15b783b-244c-4266-9147-1c8716083560	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	a6c823d3-7622-4ffb-a61b-7ebcea535e95	null	{"decision": "FILE_SAR", "report_id": "89e768db-4339-4f67-8e57-255f284574df", "pdf_sha256": "9e5751d421f271b3ca2352e1904c91d4e8141cb89ab4d96d8da8ef8419e63187", "payload_sha256": "dbb66939578dcc401c467697701c96d80f19e343c54032add1ee2b423e632c01"}	\N	2026-05-20 00:28:48.614952+00	\N
3310fc63-e7c1-4d9c-8b85-0c41fe205a57	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:28:49.580675+00	\N
4ff4a30a-a3aa-47cf-9765-15524ac5174f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	null	{"title": "E2E COAF Protocol 1779236929685", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:28:49.726126+00	\N
d1ac6919-846d-4eb1-a6ca-6c33b8034092	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:28:49.812486+00	\N
66887653-3cca-48bc-aef2-903e75c0d178	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:28:49.896581+00	\N
c8f31ffd-764c-4689-8147-b4b8997fd57d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:28:49.986609+00	\N
5fc3c601-2faf-4440-bc6a-b0a36e2709d2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	null	{"decision": "FILE_SAR", "report_id": "93c67528-0f08-4b22-ab86-b932c31c65b3", "pdf_sha256": "02b572d882a637aea86594e88efc06b98f12dffd3ee1f7dd368cd5793a967903", "payload_sha256": "77ac23543d7b395c86ddace087a15da4ec0914e02e3f06391a9c13b3a1d75291"}	\N	2026-05-20 00:28:50.109829+00	\N
c3db380e-246c-43f7-b37c-f636467bfaa6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:28:51.013306+00	\N
784fc00b-674c-4ab4-9050-1ff1883a0c5c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	7d7cdb0d-b5dd-4090-84b2-9486019ce2e0	null	{"filed_at": "2026-05-20T00:28:53.057520+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/7d7cdb0d-b5dd-4090-84b2-9486019ce2e0/coaf-d6df8218-84a8-44e7-b66e-af1ca0f7caa8.xml", "xml_sha256": "4778bf0a77c50301d33d045fa47cad277e6c87c0fd2589c290c2d40031c3fd82", "case_status": "REPORTED", "tracking_id": "ba905171-63fc-4285-9cdf-1f488b6237ff", "report_package_id": "d6df8218-84a8-44e7-b66e-af1ca0f7caa8"}	\N	2026-05-20 00:28:53.0289+00	\N
89afb313-a60e-461e-97b5-fb6e90532c61	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:29:00.291621+00	\N
d814e46c-daea-402e-bd52-bf252ce8393b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:29:00.927254+00	\N
0bfb8270-701e-4f32-b204-b3930632d992	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	817097da-1c7f-45a0-bad6-61c27412c1e9	null	{"title": "E2E COAF Protocol 1779236940983", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:29:01.027176+00	\N
cbade045-cedc-4652-aa26-c8c3a7e02530	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	817097da-1c7f-45a0-bad6-61c27412c1e9	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:29:01.105636+00	\N
0a0badf7-f23a-4557-bb96-2a2e3e7e7943	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	817097da-1c7f-45a0-bad6-61c27412c1e9	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:29:01.162857+00	\N
b57a90c8-8371-4db6-ad40-9ae03d221fd6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	817097da-1c7f-45a0-bad6-61c27412c1e9	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:29:01.217743+00	\N
d1ba8c4a-7db3-4d5b-a63e-ab846c6b2a9e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	817097da-1c7f-45a0-bad6-61c27412c1e9	null	{"decision": "FILE_SAR", "report_id": "6ef058bb-7190-4ede-ade1-265127616651", "pdf_sha256": "985aabae2afaaced908e09554811613e9f300c19a3153f40931a99f366cbb7e8", "payload_sha256": "35edf3eceb02a06bd633f00de39f709bad09e8c2a2f73a6c77b0122f8ebee1a3"}	\N	2026-05-20 00:29:01.280398+00	\N
f539d6aa-4c3e-4fdd-b037-0e6762e37cc7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	817097da-1c7f-45a0-bad6-61c27412c1e9	null	{"filed_at": "2026-05-20T00:29:01.440611+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/817097da-1c7f-45a0-bad6-61c27412c1e9/coaf-a6517a64-a57a-41a8-a9af-f8bc1b10c93a.xml", "xml_sha256": "136b315fde2b109b794db50c08889b978d3be8159d06431327ed89b86cc096b7", "case_status": "REPORTED", "tracking_id": "61ac5e8b-a791-445a-9d78-781d03193a58", "report_package_id": "a6517a64-a57a-41a8-a9af-f8bc1b10c93a"}	\N	2026-05-20 00:29:01.430717+00	\N
8f7e6049-89a8-4ca7-b36b-dd51f50875e2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:29:40.420778+00	\N
7ea7c6bb-b5d8-4ec5-a6a5-751b9c52dc0d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:29:41.127794+00	\N
fefad853-bce2-45a3-a0b6-cca58733cae5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	3e8279c9-50d4-48e0-8849-c862d24d8c5d	null	{"title": "E2E COAF Protocol 1779236981167", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:29:41.334029+00	\N
8fe58ceb-5c87-4380-a6a0-32de0f1fcfb0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	3e8279c9-50d4-48e0-8849-c862d24d8c5d	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:29:41.463106+00	\N
1d338e14-f551-4e75-9590-3d3781372b0b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	3e8279c9-50d4-48e0-8849-c862d24d8c5d	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:29:41.534517+00	\N
4ad36c78-fa87-44f4-b062-b5b52a76b9f7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	3e8279c9-50d4-48e0-8849-c862d24d8c5d	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:29:41.608614+00	\N
0ec8d67f-fe02-456e-a7f1-ce6825e3738f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	3e8279c9-50d4-48e0-8849-c862d24d8c5d	null	{"decision": "FILE_SAR", "report_id": "d04d21ef-502f-44d2-9f80-b687db87ad58", "pdf_sha256": "42f8893b8d7db55025026edaff78aa668e9e3fe9c73ebd9c58ea743925436e7a", "payload_sha256": "0b63ce2b64ecf9078062348cb7d6b852dae7a43b16bd5c90fab0b8bc6ae1c9b3"}	\N	2026-05-20 00:29:41.676453+00	\N
e73fc947-7be8-454f-a838-1e97357f5573	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:20:49.818182+00	\N
901a78b6-7ce3-4d84-991c-a4921c9d5c9e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:20:50.805599+00	\N
4e9d9912-3f60-4c36-9a3a-b7fc189a5a1c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:09:22.40841+00	\N
35a54aa4-753f-4027-969c-88ac8ac61cc1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	d02b4133-26c3-4b85-a9da-8ac6948e3e0c	null	{"title": "E2E COAF Protocol 1779236450921", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:20:50.948316+00	\N
8671aca9-8b60-4248-81ae-b49797d0069a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	d02b4133-26c3-4b85-a9da-8ac6948e3e0c	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:20:51.026616+00	\N
b1caa239-0c62-4176-a233-6a0666228095	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	d02b4133-26c3-4b85-a9da-8ac6948e3e0c	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:20:51.091297+00	\N
a1a53efc-78c7-472a-9520-527231970f4a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	d02b4133-26c3-4b85-a9da-8ac6948e3e0c	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:20:51.149441+00	\N
ba71b6a0-7828-49fa-8bc3-2cf12f16aca2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	d02b4133-26c3-4b85-a9da-8ac6948e3e0c	null	{"decision": "FILE_SAR", "report_id": "993a85f7-c695-42eb-9abe-a1428b8e16ce", "pdf_sha256": "450cff48a76cee57327b8eaef7f310a008fce1cdd678d2ee1934df297896111b", "payload_sha256": "8972907bc34ce497d60e2af73e431cd0c7f38b5eb7fa06ac304803387582c8e6"}	\N	2026-05-20 00:20:51.275081+00	\N
1adf4f77-229a-40d6-80b0-f44e35f00834	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	e69af611-da75-4fe3-8a48-a76b10f9546f	null	{"title": "E2E COAF Protocol 1779236489976", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:21:29.995799+00	\N
8ee4d77a-c793-43e3-a5da-a2f51cc3eb82	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e69af611-da75-4fe3-8a48-a76b10f9546f	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:21:30.096133+00	\N
fc337c23-75a3-4174-929e-73e20c5fbee9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e69af611-da75-4fe3-8a48-a76b10f9546f	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:21:30.185224+00	\N
a3e1efe9-16b3-4a3c-a0ad-4fc6f2f3ae63	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e69af611-da75-4fe3-8a48-a76b10f9546f	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:21:30.25165+00	\N
426f7abd-5d21-48f0-9502-b0b0526f8af5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	e69af611-da75-4fe3-8a48-a76b10f9546f	null	{"decision": "FILE_SAR", "report_id": "653fb266-093c-4e7a-b221-8b4b23a1efa1", "pdf_sha256": "941edae0dcd38ca9c6d343637bef621da3bc3a03b6c2b50054ee1786c801d78b", "payload_sha256": "e4ad8f7e8c81ca7d2939a241b3d1def129fb09e6bb5cc9469290db4bc59fcdfc"}	\N	2026-05-20 00:21:30.368645+00	\N
b0aea33d-6a17-478b-b6f3-21cb0ffc6276	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	PLAYER_SELF_EXCLUSION_CLEARED	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "ACTIVE", "self_exclusion_flag": false}	\N	2026-05-20 00:22:03.763482+00	\N
cb89a708-9471-4b27-8b72-8daa0b158897	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:22:04.478406+00	\N
b2d61b6f-a308-4df9-9879-465f663a0e74	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"reason": null, "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:22:04.63044+00	\N
e962c987-5ea5-4ec3-a317-3fecad8f9eb8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:22:05.434081+00	\N
0502e89b-351b-4b41-aa48-790424d99aec	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:22:07.20239+00	\N
923c297b-fd40-4f5f-9dc6-0822568a9745	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:22:10.87109+00	\N
0aac60b9-1b73-4942-9450-163cc486c5f1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"status": "REJECTED", "provider": "manual", "event_type": "FACIAL_BIOMETRY", "player_status": "PENDING_KYC"}	\N	2026-05-20 00:22:11.031838+00	\N
53a03018-3851-47e3-ae7d-807cb05ae1ce	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"status": "APPROVED", "provider": "compliance-team", "event_type": "MANUAL_APPROVAL", "player_status": "ACTIVE"}	\N	2026-05-20 00:22:11.119514+00	\N
2461c86d-7ba9-400d-852c-c6420f2ad540	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:22:31.588794+00	\N
b6989530-f141-4b9e-b6c0-29cf1091e499	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:23:09.923809+00	\N
e5c5ed80-a27a-44aa-b0c5-ecf8691d8821	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:23:46.76211+00	\N
c3e5db84-1d44-421b-bc4e-a135dea5d8ae	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:24:40.306193+00	\N
3c6006cd-b56e-4008-bd5c-af13e505c82a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	7d7cdb0d-b5dd-4090-84b2-9486019ce2e0	null	{"title": "E2E COAF Protocol 1779236932457", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:28:52.539262+00	\N
32e3b4d5-75a1-4cbc-b629-ba24a0a0b1a8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	7d7cdb0d-b5dd-4090-84b2-9486019ce2e0	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:28:52.624485+00	\N
155b0655-93da-4995-a552-865708433c21	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	7d7cdb0d-b5dd-4090-84b2-9486019ce2e0	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:28:52.701203+00	\N
cd1b608e-b924-49a2-be99-84e577d88975	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	7d7cdb0d-b5dd-4090-84b2-9486019ce2e0	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:28:52.761852+00	\N
fcfef25d-580b-452f-9410-1f9a3ca3f308	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	d02b4133-26c3-4b85-a9da-8ac6948e3e0c	null	{"filed_at": "2026-05-20T00:20:51.461917+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d02b4133-26c3-4b85-a9da-8ac6948e3e0c/coaf-bcd483fd-b8a4-4ac7-bd76-3d743ffdc4b1.xml", "xml_sha256": "a1a5dc84a4eb09ad6ac425e9d3e3c08952493551b172e05e831e7fdf9928392c", "case_status": "REPORTED", "tracking_id": "c712da87-596c-4628-8004-8d85eb6949a2", "report_package_id": "bcd483fd-b8a4-4ac7-bd76-3d743ffdc4b1"}	\N	2026-05-20 00:20:51.44644+00	\N
b16ef27a-1d60-4e21-8625-075fd80cb2a1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:11:59.154598+00	\N
d9eaa741-8833-4d7a-be04-26b33be779df	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:21:29.309811+00	\N
be79cd08-41fa-44ea-ae41-6c158760dd17	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	f71ed380-a936-4b4d-a075-1b3fd6e022c2	null	{"reason": null, "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:11:59.702043+00	\N
5a241ca8-0425-4e05-94b4-2491d5b0f137	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_DEPOSIT_LIMIT_UPDATED	Player	f71ed380-a936-4b4d-a075-1b3fd6e022c2	{"deposit_limit_daily": null}	{"deposit_limit_daily": 750.0}	\N	2026-05-20 00:11:59.841605+00	\N
46e9f838-dd4e-4ce4-a25f-b8b203d0a84f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	f71ed380-a936-4b4d-a075-1b3fd6e022c2	null	{"status": "PENDING", "provider": "manual", "event_type": "DOCUMENT_CHECK", "player_status": "SELF_EXCLUDED"}	\N	2026-05-20 00:11:59.925429+00	\N
b8007dfd-a94d-4f8c-a065-ca75e9edacb3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	e21505cc-cb01-4958-a794-e6f59fbe8ee6	null	{"decision": "NO_ACTION", "report_id": "1fb9e889-23d6-4f03-979d-85784d55899c", "pdf_sha256": "0c5cc0524595644bd87b893c95258836510dcb14d0b9976646086fc3a35ca586", "payload_sha256": "527172fbae72b5c53ac6a8b524e307f91e77a86eb5a6c1fb553754fed2d0a9d2"}	\N	2026-05-20 00:12:00.048497+00	\N
5446fbf0-7be9-46f0-b60d-3e1926f4d910	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:13:25.977529+00	\N
8dceeea1-a878-4e47-a724-1cbdb7c18311	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:13:26.621414+00	\N
a2645ab2-c39c-453c-85df-322d61566d60	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:21:29.869123+00	\N
67a7797e-e3c8-4202-8465-531300177a16	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	f0fe6296-60e6-439d-a7a5-bcacc4239d18	null	{"title": "E2E COAF Protocol 1779236006620", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:13:26.746134+00	\N
edca6b49-c87e-43b2-af74-bc1dbd1b2ba2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	f0fe6296-60e6-439d-a7a5-bcacc4239d18	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:13:26.859759+00	\N
8d6904a8-a541-4136-a64c-68a91ea3a3d7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	f0fe6296-60e6-439d-a7a5-bcacc4239d18	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:13:26.941374+00	\N
acc6791f-5219-455b-894a-14a5b6ae6e64	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	f0fe6296-60e6-439d-a7a5-bcacc4239d18	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:13:27.082596+00	\N
98af2615-72ef-4172-b1a4-61a667ff4d37	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	f0fe6296-60e6-439d-a7a5-bcacc4239d18	null	{"decision": "FILE_SAR", "report_id": "29da91f3-aa9e-4782-af6e-85e79db28325", "pdf_sha256": "3c859a9d5fbe4b4c2abd5f4f04a0a370a55e9d74736987f865c7c1b672b7e97f", "payload_sha256": "46185c7dfad933d90252575fdef012b1ec202cbc09a33355ca73ea69ac3ea484"}	\N	2026-05-20 00:13:27.175562+00	\N
93386009-7be6-4352-948b-7aaa5c5c4343	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	f0fe6296-60e6-439d-a7a5-bcacc4239d18	null	{"filed_at": "2026-05-20T00:13:27.477916+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/f0fe6296-60e6-439d-a7a5-bcacc4239d18/coaf-ca82e2ae-02e1-4c0d-898f-c6540fac9951.xml", "xml_sha256": "c7a7746e7057110aebf6b642b48032beed432bfa4f1d6b86e1d81203ad7bdad5", "case_status": "REPORTED", "tracking_id": "4380a3a9-a651-45ca-9bf2-78f2b71958de", "report_package_id": "ca82e2ae-02e1-4c0d-898f-c6540fac9951"}	\N	2026-05-20 00:13:27.441445+00	\N
8871eee6-bdb6-41f9-8807-3c1c46eff4c2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	REGISTER_COAF_PROTOCOL	ReportPackage	ca82e2ae-02e1-4c0d-898f-c6540fac9951	null	{"case_id": "f0fe6296-60e6-439d-a7a5-bcacc4239d18", "coaf_protocol_number": "COAF-E2E-1779236007474"}	\N	2026-05-20 00:13:27.60793+00	\N
f712ebc4-4ac5-4a7c-bfe5-5709b5ad89ff	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:13:28.374046+00	\N
ece9fb51-9552-4e15-8762-51998c2e4031	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:13:29.174097+00	\N
4115152f-10c7-473b-a0ec-68f55a9b9531	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	20307f11-535c-46e4-a4d9-8d7090bd954c	null	{"title": "E2E COAF Protocol 1779236009272", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:13:29.297254+00	\N
19b0c143-f504-4d30-8695-80b0ac198fc8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	20307f11-535c-46e4-a4d9-8d7090bd954c	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:13:29.380753+00	\N
15b543ea-66a4-4c61-af02-d3a5cf7d52ea	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	20307f11-535c-46e4-a4d9-8d7090bd954c	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:13:29.44861+00	\N
3a7270e1-a710-42ef-80d7-513068f09276	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	20307f11-535c-46e4-a4d9-8d7090bd954c	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:13:29.518091+00	\N
79c6d2c9-748f-4cd4-849c-73112c58e9dc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	20307f11-535c-46e4-a4d9-8d7090bd954c	null	{"decision": "FILE_SAR", "report_id": "84950925-d4a7-4ce8-960d-fcb7961ca7d2", "pdf_sha256": "a593766d22af4a0ff769c2675fed0dc89268030f7fb16137466bf9e431734838", "payload_sha256": "419e701cc1225ce8537d68d3539276056760e935b1c248915e75fb0dcdc82bf4"}	\N	2026-05-20 00:13:29.587441+00	\N
cf674d14-0e24-4218-8020-935d03016518	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	20307f11-535c-46e4-a4d9-8d7090bd954c	null	{"filed_at": "2026-05-20T00:13:29.758934+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/20307f11-535c-46e4-a4d9-8d7090bd954c/coaf-1e764da9-9396-4d9a-a397-ca28426ee889.xml", "xml_sha256": "dc9ece06964d32a5696e00e2f43b064d602e31264e24cfda6648933292148c37", "case_status": "REPORTED", "tracking_id": "676ab896-5c77-47b8-b3fe-8bd09272e312", "report_package_id": "1e764da9-9396-4d9a-a397-ca28426ee889"}	\N	2026-05-20 00:13:29.743887+00	\N
f7414f34-48e3-49b3-9d51-ef6ba329f07e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:13:30.606977+00	\N
d6b829f7-c222-475b-ab89-dfbcf422aeef	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:13:31.433798+00	\N
d2eb88f9-bfab-42e0-9f65-f5155e8633a7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	607d3d6d-e568-4a39-ba6e-d1aa19db91b3	null	{"title": "E2E COAF Protocol 1779236011493", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:13:31.62715+00	\N
dac6ca45-cd68-4b46-83c1-f6b0476e5927	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	607d3d6d-e568-4a39-ba6e-d1aa19db91b3	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:13:31.757431+00	\N
88adb447-4588-471a-aaf2-d35e36537150	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	607d3d6d-e568-4a39-ba6e-d1aa19db91b3	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:13:31.833163+00	\N
c2cc56d7-56bb-4209-83ea-175b5e55e78d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	607d3d6d-e568-4a39-ba6e-d1aa19db91b3	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:13:31.898232+00	\N
62ee41fb-77ac-4f75-942e-544f70542a92	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	607d3d6d-e568-4a39-ba6e-d1aa19db91b3	null	{"decision": "FILE_SAR", "report_id": "deb2093c-6e95-435e-a377-dc48385d1f11", "pdf_sha256": "747bd7b854d7182cb2c2439741ae5f394a561505d30d7d13ab46468a5326d633", "payload_sha256": "653c9eef2362d024307e5af2388182469482493ac5febca14f4b1d6622bdb930"}	\N	2026-05-20 00:13:32.018197+00	\N
22bad844-c257-42a6-8764-b6c4f24db832	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	607d3d6d-e568-4a39-ba6e-d1aa19db91b3	null	{"filed_at": "2026-05-20T00:13:32.203875+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/607d3d6d-e568-4a39-ba6e-d1aa19db91b3/coaf-7162e1bb-e010-456b-9b73-dbebad25f33c.xml", "xml_sha256": "cf6af3f82ea3ff656a6aa9590e379a5098584cad9a5c740ec9f7778799f67ec8", "case_status": "REPORTED", "tracking_id": "bbd96d69-8d5c-45f9-9a6f-299a4ee90e24", "report_package_id": "7162e1bb-e010-456b-9b73-dbebad25f33c"}	\N	2026-05-20 00:13:32.184389+00	\N
5a543766-d2ae-4100-b501-89e0d558a1e7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:13:32.990943+00	\N
1f2d9e11-da1c-486b-9b19-0fc514cae6ae	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	e94f825a-af60-4a71-9eac-f4673f07b720	null	{"title": "E2E COAF Protocol 1779236013019", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:13:33.212315+00	\N
d098ca99-c3f3-4157-b57f-8334028cba8a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e94f825a-af60-4a71-9eac-f4673f07b720	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:13:33.357237+00	\N
eaf6c0fc-5f2a-4eb4-bb82-be9c7e846adc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e94f825a-af60-4a71-9eac-f4673f07b720	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:13:33.437399+00	\N
8b9f4979-2750-4302-a74b-e14c65ab5d0d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e94f825a-af60-4a71-9eac-f4673f07b720	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:13:33.517274+00	\N
6519e1d3-42d3-4b2a-b6ea-483c46573da3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	e94f825a-af60-4a71-9eac-f4673f07b720	null	{"decision": "FILE_SAR", "report_id": "bd25c805-ed5a-4d7b-9998-1896c6eb17cf", "pdf_sha256": "c16768d9a6541c81ca25f8ffce1d670ff0b4fca63c8df6158fa9a6cac677139b", "payload_sha256": "a63941f692089a7dd4f18dcb78583b714119c46d2e1d747eeae9fb6dde049f7a"}	\N	2026-05-20 00:13:33.607385+00	\N
7ca1d4f6-bea9-4dbb-97f8-7ed6b4f786dc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:13:34.348977+00	\N
650a0b69-9e8d-4a2a-94aa-8e027d54e98a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:13:35.057394+00	\N
26e18f98-5247-4246-b989-a67b61dd1af1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:13:35.682044+00	\N
152cdcf9-baae-4c8b-8814-44e1ab9dd3b5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:30:18.109489+00	\N
172b2528-3866-4e03-b82a-8b5e196e696f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	edefa731-72fc-4b4c-bb96-8cb786eb3433	null	{"title": "E2E COAF Protocol 1779236015689", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:13:35.837854+00	\N
f117262e-870f-4acc-9940-08c66fa31e30	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	edefa731-72fc-4b4c-bb96-8cb786eb3433	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:13:35.935207+00	\N
bc232593-64e4-4e61-a99d-7718a2db5a2a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	edefa731-72fc-4b4c-bb96-8cb786eb3433	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:13:36.028566+00	\N
c38c3fa3-66a8-41e3-9065-d8eaa727caa3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	edefa731-72fc-4b4c-bb96-8cb786eb3433	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:13:36.102075+00	\N
e1eeabe7-eb86-4ad6-8404-88b1eefba330	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	edefa731-72fc-4b4c-bb96-8cb786eb3433	null	{"decision": "FILE_SAR", "report_id": "e42b7db9-6b36-49d0-8834-5d7d0d79e793", "pdf_sha256": "cd04d5875237f78054a9637874ff56196c475c905fbf47aee9835eed0d9bed2d", "payload_sha256": "bd424b0f8fb7fe52047204e335ad85615d90a6645917ed1355595adbc4de7ce0"}	\N	2026-05-20 00:13:36.186931+00	\N
d15988d7-d14f-4d2d-b374-60bf6ea38987	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	edefa731-72fc-4b4c-bb96-8cb786eb3433	null	{"filed_at": "2026-05-20T00:13:36.384103+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/edefa731-72fc-4b4c-bb96-8cb786eb3433/coaf-528299eb-e916-4875-935e-fb42ef1338fb.xml", "xml_sha256": "0c00c6a92b5fb44c28fc9e516b05ca13d18ee1265913ae048538a5f919db31e1", "case_status": "REPORTED", "tracking_id": "23d67982-35e2-4b87-977d-21c021feb5cb", "report_package_id": "528299eb-e916-4875-935e-fb42ef1338fb"}	\N	2026-05-20 00:13:36.35955+00	\N
6764f567-f98d-41ce-9b6c-145e2be8b311	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	REGISTER_COAF_PROTOCOL	ReportPackage	528299eb-e916-4875-935e-fb42ef1338fb	null	{"case_id": "edefa731-72fc-4b4c-bb96-8cb786eb3433", "coaf_protocol_number": "COAF-AUDIT-1779236016355"}	\N	2026-05-20 00:13:36.490637+00	\N
04b16ae0-4849-4d11-927f-3414d3d5ec71	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:13:45.278057+00	\N
e4e16308-9a95-43c8-88dd-7d4d689a79c2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:13:45.990137+00	\N
2f4496dc-dd68-40ab-bbd0-9058e8c12296	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:30:18.653557+00	\N
8ee397b4-11e6-4d8c-962f-fb6d4191c37d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	e21867bf-2495-4371-8cdd-0f46d083bb6e	null	{"title": "E2E COAF Protocol 1779236026036", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:13:46.093429+00	\N
8ff80b8e-921d-421f-9517-bf3e6e2a2670	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e21867bf-2495-4371-8cdd-0f46d083bb6e	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:13:46.162418+00	\N
2d48cbca-0729-44a0-98d2-b3ef44cb0992	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e21867bf-2495-4371-8cdd-0f46d083bb6e	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:13:46.228326+00	\N
2ee51d54-a8a7-48a1-ac2d-7d35db34ac01	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	e21867bf-2495-4371-8cdd-0f46d083bb6e	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:13:46.300577+00	\N
16037333-3439-43eb-8906-8b37f4b6a89b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	e21867bf-2495-4371-8cdd-0f46d083bb6e	null	{"decision": "FILE_SAR", "report_id": "3cbd33a4-ce30-4d68-bf3e-4654404d985f", "pdf_sha256": "ef266b2a19d47fe437303a915e80195a0dc7b8ea1297d931ab7627fc472f7788", "payload_sha256": "ad4c757c4f9e9e990176d869d62b4c46ea26d4c4f9b4f449bd91d26d92aeee6c"}	\N	2026-05-20 00:13:46.380863+00	\N
e939dd60-82f8-4cb5-824e-cb992ec195e0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	e21867bf-2495-4371-8cdd-0f46d083bb6e	null	{"filed_at": "2026-05-20T00:13:46.565330+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/e21867bf-2495-4371-8cdd-0f46d083bb6e/coaf-2395e07b-e648-4cd5-82ab-7779d8cec89f.xml", "xml_sha256": "c7f24d9ab8622a75d0234f4a0b2bf606e46c48aac4621f2e6f1b3969f64df648", "case_status": "REPORTED", "tracking_id": "79cd4348-d869-456c-85fa-097a4a8e5238", "report_package_id": "2395e07b-e648-4cd5-82ab-7779d8cec89f"}	\N	2026-05-20 00:13:46.549532+00	\N
3118ba9f-44d2-4f2a-8126-6e3026d76c0d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.20	2026-05-20 00:13:53.690862+00	\N
45c64e9d-c5e9-45e9-83f2-188f34146f71	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:14:31.65354+00	\N
04b2aca9-d4b3-42b2-8743-80adcdcf3028	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:14:32.617201+00	\N
127f2567-b888-4bb3-b425-3c4c71647643	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	e69af611-da75-4fe3-8a48-a76b10f9546f	null	{"filed_at": "2026-05-20T00:21:30.519355+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/e69af611-da75-4fe3-8a48-a76b10f9546f/coaf-e2b9c351-9302-44c9-84b1-aa508e858668.xml", "xml_sha256": "916a4f66cd732f62892dfc4b63ec7ce05df75d85d94d03ebdf967849ebd01790", "case_status": "REPORTED", "tracking_id": "128adb28-7d4d-4853-b2ff-ed5825099140", "report_package_id": "e2b9c351-9302-44c9-84b1-aa508e858668"}	\N	2026-05-20 00:21:30.503714+00	\N
c3b27bc7-ff00-4e22-aa9f-a24fddf76dfa	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5	null	{"title": "E2E COAF Protocol 1779236072705", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:14:32.791017+00	\N
6bd2c122-f9fc-4083-9732-961e0df4d4cd	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:14:32.991246+00	\N
6902dc77-f2a5-4a36-a8c3-485e87bc93de	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:14:33.153851+00	\N
9509bffb-f6c1-4703-977c-0e5b9d868606	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:14:33.270035+00	\N
d97d0547-3a7e-417e-a97d-f27d04bda2d1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5	null	{"decision": "FILE_SAR", "report_id": "aaf163a5-8417-4c14-8474-2a1c3919aaf5", "pdf_sha256": "1d0e542535c36584428cb65540011ee2907f91218d5673bf4fd4578c06208a13", "payload_sha256": "5c3d56c7c880ef14bc1b7ff21ac1816f289307fd5c0052704fba58cbe1a6f74d"}	\N	2026-05-20 00:14:33.452895+00	\N
12124ced-75b5-4ed7-9f1d-befbf36f1068	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5	null	{"filed_at": "2026-05-20T00:14:33.752839+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5/coaf-af990639-bcd1-47ac-8c8b-2719a24e6ac1.xml", "xml_sha256": "516bb1942d72ade3d3b26aeb96860da8dc2a5a84a1c891979e876f02e8809147", "case_status": "REPORTED", "tracking_id": "bb8ec76e-5dbe-4122-8b79-bd6006bd1162", "report_package_id": "af990639-bcd1-47ac-8c8b-2719a24e6ac1"}	\N	2026-05-20 00:14:33.720627+00	\N
df716872-ea6b-41e3-bc61-33b45ef985d5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:15:13.293625+00	\N
dea449a6-2569-4f79-8712-ef5762832e35	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:15:14.488363+00	\N
2a0f8ad0-963c-4046-88d5-a23d559529c0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	97cb2b12-475b-4596-995c-73eb62f51ba4	null	{"title": "E2E COAF Protocol 1779236114577", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:15:14.79521+00	\N
474053c7-83d5-4b8c-af60-0565b9f95695	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	97cb2b12-475b-4596-995c-73eb62f51ba4	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:15:14.884618+00	\N
5fb36602-2cc4-4e75-9361-0b187abcd564	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	97cb2b12-475b-4596-995c-73eb62f51ba4	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:15:15.009459+00	\N
c55dff96-0b34-4e46-b1cb-50a45c8eac40	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	97cb2b12-475b-4596-995c-73eb62f51ba4	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:15:15.181741+00	\N
84d29933-d043-43f5-92a2-c5c43b25e732	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	97cb2b12-475b-4596-995c-73eb62f51ba4	null	{"decision": "FILE_SAR", "report_id": "d3772679-a33c-4250-a0ed-f0a195120a15", "pdf_sha256": "979e9e46bb53c3c4f2c3611bc4b88a5c1adea80d26d4ef4768b8139a3e435452", "payload_sha256": "7cd2505248296d0e88eb61cb35453051693de748e594cc4ce1e95d8a6d39a7d6"}	\N	2026-05-20 00:15:15.262066+00	\N
c5f73595-7bc4-4c14-b699-6cea85d43b8c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	97cb2b12-475b-4596-995c-73eb62f51ba4	null	{"filed_at": "2026-05-20T00:15:15.593838+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/97cb2b12-475b-4596-995c-73eb62f51ba4/coaf-4b84fda5-b796-4aa6-ac4c-fcb2622e615e.xml", "xml_sha256": "d03c8ae58b74957495763bbf4ccc6d223ab65474ed4482741177fb182a1832e8", "case_status": "REPORTED", "tracking_id": "99cd79f3-de85-4a62-8f72-b401f8e92f55", "report_package_id": "4b84fda5-b796-4aa6-ac4c-fcb2622e615e"}	\N	2026-05-20 00:15:15.567323+00	\N
4ac9ee33-3f8f-4f62-ba45-e801a1631942	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:15:54.671757+00	\N
00b503b5-fa88-4647-8eea-3b44b222df99	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"reason": "Solicitação do próprio jogador E2E", "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:15:54.940568+00	\N
9ddc7756-398d-4c49-bc90-83341b47b3dd	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:15:55.905091+00	\N
7d4f446e-9c6b-488d-a9a7-98c423c25fe5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	PLAYER_SELF_EXCLUSION_CLEARED	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "ACTIVE", "self_exclusion_flag": false}	\N	2026-05-20 00:15:55.977845+00	\N
26ccd302-08c3-405c-ac6e-07d5bdf56ee7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:15:57.039856+00	\N
62739276-c7ef-48be-a5eb-57642e3b4947	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"reason": null, "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:15:57.195153+00	\N
7bdf5882-e558-40a2-b505-bb10bdd1b114	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:15:58.061182+00	\N
7d47122a-e1f3-4d9c-bcc2-b0e8b1d7ea7b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	PLAYER_SELF_EXCLUSION_CLEARED	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"status": "ACTIVE", "self_exclusion_flag": false}	\N	2026-05-20 00:15:58.117053+00	\N
09680436-dbaa-4440-baf2-9c59248d725d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:15:58.92507+00	\N
b187994b-9637-4e2b-81fd-1671146c5def	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:16:00.189602+00	\N
7f4f96d9-cafc-4286-baf6-616bab03a9ed	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"reason": null, "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:15:59.095165+00	\N
3af24139-4482-4774-bfe6-dd25d8ce32a6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	PLAYER_SELF_EXCLUSION_CLEARED	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "ACTIVE", "self_exclusion_flag": false}	\N	2026-05-20 00:16:00.255769+00	\N
f32d9f15-5b29-4611-87fd-e468537817b8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:16:01.059348+00	\N
cc390cbc-14dc-428b-b2ee-98412d3bdbd5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_DEPOSIT_LIMIT_UPDATED	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	{"deposit_limit_daily": null}	{"deposit_limit_daily": 500.0}	\N	2026-05-20 00:16:01.194745+00	\N
123a47e5-6b6f-4692-9dbd-55c6789f978f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:16:01.862316+00	\N
510b77ce-0939-4837-92b7-a16d34a554c3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:16:02.612066+00	\N
7a95e8ec-8f59-4adf-8a04-15aaa6637f91	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "PENDING", "provider": "Serasa", "event_type": "DOCUMENT_CHECK", "player_status": "ACTIVE"}	\N	2026-05-20 00:16:02.742956+00	\N
d3abca46-e124-4a2b-b4bb-ee2054551ff0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:22:03.065313+00	\N
d8ae3d32-38c2-474e-86e3-8a43cf9c24dc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:16:04.298292+00	\N
385d8e61-2932-4da9-a920-979f5068e12f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"status": "APPROVED", "provider": "Lista PEP Gov", "event_type": "PEP_CHECK", "player_status": "ACTIVE"}	\N	2026-05-20 00:16:04.400869+00	\N
cbe24f5d-4127-4afa-a796-5863efda1d2f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:16:11.060717+00	\N
4900e443-4699-4f22-992a-c408e13ccad8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"reason": null, "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:16:11.246686+00	\N
62954ecb-5d95-4052-99ae-06fe8cbd78d4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"reason": "Solicitação do próprio jogador E2E", "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:22:03.17936+00	\N
c98b0142-c590-4be5-9ad9-3443c0e5c532	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:17:36.734698+00	\N
0d4786ed-b175-4472-b01d-07ef498d97e4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"reason": null, "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:17:36.868727+00	\N
72863d7d-466b-4ab6-a1c3-5974e579f45f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:22:03.710265+00	\N
e4db5ac0-01c6-412b-8b15-bb6e0f87db35	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	PLAYER_SELF_EXCLUSION_CLEARED	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"status": "ACTIVE", "self_exclusion_flag": false}	\N	2026-05-20 00:22:05.474799+00	\N
7c5ce21c-c4e3-4551-8936-fa90cacde3f7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:22:06.178455+00	\N
6ee0f78b-57e6-4520-9a55-b1b388ab37bd	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"reason": null, "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:22:06.312554+00	\N
981cf8dc-69dd-4f49-8480-86a49acb4654	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	PLAYER_SELF_EXCLUSION_CLEARED	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"status": "ACTIVE", "self_exclusion_flag": false}	\N	2026-05-20 00:22:07.276813+00	\N
bd1f2817-f174-47f3-9540-fb06b33f9305	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:22:07.980414+00	\N
1b6560dd-4792-4869-97a4-7e8622d0e8cb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_DEPOSIT_LIMIT_UPDATED	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"deposit_limit_daily": null}	{"deposit_limit_daily": 500.0}	\N	2026-05-20 00:22:08.079544+00	\N
d601deec-e762-4ef9-bdc5-b75ba8b01fa1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:22:08.995124+00	\N
3a06d94d-e9ce-48b6-a0a2-4aba31ea3ffa	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:22:09.957545+00	\N
431b9558-77d1-4947-a485-4ac64a73e5db	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"status": "PENDING", "provider": "Serasa", "event_type": "DOCUMENT_CHECK", "player_status": "ACTIVE"}	\N	2026-05-20 00:22:10.129609+00	\N
d813de2f-244e-471a-9290-6f883bbbb399	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:22:12.17601+00	\N
704434a2-e5de-4636-b621-5547d97757c3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "APPROVED", "provider": "Lista PEP Gov", "event_type": "PEP_CHECK", "player_status": "ACTIVE"}	\N	2026-05-20 00:22:12.312315+00	\N
c7c5f4cf-ea64-4dc2-81fa-259ba2a2de4c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:22:17.668784+00	\N
c9970c58-038b-4cd9-8c25-34046486d093	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"reason": null, "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:22:17.826436+00	\N
3bda4832-3d37-4d2f-b2ad-f0819817c91e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:23:10.607132+00	\N
b49c5557-d12f-40b7-ae71-cb5d31b59cc9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"reason": null, "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:23:46.897449+00	\N
efeb5721-4e54-4383-868d-02d5f6e83e63	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	7d7cdb0d-b5dd-4090-84b2-9486019ce2e0	null	{"decision": "FILE_SAR", "report_id": "07d7c24c-0ee6-4cae-b9a7-43fc7a7228d3", "pdf_sha256": "0ff08119c8bccfd96b340c2420968c9ad86c2ad985c62a249986298dc8f5dbd0", "payload_sha256": "e22967e715459059520d3650bb2f4a11a6c8ef3ea994d18cd429f79142aeea7e"}	\N	2026-05-20 00:28:52.840986+00	\N
fd90a01a-73ce-4f35-a583-2f0d45cc3d34	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	REGISTER_COAF_PROTOCOL	ReportPackage	d6df8218-84a8-44e7-b66e-af1ca0f7caa8	null	{"case_id": "7d7cdb0d-b5dd-4090-84b2-9486019ce2e0", "coaf_protocol_number": "COAF-AUDIT-1779236933065"}	\N	2026-05-20 00:28:53.141537+00	\N
4ee8be82-da9d-40a4-9deb-393ab46e39aa	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:27:14.146769+00	\N
edadb405-2a59-4b3c-a5c2-75b7e3f4504d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:16:03.427668+00	\N
1219ec7c-a6bd-4dfa-8a31-5309ecff1e68	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "REJECTED", "provider": "manual", "event_type": "FACIAL_BIOMETRY", "player_status": "PENDING_KYC"}	\N	2026-05-20 00:16:03.535295+00	\N
f1963c1e-bb52-4792-a47b-a73db292e2e7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "APPROVED", "provider": "compliance-team", "event_type": "MANUAL_APPROVAL", "player_status": "ACTIVE"}	\N	2026-05-20 00:16:03.630724+00	\N
bfd72080-24e4-4530-98ae-7f57597be4e7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	3a3f6cae-cf66-47a1-b02d-142bf667665e	null	{"title": "E2E COAF Protocol 1779236922205", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:28:42.293764+00	\N
ad29d5a1-914e-48d7-9a53-174f7f3bdfd2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	3a3f6cae-cf66-47a1-b02d-142bf667665e	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:28:42.428388+00	\N
c5179827-cdf8-4a0b-a5b1-96d7c284e0e7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	3a3f6cae-cf66-47a1-b02d-142bf667665e	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:28:42.511501+00	\N
8d97cb94-61de-47b9-bada-84b81d9e24d2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:16:24.006926+00	\N
86b0b171-5f4a-410b-a92d-c1932cd6ede5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:16:58.61171+00	\N
a055e6e1-69ce-454e-b69d-b83dda7eb4a7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	3a3f6cae-cf66-47a1-b02d-142bf667665e	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:28:42.58235+00	\N
de920939-d914-4cef-8b6c-5fbe3bd60dfa	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:16:59.717104+00	\N
f1541c07-4c81-4f26-ad3e-5a451ad2c0c5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	3a3f6cae-cf66-47a1-b02d-142bf667665e	null	{"decision": "FILE_SAR", "report_id": "668b8ed4-daa9-4130-a67e-871f77c4ef33", "pdf_sha256": "a2374b31d332d96a3ff49cd2b478d38e4c6f768a7582a4b8ff5296e1bb4fdf0a", "payload_sha256": "24035a0cf47934a6dd15613dd9a8569adbe5f6d969b23d3d6e980acb5de0bdea"}	\N	2026-05-20 00:28:42.650146+00	\N
ef09423c-8ad6-4e30-85e3-8fda95176bfe	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:19:08.275704+00	\N
6b582a54-fd88-4d9c-8cd2-199328968432	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	REGISTER_COAF_PROTOCOL	ReportPackage	0c6f08ab-62a2-4856-bb8e-3fb9a4a68aee	null	{"case_id": "3a3f6cae-cf66-47a1-b02d-142bf667665e", "coaf_protocol_number": "COAF-E2E-1779236923618"}	\N	2026-05-20 00:28:43.835667+00	\N
ac0a242e-725b-4073-90d9-f2955a0594ed	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:19:14.724776+00	\N
53c815e3-af7c-41d6-947f-6fd8446b1568	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:28:44.983594+00	\N
4db80cf2-2fca-44ec-bcb9-f08ce4b81811	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"reason": "Solicitação do próprio jogador E2E", "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:19:14.862359+00	\N
68d46364-7c24-4d7b-a15e-60ba0ba184b6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:19:15.532793+00	\N
2b364cc1-5342-4c96-ac3e-af0f101929d8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	PLAYER_SELF_EXCLUSION_CLEARED	Player	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	null	{"status": "ACTIVE", "self_exclusion_flag": false}	\N	2026-05-20 00:19:15.601909+00	\N
320694a1-4e31-4ac6-9571-8e896c5eac48	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:19:16.349522+00	\N
774b195a-c175-4ae3-8896-28b296a20b9c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:28:45.625261+00	\N
ea00611a-af9d-4bf1-a66e-642ebc201c21	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:19:17.242342+00	\N
fbbbc4a6-1b92-458b-8230-922fc9778cae	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	0a2b0872-efcd-4bca-b668-3bfad54a5b93	null	{"title": "E2E COAF Protocol 1779236925667", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:28:45.82691+00	\N
dbf91c4f-92bf-4de2-ad8a-d242281c7509	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "PENDING", "provider": "Serasa", "event_type": "DOCUMENT_CHECK", "player_status": "SELF_EXCLUDED"}	\N	2026-05-20 00:19:17.442974+00	\N
985afc77-71b0-4016-9eaf-c904b6c067e2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	0a2b0872-efcd-4bca-b668-3bfad54a5b93	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:28:45.900342+00	\N
de149160-1832-4438-8da4-f166e311baf7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	0a2b0872-efcd-4bca-b668-3bfad54a5b93	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:28:45.970784+00	\N
ee62f2bd-4e02-45d7-b284-0b1ef58a98c1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	0a2b0872-efcd-4bca-b668-3bfad54a5b93	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:28:46.139212+00	\N
a9f7b14c-493d-4021-9108-13de496e3c6c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	0a2b0872-efcd-4bca-b668-3bfad54a5b93	null	{"decision": "FILE_SAR", "report_id": "bda1d5b6-086b-423b-807e-5ae5d4bafe2f", "pdf_sha256": "ee8e9b5fc1f8a94a2debd189f2a57cdd8a8fed7c84a8d563a2c1b5427199a024", "payload_sha256": "5bc06ea45b3d28ddc9b3db128ec94df37629bea7de259ce3f445cc34a720754a"}	\N	2026-05-20 00:28:46.219001+00	\N
033e7845-43ea-4f3f-9a15-7925d9c180e2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:28:47.526176+00	\N
62a4027e-ecfe-4b6e-88c6-7fdd8285e762	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:28:48.370417+00	\N
756644c6-127c-4db2-b0d1-3dba8be8d07f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	a6c823d3-7622-4ffb-a61b-7ebcea535e95	null	{"title": "E2E COAF Protocol 1779236928289", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:28:48.46017+00	\N
089c4bc8-fd9b-42db-a113-3a0bad5603d1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	a6c823d3-7622-4ffb-a61b-7ebcea535e95	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:28:48.516731+00	\N
a8f6c088-4231-47e4-8d64-f608da57b127	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	a6c823d3-7622-4ffb-a61b-7ebcea535e95	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:28:48.616336+00	\N
2e79816e-30fd-43c3-9c8f-e92d86089c12	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	a6c823d3-7622-4ffb-a61b-7ebcea535e95	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:28:48.686801+00	\N
1772ad3a-33d2-400b-bfde-0dd28da8d380	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	3e8279c9-50d4-48e0-8849-c862d24d8c5d	null	{"filed_at": "2026-05-20T00:29:41.867875+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/3e8279c9-50d4-48e0-8849-c862d24d8c5d/coaf-4e0d46b5-575a-4b1f-832b-cdc17d9ac91e.xml", "xml_sha256": "b0d27dd6ad115ec7dec442eb1dad66bdb9c9d82a7f93a982701e86b92c87b105", "case_status": "REPORTED", "tracking_id": "6bef21e1-ab22-41c1-87a6-2a54d41e79e5", "report_package_id": "4e0d46b5-575a-4b1f-832b-cdc17d9ac91e"}	\N	2026-05-20 00:29:41.852033+00	\N
9ffb391d-0c10-4e46-8de5-3d8673b20e4d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:56:25.543254+00	\N
3f6a276c-460b-4b6f-ace4-114b1971fdda	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	f22ee9d6-f2bd-42bf-9a16-01fa36424384	null	{"decision": "FILE_SAR", "report_id": "a7e978b1-89c7-4537-a098-414f462e8e83", "pdf_sha256": "93c675195a37bddfbadc73230fb8168191af08d26e777c77482b9812f378c828", "payload_sha256": "dabcacc83f3b204533822f52bf3e52e32dfbe523798d2e594eaeab53aa8fc723"}	\N	2026-05-22 15:56:25.655732+00	\N
079908c7-a2b9-44e7-a5aa-8e0bdcafbbda	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	EXPORT_REPORT_JSON	ReportPackage	e129945d-7237-446f-a9fa-ca6b4a803fd0	null	null	\N	2026-05-22 15:56:25.727707+00	\N
e5733e34-7cf9-4e1a-a03e-2189166dd71a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:56:26.263279+00	\N
335ad863-b63b-4d66-a5ee-e543fe5be8ac	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	null	{"decision": "FILE_SAR", "report_id": "762b1829-0386-49af-a7a9-f5c655965b0c", "pdf_sha256": "2e75ad3788bcbed8130a5d3fa343efa4f1866c6c84537bbea214deb7d6993c11", "payload_sha256": "76802436ea5e2ef0cac9f9635fd4547e2a7e8182ece371841facf490ed768f95"}	\N	2026-05-22 15:56:26.349896+00	\N
208f4f42-02cf-46e5-947b-1d3c13bd79ee	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DOWNLOAD_COAF_XML	Case	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	null	null	\N	2026-05-22 15:56:26.624426+00	\N
a78c3c68-23dc-416b-99c3-2df24ca3bee4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	dd83cc19-5fee-42e0-9aa1-d5149c82e097	null	{"title": "E2E COAF Protocol 1779237018746", "severity": "HIGH", "player_id": "dc662a23-33a0-4898-81c1-22fe4404f5c4", "description": "Caso criado automaticamente pela suíte E2E"}	\N	2026-05-20 00:30:18.767819+00	\N
c135e0f9-2de9-471d-83d3-21d4a0948616	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	dd83cc19-5fee-42e0-9aa1-d5149c82e097	null	{"new_status": "INVESTIGATING"}	\N	2026-05-20 00:30:18.838932+00	\N
26d18205-2086-4678-b8c8-f04d4eb6edac	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	dd83cc19-5fee-42e0-9aa1-d5149c82e097	null	{"new_status": "PENDING_REVIEW"}	\N	2026-05-20 00:30:18.905489+00	\N
c8b5a101-58c4-4f8e-ae4f-d5007bc3722c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CASE_STATUS_CHANGE	Case	dd83cc19-5fee-42e0-9aa1-d5149c82e097	null	{"new_status": "CLOSED"}	\N	2026-05-20 00:30:18.988155+00	\N
2fad2506-2d67-41ce-80fb-0814f0afc869	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	GENERATE_REPORT	Case	dd83cc19-5fee-42e0-9aa1-d5149c82e097	null	{"decision": "FILE_SAR", "report_id": "78062c9b-b61d-4fc2-ac79-6c4676ba34d3", "pdf_sha256": "6f09e346702da805bb40c5566697bb42b4889e3a44d93d2e074dacf0de6ca34f", "payload_sha256": "fddbbe4df923f884ab86e1e13356957315206b00472c843656558b52c0b59580"}	\N	2026-05-20 00:30:19.076275+00	\N
def64593-165f-4a5d-98b5-e4824e840340	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"reason": "Solicitação do próprio jogador E2E", "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:30:52.796226+00	\N
e403082c-28e8-4f60-bb48-70fe1df2ab74	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:30:53.391034+00	\N
3b046fa8-fd76-491d-8cec-bdf2e26f1714	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:56:27.177993+00	\N
050f671f-b5a8-49a2-88e4-75527ba54a82	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	PLAYER_SELF_EXCLUSION_CLEARED	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "ACTIVE", "self_exclusion_flag": false}	\N	2026-05-20 00:30:55.05624+00	\N
0e7010ee-c9fe-4446-b3a0-0babafd58824	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:30:56.018462+00	\N
c819fa02-f8cb-484a-9692-befde6679196	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"reason": null, "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:30:56.209226+00	\N
017a2e51-e4b2-402a-bc46-7fb610a4d72d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	PLAYER_SELF_EXCLUSION_CLEARED	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "ACTIVE", "self_exclusion_flag": false}	\N	2026-05-20 00:30:57.022131+00	\N
ad2a7c49-2ddf-4927-8af7-22dc428e964d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:30:57.728595+00	\N
efdb5a71-ab0d-4a1b-8288-2c8e0e3d8729	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_DEPOSIT_LIMIT_UPDATED	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"deposit_limit_daily": null}	{"deposit_limit_daily": 500.0}	\N	2026-05-20 00:30:57.839498+00	\N
4f80d5da-ed93-404d-b3b5-56db42a6f630	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:30:58.614034+00	\N
fdbfbcff-7582-4b16-a5ab-d91adf57d86f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:30:59.49571+00	\N
9a2121ee-cd8c-4eed-b65b-8e8d65f67fce	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "PENDING", "provider": "Serasa", "event_type": "DOCUMENT_CHECK", "player_status": "ACTIVE"}	\N	2026-05-20 00:30:59.587279+00	\N
c58453cc-2da7-4f50-9463-d7dc7c64b06f	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 15:56:27.751239+00	\N
447e39f9-da61-403b-86e2-2c3627dfd80b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:31:01.148511+00	\N
4abe39a3-775e-471f-824e-539352154fe2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "APPROVED", "provider": "Lista PEP Gov", "event_type": "PEP_CHECK", "player_status": "ACTIVE"}	\N	2026-05-20 00:31:01.30747+00	\N
a7c9fc02-4016-4e89-aaac-8f13575a39d8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:31:02.180274+00	\N
90d913cd-3ee6-4337-a790-7bdc017f0a5a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"reason": null, "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:31:02.296684+00	\N
70eade38-3e54-484a-b0d1-a123a5f076f9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	PLAYER_SELF_EXCLUSION_CLEARED	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "ACTIVE", "self_exclusion_flag": false}	\N	2026-05-20 00:31:03.159758+00	\N
c0ec8b36-ae9a-44f6-a572-e1de77213ff1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:31:08.631132+00	\N
d7399d74-2b4e-4cda-9e0e-ee35c53c2f1b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:31:47.869724+00	\N
f49585cb-2db0-441f-98e8-d9b5a8739ce3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:32:25.23465+00	\N
a147e1b0-d3df-4478-a02a-a4451bfb0084	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	LOGIN	User	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	null	null	172.18.0.19	2026-05-22 15:59:44.381607+00	\N
0ce4c4aa-c35d-46f3-8838-3063b1d37956	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:33:40.208345+00	\N
96f8ff1a-58e2-496a-ba5c-765f4cc7fc5f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	3e32661a-e88d-41c7-b177-36c262195da1	null	{"title": "Caso SAR fac7ea", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 16:02:49.383088+00	\N
38eac048-449e-47d4-abea-7ad51d6920be	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:34:18.398474+00	\N
e8ee75eb-7a14-4cc4-9bef-85748db625cc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "APPROVED", "provider": "OFAC", "event_type": "SANCTIONS_CHECK", "player_status": "SELF_EXCLUDED"}	\N	2026-05-20 00:34:18.581325+00	\N
eb810fd3-f021-4444-8790-71379efeca6b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "PENDING", "provider": "Lista PEP", "event_type": "PEP_CHECK", "player_status": "SELF_EXCLUDED"}	\N	2026-05-20 00:34:18.683725+00	\N
1967bdbc-4834-4881-b731-870461bf4a20	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	3e32661a-e88d-41c7-b177-36c262195da1	null	{"decision": "FILE_SAR", "report_id": "4916ab29-472a-4a7a-a712-826e850574ed", "pdf_sha256": "fd4adf35e3fc4ad203f4a52ffa20f450639912de73a3df8993cef450e18ff16a", "payload_sha256": "9b282fa222c2d9b078d4cafcc30129ea273365b8d818f4a747ffe6933f7c4cef"}	\N	2026-05-22 16:02:49.453469+00	\N
0d3579ce-ad13-4030-8d3c-c9a86d4c4973	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	cf67acb2-a3f3-4384-aaa5-fac4c2067efe	null	{"title": "Caso CPF Mask Test", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 16:02:49.702581+00	\N
966a9df3-5c4f-49d9-b7c5-b5d0d16b92c1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	SUBMIT_COAF_REPORT	Case	dd83cc19-5fee-42e0-9aa1-d5149c82e097	null	{"filed_at": "2026-05-20T00:30:19.240190+00:00", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/dd83cc19-5fee-42e0-9aa1-d5149c82e097/coaf-7541779c-5795-4ad0-ad23-592cc6bcff1f.xml", "xml_sha256": "64444308b4e2de0489a41994386aee08c00b658e16112545d17c9f7cc1678e1a", "case_status": "REPORTED", "tracking_id": "21a72f94-d447-4f15-aecb-d3c8cdcc3917", "report_package_id": "7541779c-5795-4ad0-ad23-592cc6bcff1f"}	\N	2026-05-20 00:30:19.221474+00	\N
187914a6-65b1-41b6-885d-28d8cbaed73d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:30:52.650377+00	\N
0400be4c-9447-4044-b749-a113d84bee97	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:01:31.364814+00	\N
8b9aaeec-96c0-441c-9601-8590f1c40c2e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	PLAYER_SELF_EXCLUSION_CLEARED	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "ACTIVE", "self_exclusion_flag": false}	\N	2026-05-20 00:30:53.438517+00	\N
2a9a3bc2-1087-4d7f-997b-05f08ff5ff42	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:30:54.226345+00	\N
f64a1539-1146-432e-b303-18c93826595a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"reason": null, "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:30:54.377443+00	\N
70df6841-5139-4dc2-935e-dac423f7b4b0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:30:54.95921+00	\N
d1a7fc20-217a-4ac4-83cd-6f5c4ca712e1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:01:32.55082+00	\N
714c7463-46d8-4853-a535-54d53354c1a9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:30:56.977226+00	\N
bc0b51c8-d45b-4994-907e-d1617ff6b847	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:01:38.378243+00	\N
a2adbd4f-48ff-4ddf-8635-6134089c14ab	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:01:40.430616+00	\N
b1e65645-1540-4fac-86f0-e6dafd91d55d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	f22ee9d6-f2bd-42bf-9a16-01fa36424384	null	{"decision": "FILE_SAR", "report_id": "55163958-bbfa-4913-af4a-92c6b8a95d09", "pdf_sha256": "6e7e2dc62d325e31ae6aec213875ab5810e95c7ce81401f821f3718cd9902cd1", "payload_sha256": "e5af6423f9a71c62706efd235c7067733a552308fcfe541d7d2bb7b6155a1158"}	\N	2026-05-22 16:01:40.570335+00	\N
ee071ea3-9037-44dd-8559-8675de2e81b4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:31:00.271822+00	\N
8472adae-1f01-4538-8456-29d911c574c3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "REJECTED", "provider": "manual", "event_type": "FACIAL_BIOMETRY", "player_status": "PENDING_KYC"}	\N	2026-05-20 00:31:00.391223+00	\N
106690d1-8041-4dd0-ac3d-b06cfaf438ac	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_KYC_EVENT	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"status": "APPROVED", "provider": "compliance-team", "event_type": "MANUAL_APPROVAL", "player_status": "ACTIVE"}	\N	2026-05-20 00:31:00.458451+00	\N
24266394-f7b4-48e5-a836-a03ee81bb11b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	EXPORT_REPORT_JSON	ReportPackage	8457ecdd-7a3c-4730-9c19-02c5af460c7b	null	null	\N	2026-05-22 16:01:41.38497+00	\N
ab3a48ef-9c1e-40f6-831f-3d3124a3777a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:01:42.121888+00	\N
6f7b3e3e-e384-46d4-a6d4-a22031a511ef	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-20 00:31:03.123298+00	\N
9a2bf2d2-b8ff-4285-8e6d-965f81244420	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:31:47.056317+00	\N
32562b72-12ea-47ac-8692-02b1e5ea2ed0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	PLAYER_SELF_EXCLUSION_SET	Player	dc662a23-33a0-4898-81c1-22fe4404f5c4	null	{"reason": null, "status": "SELF_EXCLUDED", "self_exclusion_flag": true}	\N	2026-05-20 00:32:25.439298+00	\N
19d9a453-5e19-4b04-8722-b3dc5336e63c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:33:02.577498+00	\N
6a428da3-a0be-42a1-bcba-e0c0180cf247	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-20 00:35:49.174019+00	\N
57740680-2cec-46ae-95a3-6fe6e7598528	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:46:30.486698+00	\N
e6950cdb-76a9-4fbb-8a81-8e7022d72ce0	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 15:46:31.107729+00	\N
86e0c913-3cac-4cd5-a99d-b2fe2bf1676e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:46:31.593821+00	\N
673ecdb8-ec69-4157-b22f-663f1f61467d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:32.521241+00	\N
cc95ae1d-0e07-4047-9730-fd236483974e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	ERASE_PLAYER_DATA	Player	erase_test_gap7_1bf4e916	{"status": null}	{"reason": "Solicitação de titular (LGPD Art. 18)", "status": "ERASED"}	\N	2026-05-22 15:46:32.671791+00	\N
690635dc-c636-4835-a511-d15873c47eae	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:46:33.452974+00	\N
6026da46-fb06-4ea4-8076-3f3c1393aa0e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	1be39b6b-3938-4ebe-b779-fa393561dd31	null	{"title": "GAP7 Test", "severity": "HIGH", "player_id": "test", "description": null}	\N	2026-05-22 15:46:33.482035+00	\N
7cb7d621-12e9-4140-bbb5-e9d7ebf6ec0b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:34.216695+00	\N
77c15974-5b6b-4232-8956-58c34a95a6ff	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:46:34.728318+00	\N
5b8d8e1b-489f-4d40-b78a-fcbc7f167756	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:35.185759+00	\N
763f1f67-1d77-4a48-b855-c6b7c2e67cf2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_USER	User	3fb10cdb-5eaa-4207-bd31-9b34f8f99c7e	\N	{"role": "AML_ANALYST", "email": "gap7_fce8fecb@test.com", "username": "gap7_fce8fecb"}	\N	2026-05-22 15:46:35.217129+00	\N
a94fbc8a-c20e-43f5-95ca-ba00bab68435	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DEACTIVATE_USER	User	3fb10cdb-5eaa-4207-bd31-9b34f8f99c7e	\N	{"active": false, "username": "gap7_fce8fecb"}	\N	2026-05-22 15:46:35.758389+00	\N
3d53d845-89eb-479e-b58a-2fe70a53483f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:36.278287+00	\N
d8cbc5cd-87b2-400f-b770-265916f8b213	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:46:36.894726+00	\N
0c09227a-e371-4cf4-9cb7-d1a3bf2e958c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:37.558944+00	\N
f45bd33b-7b8b-474e-bca1-ef83fdd59768	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:46:37.570057+00	\N
918be545-952e-4079-9f6b-6c97ea567284	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:38.50495+00	\N
41491040-59ae-412f-a261-1adf50dd73d4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_COMPOUND_RULE	CompoundRule	8a0e5aab-6e5c-413b-9282-0e6cbca41f91	null	null	\N	2026-05-22 15:46:38.55701+00	\N
31e7188c-0426-420e-8779-33232bf7626a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DELETE_COMPOUND_RULE	CompoundRule	8a0e5aab-6e5c-413b-9282-0e6cbca41f91	{"name": "[REDACTED]"}	null	\N	2026-05-22 15:46:38.684601+00	\N
f78412f6-75fc-40ab-ba00-978181c098e9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:39.181331+00	\N
6637bd99-7aa0-413e-9445-7d94c4a17ff8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_COMPOUND_RULE	CompoundRule	32b6551c-3339-4f9f-a4e2-4f03530e205b	null	null	\N	2026-05-22 15:46:39.205804+00	\N
3fd9b791-96c0-4b76-a58d-d9b2383c2c1e	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 15:46:39.613404+00	\N
a41ba5c5-d9c8-46dd-a1d3-67f34caae702	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DELETE_COMPOUND_RULE	CompoundRule	32b6551c-3339-4f9f-a4e2-4f03530e205b	{"name": "[REDACTED]"}	null	\N	2026-05-22 15:46:39.659788+00	\N
7d2fad19-93a5-4051-a9e5-0f9ac9d400dd	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:40.110142+00	\N
06f81cb2-206b-4cd2-af35-e450ba4f0f71	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_MACRO	RuleMacro	6774a576-0906-4625-8989-0d4fc6d97b05	null	null	\N	2026-05-22 15:46:40.136262+00	\N
c5dc3f3b-e2d8-43ee-ac79-252e26a0ee22	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:41.234084+00	\N
1a5595a5-b0a3-401b-b860-5f52ea5ec2a8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_PLAYER_LIST	PlayerList	590a92d3-7f56-44da-bca1-41cd87f37c8f	null	{"name": "[REDACTED]"}	\N	2026-05-22 15:46:41.272294+00	\N
1b65066f-9303-4f93-91ce-2bf8b05d7033	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	null	{"decision": "FILE_SAR", "report_id": "bfa2f26f-3d16-4c74-bd4a-8b18fcbe2dcb", "pdf_sha256": "8d87cd4d7a0bf24b5234f70d859cbb20e9ec4cc0c0333c5d68fc46d4ab23930f", "payload_sha256": "1cd9c70ed4c2e152587265f7bc275bf4eecb87792b3935ae6ef0462ff087cb32"}	\N	2026-05-22 16:01:42.179914+00	\N
91a9bc42-1165-44ba-9d83-238e62499b44	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DELETE_PLAYER_LIST	PlayerList	590a92d3-7f56-44da-bca1-41cd87f37c8f	{"name": "[REDACTED]"}	null	\N	2026-05-22 15:46:41.445043+00	\N
3afa3a50-94ef-4232-b9d6-7112df81578f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:42.413428+00	\N
f2693aa6-4726-4840-9304-14519ad4c3ed	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_PLAYER_LIST	PlayerList	ea82d927-07f2-4477-b79b-93c497004a7a	null	{"name": "[REDACTED]"}	\N	2026-05-22 15:46:42.449616+00	\N
e4d07582-eda6-4738-abc0-d3459a7649fc	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 15:46:43.206739+00	\N
432f7bf9-d28a-449a-b791-28638fb0a9ee	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DELETE_PLAYER_LIST	PlayerList	ea82d927-07f2-4477-b79b-93c497004a7a	{"name": "[REDACTED]"}	null	\N	2026-05-22 15:46:43.316047+00	\N
b5897cec-3680-45b5-9052-5320654e79e7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:43.856921+00	\N
9a8f7ba4-4a2b-4cc5-ba9b-7e17c7a0f63c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DOWNLOAD_COAF_XML	Case	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	null	null	\N	2026-05-22 16:01:42.30349+00	\N
9a8ba776-dc3a-4dbb-ada9-00fb8a6b6801	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	EXTERNAL_VALIDATION_REQUEST	Player	087318c7-8467-41d9-a23a-ffed149c7dfb	null	{"trigger": "integration_test", "provider": "mock_identity", "validation_type": "CPF_IDENTITY"}	\N	2026-05-22 15:46:43.99373+00	\N
307e6d90-551a-4f31-8dc8-75e7fac505b5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:45.46169+00	\N
7ea9f1fe-306d-458c-a7f7-710466113da0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 16:01:56.875748+00	\N
d8d87bde-d268-4a4b-a0a2-431454181263	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:46.310058+00	\N
f9241dda-91f6-4b30-b532-56c6aaaa665c	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 15:46:46.908303+00	\N
04ff0327-f913-4cee-9546-992c074666b6	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 16:01:57.640352+00	\N
373afbb3-4804-4ffc-b892-c26a11ec9531	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:47.846536+00	\N
469478d0-a178-4a09-9e78-076f17983aae	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN_FAILED	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:47.462973+00	\N
0c7eaa9a-628a-4967-82fa-2ee8fcc50923	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:46:48.900125+00	\N
fa240fc2-7fb2-4edb-8fb2-9a07dea7833f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 16:01:58.77345+00	\N
7fca6889-b50d-49eb-b34a-fbc36e6c37e8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:00.373002+00	\N
29985880-f536-4c2e-83a6-c8250172cd5e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	ERASE_PLAYER_DATA	Player	erase_test_gap7_458fbe56	{"status": null}	{"reason": "Solicitação de titular (LGPD Art. 18)", "status": "ERASED"}	\N	2026-05-22 16:02:00.661377+00	\N
be4fe4b5-be2d-443e-badf-ddcd3019bfdf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 16:02:01.512337+00	\N
20730e07-2805-4f89-a87b-8099f7f31e45	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	b0630225-62e3-440a-9cb6-bd39fbb96ef9	null	{"title": "Caso de Teste 0676af", "severity": "HIGH", "player_id": null, "description": "Criado por teste de integração automatizado"}	\N	2026-05-22 15:46:53.954825+00	\N
e75b1d63-8aed-44fb-8176-69f7bb0f96fa	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	3beff455-a892-4004-8bbb-5b6e6d6db780	null	{"title": "Caso para Fetch", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:46:54.064521+00	\N
bd179dad-8744-4f0f-b9bd-c970bca8a6a1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	4090b4d3-47fe-4caf-bb39-726a0c033eda	null	{"title": "Caso Link Test", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:46:54.194717+00	\N
81790869-7214-4be8-b280-e12f000930be	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	RuleDefinition	1c46bbbe-c80d-41c7-ae4c-152d913b7cb5	null	{"name": "[REDACTED]", "scope": "TRANSACTION", "params": {}, "status": "ACTIVE", "weight": 0.5, "severity": "HIGH", "description": null, "condition_dsl": "transaction.amount > 9000 and transaction.type == 'DEPOSIT'"}	\N	2026-05-22 15:46:54.499961+00	\N
c0f6a7d4-2075-4c18-8c9b-411f66fca8b8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	31740fef-863a-4937-bea9-7dd363c0a87c	null	{"title": "GAP7 Test", "severity": "HIGH", "player_id": "test", "description": null}	\N	2026-05-22 16:02:01.570602+00	\N
75b24e10-87bb-449f-8b02-f1277a174382	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:02.239042+00	\N
462da004-364e-41df-9272-554ae4bc5793	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 16:02:02.874594+00	\N
d4f1ebc4-7bd9-4e88-a890-4bdeb161b7e6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:03.571422+00	\N
1445a8ef-dc8b-4eb5-8683-732671b5351b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_USER	User	bcfd0d18-07aa-4911-9159-eadf44d44757	\N	{"role": "AML_ANALYST", "email": "gap7_2ee1ea0d@test.com", "username": "gap7_2ee1ea0d"}	\N	2026-05-22 16:02:03.603925+00	\N
589ad4c3-8933-4d3c-a7e2-f635ac2a8366	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 15:46:55.435328+00	\N
de76550b-0933-41a4-a2a2-5987a4219297	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	CREATE	Case	8fcd6c84-097e-4617-b69e-755e49bee79b	null	{"title": "Caso Tenant B", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:46:55.607594+00	\N
19f1d2c2-52bd-4178-984c-62aa9dddc367	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_API_KEY	ApiKey	4174dbf1-d7da-4c60-b4da-81e69b932862	\N	{"name": "test-key-integration", "permissions": ["ingest"], "source_system": null, "expires_in_days": null}	\N	2026-05-22 15:46:55.929541+00	\N
6ff70e15-93b2-4f0e-bf41-563938707342	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	REVOKE_API_KEY	ApiKey	4174dbf1-d7da-4c60-b4da-81e69b932862	\N	{}	\N	2026-05-22 15:46:56.057489+00	\N
47dcd6a1-0d84-4f21-9649-8155b5b7b5c6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DEACTIVATE_USER	User	bcfd0d18-07aa-4911-9159-eadf44d44757	\N	{"active": false, "username": "gap7_2ee1ea0d"}	\N	2026-05-22 16:02:04.142044+00	\N
97104a21-a3c0-447b-925c-07180238571f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:04.646308+00	\N
f1589ecd-021e-493d-9b30-0228d3d033ba	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 16:02:05.209235+00	\N
71a22947-ffe0-4749-a5f9-25dbd0070eba	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:05.90717+00	\N
44860dbc-eb56-40ea-852f-71975bc2f7ca	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 16:02:06.44129+00	\N
4a674ea2-1ae2-400c-808d-be1b109b4eb6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:06.919007+00	\N
244ab981-645f-4d4e-9080-1182c8320ba3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	9a33886c-5d3a-4170-a082-415b6e3a2d37	null	{"title": "Caso COAF Test 808f4e", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:47:07.632603+00	\N
19282f40-f844-4417-85eb-b668668011eb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	fb59b5d0-b12f-43de-8a0a-446899f04964	null	{"title": "Caso SAR 4dcb5e", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:47:07.790503+00	\N
ec417e7c-6caa-498f-99b6-bd4126d66190	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	3d4821e8-e84f-4c4d-a810-ed082dbaff64	null	{"title": "Caso SAR sem narrativa 61475e", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:47:07.558713+00	\N
eeb82fac-6039-46e4-bd8e-35d98923e311	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	06748e5f-601a-483b-bb32-e47920ee6210	null	{"title": "Caso CPF Mask Test", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:47:07.664918+00	\N
e48f1482-a0c5-4e0a-95c9-d7e0b46e9da4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:47:08.679685+00	\N
95346f87-43b8-4490-9dd1-7ff917c5fead	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGOUT	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	\N	2026-05-22 15:47:08.749071+00	\N
69026181-d625-4fac-8fdd-3a97714e0ec2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:47:09.246368+00	\N
d7cd3738-08ef-42dc-a6f0-5090292d7067	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:47:09.67873+00	\N
7437971c-681e-4c14-89f6-fd03a9856c17	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	109920b9-b859-4ed4-9348-9de10f8d21da	null	{"title": "Caso Audit Test", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:47:09.836109+00	\N
92b3ceed-0255-499b-97f1-ed4ebac3a5b4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:47:10.459965+00	\N
d2f8e5cf-4ab5-4a02-8ee1-8c84d90010e0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:47:27.345111+00	\N
a0a8df3a-1658-499a-a84c-ff650fedbb14	98c56b0f-fa44-47cd-a8d9-9479174e3140	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	LOGIN	User	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	null	null	172.18.0.1	2026-05-22 15:47:28.289214+00	\N
5bfe7c7c-beca-4ebe-9654-5a51915a84e0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_COMPOUND_RULE	CompoundRule	565c6f08-d425-4a43-af58-2e5726b11b25	null	null	\N	2026-05-22 16:02:06.945251+00	\N
bfb52741-da21-4eed-ab5d-8f66c8d3e477	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DELETE_COMPOUND_RULE	CompoundRule	565c6f08-d425-4a43-af58-2e5726b11b25	{"name": "[REDACTED]"}	null	\N	2026-05-22 16:02:07.027472+00	\N
9f528447-a476-422f-a5ee-3069ccaf7dfc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:07.53024+00	\N
741bcca1-bf1e-441b-a832-2f40dab33a73	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	LOGIN	User	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	null	null	172.18.0.1	2026-05-22 15:47:32.724212+00	\N
5cf5d315-b1f9-4e71-8f9a-b20fdebcdfa9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	CREATE_TENANT	Tenant	812a654a-3f32-4532-9bf6-5748ef933472	\N	{"slug": "test-slug-dd0b2b12", "admin_username": "u_test-s"}	\N	2026-05-22 15:47:32.777289+00	\N
e4e50d2a-e998-4617-baa8-fe37d583ef26	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:47:35.292657+00	\N
8df12960-d183-482f-a7c0-3f3a27a1f4cb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:47:41.127604+00	\N
2f76d64b-0b9e-4bef-bdce-1ad08ebf6a0c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:47:41.615743+00	\N
70005dd4-da37-44cd-bb27-30d6c3f79beb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_COMPOUND_RULE	CompoundRule	6740fe04-e9f3-48df-be78-01cfb8b8d71f	null	null	\N	2026-05-22 16:02:07.609924+00	\N
1f59feff-6a2d-454b-9bf9-0535e92b1337	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 16:02:08.213253+00	\N
2bdc14a4-72e6-45d1-95dc-bbf54d65f879	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DELETE_COMPOUND_RULE	CompoundRule	6740fe04-e9f3-48df-be78-01cfb8b8d71f	{"name": "[REDACTED]"}	null	\N	2026-05-22 16:02:08.412389+00	\N
343a84af-9141-4c3d-a684-82c86f0f3844	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:08.873324+00	\N
83d80a0f-9a27-47e8-8fe4-27c0bcc288d3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_MACRO	RuleMacro	c1e0bd8b-6f7a-472e-98a9-be2935aa9243	null	null	\N	2026-05-22 16:02:08.906578+00	\N
464bfc5b-62eb-444d-afca-9dcf84e923c3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:09.493992+00	\N
9f8ab210-90fc-4c6e-b024-256dbb9e4fd9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_PLAYER_LIST	PlayerList	c310c0ce-8320-47c8-89f1-e775e72f97e4	null	{"name": "[REDACTED]"}	\N	2026-05-22 16:02:09.525032+00	\N
02f0f1a0-77e4-4dc8-9dad-4212bb4b33a6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DELETE_PLAYER_LIST	PlayerList	c310c0ce-8320-47c8-89f1-e775e72f97e4	{"name": "[REDACTED]"}	null	\N	2026-05-22 16:02:09.738109+00	\N
2721b0e0-33aa-418f-aa79-45f26ad6804d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:10.409098+00	\N
05f82d74-e48d-45f1-a50c-8c23b7d482cc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_PLAYER_LIST	PlayerList	4ed32cf8-a0df-442e-9fa8-768173d7d453	null	{"name": "[REDACTED]"}	\N	2026-05-22 16:02:10.440683+00	\N
369f4308-102e-4b0b-a5ec-993ff966fe8c	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 16:02:10.872698+00	\N
09e148a7-a443-4b15-8f9f-3fee758652ea	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DELETE_PLAYER_LIST	PlayerList	4ed32cf8-a0df-442e-9fa8-768173d7d453	{"name": "[REDACTED]"}	null	\N	2026-05-22 16:02:10.928759+00	\N
ed4c15e2-039f-40d7-90ae-5441e57b8a73	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:11.363666+00	\N
e1ba1780-91b4-4c9b-b196-71c2b3b1762f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	EXTERNAL_VALIDATION_REQUEST	Player	087318c7-8467-41d9-a23a-ffed149c7dfb	null	{"trigger": "integration_test", "provider": "mock_identity", "validation_type": "CPF_IDENTITY"}	\N	2026-05-22 16:02:11.438054+00	\N
b41c3e06-9409-4998-9742-3f294b789c16	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:13.949782+00	\N
0bf1d777-b4cf-416f-871e-61df6a63cec6	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 16:02:14.377208+00	\N
da316ecc-f96e-4043-b03a-0f1166a61517	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:16.139995+00	\N
4e92247d-1b11-4705-b611-14dbfd195cd6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	583ac91c-e317-4fad-9012-f714629b3d62	null	{"title": "Caso para Fetch", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 16:02:21.064002+00	\N
62a96d92-f067-4e21-91a7-28104f05ec94	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LINK_CASE	Alert	36d6e3a5-cf34-4e62-aff3-77ecb0909deb	null	{"case_id": "0d802281-da37-43c1-91b8-aba355578826"}	\N	2026-05-22 16:02:21.229123+00	\N
e03e0631-6a8b-4a1e-a0bb-42c0b5c4d7bb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	RuleDefinition	42028baf-41a6-4090-abba-78fb297c42ac	null	{"name": "[REDACTED]", "scope": "TRANSACTION", "params": {}, "status": "ACTIVE", "weight": 0.5, "severity": "HIGH", "description": null, "condition_dsl": "transaction.amount > 9000 and transaction.type == 'DEPOSIT'"}	\N	2026-05-22 16:02:21.318774+00	\N
bb9c7acc-47b8-4ad8-80a5-fe54b269a645	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 16:02:22.248006+00	\N
ba904ecc-cf54-4607-9dc0-83311dba1378	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_API_KEY	ApiKey	d1523547-6b60-4f86-9382-30b59d8e3779	\N	{"name": "test-key-integration", "permissions": ["ingest"], "source_system": null, "expires_in_days": null}	\N	2026-05-22 16:02:22.550569+00	\N
80973f89-4139-4eae-9965-0fe8a6146b62	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	cf67acb2-a3f3-4384-aaa5-fac4c2067efe	null	{"decision": "PENDING", "report_id": "758e0ec1-858d-4301-8a17-30a30f92c2d7", "pdf_sha256": "ff5b796ceefce9a090779ba45eebd18ded2a3be85f076824570a5c34d5c6ee5a", "payload_sha256": "737302fc85df4ee7520e9a925f01ef4f6fd4b9b3de242c62ff7372d24c62f1a8"}	\N	2026-05-22 16:02:49.778991+00	\N
95c94201-4c28-4adf-a503-b4ba2234ed36	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:50.28355+00	\N
caa4240b-6d84-4337-b5c8-99a520f5b8ef	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	510078bd-3aab-411d-97f9-e22b883da667	null	{"title": "Caso Audit Test", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 16:02:51.285011+00	\N
1281126b-78d3-41e8-a546-b0d0783c864b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	510078bd-3aab-411d-97f9-e22b883da667	null	{"decision": "PENDING", "report_id": "90bee7c5-4947-4e8e-b653-61ea63b6a231", "pdf_sha256": "590426ca3c5123fff3bcccdfe878d714ccb35d64ad09e2cb087a7fe38df4017a", "payload_sha256": "1e2467448b661887631f764333e403602d03a523142203c354a52353c9bf5b36"}	\N	2026-05-22 16:02:51.326609+00	\N
81b7f929-1597-4b57-abeb-8a269d1df063	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 16:02:52.845065+00	\N
91ba6cd9-374e-4705-86aa-aa844836b06f	98c56b0f-fa44-47cd-a8d9-9479174e3140	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	LOGIN	User	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	null	null	172.18.0.1	2026-05-22 16:02:53.253033+00	\N
7bf6e1e1-6eeb-4e8b-bd64-a1fd9ab15ab0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	LOGIN	User	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	null	null	172.18.0.1	2026-05-22 16:02:55.596231+00	\N
e47b8e14-9206-4c7d-adce-6cc351787441	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:56.707835+00	\N
665c7e46-971a-4b75-b03e-3795b4f11d31	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:03:02.267637+00	\N
bb1eaf62-6a24-4f44-8360-e357ad5aa56f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:03:02.722612+00	\N
91ce4da0-a449-461c-a774-4f63de79ff5e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:47:49.559477+00	\N
866cf04b-13e4-4d88-892e-c3b03bdd8285	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:47:50.29745+00	\N
34143af5-9403-4749-aaae-ceb59c503ae3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:47:50.944984+00	\N
f17f5b63-8367-405f-9898-cc6018b08243	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 15:47:51.399656+00	\N
d3839084-f898-4998-88e3-454c8a53e490	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	LOGIN	User	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	null	null	172.18.0.19	2026-05-22 15:51:35.520687+00	\N
53754da5-76e6-4c3a-bdd3-2197a5eaab54	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.19	2026-05-22 15:52:40.256289+00	\N
d295ee19-dbf9-4ed2-bc42-6d63c75d3dc3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.19	2026-05-22 15:52:46.35369+00	\N
6af6b085-0d24-422a-975b-79b838b0d7b3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:52:50.847738+00	\N
5433983a-4969-4d66-9a4a-cb18c9e5e7e8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:52:51.404613+00	\N
1f49d0dc-1ae6-4952-be8f-98093523c185	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:52:51.9878+00	\N
98aafb49-4e54-47e3-9b69-e669ded86fbb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:52:52.552944+00	\N
b38312e1-bd61-4b01-8e9c-85d2a17f9cf0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	8d5d46c2-b4b1-425a-ad70-d87ff52b38a8	null	{"title": "Caso COAF Test 755f21", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:52:54.87516+00	\N
906ca4a2-f113-4a57-a51f-a0d79a29b106	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	7911feb1-05c3-45dc-976b-020f4b7a0fc0	null	{"title": "Caso SAR sem narrativa d33620", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:52:55.332236+00	\N
e6bd585f-97b6-428b-93aa-260906fe6389	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:52:56.273418+00	\N
6a9553cf-9a0a-472a-8493-7b05099fc4e2	98c56b0f-fa44-47cd-a8d9-9479174e3140	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	LOGIN	User	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	null	null	172.18.0.1	2026-05-22 15:52:57.113979+00	\N
9e10d62e-78b2-4579-838c-61f0d36377fb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.19	2026-05-22 15:53:34.21895+00	\N
bfba6ea8-360b-4bdd-9e00-bd9c22096e57	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:25.310063+00	\N
63ee4455-26eb-4c1c-823e-49309668f32f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	7067f39b-8afe-4b83-b7e9-4391b079ebda	null	{"title": "Caso COAF Test 82cf2c", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:54:25.456379+00	\N
00abe8fb-cdfe-454f-8715-f3b6a4640245	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	7067f39b-8afe-4b83-b7e9-4391b079ebda	null	{"decision": "PENDING", "report_id": "9fb0595f-61ea-4851-9391-6defd221554e", "pdf_sha256": "3cf68ca17d207d58c553e4cf23dba454f79ab3ef03e6ae26ea337715556eda9e", "payload_sha256": "26d7bc2df6fe5357413e58bfe30df1bcb8f2182ca0acd351331a86c0577899f9"}	\N	2026-05-22 15:54:25.536212+00	\N
f3d8e4d0-7be4-43fd-8be9-54799cc36812	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:54:41.420564+00	\N
4e427944-c7c8-47b5-b6d3-c88ec2fcf4aa	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 15:54:42.479597+00	\N
d1596618-13d6-432e-8c97-6a81e5f93fb9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:54:43.291905+00	\N
3d5c7669-55db-4065-8d61-7dc7c7dcd290	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:43.890949+00	\N
456d7a0e-936e-4f3d-bcf7-404cd9430bf0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	ERASE_PLAYER_DATA	Player	erase_test_gap7_e6c634c9	{"status": null}	{"reason": "Solicitação de titular (LGPD Art. 18)", "status": "ERASED"}	\N	2026-05-22 15:54:44.015545+00	\N
283ae36d-cc50-4048-8cd4-9f653ce46499	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:54:44.687348+00	\N
83d8e2bc-5ac1-487e-b2c6-7634c5fa402e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	CREATE	Case	26c430d1-fdfc-42ea-a4e5-df1d25e1f95a	null	{"title": "GAP7 Test", "severity": "HIGH", "player_id": "test", "description": null}	\N	2026-05-22 15:54:44.719364+00	\N
61e0052a-fb12-4d02-95b8-dd85634149df	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:45.290969+00	\N
403b0e4b-ded3-4af7-8ca5-9b190952f4f6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:54:45.755015+00	\N
9c0fe7d9-55da-4066-b3b4-f4d83c8c5dc3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:46.200194+00	\N
c56cfcb4-f826-4c22-9448-fd564ace8f60	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_USER	User	0a609ad1-9832-4f8f-88a8-f878b6bb1d8a	\N	{"role": "AML_ANALYST", "email": "gap7_0218a4e0@test.com", "username": "gap7_0218a4e0"}	\N	2026-05-22 15:54:46.227646+00	\N
75b04d8a-5762-41d9-ac04-4f44828d5714	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DEACTIVATE_USER	User	0a609ad1-9832-4f8f-88a8-f878b6bb1d8a	\N	{"active": false, "username": "gap7_0218a4e0"}	\N	2026-05-22 15:54:46.620662+00	\N
96a985af-3318-4a3d-820f-7f19879809da	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:47.321919+00	\N
839d6d2d-e3a3-46e4-9aeb-c6b0b242ec79	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:54:47.594422+00	\N
ace8d61a-dd2e-4e96-b724-c5b95d079ad0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:48.970804+00	\N
373a33b2-a48f-4d2b-972f-47471baea7fc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 15:54:50.165741+00	\N
68591cce-6e76-425e-b17f-91496ff53832	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:50.622672+00	\N
de2057e1-7f98-4279-aba7-54aa8eb9ffb2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_COMPOUND_RULE	CompoundRule	1ef5d806-262e-43b9-9fd3-79998db35b89	null	null	\N	2026-05-22 15:54:50.671225+00	\N
3c9bb3a1-81ca-4206-bd09-8f6857ee6939	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DELETE_COMPOUND_RULE	CompoundRule	1ef5d806-262e-43b9-9fd3-79998db35b89	{"name": "[REDACTED]"}	null	\N	2026-05-22 15:54:50.750495+00	\N
b93e9354-20a8-40b4-8f96-70f798a39517	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:51.161839+00	\N
f8b911d4-1aa1-4559-82c5-e022ea896c68	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_COMPOUND_RULE	CompoundRule	d133e52a-9451-4e6c-8d26-af8c1e4a94ed	null	null	\N	2026-05-22 15:54:51.185549+00	\N
fbae3cd7-db1a-45b3-94dd-e38ec5a18ce6	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 15:54:51.578921+00	\N
4fdf7f94-1abe-4181-a117-32d47f80e594	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DELETE_COMPOUND_RULE	CompoundRule	d133e52a-9451-4e6c-8d26-af8c1e4a94ed	{"name": "[REDACTED]"}	null	\N	2026-05-22 15:54:51.632654+00	\N
4a130183-c957-4708-8a41-b00b1cb2830f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:52.026162+00	\N
f99ccb61-c0a1-422a-b920-1bc456d5a85c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_MACRO	RuleMacro	ef3a9d6d-c06b-4307-a18b-3ec9e8ef1878	null	null	\N	2026-05-22 15:54:52.051762+00	\N
b3df27ec-7d99-4e24-ab08-d448707c764e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:52.578058+00	\N
421ea502-da33-4e7c-b0e2-cea685941ad6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_PLAYER_LIST	PlayerList	26e5919a-38e2-430f-9521-dbeac346076c	null	{"name": "[REDACTED]"}	\N	2026-05-22 15:54:52.614269+00	\N
7dbe52b6-a99b-4cd0-8989-e7b04a1c9794	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:12.602025+00	\N
efa29544-26c2-4ed4-b4c1-76a9ad74f94f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DELETE_PLAYER_LIST	PlayerList	26e5919a-38e2-430f-9521-dbeac346076c	{"name": "[REDACTED]"}	null	\N	2026-05-22 15:54:52.822125+00	\N
d43c6411-99e7-4a3c-8118-8e6dded7f034	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:53.339296+00	\N
48a31801-0356-4899-8104-0e50ef8e1550	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_PLAYER_LIST	PlayerList	6f98f87e-a923-4cf8-9cbc-3978e1f24daf	null	{"name": "[REDACTED]"}	\N	2026-05-22 15:54:53.387412+00	\N
1d61dfd5-5550-439b-b8c9-c55af42fe378	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 15:54:53.865777+00	\N
eb730eff-8523-42a4-b569-aaa1debbbc4a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DELETE_PLAYER_LIST	PlayerList	6f98f87e-a923-4cf8-9cbc-3978e1f24daf	{"name": "[REDACTED]"}	null	\N	2026-05-22 15:54:53.922203+00	\N
97a0a310-8a61-44bc-87c9-1d5ecfce9d0c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:55.224682+00	\N
a3585ea2-4647-4086-9d24-28a78fa0dd0c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:55.988062+00	\N
d9b67d44-8449-46de-9feb-3406bd546b25	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:15.289968+00	\N
051e7f25-3581-4819-be2d-ee8577ec37ab	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:56.596098+00	\N
109fdc61-07ca-4b9c-bef6-d76db450e5bc	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 15:54:57.101466+00	\N
be7c9855-8cd8-475d-b54e-4aca183c5b5f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN_FAILED	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:15.339487+00	\N
12d17cf2-271d-4c40-a2d4-dbbeb5ba71fa	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:58.672951+00	\N
f89eb942-d606-4bb4-9ebf-f8bb661aebb7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN_FAILED	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:54:58.932544+00	\N
ce80ba54-0913-4877-a3ef-dbce6c3fa7ea	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:55:00.017708+00	\N
3a2c6693-550f-4176-9a03-6ff5bf647ede	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	TRIAGE	Alert	4ab2f20e-a686-4195-868f-4d58751c20eb	null	{"note": "Triagem automática via teste de integração", "disposition": "IN_REVIEW"}	\N	2026-05-22 16:02:20.703457+00	\N
a3bde593-0df9-4545-881f-f3006fd3616e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	2011aa14-cf71-48a7-bb77-9965d1a4f382	null	{"title": "Caso de Teste d7a3ba", "severity": "HIGH", "player_id": null, "description": "Criado por teste de integração automatizado"}	\N	2026-05-22 16:02:20.92864+00	\N
9ad22753-ec8f-48cb-a3d6-ede3723ca16c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	0d802281-da37-43c1-91b8-aba355578826	null	{"title": "Caso Link Test", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 16:02:21.157133+00	\N
e980368c-693b-445f-972d-ba0d0767190f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	TRIAGE	Alert	efd29b69-2355-4637-8f52-b685eaafc776	null	{"note": "Triagem automática via teste de integração", "disposition": "IN_REVIEW"}	\N	2026-05-22 15:55:04.662993+00	\N
671ad69a-e5a8-4147-a369-f9fcfd5a5169	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	b1bb9d65-20d1-471a-ab04-6dcc4391ab13	null	{"title": "Caso de Teste c19554", "severity": "HIGH", "player_id": null, "description": "Criado por teste de integração automatizado"}	\N	2026-05-22 15:55:05.452669+00	\N
a10b16b7-572a-443e-80b5-9d2b7c184726	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	0dfbce2e-f6f3-4616-95a8-1be4a8780064	null	{"title": "Caso para Fetch", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:55:05.778279+00	\N
408f0968-6181-4774-801b-6d38be0e88a8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	688ad55f-fba1-435e-b491-16e933d1f2ff	null	{"title": "Caso Link Test", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:55:05.925499+00	\N
59f9ecf6-f12f-4d4a-b2e2-16265b36dfa2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LINK_CASE	Alert	4ab2f20e-a686-4195-868f-4d58751c20eb	null	{"case_id": "688ad55f-fba1-435e-b491-16e933d1f2ff"}	\N	2026-05-22 15:55:06.054839+00	\N
55578125-ef71-439b-a768-12e992d17a1f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	RuleDefinition	9673cf76-936c-4998-a009-d30c29a4ee3e	null	{"name": "[REDACTED]", "scope": "TRANSACTION", "params": {}, "status": "ACTIVE", "weight": 0.5, "severity": "HIGH", "description": null, "condition_dsl": "transaction.amount > 9000 and transaction.type == 'DEPOSIT'"}	\N	2026-05-22 15:55:06.188971+00	\N
547a652f-edf2-43dc-8199-bc785722c7d4	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	CREATE	Case	3a0d1009-f022-4655-9868-fc9d81ac45bb	null	{"title": "Caso Tenant B", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 16:02:22.347457+00	\N
a463e553-ce6b-4637-aef5-8b2aece93a53	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 15:55:07.554316+00	\N
379ef34b-18fb-4132-a872-9706bdcc5fc0	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	CREATE	Case	600c72a0-c4d5-44ee-adc8-9bf7845c088b	null	{"title": "Caso Tenant B", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:55:07.68514+00	\N
53d1f1d1-8f67-4da9-b911-513a7d6b76df	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE_API_KEY	ApiKey	39d01f74-9314-44fd-a440-4bf725e902fc	\N	{"name": "test-key-integration", "permissions": ["ingest"], "source_system": null, "expires_in_days": null}	\N	2026-05-22 15:55:07.903108+00	\N
49a24c86-15ed-48d9-8fae-2d366f731315	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	REVOKE_API_KEY	ApiKey	39d01f74-9314-44fd-a440-4bf725e902fc	\N	{}	\N	2026-05-22 15:55:07.591937+00	\N
ed1b5f16-83da-42ea-a08f-580ce2f47100	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	REVOKE_API_KEY	ApiKey	d1523547-6b60-4f86-9382-30b59d8e3779	\N	{}	\N	2026-05-22 16:02:22.650161+00	\N
0e5ead1b-925a-473e-8a1d-1671cf309f86	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	LOGIN	User	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	null	null	172.18.0.19	2026-05-22 16:02:35.539562+00	\N
81069330-db1f-40b7-8b8e-01a25d690ea5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	233a5b9e-1d89-493c-9b94-9d96c59991d7	null	{"title": "Caso COAF Test ee05dd", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:55:38.350196+00	\N
40f931bc-c36e-4a27-a396-f840212902ce	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	233a5b9e-1d89-493c-9b94-9d96c59991d7	null	{"decision": "PENDING", "report_id": "301e1bb9-4281-4f8e-8fae-de463552b9ab", "pdf_sha256": "3a3b74920210375dcfd93cf2f23541c1fc220e1dbff12329555e5c0c4d04827f", "payload_sha256": "99bac121a89366220376ee2a6c8d97fd36f3ae258aefa0deaef1528775bbcc31"}	\N	2026-05-22 15:55:38.453515+00	\N
a43db778-94b5-4d16-92b8-e4830148113a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	6c6d0df9-0f51-4bc5-84f4-53c16bf788e9	null	{"title": "Caso SAR 8d4939", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:55:38.637594+00	\N
7b6d2894-20e9-4d25-b75a-2ee73d7cd57e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	6c6d0df9-0f51-4bc5-84f4-53c16bf788e9	null	{"decision": "FILE_SAR", "report_id": "d911f74c-2d62-4aba-8d48-1eb7e71cf020", "pdf_sha256": "1f13d9911a282ab467aa38bb42829f1d4faa248775627474ac7862c2255d5f7e", "payload_sha256": "d980c87b75a014de75ad6565eb77119f5f58f462ba40cf0e58b361b17ad300e2"}	\N	2026-05-22 15:55:38.731712+00	\N
f8e79862-8624-47d7-99a8-3c089daf388f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	914fdfca-3a89-41ae-a99a-815007cad049	null	{"title": "Caso SAR sem narrativa 8a5be0", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:55:38.897731+00	\N
bf53af2e-f9fd-4f1f-bb24-7479d9268e2a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	3b1515c5-de8b-420d-9e89-7a01bfb8a3de	null	{"title": "Caso CPF Mask Test", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:55:39.052398+00	\N
d009a9a3-e8cf-4da3-b3b1-c767de49c280	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	3b1515c5-de8b-420d-9e89-7a01bfb8a3de	null	{"decision": "PENDING", "report_id": "1f8f4810-012e-4539-8ec1-bcf9b84e994c", "pdf_sha256": "46c8f7880d331e627965bdf190112e41ec2efadf8161ae3adc9eeea7e8c8e67d", "payload_sha256": "339d0e59afbf0140c8ea77b200f370276ae581b9d8d5a77201231aace915ba59"}	\N	2026-05-22 15:55:39.1348+00	\N
06a91696-608e-4ac0-b2b8-e0963208a034	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:55:39.671574+00	\N
189e4427-ee3d-4104-a4a1-163bc0181771	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGOUT	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	\N	2026-05-22 15:55:39.747217+00	\N
b23e80e5-8e5e-464d-a74a-19f361178487	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:55:40.361938+00	\N
42737043-8792-486d-a0cb-7affafe3f40d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:55:40.948517+00	\N
e14cd516-928c-49bf-ab71-4806741c7bfd	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	f22ee9d6-f2bd-42bf-9a16-01fa36424384	null	{"title": "Caso Audit Test", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 15:55:41.091622+00	\N
3e7d1165-3310-468a-9216-a7b3197b16be	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	f22ee9d6-f2bd-42bf-9a16-01fa36424384	null	{"decision": "PENDING", "report_id": "d557a2ff-c9e5-4279-ad12-49a471009e3c", "pdf_sha256": "170807b5d3f9ff2788ae3a198d8c068bd3e18f21938d17fa34aa10119e46ab8f", "payload_sha256": "82b060af3c37d6dcbef678db025d0e38210844221753699dac1c6092fca3a2ec"}	\N	2026-05-22 15:55:41.190768+00	\N
f2945bb4-a912-47bf-b626-6f9dffbe662c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 15:55:41.855161+00	\N
126bc13d-bfb0-4575-98c0-8ded60718ab7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	11dc8f67-7311-4647-85f0-8117406bc5d6	null	{"title": "Caso COAF Test dffd7c", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 16:02:49.148235+00	\N
3a044247-2fdf-454e-a666-a1241d6d7931	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	11dc8f67-7311-4647-85f0-8117406bc5d6	null	{"decision": "PENDING", "report_id": "d0cc410b-bc42-4e11-bc9e-ac757670e85e", "pdf_sha256": "0276d62d12d56c2041f7648d2a0fda5eed55df6821cb49a80b8d867feb253bc8", "payload_sha256": "ee4ce66e56bc8e50c1b1b482008cc98d41676360c5a3af93130859ace2c52cf8"}	\N	2026-05-22 16:02:49.221437+00	\N
37dbf616-654d-4b33-80d3-cd7972863a54	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	CREATE	Case	fe0b2cc2-7c06-4f51-b807-afa4dedcd70a	null	{"title": "Caso SAR sem narrativa 4dbc0f", "severity": "HIGH", "player_id": null, "description": null}	\N	2026-05-22 16:02:49.594688+00	\N
c4e84170-b4f6-49d7-a82c-5f3463f0f17f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGOUT	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	\N	2026-05-22 16:02:50.358878+00	\N
106a3bae-344a-4796-bcd4-d03e3d101d59	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:50.800453+00	\N
80cc25b1-6e55-4ddd-b133-b804e58b60ac	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:51.182652+00	\N
87879805-b6af-4062-a368-a8210b2fa532	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:02:51.882597+00	\N
e8780a82-edf9-4ca8-adb1-1b4081625aae	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	CREATE_TENANT	Tenant	08589c68-4b20-4484-a1d7-86ff73a084e4	\N	{"slug": "test-slug-07c07e77", "admin_username": "u_test-s"}	\N	2026-05-22 16:02:55.625658+00	\N
0a7d34cb-96da-4463-a67d-dc57c4b2b2c1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:03:07.736848+00	\N
c4fc0d70-e94c-4a82-8d73-c4a439960d01	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	510078bd-3aab-411d-97f9-e22b883da667	null	{"decision": "FILE_SAR", "report_id": "49913c05-90e6-4550-b6cd-33cd2ff094a4", "pdf_sha256": "061d2c33bcf75df8f6c3c0bab536e598f350cb18e96467825ed91115169af470", "payload_sha256": "f686a10f6943e5f2c265a231dbe79e7383a7b7b7ed9a1727613b18f9eda591a9"}	\N	2026-05-22 16:03:07.809572+00	\N
c332a49a-db1e-4902-b4f3-4345e504cc0d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	DOWNLOAD_COAF_XML	Case	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	null	null	\N	2026-05-22 16:03:08.556113+00	\N
f86741f5-7d75-490e-8e90-22bea4ffa579	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:03:09.012704+00	\N
a83a1d80-6d63-42e4-abb0-198c610d6320	98c56b0f-fa44-47cd-a8d9-9479174e3140	89a78d77-d61e-44d1-916c-c9fda278d0e9	LOGIN	User	89a78d77-d61e-44d1-916c-c9fda278d0e9	null	null	172.18.0.1	2026-05-22 16:03:09.396499+00	\N
0c8c7465-8fa0-48db-a3dc-71b1aa14f1a8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	LOGIN	User	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	null	null	172.18.0.19	2026-05-22 16:09:31.573968+00	\N
d06f31f1-e514-470b-a345-a5f8deafff87	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.19	2026-05-22 16:09:39.290907+00	\N
43325419-cda4-4ae1-ba2b-805f5eeabfd0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.19	2026-05-22 16:10:32.052665+00	\N
fc5657bc-0e32-40f8-b292-37d30f1260d6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.19	2026-05-22 16:15:00.27676+00	\N
9156f8d4-792f-40f5-807e-1197dd7aff1f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	EXPORT_REPORT_JSON	ReportPackage	afdff049-8919-40b1-99d2-95cdd31d98b6	null	null	\N	2026-05-22 16:03:07.897484+00	\N
0cd50771-d0c5-4bfa-947c-267cb9658776	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.1	2026-05-22 16:03:08.39481+00	\N
97b89183-e040-4aa0-bd33-82174a999ea1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	GENERATE_REPORT	Case	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	null	{"decision": "FILE_SAR", "report_id": "0fb773aa-f428-466e-aac5-697e35372170", "pdf_sha256": "5f626dd38ae79dd7bd49daeaa54ddd069846a744ec9e7ede3a541c755feedc1f", "payload_sha256": "e34eadc120ef1c5830bcc42d61e5384edc5c0b9560eb454c812bc9c2a73c2d12"}	\N	2026-05-22 16:03:08.450139+00	\N
efca172e-300f-467d-ab79-9c1d8c6babd2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.19	2026-05-22 16:15:37.463902+00	\N
559ca859-0cb5-4258-b2a8-68cbad12caf1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 17:21:32.835144+00	\N
4e65fc01-e6e3-4ff5-a93d-389fd70dd5b2	98c56b0f-fa44-47cd-a8d9-9479174e3140	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	LOGIN	User	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	null	null	172.18.0.1	2026-05-22 17:21:33.508002+00	\N
0996b54c-145d-4f75-ac5b-7715254719af	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	LOGIN	User	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	null	null	172.18.0.1	2026-05-22 17:21:38.439659+00	\N
78c09753-0991-4731-9268-1df2e4a91169	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	CREATE_TENANT	Tenant	b10f6774-339e-46ed-8385-8af37cac6b2e	\N	{"slug": "test-slug-826bbc1e", "admin_username": "u_test-s"}	\N	2026-05-22 17:21:38.492062+00	\N
3a9cd2ce-9755-4b07-b877-685faf429736	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.19	2026-05-22 19:34:04.969557+00	\N
f8bbca00-c91a-4d79-bcc8-723b23536ef8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a59dcbec-90f2-4427-bd34-c2359850fb9d	LOGIN	User	a59dcbec-90f2-4427-bd34-c2359850fb9d	null	null	172.18.0.19	2026-05-22 19:35:03.114166+00	\N
f3be6aae-8612-495e-8956-6b395fb66ffa	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 19:35:34.293516+00	\N
00e2f94f-14d8-4348-ac3f-9fd9b294af79	98c56b0f-fa44-47cd-a8d9-9479174e3140	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	LOGIN	User	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	null	null	172.18.0.1	2026-05-22 19:35:35.106055+00	\N
aa3452ee-163d-4334-82ed-3af62fd27ca8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	LOGIN	User	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	null	null	172.18.0.1	2026-05-22 19:35:40.072054+00	\N
89002b73-b002-4bf1-bc00-2035a59d8287	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	CREATE_TENANT	Tenant	9423e928-b354-4b58-a26d-6ea1cad11f37	\N	{"slug": "test-slug-4a2d7f63", "admin_username": "u_test-s"}	\N	2026-05-22 19:35:40.133825+00	\N
dafd3dd9-3cb7-4a65-a560-987fdce7244c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	47b184c7-360c-41ac-8676-f52b54c5e4a8	LOGIN	User	47b184c7-360c-41ac-8676-f52b54c5e4a8	null	null	172.18.0.1	2026-05-22 19:38:03.496608+00	\N
b8551f8e-320b-493a-8dc6-daa674d76b20	98c56b0f-fa44-47cd-a8d9-9479174e3140	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	LOGIN	User	82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	null	null	172.18.0.1	2026-05-22 19:38:05.326869+00	\N
213819e7-6a00-424d-9dfa-dbc241a2af18	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	LOGIN	User	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	null	null	172.18.0.1	2026-05-22 19:38:12.386481+00	\N
dcc7e775-f09e-4b5f-bb13-b0691a5b5029	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	CREATE_TENANT	Tenant	f19e18c1-272d-48bb-9c61-5dd767ffc99d	\N	{"slug": "test-slug-ab4204aa", "admin_username": "u_test-s"}	\N	2026-05-22 19:38:12.90199+00	\N
\.


--
-- Data for Name: bets; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.bets (id, tenant_id, player_id, external_bet_id, source_system, bet_type, stake_amount, potential_payout, actual_payout, odds, currency, status, event_name, market_name, selection_name, source_event_id, ingest_job_id, raw_payload, occurred_at, settled_at, created_at, product_type, game_id, game_name, game_provider, game_category, rtp_teorico) FROM stdin;
\.


--
-- Data for Name: case_events; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.case_events (id, case_id, tenant_id, event_type, content, created_by, created_at) FROM stdin;
ae42edb6-9bae-4faa-86e9-818ed3610c6a	84bd3a0e-e274-45ec-aedd-491722778caa	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	NOTE	{"note": "Caso criado automaticamente por alta severidade e anomaly_score > 0.9"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-19 23:57:44.872891+00
33db95da-3364-46be-b4d1-22299fd78255	85596b71-cf3b-4eb5-a2d3-5e50ef34b018	98c56b0f-fa44-47cd-a8d9-9479174e3140	NOTE	{"note": "Caso criado automaticamente por alta severidade e anomaly_score > 0.9"}	89a78d77-d61e-44d1-916c-c9fda278d0e9	2026-05-19 23:57:44.872891+00
2a58b160-ec3a-46fa-ab0c-c842dbef4c98	2c953fd3-0c49-4d47-a956-4038ec338b9d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:22.059132+00
58e8ce03-0460-409d-af54-64eab5496ce1	2c953fd3-0c49-4d47-a956-4038ec338b9d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:22.191056+00
ec2d5af9-a3dd-4f67-84dd-f7f73fa1ac6a	2c953fd3-0c49-4d47-a956-4038ec338b9d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:22.285746+00
f9216a82-5170-4f94-bf74-227bb75506fe	e377d705-472f-4060-b62b-17963b5c48cc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:31.351849+00
1527e99a-25a3-4c3d-b011-16d339383ab2	e377d705-472f-4060-b62b-17963b5c48cc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:31.409466+00
6ec26c6a-6458-4449-9d3f-b9a89c0ff391	e377d705-472f-4060-b62b-17963b5c48cc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:31.489159+00
14c178d7-6ecc-408b-9a2d-efc1df21f44b	f0818532-66b1-471c-9902-4d8f359c1d26	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:37.867516+00
c0651116-552b-42bf-88bf-833f3e727a46	f0818532-66b1-471c-9902-4d8f359c1d26	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:37.958859+00
97ea9c69-3bc4-4250-b181-1ecbc52acfbd	f0818532-66b1-471c-9902-4d8f359c1d26	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:38.018299+00
65296542-5893-4f94-a16d-f9cbca5f0a1a	ab6ef6d1-6c92-4989-9f8c-5d6aaf90cf15	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:43.432497+00
4f61b24a-848b-4fce-9594-19ccfdfd93d4	ab6ef6d1-6c92-4989-9f8c-5d6aaf90cf15	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:43.50319+00
07bdb0e1-338d-4791-9cd0-e513ec8e6910	ab6ef6d1-6c92-4989-9f8c-5d6aaf90cf15	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:43.566404+00
afdfd599-7676-460d-a64e-1da65c697807	a6d4286f-e75c-4ff3-b6b6-ac1b626b7030	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:50.241048+00
dfc69a8e-7754-4ad9-8cb9-09e956f5da47	a6d4286f-e75c-4ff3-b6b6-ac1b626b7030	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:50.295881+00
2b7459a2-06a9-4a1b-a43e-68a74c73eb57	a6d4286f-e75c-4ff3-b6b6-ac1b626b7030	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:50.384589+00
8c7cf898-de2c-4c70-82d9-6557e76f1eaa	032940ff-c161-4765-a4bd-65a41bb7f0db	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:59:03.227676+00
4d332401-83e2-4662-89ac-d620c5feec16	032940ff-c161-4765-a4bd-65a41bb7f0db	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:59:03.295078+00
04961d2a-b18b-4182-b3e1-844bfe328dc8	032940ff-c161-4765-a4bd-65a41bb7f0db	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:59:03.365636+00
6153bd69-fbff-41ca-9100-18d64d33a8a1	eb453a94-9f9a-442b-be31-2b886c4ba711	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:59:15.509399+00
910cb482-6080-46ba-b791-060b864f4d00	eb453a94-9f9a-442b-be31-2b886c4ba711	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:59:15.593396+00
d3969ac8-d7c2-43ec-8f18-8415a01f2d19	eb453a94-9f9a-442b-be31-2b886c4ba711	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:59:15.668782+00
9115b188-1117-4e86-9df6-38d3687978ec	e21505cc-cb01-4958-a794-e6f59fbe8ee6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:59:26.347495+00
75482be0-168d-49fe-ada6-e731ddb81dce	e21505cc-cb01-4958-a794-e6f59fbe8ee6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:59:26.424256+00
76be54a5-5f0c-4d81-8f73-40c7eaff1a8a	e21505cc-cb01-4958-a794-e6f59fbe8ee6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:59:26.493701+00
802f0604-93b9-49c2-8a23-da78f0bb9d3d	e21867bf-2495-4371-8cdd-0f46d083bb6e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:46.300577+00
8346c5ce-12f0-4114-a477-8a4f766b75a9	e21505cc-cb01-4958-a794-e6f59fbe8ee6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "NO_ACTION", "report_id": "1fb9e889-23d6-4f03-979d-85784d55899c", "pdf_sha256": "0c5cc0524595644bd87b893c95258836510dcb14d0b9976646086fc3a35ca586", "payload_sha256": "527172fbae72b5c53ac6a8b524e307f91e77a86eb5a6c1fb553754fed2d0a9d2", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:12:00.048497+00
b73accfb-9d5a-4a86-8236-629ae69d903d	f0fe6296-60e6-439d-a7a5-bcacc4239d18	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:26.859759+00
877b575a-c411-4e50-9f62-9c5bbcfd5133	f0fe6296-60e6-439d-a7a5-bcacc4239d18	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:26.941374+00
c1f003aa-277c-404d-a2b8-192428d13458	f0fe6296-60e6-439d-a7a5-bcacc4239d18	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:27.082596+00
f065eff1-2d4e-409e-a558-7ed4d147f4eb	f0fe6296-60e6-439d-a7a5-bcacc4239d18	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "29da91f3-aa9e-4782-af6e-85e79db28325", "pdf_sha256": "3c859a9d5fbe4b4c2abd5f4f04a0a370a55e9d74736987f865c7c1b672b7e97f", "payload_sha256": "46185c7dfad933d90252575fdef012b1ec202cbc09a33355ca73ea69ac3ea484", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:27.175562+00
b0ff98ab-184c-4927-8df4-555ddc86ce77	f0fe6296-60e6-439d-a7a5-bcacc4239d18	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/f0fe6296-60e6-439d-a7a5-bcacc4239d18/coaf-ca82e2ae-02e1-4c0d-898f-c6540fac9951.xml", "xml_sha256": "c7a7746e7057110aebf6b642b48032beed432bfa4f1d6b86e1d81203ad7bdad5", "case_status": "REPORTED", "tracking_id": "4380a3a9-a651-45ca-9bf2-78f2b71958de", "submitted_at": "2026-05-20T00:13:27.477916+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "46185c7dfad933d90252575fdef012b1ec202cbc09a33355ca73ea69ac3ea484", "report_package_id": "ca82e2ae-02e1-4c0d-898f-c6540fac9951"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:13:27.441445+00
b9ec94e2-785e-48ac-8ced-844fb04de2ae	20307f11-535c-46e4-a4d9-8d7090bd954c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:29.380753+00
031000b3-04ba-404f-a619-56b5fedee066	20307f11-535c-46e4-a4d9-8d7090bd954c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:29.44861+00
0fc4afd8-9dc3-4672-ba42-2f8935ff25f0	20307f11-535c-46e4-a4d9-8d7090bd954c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:29.518091+00
5c52f9ce-2649-457c-81eb-d5374a00aea3	20307f11-535c-46e4-a4d9-8d7090bd954c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "84950925-d4a7-4ce8-960d-fcb7961ca7d2", "pdf_sha256": "a593766d22af4a0ff769c2675fed0dc89268030f7fb16137466bf9e431734838", "payload_sha256": "419e701cc1225ce8537d68d3539276056760e935b1c248915e75fb0dcdc82bf4", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:29.587441+00
b1a5a2dc-b0b1-41c0-86dc-634e07ec17db	20307f11-535c-46e4-a4d9-8d7090bd954c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/20307f11-535c-46e4-a4d9-8d7090bd954c/coaf-1e764da9-9396-4d9a-a397-ca28426ee889.xml", "xml_sha256": "dc9ece06964d32a5696e00e2f43b064d602e31264e24cfda6648933292148c37", "case_status": "REPORTED", "tracking_id": "676ab896-5c77-47b8-b3fe-8bd09272e312", "submitted_at": "2026-05-20T00:13:29.758934+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "419e701cc1225ce8537d68d3539276056760e935b1c248915e75fb0dcdc82bf4", "report_package_id": "1e764da9-9396-4d9a-a397-ca28426ee889"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:13:29.743887+00
abf7a62f-8c29-4359-8dd5-954a70cc4619	607d3d6d-e568-4a39-ba6e-d1aa19db91b3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:31.757431+00
830f4dcc-d82d-4455-948a-d719cea63373	607d3d6d-e568-4a39-ba6e-d1aa19db91b3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:31.833163+00
a4b6fa7d-aeee-4bd5-874f-0002df5f4029	607d3d6d-e568-4a39-ba6e-d1aa19db91b3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:31.898232+00
cb189f8e-e72d-4b74-adbc-2bddb12890f6	607d3d6d-e568-4a39-ba6e-d1aa19db91b3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "deb2093c-6e95-435e-a377-dc48385d1f11", "pdf_sha256": "747bd7b854d7182cb2c2439741ae5f394a561505d30d7d13ab46468a5326d633", "payload_sha256": "653c9eef2362d024307e5af2388182469482493ac5febca14f4b1d6622bdb930", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:32.018197+00
dc857483-b423-4e2d-98df-193a6abd953f	607d3d6d-e568-4a39-ba6e-d1aa19db91b3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/607d3d6d-e568-4a39-ba6e-d1aa19db91b3/coaf-7162e1bb-e010-456b-9b73-dbebad25f33c.xml", "xml_sha256": "cf6af3f82ea3ff656a6aa9590e379a5098584cad9a5c740ec9f7778799f67ec8", "case_status": "REPORTED", "tracking_id": "bbd96d69-8d5c-45f9-9a6f-299a4ee90e24", "submitted_at": "2026-05-20T00:13:32.203875+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "653c9eef2362d024307e5af2388182469482493ac5febca14f4b1d6622bdb930", "report_package_id": "7162e1bb-e010-456b-9b73-dbebad25f33c"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:13:32.184389+00
5f6d909f-52e5-4ced-84ed-b9c4f03cc996	e94f825a-af60-4a71-9eac-f4673f07b720	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:33.357237+00
ff475bf8-f6ce-4855-b6e6-7ccad6632b0a	e94f825a-af60-4a71-9eac-f4673f07b720	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:33.437399+00
18860930-20e4-4488-bc54-3ecab1f9f9a6	e94f825a-af60-4a71-9eac-f4673f07b720	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:33.517274+00
fabfa270-e13f-4ae9-9b13-4fbaf6d088cc	e94f825a-af60-4a71-9eac-f4673f07b720	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "bd25c805-ed5a-4d7b-9998-1896c6eb17cf", "pdf_sha256": "c16768d9a6541c81ca25f8ffce1d670ff0b4fca63c8df6158fa9a6cac677139b", "payload_sha256": "a63941f692089a7dd4f18dcb78583b714119c46d2e1d747eeae9fb6dde049f7a", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:33.607385+00
b523159d-c6bc-4dfd-a24c-fbad5adb0a92	edefa731-72fc-4b4c-bb96-8cb786eb3433	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:35.935207+00
2de942ce-4f44-4e20-a4d2-0b0f6dac3bf2	edefa731-72fc-4b4c-bb96-8cb786eb3433	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:36.028566+00
541dab2b-97fd-4d99-b333-fe55ea149b95	edefa731-72fc-4b4c-bb96-8cb786eb3433	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:36.102075+00
66d9ed5f-929d-4ca7-ade7-7fb34dc4d9f5	edefa731-72fc-4b4c-bb96-8cb786eb3433	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "e42b7db9-6b36-49d0-8834-5d7d0d79e793", "pdf_sha256": "cd04d5875237f78054a9637874ff56196c475c905fbf47aee9835eed0d9bed2d", "payload_sha256": "bd424b0f8fb7fe52047204e335ad85615d90a6645917ed1355595adbc4de7ce0", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:36.186931+00
d32f9f3b-1b81-4845-8a98-8ac7fd2995d8	edefa731-72fc-4b4c-bb96-8cb786eb3433	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/edefa731-72fc-4b4c-bb96-8cb786eb3433/coaf-528299eb-e916-4875-935e-fb42ef1338fb.xml", "xml_sha256": "0c00c6a92b5fb44c28fc9e516b05ca13d18ee1265913ae048538a5f919db31e1", "case_status": "REPORTED", "tracking_id": "23d67982-35e2-4b87-977d-21c021feb5cb", "submitted_at": "2026-05-20T00:13:36.384103+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "bd424b0f8fb7fe52047204e335ad85615d90a6645917ed1355595adbc4de7ce0", "report_package_id": "528299eb-e916-4875-935e-fb42ef1338fb"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:13:36.35955+00
31605b06-ce36-459c-ae20-a064cb5d5eee	e21867bf-2495-4371-8cdd-0f46d083bb6e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:46.162418+00
479df775-c588-465d-8afd-cf412228de65	e21867bf-2495-4371-8cdd-0f46d083bb6e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:46.228326+00
b2e293fb-449b-4195-8648-1922bcd62f26	e21867bf-2495-4371-8cdd-0f46d083bb6e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "3cbd33a4-ce30-4d68-bf3e-4654404d985f", "pdf_sha256": "ef266b2a19d47fe437303a915e80195a0dc7b8ea1297d931ab7627fc472f7788", "payload_sha256": "ad4c757c4f9e9e990176d869d62b4c46ea26d4c4f9b4f449bd91d26d92aeee6c", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:46.380863+00
24587a54-6911-4eba-b9b1-731787739841	e21867bf-2495-4371-8cdd-0f46d083bb6e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/e21867bf-2495-4371-8cdd-0f46d083bb6e/coaf-2395e07b-e648-4cd5-82ab-7779d8cec89f.xml", "xml_sha256": "c7f24d9ab8622a75d0234f4a0b2bf606e46c48aac4621f2e6f1b3969f64df648", "case_status": "REPORTED", "tracking_id": "79cd4348-d869-456c-85fa-097a4a8e5238", "submitted_at": "2026-05-20T00:13:46.565330+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "ad4c757c4f9e9e990176d869d62b4c46ea26d4c4f9b4f449bd91d26d92aeee6c", "report_package_id": "2395e07b-e648-4cd5-82ab-7779d8cec89f"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:13:46.549532+00
d6099ee7-998e-42f0-a6a4-b658091702a4	a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:14:32.991246+00
00faca8a-03cc-4afa-8927-6ff10b40d443	a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:14:33.153851+00
a1e1304d-9035-46a5-83ab-1e7e2a68416a	a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:14:33.270035+00
aa28bbeb-b83c-4f10-bc02-634bf849bcde	a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "aaf163a5-8417-4c14-8474-2a1c3919aaf5", "pdf_sha256": "1d0e542535c36584428cb65540011ee2907f91218d5673bf4fd4578c06208a13", "payload_sha256": "5c3d56c7c880ef14bc1b7ff21ac1816f289307fd5c0052704fba58cbe1a6f74d", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:14:33.452895+00
f704fcf6-bd74-4641-b869-4d628f861e08	a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5/coaf-af990639-bcd1-47ac-8c8b-2719a24e6ac1.xml", "xml_sha256": "516bb1942d72ade3d3b26aeb96860da8dc2a5a84a1c891979e876f02e8809147", "case_status": "REPORTED", "tracking_id": "bb8ec76e-5dbe-4122-8b79-bd6006bd1162", "submitted_at": "2026-05-20T00:14:33.752839+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "5c3d56c7c880ef14bc1b7ff21ac1816f289307fd5c0052704fba58cbe1a6f74d", "report_package_id": "af990639-bcd1-47ac-8c8b-2719a24e6ac1"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:14:33.720627+00
e35fbcdf-f70b-48a4-a629-94b97205c583	97cb2b12-475b-4596-995c-73eb62f51ba4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:15:14.884618+00
d76b98a0-30fb-4c90-871f-993414a41310	97cb2b12-475b-4596-995c-73eb62f51ba4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:15:15.009459+00
83fbebb3-7c0d-4a37-86be-486fb44a5d12	97cb2b12-475b-4596-995c-73eb62f51ba4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:15:15.181741+00
03b02224-ae93-4134-8fd4-7a3bd105bc53	97cb2b12-475b-4596-995c-73eb62f51ba4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "d3772679-a33c-4250-a0ed-f0a195120a15", "pdf_sha256": "979e9e46bb53c3c4f2c3611bc4b88a5c1adea80d26d4ef4768b8139a3e435452", "payload_sha256": "7cd2505248296d0e88eb61cb35453051693de748e594cc4ce1e95d8a6d39a7d6", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:15:15.262066+00
a492fbd6-d6aa-4012-8617-e0951ebfdab1	97cb2b12-475b-4596-995c-73eb62f51ba4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/97cb2b12-475b-4596-995c-73eb62f51ba4/coaf-4b84fda5-b796-4aa6-ac4c-fcb2622e615e.xml", "xml_sha256": "d03c8ae58b74957495763bbf4ccc6d223ab65474ed4482741177fb182a1832e8", "case_status": "REPORTED", "tracking_id": "99cd79f3-de85-4a62-8f72-b401f8e92f55", "submitted_at": "2026-05-20T00:15:15.593838+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "7cd2505248296d0e88eb61cb35453051693de748e594cc4ce1e95d8a6d39a7d6", "report_package_id": "4b84fda5-b796-4aa6-ac4c-fcb2622e615e"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:15:15.567323+00
eaa48c10-d065-437b-b024-dbc6e75c83ed	cdef2fe6-dea8-4b0f-b76f-948d085e810f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:50.886103+00
36263ab5-34ba-4c8b-a3c5-d19345c9004d	cdef2fe6-dea8-4b0f-b76f-948d085e810f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:50.996605+00
0c791c37-42c6-4329-af30-f65b4b62ab5d	cdef2fe6-dea8-4b0f-b76f-948d085e810f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:51.072989+00
05d89306-a704-44da-aa46-3eb49538cc04	cdef2fe6-dea8-4b0f-b76f-948d085e810f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "1874f73d-c44c-4434-a86c-49ed8d0f927d", "pdf_sha256": "a949f23285f55d5b50099356bcac9d981a54527a7b88ea7257cb7e5833f5eb3a", "payload_sha256": "f8f7373a019d5519c368dca8b7c4c46a040e67c2d8b9cd30ed64d42fb5ea3e13", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:51.148951+00
7e2c6b21-6574-4b67-af70-74c0f96281af	cdef2fe6-dea8-4b0f-b76f-948d085e810f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/cdef2fe6-dea8-4b0f-b76f-948d085e810f/coaf-b30cf1c1-b049-4e85-bf83-d21067594b51.xml", "xml_sha256": "91113dca14f93ce58d0a13817b323b5c87727fc94f21e1a6dc4f39f9797d46cc", "case_status": "REPORTED", "tracking_id": "490b93df-6b2e-4d44-83c3-083678a42d8e", "submitted_at": "2026-05-20T00:19:51.684260+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "f8f7373a019d5519c368dca8b7c4c46a040e67c2d8b9cd30ed64d42fb5ea3e13", "report_package_id": "b30cf1c1-b049-4e85-bf83-d21067594b51"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:19:51.6504+00
5356d42b-83a9-45cd-a337-bd22bbb6c634	898955fd-f537-4a4a-9cc3-e490d5f343b5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:53.546892+00
f6ca2b87-f171-4af1-a635-7c784b0fe433	898955fd-f537-4a4a-9cc3-e490d5f343b5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:53.62998+00
e6b7f9eb-c9f7-459a-9525-ac33b2dfca5d	898955fd-f537-4a4a-9cc3-e490d5f343b5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:53.704904+00
a91d8a04-94da-4848-93d6-0f442412990c	898955fd-f537-4a4a-9cc3-e490d5f343b5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "186db93f-4e0b-4200-ac83-40e6b7528116", "pdf_sha256": "f44e5a22691b920732809159ed2c44c87c198ec78acea836c1663d38186450a2", "payload_sha256": "5f7cd05a2fc57e448dace0a49f21330da29d7458e4126f00d61ef9ee229f1e37", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:53.7989+00
7dd33724-355c-407d-ba4a-fc6276657082	898955fd-f537-4a4a-9cc3-e490d5f343b5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/898955fd-f537-4a4a-9cc3-e490d5f343b5/coaf-a72577c1-e3aa-4f1f-96ed-6cd4c56119eb.xml", "xml_sha256": "8ff56664c0f2b810946dd52215263adffbf7cc53271f36a9742b8cbf3ec89ef6", "case_status": "REPORTED", "tracking_id": "8b64bf09-42da-4b6a-955d-d9500dc322c6", "submitted_at": "2026-05-20T00:19:54.088320+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "5f7cd05a2fc57e448dace0a49f21330da29d7458e4126f00d61ef9ee229f1e37", "report_package_id": "a72577c1-e3aa-4f1f-96ed-6cd4c56119eb"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:19:54.069161+00
f1a17368-f387-4e7c-a3ba-67aff35a86b7	93321cb0-c1d2-4c42-bd47-84f0d1da6bdf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:56.091513+00
28a7ea8f-09c8-4cb7-bdec-bc0ae893d995	93321cb0-c1d2-4c42-bd47-84f0d1da6bdf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:56.174683+00
4e441a07-a7db-4aa3-92ee-497aa14fa051	93321cb0-c1d2-4c42-bd47-84f0d1da6bdf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:56.231601+00
4663698e-7ab6-49b9-8668-af5d9aeba618	93321cb0-c1d2-4c42-bd47-84f0d1da6bdf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "12cc65c6-decb-4aea-ace8-a6c5a6fe9533", "pdf_sha256": "9d571811b6fa9234cedf989272424f96d96d4ec13fcc769982afe2cb9c82892a", "payload_sha256": "498412647a7549b3a2a6f325c7874d33827bcbbc07c466c3a4c291c2fde465f4", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:56.291796+00
1ca2736b-c5ca-4a2f-80ba-4f7832486636	5014b829-e438-4d15-8647-28ee47547247	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:57.393337+00
1bcae8e6-c6fd-43d6-8fa0-4e12faea4a57	5014b829-e438-4d15-8647-28ee47547247	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:57.471599+00
8d17116e-1706-4b92-9996-f2ebd420f45d	5014b829-e438-4d15-8647-28ee47547247	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:57.528351+00
120e1490-a8b3-4f18-88a7-bc389c57a95d	5014b829-e438-4d15-8647-28ee47547247	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "d8b40707-cc26-4d60-b3b2-087920615564", "pdf_sha256": "4e9350a675b8496549c0b679cfd8699df0a2c4be444d97f38a59ad4d5ea218ae", "payload_sha256": "d17223a818708de83185c3c6bda81aac245d9e76c8b9a6fa8d10199da248bcb0", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:57.592075+00
62d0bae4-bdf7-481c-b4e1-d060d4c0e32b	803539be-379f-4992-a510-c1f50278372e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/803539be-379f-4992-a510-c1f50278372e/coaf-9694ef42-b209-4c01-a091-a265c18a3c37.xml", "xml_sha256": "dd1e3b11b3f34a9a7b588547b2a7d0ec4f81982490db541a2278204397523b5a", "case_status": "REPORTED", "tracking_id": "06d41c60-8ac4-4c7c-aec5-0180117abf8e", "submitted_at": "2026-05-20T00:20:00.252513+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "99f8c460ed8eea33842f8c5fdb815ec6117a6be56d7dc8a67f94377fe2f894ce", "report_package_id": "9694ef42-b209-4c01-a091-a265c18a3c37"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:20:00.231714+00
e34ed70b-872a-4816-a557-a4dbb9611b43	95c36d67-1b75-4e86-bd3a-b317c80e50af	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:20:07.26663+00
b563d860-502f-42b9-b772-adead3bf9872	95c36d67-1b75-4e86-bd3a-b317c80e50af	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:20:07.380074+00
949da29d-4c69-4a03-9359-a29bd9dc78f8	95c36d67-1b75-4e86-bd3a-b317c80e50af	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:20:07.501992+00
0ab3f506-c816-45f1-9833-7b3973c843fa	95c36d67-1b75-4e86-bd3a-b317c80e50af	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "01487da8-2dd9-46e2-9990-0254381d86d8", "pdf_sha256": "4d8b7a931c0c52a77c155cd3317a9f732f545796366f8745fdfd8217eafd0b82", "payload_sha256": "1353c15efe511933f45ff5d5c1f980ad81af23afcc7af8b14642b3f1ecf2406e", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:20:07.599454+00
b94ab6b7-2e61-4f2f-9a92-9af10a9c1cce	95c36d67-1b75-4e86-bd3a-b317c80e50af	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/95c36d67-1b75-4e86-bd3a-b317c80e50af/coaf-a89b0764-3613-432f-b99f-9926168ff629.xml", "xml_sha256": "f8330a71e33b9404c86a65efc79034e571b675ae3204f25c4c53b7da8507c745", "case_status": "REPORTED", "tracking_id": "fe24529f-48be-4438-8a32-b518469944f0", "submitted_at": "2026-05-20T00:20:07.885992+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "1353c15efe511933f45ff5d5c1f980ad81af23afcc7af8b14642b3f1ecf2406e", "report_package_id": "a89b0764-3613-432f-b99f-9926168ff629"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:20:07.851384+00
b42bcefb-fe21-4395-b98d-8f750f531df0	d02b4133-26c3-4b85-a9da-8ac6948e3e0c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:20:51.026616+00
347b65ce-694e-4084-b437-c7af4068dfef	d02b4133-26c3-4b85-a9da-8ac6948e3e0c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:20:51.091297+00
dcf75870-6c0c-480d-bb18-bcdf4915f94e	d02b4133-26c3-4b85-a9da-8ac6948e3e0c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:20:51.149441+00
d3b575ee-9e76-4f40-9add-2754abb02f6b	d02b4133-26c3-4b85-a9da-8ac6948e3e0c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "993a85f7-c695-42eb-9abe-a1428b8e16ce", "pdf_sha256": "450cff48a76cee57327b8eaef7f310a008fce1cdd678d2ee1934df297896111b", "payload_sha256": "8972907bc34ce497d60e2af73e431cd0c7f38b5eb7fa06ac304803387582c8e6", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:20:51.275081+00
6ec49bf8-fd3c-445f-a893-a4df40aaa5fc	e69af611-da75-4fe3-8a48-a76b10f9546f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:21:30.096133+00
aa3907ca-c822-4d05-9d7a-a446c9f44aed	e69af611-da75-4fe3-8a48-a76b10f9546f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:21:30.185224+00
39c9a5fa-1640-40e7-9c2c-a0d07a57674a	e69af611-da75-4fe3-8a48-a76b10f9546f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:21:30.25165+00
d9784bbb-f9e9-4674-a85a-666cee96005b	e69af611-da75-4fe3-8a48-a76b10f9546f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "653fb266-093c-4e7a-b221-8b4b23a1efa1", "pdf_sha256": "941edae0dcd38ca9c6d343637bef621da3bc3a03b6c2b50054ee1786c801d78b", "payload_sha256": "e4ad8f7e8c81ca7d2939a241b3d1def129fb09e6bb5cc9469290db4bc59fcdfc", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:21:30.368645+00
e11b43de-dfa6-4257-a11a-52b1314f0991	93321cb0-c1d2-4c42-bd47-84f0d1da6bdf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/93321cb0-c1d2-4c42-bd47-84f0d1da6bdf/coaf-a809ca82-9296-4055-be34-06469524a9f8.xml", "xml_sha256": "f6cd087287e6a6dead2dfb8473ee327e0d1852414fdef9d40aa96760b348b8c2", "case_status": "REPORTED", "tracking_id": "8ba99dcc-5ab5-44e5-a9c8-13aea8ae2ae0", "submitted_at": "2026-05-20T00:19:56.430319+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "498412647a7549b3a2a6f325c7874d33827bcbbc07c466c3a4c291c2fde465f4", "report_package_id": "a809ca82-9296-4055-be34-06469524a9f8"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:19:56.413894+00
7ab99660-d571-42ea-90cd-6071a232c73a	803539be-379f-4992-a510-c1f50278372e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:59.744167+00
4182c78a-6d9e-47db-ac0f-658e87341934	803539be-379f-4992-a510-c1f50278372e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:59.819504+00
3cc63d63-3aef-491f-9dca-cfc6ccdb6abd	803539be-379f-4992-a510-c1f50278372e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:59.88484+00
cd694f1a-5dee-425c-a326-2c8a16a03d30	803539be-379f-4992-a510-c1f50278372e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "cfc4cb2b-1b18-467a-984a-25abe611024e", "pdf_sha256": "e7a9c1eb4e42fb01968e3d89a9235c05da6c50e7998a27f6b7763ffd36c56fc7", "payload_sha256": "99f8c460ed8eea33842f8c5fdb815ec6117a6be56d7dc8a67f94377fe2f894ce", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:59.965276+00
4bf9ba12-a346-43c1-8e18-fb1d1d5cd036	d02b4133-26c3-4b85-a9da-8ac6948e3e0c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d02b4133-26c3-4b85-a9da-8ac6948e3e0c/coaf-bcd483fd-b8a4-4ac7-bd76-3d743ffdc4b1.xml", "xml_sha256": "a1a5dc84a4eb09ad6ac425e9d3e3c08952493551b172e05e831e7fdf9928392c", "case_status": "REPORTED", "tracking_id": "c712da87-596c-4628-8004-8d85eb6949a2", "submitted_at": "2026-05-20T00:20:51.461917+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "8972907bc34ce497d60e2af73e431cd0c7f38b5eb7fa06ac304803387582c8e6", "report_package_id": "bcd483fd-b8a4-4ac7-bd76-3d743ffdc4b1"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:20:51.44644+00
9ebda692-55c8-4a34-ab28-b66cefb22d79	e69af611-da75-4fe3-8a48-a76b10f9546f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/e69af611-da75-4fe3-8a48-a76b10f9546f/coaf-e2b9c351-9302-44c9-84b1-aa508e858668.xml", "xml_sha256": "916a4f66cd732f62892dfc4b63ec7ce05df75d85d94d03ebdf967849ebd01790", "case_status": "REPORTED", "tracking_id": "128adb28-7d4d-4853-b2ff-ed5825099140", "submitted_at": "2026-05-20T00:21:30.519355+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "e4ad8f7e8c81ca7d2939a241b3d1def129fb09e6bb5cc9469290db4bc59fcdfc", "report_package_id": "e2b9c351-9302-44c9-84b1-aa508e858668"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:21:30.503714+00
16141d88-275d-44ca-82a6-ccbd61e443b3	3a3f6cae-cf66-47a1-b02d-142bf667665e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:42.428388+00
7f00d38e-de95-4adc-a79b-5c3d3294de7c	3a3f6cae-cf66-47a1-b02d-142bf667665e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:42.511501+00
ece8af5e-df41-4c09-bdd7-b151a2cd1ce8	3a3f6cae-cf66-47a1-b02d-142bf667665e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:42.58235+00
38b09f1a-0525-4bcf-9865-2d282d52efc0	3a3f6cae-cf66-47a1-b02d-142bf667665e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "668b8ed4-daa9-4130-a67e-871f77c4ef33", "pdf_sha256": "a2374b31d332d96a3ff49cd2b478d38e4c6f768a7582a4b8ff5296e1bb4fdf0a", "payload_sha256": "24035a0cf47934a6dd15613dd9a8569adbe5f6d969b23d3d6e980acb5de0bdea", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:42.650146+00
b74cc6d6-25e8-47fa-a062-d5619568136d	3a3f6cae-cf66-47a1-b02d-142bf667665e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/3a3f6cae-cf66-47a1-b02d-142bf667665e/coaf-0c6f08ab-62a2-4856-bb8e-3fb9a4a68aee.xml", "xml_sha256": "5800bb392930606bc9c22141a5e54a84f661b83d11f18cc2365a7b9329b4ae48", "case_status": "REPORTED", "tracking_id": "50958dca-0c13-4994-9eea-9cdc404c68a4", "submitted_at": "2026-05-20T00:28:43.528658+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "24035a0cf47934a6dd15613dd9a8569adbe5f6d969b23d3d6e980acb5de0bdea", "report_package_id": "0c6f08ab-62a2-4856-bb8e-3fb9a4a68aee"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:28:43.474042+00
44aa6d84-8e20-4f05-863c-a1674834bbc5	0a2b0872-efcd-4bca-b668-3bfad54a5b93	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:45.900342+00
4762dbdc-8b52-46b0-88e9-47ed0bbbaba4	0a2b0872-efcd-4bca-b668-3bfad54a5b93	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:45.970784+00
877eb49c-ca80-41c8-af26-048847e4584d	0a2b0872-efcd-4bca-b668-3bfad54a5b93	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:46.139212+00
1bb63be4-4c59-4732-94f4-081ea18c7967	0a2b0872-efcd-4bca-b668-3bfad54a5b93	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "bda1d5b6-086b-423b-807e-5ae5d4bafe2f", "pdf_sha256": "ee8e9b5fc1f8a94a2debd189f2a57cdd8a8fed7c84a8d563a2c1b5427199a024", "payload_sha256": "5bc06ea45b3d28ddc9b3db128ec94df37629bea7de259ce3f445cc34a720754a", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:46.219001+00
54175c65-cd54-4635-bc32-6b2662ff76c0	0a2b0872-efcd-4bca-b668-3bfad54a5b93	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/0a2b0872-efcd-4bca-b668-3bfad54a5b93/coaf-67a9a2d1-f687-449e-8d75-cdeadf38b345.xml", "xml_sha256": "7793d100c508533c1a60405f706df1c583e98c117e940c3b46bff721e8626320", "case_status": "REPORTED", "tracking_id": "e442c448-9c06-47e7-b93b-10dfba7abb0f", "submitted_at": "2026-05-20T00:28:46.397848+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "5bc06ea45b3d28ddc9b3db128ec94df37629bea7de259ce3f445cc34a720754a", "report_package_id": "67a9a2d1-f687-449e-8d75-cdeadf38b345"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:28:46.381072+00
0638b003-99c5-412b-82c1-1e0f36b1a547	a6c823d3-7622-4ffb-a61b-7ebcea535e95	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:48.516731+00
6c6a2707-c785-4555-9e19-0ceea302e5ed	a6c823d3-7622-4ffb-a61b-7ebcea535e95	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:48.616336+00
886ee974-fba2-4394-9230-8809bb05bb1a	a6c823d3-7622-4ffb-a61b-7ebcea535e95	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:48.686801+00
34c3b70f-d33e-4826-b67e-5483f2151dda	a6c823d3-7622-4ffb-a61b-7ebcea535e95	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "89e768db-4339-4f67-8e57-255f284574df", "pdf_sha256": "9e5751d421f271b3ca2352e1904c91d4e8141cb89ab4d96d8da8ef8419e63187", "payload_sha256": "dbb66939578dcc401c467697701c96d80f19e343c54032add1ee2b423e632c01", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:48.614952+00
15e37dd5-7150-4d55-b738-54852c9192e7	a6c823d3-7622-4ffb-a61b-7ebcea535e95	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/a6c823d3-7622-4ffb-a61b-7ebcea535e95/coaf-92b2998b-e991-4c67-8883-748249c35390.xml", "xml_sha256": "62541e18eedf2a6b4aa096507e9d4f9b9f377ae4719c3a55f57603313dced81d", "case_status": "REPORTED", "tracking_id": "a8d75f11-cfa4-4618-ae26-5a563865605d", "submitted_at": "2026-05-20T00:28:48.780468+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "dbb66939578dcc401c467697701c96d80f19e343c54032add1ee2b423e632c01", "report_package_id": "92b2998b-e991-4c67-8883-748249c35390"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:28:48.727586+00
1501c438-20d2-496e-a116-5059852e7379	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:49.812486+00
60021027-5796-4d4d-9aa2-290e9b47d03f	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:49.896581+00
ed8b9730-15c2-485a-8f16-34e444cd7f39	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:49.986609+00
d5d9a56b-28d7-4c0f-b324-0d8eacd1bcb7	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "93c67528-0f08-4b22-ab86-b932c31c65b3", "pdf_sha256": "02b572d882a637aea86594e88efc06b98f12dffd3ee1f7dd368cd5793a967903", "payload_sha256": "77ac23543d7b395c86ddace087a15da4ec0914e02e3f06391a9c13b3a1d75291", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:50.109829+00
98f0e1e1-f95f-4a44-a94f-499bb9b384dc	7d7cdb0d-b5dd-4090-84b2-9486019ce2e0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/7d7cdb0d-b5dd-4090-84b2-9486019ce2e0/coaf-d6df8218-84a8-44e7-b66e-af1ca0f7caa8.xml", "xml_sha256": "4778bf0a77c50301d33d045fa47cad277e6c87c0fd2589c290c2d40031c3fd82", "case_status": "REPORTED", "tracking_id": "ba905171-63fc-4285-9cdf-1f488b6237ff", "submitted_at": "2026-05-20T00:28:53.057520+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "e22967e715459059520d3650bb2f4a11a6c8ef3ea994d18cd429f79142aeea7e", "report_package_id": "d6df8218-84a8-44e7-b66e-af1ca0f7caa8"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:28:53.0289+00
399dd1cf-ff63-4dda-b0ce-e5416e0d62b7	817097da-1c7f-45a0-bad6-61c27412c1e9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:29:01.105636+00
e9717fc3-d452-42ed-bef9-2c351ed3c221	817097da-1c7f-45a0-bad6-61c27412c1e9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:29:01.162857+00
e09fda6a-5d30-4d4c-b133-cf7df0573907	817097da-1c7f-45a0-bad6-61c27412c1e9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:29:01.217743+00
9cff5a21-7655-40c6-af5d-6203fb9af14a	817097da-1c7f-45a0-bad6-61c27412c1e9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "6ef058bb-7190-4ede-ade1-265127616651", "pdf_sha256": "985aabae2afaaced908e09554811613e9f300c19a3153f40931a99f366cbb7e8", "payload_sha256": "35edf3eceb02a06bd633f00de39f709bad09e8c2a2f73a6c77b0122f8ebee1a3", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:29:01.280398+00
af1d62f6-bb0e-4969-9cc4-4a79539d9753	dd83cc19-5fee-42e0-9aa1-d5149c82e097	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/dd83cc19-5fee-42e0-9aa1-d5149c82e097/coaf-7541779c-5795-4ad0-ad23-592cc6bcff1f.xml", "xml_sha256": "64444308b4e2de0489a41994386aee08c00b658e16112545d17c9f7cc1678e1a", "case_status": "REPORTED", "tracking_id": "21a72f94-d447-4f15-aecb-d3c8cdcc3917", "submitted_at": "2026-05-20T00:30:19.240190+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "fddbbe4df923f884ab86e1e13356957315206b00472c843656558b52c0b59580", "report_package_id": "7541779c-5795-4ad0-ad23-592cc6bcff1f"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:30:19.221474+00
2f8a8885-b165-4f6f-b8b6-d350d6e95f56	7d7cdb0d-b5dd-4090-84b2-9486019ce2e0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:52.624485+00
9d524cda-7247-44b0-918b-ac8baa23229b	7d7cdb0d-b5dd-4090-84b2-9486019ce2e0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:52.701203+00
89935610-444a-4ce7-8049-09b798adb316	7d7cdb0d-b5dd-4090-84b2-9486019ce2e0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:52.761852+00
beae2cbd-f73e-41b9-bfc8-9098c14ec7fc	7d7cdb0d-b5dd-4090-84b2-9486019ce2e0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "07d7c24c-0ee6-4cae-b9a7-43fc7a7228d3", "pdf_sha256": "0ff08119c8bccfd96b340c2420968c9ad86c2ad985c62a249986298dc8f5dbd0", "payload_sha256": "e22967e715459059520d3650bb2f4a11a6c8ef3ea994d18cd429f79142aeea7e", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:52.840986+00
4a24bd65-207c-47e5-8c97-bdbb8969808f	817097da-1c7f-45a0-bad6-61c27412c1e9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/817097da-1c7f-45a0-bad6-61c27412c1e9/coaf-a6517a64-a57a-41a8-a9af-f8bc1b10c93a.xml", "xml_sha256": "136b315fde2b109b794db50c08889b978d3be8159d06431327ed89b86cc096b7", "case_status": "REPORTED", "tracking_id": "61ac5e8b-a791-445a-9d78-781d03193a58", "submitted_at": "2026-05-20T00:29:01.440611+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "35edf3eceb02a06bd633f00de39f709bad09e8c2a2f73a6c77b0122f8ebee1a3", "report_package_id": "a6517a64-a57a-41a8-a9af-f8bc1b10c93a"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:29:01.430717+00
c51ed0f0-4dcf-4da5-b91f-cff1786fbeb2	3e8279c9-50d4-48e0-8849-c862d24d8c5d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:29:41.463106+00
28d603a4-cc58-4b16-82f3-11a3fef8d73d	3e8279c9-50d4-48e0-8849-c862d24d8c5d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:29:41.534517+00
8a7f4864-d3c7-4b32-a56d-ae73708008a3	3e8279c9-50d4-48e0-8849-c862d24d8c5d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:29:41.608614+00
a3cb9263-945a-45b0-b367-c972b339179c	3e8279c9-50d4-48e0-8849-c862d24d8c5d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "d04d21ef-502f-44d2-9f80-b687db87ad58", "pdf_sha256": "42f8893b8d7db55025026edaff78aa668e9e3fe9c73ebd9c58ea743925436e7a", "payload_sha256": "0b63ce2b64ecf9078062348cb7d6b852dae7a43b16bd5c90fab0b8bc6ae1c9b3", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:29:41.676453+00
09fefb3f-87dd-47de-a9ad-940870e270e8	3e8279c9-50d4-48e0-8849-c862d24d8c5d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_SUBMITTED	{"channel": "MANUAL_PORTAL", "xml_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/3e8279c9-50d4-48e0-8849-c862d24d8c5d/coaf-4e0d46b5-575a-4b1f-832b-cdc17d9ac91e.xml", "xml_sha256": "b0d27dd6ad115ec7dec442eb1dad66bdb9c9d82a7f93a982701e86b92c87b105", "case_status": "REPORTED", "tracking_id": "6bef21e1-ab22-41c1-87a6-2a54d41e79e5", "submitted_at": "2026-05-20T00:29:41.867875+00:00", "submitted_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "payload_sha256": "0b63ce2b64ecf9078062348cb7d6b852dae7a43b16bd5c90fab0b8bc6ae1c9b3", "report_package_id": "4e0d46b5-575a-4b1f-832b-cdc17d9ac91e"}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-20 00:29:41.852033+00
efa1acb6-d966-4c1e-91c6-9be4efbf5274	dd83cc19-5fee-42e0-9aa1-d5149c82e097	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "INVESTIGATING"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:30:18.838932+00
fc1f7fe9-6c56-4f80-a39d-5b34353781b3	dd83cc19-5fee-42e0-9aa1-d5149c82e097	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "PENDING_REVIEW"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:30:18.905489+00
868d0b21-b06d-4501-9dba-0084bae1f71b	dd83cc19-5fee-42e0-9aa1-d5149c82e097	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	STATUS_CHANGE	{"new_status": "CLOSED"}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:30:18.988155+00
1e7c5c31-3ac6-4109-bfb8-b4a67bdd51b1	dd83cc19-5fee-42e0-9aa1-d5149c82e097	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "78062c9b-b61d-4fc2-ac79-6c4676ba34d3", "pdf_sha256": "6f09e346702da805bb40c5566697bb42b4889e3a44d93d2e074dacf0de6ca34f", "payload_sha256": "fddbbe4df923f884ab86e1e13356957315206b00472c843656558b52c0b59580", "attachments_count": 0}	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:30:19.076275+00
113dc401-9480-4e31-a406-cf139d5a74d1	7067f39b-8afe-4b83-b7e9-4391b079ebda	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "PENDING", "report_id": "9fb0595f-61ea-4851-9391-6defd221554e", "pdf_sha256": "3cf68ca17d207d58c553e4cf23dba454f79ab3ef03e6ae26ea337715556eda9e", "payload_sha256": "26d7bc2df6fe5357413e58bfe30df1bcb8f2182ca0acd351331a86c0577899f9", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:54:25.536212+00
37ca5f4e-d893-411b-b8f1-1d4befee34ce	233a5b9e-1d89-493c-9b94-9d96c59991d7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "PENDING", "report_id": "301e1bb9-4281-4f8e-8fae-de463552b9ab", "pdf_sha256": "3a3b74920210375dcfd93cf2f23541c1fc220e1dbff12329555e5c0c4d04827f", "payload_sha256": "99bac121a89366220376ee2a6c8d97fd36f3ae258aefa0deaef1528775bbcc31", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:38.453515+00
554f6c75-6019-4e90-baf6-d0445d231fd5	6c6d0df9-0f51-4bc5-84f4-53c16bf788e9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "d911f74c-2d62-4aba-8d48-1eb7e71cf020", "pdf_sha256": "1f13d9911a282ab467aa38bb42829f1d4faa248775627474ac7862c2255d5f7e", "payload_sha256": "d980c87b75a014de75ad6565eb77119f5f58f462ba40cf0e58b361b17ad300e2", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:38.731712+00
95711c15-8d77-475e-8ed6-5af28e801482	3b1515c5-de8b-420d-9e89-7a01bfb8a3de	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "PENDING", "report_id": "1f8f4810-012e-4539-8ec1-bcf9b84e994c", "pdf_sha256": "46c8f7880d331e627965bdf190112e41ec2efadf8161ae3adc9eeea7e8c8e67d", "payload_sha256": "339d0e59afbf0140c8ea77b200f370276ae581b9d8d5a77201231aace915ba59", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:39.1348+00
4bdb0411-f04b-42be-a8a0-ccb4e5bda1c6	f22ee9d6-f2bd-42bf-9a16-01fa36424384	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "PENDING", "report_id": "d557a2ff-c9e5-4279-ad12-49a471009e3c", "pdf_sha256": "170807b5d3f9ff2788ae3a198d8c068bd3e18f21938d17fa34aa10119e46ab8f", "payload_sha256": "82b060af3c37d6dcbef678db025d0e38210844221753699dac1c6092fca3a2ec", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:41.190768+00
71385965-84d8-4164-b7e1-d5f49776f0f7	f22ee9d6-f2bd-42bf-9a16-01fa36424384	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "a7e978b1-89c7-4537-a098-414f462e8e83", "pdf_sha256": "93c675195a37bddfbadc73230fb8168191af08d26e777c77482b9812f378c828", "payload_sha256": "dabcacc83f3b204533822f52bf3e52e32dfbe523798d2e594eaeab53aa8fc723", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:56:25.655732+00
7195e7e9-f8d5-446f-a522-1d0b8564f689	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "762b1829-0386-49af-a7a9-f5c655965b0c", "pdf_sha256": "2e75ad3788bcbed8130a5d3fa343efa4f1866c6c84537bbea214deb7d6993c11", "payload_sha256": "76802436ea5e2ef0cac9f9635fd4547e2a7e8182ece371841facf490ed768f95", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:56:26.349896+00
027c658d-6036-44ca-b327-d3d295a3279d	f22ee9d6-f2bd-42bf-9a16-01fa36424384	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "55163958-bbfa-4913-af4a-92c6b8a95d09", "pdf_sha256": "6e7e2dc62d325e31ae6aec213875ab5810e95c7ce81401f821f3718cd9902cd1", "payload_sha256": "e5af6423f9a71c62706efd235c7067733a552308fcfe541d7d2bb7b6155a1158", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:01:40.570335+00
5ea77159-4e38-46bd-8f53-5779fa9a0652	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "bfa2f26f-3d16-4c74-bd4a-8b18fcbe2dcb", "pdf_sha256": "8d87cd4d7a0bf24b5234f70d859cbb20e9ec4cc0c0333c5d68fc46d4ab23930f", "payload_sha256": "1cd9c70ed4c2e152587265f7bc275bf4eecb87792b3935ae6ef0462ff087cb32", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:01:42.179914+00
ac803c52-6239-4e28-8967-ced32c708232	11dc8f67-7311-4647-85f0-8117406bc5d6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "PENDING", "report_id": "d0cc410b-bc42-4e11-bc9e-ac757670e85e", "pdf_sha256": "0276d62d12d56c2041f7648d2a0fda5eed55df6821cb49a80b8d867feb253bc8", "payload_sha256": "ee4ce66e56bc8e50c1b1b482008cc98d41676360c5a3af93130859ace2c52cf8", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:49.221437+00
6d1c74f5-63fb-457a-83e2-4ac45e4a952e	3e32661a-e88d-41c7-b177-36c262195da1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "4916ab29-472a-4a7a-a712-826e850574ed", "pdf_sha256": "fd4adf35e3fc4ad203f4a52ffa20f450639912de73a3df8993cef450e18ff16a", "payload_sha256": "9b282fa222c2d9b078d4cafcc30129ea273365b8d818f4a747ffe6933f7c4cef", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:49.453469+00
0da5fa9d-3f8c-4b36-9ff6-b48ff9b2a5d4	cf67acb2-a3f3-4384-aaa5-fac4c2067efe	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "PENDING", "report_id": "758e0ec1-858d-4301-8a17-30a30f92c2d7", "pdf_sha256": "ff5b796ceefce9a090779ba45eebd18ded2a3be85f076824570a5c34d5c6ee5a", "payload_sha256": "737302fc85df4ee7520e9a925f01ef4f6fd4b9b3de242c62ff7372d24c62f1a8", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:49.778991+00
5c0f70e5-a3a2-4a1c-bda1-febf56f8eecd	510078bd-3aab-411d-97f9-e22b883da667	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "PENDING", "report_id": "90bee7c5-4947-4e8e-b653-61ea63b6a231", "pdf_sha256": "590426ca3c5123fff3bcccdfe878d714ccb35d64ad09e2cb087a7fe38df4017a", "payload_sha256": "1e2467448b661887631f764333e403602d03a523142203c354a52353c9bf5b36", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:51.326609+00
fdd7aba6-a71c-4a1c-9a84-2d4341cf19da	510078bd-3aab-411d-97f9-e22b883da667	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "49913c05-90e6-4550-b6cd-33cd2ff094a4", "pdf_sha256": "061d2c33bcf75df8f6c3c0bab536e598f350cb18e96467825ed91115169af470", "payload_sha256": "f686a10f6943e5f2c265a231dbe79e7383a7b7b7ed9a1727613b18f9eda591a9", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:03:07.809572+00
cf7ff4b3-5c56-44ef-9b07-f224cd6f85d2	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	REPORT_GENERATED	{"decision": "FILE_SAR", "report_id": "0fb773aa-f428-466e-aac5-697e35372170", "pdf_sha256": "5f626dd38ae79dd7bd49daeaa54ddd069846a744ec9e7ede3a541c755feedc1f", "payload_sha256": "e34eadc120ef1c5830bcc42d61e5384edc5c0b9560eb454c812bc9c2a73c2d12", "attachments_count": 0}	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:03:08.450139+00
\.


--
-- Data for Name: cases; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.cases (id, tenant_id, player_id, title, description, status, severity, assigned_to, created_by, closed_by, closed_at, created_at, updated_at, reference_number, sla_due_at, priority, auto_created, auto_created_reason, source_alert_id, backfill_job_id, ingest_mode) FROM stdin;
85596b71-cf3b-4eb5-a2d3-5e50ef34b018	98c56b0f-fa44-47cd-a8d9-9479174e3140	295626b4-138e-4166-8bcb-f9fc7e4febd4	Investigação PLD — Round-tripping EXT-OPERADOR_B-004	Caso auto-criado por detecção de padrão de round-tripping	OPEN	CRITICAL	\N	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	\N	MEDIUM	t	scoring.alerts: anomaly_score=0.91, severity=CRITICAL	471813f0-bec0-4212-9683-764e1f39623b	\N	incremental
2c953fd3-0c49-4d47-a956-4038ec338b9d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	5f4b66dd-66b9-49d7-ac79-10c15f7b9e71	E2E COAF Protocol 1779235101622	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:22.297849+00	2026-05-19 23:58:21.72704+00	2026-05-19 23:58:22.285746+00	CASE-20260519-2C953FD3	2026-05-20 23:58:21.83815+00	MEDIUM	f	\N	\N	\N	incremental
a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236072705	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:14:33.287904+00	2026-05-20 00:14:32.791017+00	2026-05-20 00:14:33.720627+00	CASE-20260520-A7F2AD2D	2026-05-21 00:14:32.857568+00	MEDIUM	f	\N	\N	\N	incremental
e377d705-472f-4060-b62b-17963b5c48cc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	5f4b66dd-66b9-49d7-ac79-10c15f7b9e71	E2E COAF Protocol 1779235111212	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:31.494815+00	2026-05-19 23:58:31.267551+00	2026-05-19 23:58:31.489159+00	CASE-20260519-E377D705	2026-05-20 23:58:31.286976+00	MEDIUM	f	\N	\N	\N	incremental
97cb2b12-475b-4596-995c-73eb62f51ba4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236114577	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:15:15.192726+00	2026-05-20 00:15:14.79521+00	2026-05-20 00:15:15.567323+00	CASE-20260520-97CB2B12	2026-05-21 00:15:14.813438+00	MEDIUM	f	\N	\N	\N	incremental
f0818532-66b1-471c-9902-4d8f359c1d26	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	5f4b66dd-66b9-49d7-ac79-10c15f7b9e71	E2E COAF Protocol 1779235117645	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:38.029791+00	2026-05-19 23:58:37.778644+00	2026-05-19 23:58:38.018299+00	CASE-20260519-F0818532	2026-05-20 23:58:37.795173+00	MEDIUM	f	\N	\N	\N	incremental
ab6ef6d1-6c92-4989-9f8c-5d6aaf90cf15	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	5f4b66dd-66b9-49d7-ac79-10c15f7b9e71	E2E COAF Protocol 1779235123318	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:43.579344+00	2026-05-19 23:58:43.361733+00	2026-05-19 23:58:43.566404+00	CASE-20260519-AB6EF6D1	2026-05-20 23:58:43.37692+00	MEDIUM	f	\N	\N	\N	incremental
cdef2fe6-dea8-4b0f-b76f-948d085e810f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236390712	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:51.07929+00	2026-05-20 00:19:50.765927+00	2026-05-20 00:19:51.6504+00	CASE-20260520-CDEF2FE6	2026-05-21 00:19:50.805987+00	MEDIUM	f	\N	\N	\N	incremental
a6d4286f-e75c-4ff3-b6b6-ac1b626b7030	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	5f4b66dd-66b9-49d7-ac79-10c15f7b9e71	E2E COAF Protocol 1779235130094	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:58:50.393984+00	2026-05-19 23:58:50.161092+00	2026-05-19 23:58:50.384589+00	CASE-20260519-A6D4286F	2026-05-20 23:58:50.178463+00	MEDIUM	f	\N	\N	\N	incremental
898955fd-f537-4a4a-9cc3-e490d5f343b5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236393362	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:53.718349+00	2026-05-20 00:19:53.450425+00	2026-05-20 00:19:54.069161+00	CASE-20260520-898955FD	2026-05-21 00:19:53.476084+00	MEDIUM	f	\N	\N	\N	incremental
032940ff-c161-4765-a4bd-65a41bb7f0db	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	5f4b66dd-66b9-49d7-ac79-10c15f7b9e71	E2E COAF Protocol 1779235143064	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:59:03.377692+00	2026-05-19 23:59:03.153799+00	2026-05-19 23:59:03.365636+00	CASE-20260519-032940FF	2026-05-20 23:59:03.165183+00	MEDIUM	f	\N	\N	\N	incremental
eb453a94-9f9a-442b-be31-2b886c4ba711	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	5f4b66dd-66b9-49d7-ac79-10c15f7b9e71	E2E COAF Protocol 1779235155248	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:59:15.675859+00	2026-05-19 23:59:15.372375+00	2026-05-19 23:59:15.668782+00	CASE-20260519-EB453A94	2026-05-20 23:59:15.438986+00	MEDIUM	f	\N	\N	\N	incremental
93321cb0-c1d2-4c42-bd47-84f0d1da6bdf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236395867	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:56.242613+00	2026-05-20 00:19:55.993806+00	2026-05-20 00:19:56.413894+00	CASE-20260520-93321CB0	2026-05-21 00:19:56.013125+00	MEDIUM	f	\N	\N	\N	incremental
e21505cc-cb01-4958-a794-e6f59fbe8ee6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	5f4b66dd-66b9-49d7-ac79-10c15f7b9e71	E2E COAF Protocol 1779235166159	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-19 23:59:26.50302+00	2026-05-19 23:59:26.248043+00	2026-05-19 23:59:26.493701+00	CASE-20260519-E21505CC	2026-05-20 23:59:26.279054+00	MEDIUM	f	\N	\N	\N	incremental
84bd3a0e-e274-45ec-aedd-491722778caa	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	Investigação PLD — Round-tripping EXT-OPERADOR_A-004	Caso auto-criado por detecção de padrão de round-tripping	OPEN	CRITICAL	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-19 23:57:44.872891+00	2026-05-20 00:04:03.665276+00	CASE-20260519-84BD3A0E	\N	MEDIUM	t	scoring.alerts: anomaly_score=0.91, severity=CRITICAL	060cae02-d76e-458b-b9bb-f824c1419f29	\N	incremental
5014b829-e438-4d15-8647-28ee47547247	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236397180	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:57.540528+00	2026-05-20 00:19:57.311373+00	2026-05-20 00:19:57.528351+00	CASE-20260520-5014B829	2026-05-21 00:19:57.327304+00	MEDIUM	f	\N	\N	\N	incremental
f0fe6296-60e6-439d-a7a5-bcacc4239d18	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236006620	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:27.097315+00	2026-05-20 00:13:26.746134+00	2026-05-20 00:13:27.441445+00	CASE-20260520-F0FE6296	2026-05-21 00:13:26.791512+00	MEDIUM	f	\N	\N	\N	incremental
803539be-379f-4992-a510-c1f50278372e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236399614	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:59.89894+00	2026-05-20 00:19:59.638006+00	2026-05-20 00:20:00.231714+00	CASE-20260520-803539BE	2026-05-21 00:19:59.678434+00	MEDIUM	f	\N	\N	\N	incremental
20307f11-535c-46e4-a4d9-8d7090bd954c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236009272	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:29.531004+00	2026-05-20 00:13:29.297254+00	2026-05-20 00:13:29.743887+00	CASE-20260520-20307F11	2026-05-21 00:13:29.324019+00	MEDIUM	f	\N	\N	\N	incremental
95c36d67-1b75-4e86-bd3a-b317c80e50af	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236407084	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:20:07.517324+00	2026-05-20 00:20:07.17746+00	2026-05-20 00:20:07.851384+00	CASE-20260520-95C36D67	2026-05-21 00:20:07.196506+00	MEDIUM	f	\N	\N	\N	incremental
607d3d6d-e568-4a39-ba6e-d1aa19db91b3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236011493	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:31.950449+00	2026-05-20 00:13:31.62715+00	2026-05-20 00:13:32.184389+00	CASE-20260520-607D3D6D	2026-05-21 00:13:31.659033+00	MEDIUM	f	\N	\N	\N	incremental
e94f825a-af60-4a71-9eac-f4673f07b720	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236013019	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:33.527118+00	2026-05-20 00:13:33.212315+00	2026-05-20 00:13:33.517274+00	CASE-20260520-E94F825A	2026-05-21 00:13:33.233506+00	MEDIUM	f	\N	\N	\N	incremental
d02b4133-26c3-4b85-a9da-8ac6948e3e0c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236450921	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:20:51.161301+00	2026-05-20 00:20:50.948316+00	2026-05-20 00:20:51.44644+00	CASE-20260520-D02B4133	2026-05-21 00:20:50.96539+00	MEDIUM	f	\N	\N	\N	incremental
edefa731-72fc-4b4c-bb96-8cb786eb3433	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236015689	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:36.11612+00	2026-05-20 00:13:35.837854+00	2026-05-20 00:13:36.35955+00	CASE-20260520-EDEFA731	2026-05-21 00:13:35.856014+00	MEDIUM	f	\N	\N	\N	incremental
e69af611-da75-4fe3-8a48-a76b10f9546f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236489976	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:21:30.262903+00	2026-05-20 00:21:29.995799+00	2026-05-20 00:21:30.503714+00	CASE-20260520-E69AF611	2026-05-21 00:21:30.015219+00	MEDIUM	f	\N	\N	\N	incremental
e21867bf-2495-4371-8cdd-0f46d083bb6e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236026036	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:46.3148+00	2026-05-20 00:13:46.093429+00	2026-05-20 00:13:46.549532+00	CASE-20260520-E21867BF	2026-05-21 00:13:46.111908+00	MEDIUM	f	\N	\N	\N	incremental
a6c823d3-7622-4ffb-a61b-7ebcea535e95	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236928289	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:48.697638+00	2026-05-20 00:28:48.46017+00	2026-05-20 00:28:48.727586+00	CASE-20260520-A6C823D3	2026-05-21 00:28:48.479981+00	MEDIUM	f	\N	\N	\N	incremental
3a3f6cae-cf66-47a1-b02d-142bf667665e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236922205	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:42.59602+00	2026-05-20 00:28:42.293764+00	2026-05-20 00:28:43.474042+00	CASE-20260520-3A3F6CAE	2026-05-21 00:28:42.3409+00	MEDIUM	f	\N	\N	\N	incremental
2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236929685	Caso criado automaticamente pela suíte E2E	CLOSED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:50.00223+00	2026-05-20 00:28:49.726126+00	2026-05-20 00:28:49.986609+00	CASE-20260520-2D88FFD1	2026-05-21 00:28:49.745954+00	MEDIUM	f	\N	\N	\N	incremental
0a2b0872-efcd-4bca-b668-3bfad54a5b93	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236925667	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:46.150709+00	2026-05-20 00:28:45.82691+00	2026-05-20 00:28:46.381072+00	CASE-20260520-0A2B0872	2026-05-21 00:28:45.848175+00	MEDIUM	f	\N	\N	\N	incremental
7d7cdb0d-b5dd-4090-84b2-9486019ce2e0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236932457	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:52.774929+00	2026-05-20 00:28:52.539262+00	2026-05-20 00:28:53.0289+00	CASE-20260520-7D7CDB0D	2026-05-21 00:28:52.569682+00	MEDIUM	f	\N	\N	\N	incremental
817097da-1c7f-45a0-bad6-61c27412c1e9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236940983	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:29:01.229785+00	2026-05-20 00:29:01.027176+00	2026-05-20 00:29:01.430717+00	CASE-20260520-817097DA	2026-05-21 00:29:01.045687+00	MEDIUM	f	\N	\N	\N	incremental
3e8279c9-50d4-48e0-8849-c862d24d8c5d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779236981167	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:29:41.616338+00	2026-05-20 00:29:41.334029+00	2026-05-20 00:29:41.852033+00	CASE-20260520-3E8279C9	2026-05-21 00:29:41.383063+00	MEDIUM	f	\N	\N	\N	incremental
dd83cc19-5fee-42e0-9aa1-d5149c82e097	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	E2E COAF Protocol 1779237018746	Caso criado automaticamente pela suíte E2E	REPORTED	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:30:18.995716+00	2026-05-20 00:30:18.767819+00	2026-05-20 00:30:19.221474+00	CASE-20260520-DD83CC19	2026-05-21 00:30:18.778582+00	MEDIUM	f	\N	\N	\N	incremental
1be39b6b-3938-4ebe-b779-fa393561dd31	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	GAP7 Test	\N	OPEN	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	\N	\N	2026-05-22 15:46:33.482035+00	2026-05-22 15:46:33.482035+00	CASE-20260522-1BE39B6B	2026-05-23 15:46:33.532254+00	MEDIUM	f	\N	\N	\N	incremental
b0630225-62e3-440a-9cb6-bd39fbb96ef9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso de Teste 0676af	Criado por teste de integração automatizado	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:46:53.954825+00	2026-05-22 15:46:53.954825+00	CASE-20260522-B0630225	2026-05-23 15:46:53.964179+00	MEDIUM	f	\N	\N	\N	incremental
3beff455-a892-4004-8bbb-5b6e6d6db780	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso para Fetch	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:46:54.064521+00	2026-05-22 15:46:54.064521+00	CASE-20260522-3BEFF455	2026-05-23 15:46:54.07839+00	MEDIUM	f	\N	\N	\N	incremental
4090b4d3-47fe-4caf-bb39-726a0c033eda	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso Link Test	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:46:54.194717+00	2026-05-22 15:46:54.194717+00	CASE-20260522-4090B4D3	2026-05-23 15:46:54.203883+00	MEDIUM	f	\N	\N	\N	incremental
8fcd6c84-097e-4617-b69e-755e49bee79b	98c56b0f-fa44-47cd-a8d9-9479174e3140	\N	Caso Tenant B	\N	OPEN	HIGH	\N	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	\N	2026-05-22 15:46:55.607594+00	2026-05-22 15:46:55.607594+00	CASE-20260522-8FCD6C84	2026-05-23 15:46:55.620101+00	MEDIUM	f	\N	\N	\N	incremental
9a33886c-5d3a-4170-a082-415b6e3a2d37	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso COAF Test 808f4e	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:47:07.632603+00	2026-05-22 15:47:07.632603+00	CASE-20260522-9A33886C	2026-05-23 15:47:07.645411+00	MEDIUM	f	\N	\N	\N	incremental
fb59b5d0-b12f-43de-8a0a-446899f04964	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso SAR 4dcb5e	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:47:07.790503+00	2026-05-22 15:47:07.790503+00	CASE-20260522-FB59B5D0	2026-05-23 15:47:07.800226+00	MEDIUM	f	\N	\N	\N	incremental
3d4821e8-e84f-4c4d-a810-ed082dbaff64	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso SAR sem narrativa 61475e	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:47:07.558713+00	2026-05-22 15:47:07.558713+00	CASE-20260522-3D4821E8	2026-05-23 15:47:07.566988+00	MEDIUM	f	\N	\N	\N	incremental
06748e5f-601a-483b-bb32-e47920ee6210	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso CPF Mask Test	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:47:07.664918+00	2026-05-22 15:47:07.664918+00	CASE-20260522-06748E5F	2026-05-23 15:47:07.674195+00	MEDIUM	f	\N	\N	\N	incremental
109920b9-b859-4ed4-9348-9de10f8d21da	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso Audit Test	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:47:09.836109+00	2026-05-22 15:47:09.836109+00	CASE-20260522-109920B9	2026-05-23 15:47:09.850051+00	MEDIUM	f	\N	\N	\N	incremental
8d5d46c2-b4b1-425a-ad70-d87ff52b38a8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso COAF Test 755f21	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:52:54.87516+00	2026-05-22 15:52:54.87516+00	CASE-20260522-8D5D46C2	2026-05-23 15:52:54.930295+00	MEDIUM	f	\N	\N	\N	incremental
7911feb1-05c3-45dc-976b-020f4b7a0fc0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso SAR sem narrativa d33620	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:52:55.332236+00	2026-05-22 15:52:55.332236+00	CASE-20260522-7911FEB1	2026-05-23 15:52:55.371851+00	MEDIUM	f	\N	\N	\N	incremental
7067f39b-8afe-4b83-b7e9-4391b079ebda	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso COAF Test 82cf2c	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:54:25.456379+00	2026-05-22 15:54:25.456379+00	CASE-20260522-7067F39B	2026-05-23 15:54:25.497263+00	MEDIUM	f	\N	\N	\N	incremental
26c430d1-fdfc-42ea-a4e5-df1d25e1f95a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	GAP7 Test	\N	OPEN	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	\N	\N	2026-05-22 15:54:44.719364+00	2026-05-22 15:54:44.719364+00	CASE-20260522-26C430D1	2026-05-23 15:54:44.736407+00	MEDIUM	f	\N	\N	\N	incremental
b1bb9d65-20d1-471a-ab04-6dcc4391ab13	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso de Teste c19554	Criado por teste de integração automatizado	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:55:05.452669+00	2026-05-22 15:55:05.452669+00	CASE-20260522-B1BB9D65	2026-05-23 15:55:05.606459+00	MEDIUM	f	\N	\N	\N	incremental
0dfbce2e-f6f3-4616-95a8-1be4a8780064	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso para Fetch	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:55:05.778279+00	2026-05-22 15:55:05.778279+00	CASE-20260522-0DFBCE2E	2026-05-23 15:55:05.801824+00	MEDIUM	f	\N	\N	\N	incremental
600c72a0-c4d5-44ee-adc8-9bf7845c088b	98c56b0f-fa44-47cd-a8d9-9479174e3140	\N	Caso Tenant B	\N	OPEN	HIGH	\N	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	\N	2026-05-22 15:55:07.68514+00	2026-05-22 15:55:07.68514+00	CASE-20260522-600C72A0	2026-05-23 15:55:07.694291+00	MEDIUM	f	\N	\N	\N	incremental
233a5b9e-1d89-493c-9b94-9d96c59991d7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso COAF Test ee05dd	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:55:38.350196+00	2026-05-22 15:55:38.350196+00	CASE-20260522-233A5B9E	2026-05-23 15:55:38.367261+00	MEDIUM	f	\N	\N	\N	incremental
6c6d0df9-0f51-4bc5-84f4-53c16bf788e9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso SAR 8d4939	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:55:38.637594+00	2026-05-22 15:55:38.637594+00	CASE-20260522-6C6D0DF9	2026-05-23 15:55:38.653704+00	MEDIUM	f	\N	\N	\N	incremental
914fdfca-3a89-41ae-a99a-815007cad049	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso SAR sem narrativa 8a5be0	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:55:38.897731+00	2026-05-22 15:55:38.897731+00	CASE-20260522-914FDFCA	2026-05-23 15:55:38.943157+00	MEDIUM	f	\N	\N	\N	incremental
3b1515c5-de8b-420d-9e89-7a01bfb8a3de	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso CPF Mask Test	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:55:39.052398+00	2026-05-22 15:55:39.052398+00	CASE-20260522-3B1515C5	2026-05-23 15:55:39.069327+00	MEDIUM	f	\N	\N	\N	incremental
f22ee9d6-f2bd-42bf-9a16-01fa36424384	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso Audit Test	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:55:41.091622+00	2026-05-22 15:55:41.091622+00	CASE-20260522-F22EE9D6	2026-05-23 15:55:41.115186+00	MEDIUM	f	\N	\N	\N	incremental
688ad55f-fba1-435e-b491-16e933d1f2ff	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	5f4b66dd-66b9-49d7-ac79-10c15f7b9e71	Caso Link Test	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 15:55:05.925499+00	2026-05-22 15:55:06.054839+00	CASE-20260522-688AD55F	2026-05-23 15:55:05.945626+00	MEDIUM	t	backfilled_from_critical_alert	4ab2f20e-a686-4195-868f-4d58751c20eb	\N	incremental
31740fef-863a-4937-bea9-7dd363c0a87c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	GAP7 Test	\N	OPEN	HIGH	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	\N	\N	2026-05-22 16:02:01.570602+00	2026-05-22 16:02:01.570602+00	CASE-20260522-31740FEF	2026-05-23 16:02:01.618414+00	MEDIUM	f	\N	\N	\N	incremental
2011aa14-cf71-48a7-bb77-9965d1a4f382	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso de Teste d7a3ba	Criado por teste de integração automatizado	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 16:02:20.92864+00	2026-05-22 16:02:20.92864+00	CASE-20260522-2011AA14	2026-05-23 16:02:20.974156+00	MEDIUM	f	\N	\N	\N	incremental
583ac91c-e317-4fad-9012-f714629b3d62	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso para Fetch	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 16:02:21.064002+00	2026-05-22 16:02:21.064002+00	CASE-20260522-583AC91C	2026-05-23 16:02:21.074316+00	MEDIUM	f	\N	\N	\N	incremental
0d802281-da37-43c1-91b8-aba355578826	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	Caso Link Test	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 16:02:21.157133+00	2026-05-22 16:02:21.229123+00	CASE-20260522-0D802281	2026-05-23 16:02:21.167944+00	MEDIUM	f	\N	36d6e3a5-cf34-4e62-aff3-77ecb0909deb	\N	incremental
3a0d1009-f022-4655-9868-fc9d81ac45bb	98c56b0f-fa44-47cd-a8d9-9479174e3140	\N	Caso Tenant B	\N	OPEN	HIGH	\N	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	\N	2026-05-22 16:02:22.347457+00	2026-05-22 16:02:22.347457+00	CASE-20260522-3A0D1009	2026-05-23 16:02:22.359164+00	MEDIUM	f	\N	\N	\N	incremental
11dc8f67-7311-4647-85f0-8117406bc5d6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso COAF Test dffd7c	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 16:02:49.148235+00	2026-05-22 16:02:49.148235+00	CASE-20260522-11DC8F67	2026-05-23 16:02:49.165548+00	MEDIUM	f	\N	\N	\N	incremental
3e32661a-e88d-41c7-b177-36c262195da1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso SAR fac7ea	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 16:02:49.383088+00	2026-05-22 16:02:49.383088+00	CASE-20260522-3E32661A	2026-05-23 16:02:49.401196+00	MEDIUM	f	\N	\N	\N	incremental
fe0b2cc2-7c06-4f51-b807-afa4dedcd70a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso SAR sem narrativa 4dbc0f	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 16:02:49.594688+00	2026-05-22 16:02:49.594688+00	CASE-20260522-FE0B2CC2	2026-05-23 16:02:49.617465+00	MEDIUM	f	\N	\N	\N	incremental
cf67acb2-a3f3-4384-aaa5-fac4c2067efe	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso CPF Mask Test	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 16:02:49.702581+00	2026-05-22 16:02:49.702581+00	CASE-20260522-CF67ACB2	2026-05-23 16:02:49.724859+00	MEDIUM	f	\N	\N	\N	incremental
510078bd-3aab-411d-97f9-e22b883da667	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	Caso Audit Test	\N	OPEN	HIGH	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	\N	2026-05-22 16:02:51.285011+00	2026-05-22 16:02:51.285011+00	CASE-20260522-510078BD	2026-05-23 16:02:51.294443+00	MEDIUM	f	\N	\N	\N	incremental
\.


--
-- Data for Name: compound_rules; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.compound_rules (id, tenant_id, name, description, status, n_threshold, severity_mode, fixed_severity, version, created_by, updated_by, created_at, updated_at, is_active, logic, component_rule_ids, score_weights, min_score_threshold) FROM stdin;
62018224-ca03-400a-a4e8-3afe8b534003	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Structuring + Spike Combinado	Dispara quando structuring E spike de depósito ocorrem simultaneamente	ACTIVE	\N	MAX	\N	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	t	AND	["265cc264-8c01-4aad-aa32-440a68239ac3", "ff4faf5e-9166-44e5-8626-f15a586a2b0a"]	{"265cc264-8c01-4aad-aa32-440a68239ac3": 0.6, "ff4faf5e-9166-44e5-8626-f15a586a2b0a": 0.4}	0.7000
505c6661-604b-49d4-becb-612b874b969d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Round-trip HIGH Confidence	Round-tripping com alto score composto (regra + ML)	ACTIVE	\N	FIXED	CRITICAL	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	t	OR	["5bea9aca-74be-4283-8b83-5f63af3cb617"]	{"5bea9aca-74be-4283-8b83-5f63af3cb617": 1.0}	0.8000
cbccaa0b-5a3f-452c-b53b-85fbd61ec207	98c56b0f-fa44-47cd-a8d9-9479174e3140	Structuring + Spike Combinado	Dispara quando structuring E spike de depósito ocorrem simultaneamente	ACTIVE	\N	MAX	\N	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	t	AND	["f1f67fd5-6533-4ad3-97a3-ccaa5b36da1b", "941505b4-3e42-47a4-9ad1-39789ed52069"]	{"941505b4-3e42-47a4-9ad1-39789ed52069": 0.4, "f1f67fd5-6533-4ad3-97a3-ccaa5b36da1b": 0.6}	0.7000
4835e02e-e2c2-4787-afef-dacefd58d60f	98c56b0f-fa44-47cd-a8d9-9479174e3140	Round-trip HIGH Confidence	Round-tripping com alto score composto (regra + ML)	ACTIVE	\N	FIXED	CRITICAL	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	t	OR	["3781de8f-4c2c-4708-8723-1ae7b652ffdc"]	{"3781de8f-4c2c-4708-8723-1ae7b652ffdc": 1.0}	0.8000
\.


--
-- Data for Name: device_events; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.device_events (id, tenant_id, player_id, external_evt_id, source_system, action, device_id, device_type, device_hash, ip_address, ip_hash, country_code, user_agent, session_id, source_event_id, ingest_job_id, raw_payload, occurred_at, created_at) FROM stdin;
\.


--
-- Data for Name: external_validation_requests; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.external_validation_requests (id, tenant_id, player_id, provider, validation_type, status, request_payload, response_payload, external_request_id, error_message, requested_by, requested_at, completed_at, updated_at) FROM stdin;
6c35cc36-f965-4754-9aa5-417001401567	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	087318c7-8467-41d9-a23a-ffed149c7dfb	mock_identity	CPF_IDENTITY	COMPLETED	{"trigger": "integration_test"}	{"match": true, "attempts": 1, "provider": "mock_identity", "risk_hint": "LOW", "latency_ms": 293, "match_score": 0.97, "validated_at": "2026-05-22T15:46:44.538526+00:00", "retries_count": 0, "sanctions_check": {"entries": [], "matched": false, "checked_at": "2026-05-22T15:46:44.570330+00:00", "match_type": "NONE", "matched_count": 0}, "validation_type": "CPF_IDENTITY", "external_request_id": "mock-6c35cc36"}	mock-6c35cc36	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:44.141707+00	2026-05-22 15:46:44.570431+00	2026-05-22 15:46:44.551932+00
b8a90000-7b30-49fb-bd13-8c27625f0deb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	087318c7-8467-41d9-a23a-ffed149c7dfb	mock_identity	CPF_IDENTITY	COMPLETED	{"trigger": "integration_test"}	{"match": true, "attempts": 1, "provider": "mock_identity", "risk_hint": "LOW", "latency_ms": 225, "match_score": 0.97, "validated_at": "2026-05-22T16:02:11.711379+00:00", "retries_count": 0, "sanctions_check": {"entries": [], "matched": false, "checked_at": "2026-05-22T16:02:11.720415+00:00", "match_type": "NONE", "matched_count": 0}, "validation_type": "CPF_IDENTITY", "external_request_id": "mock-b8a90000"}	mock-b8a90000	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:11.462616+00	2026-05-22 16:02:11.720464+00	2026-05-22 16:02:11.714095+00
\.


--
-- Data for Name: feature_snapshots; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.feature_snapshots (id, tenant_id, player_id, feature_date, features, drift_score, created_at, snapshot_date, feature_version) FROM stdin;
53d7c3e1-2677-4705-9c77-ad2ea3161404	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	23b9d36d-0c52-4e54-91f1-edb5d8f822d3	2026-05-22	{"player_id": "erase_test_gap7_1bf4e916", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "cluster_id": "solo:erase_test_gap7_1bf4e916", "computed_at": "2026-05-22T15:46:33.200356", "entity_type": "PLAYER", "bet_count_7d": 0, "cluster_size": 1, "bet_count_30d": 0, "bet_count_90d": 0, "snapshot_date": "2026-05-22", "deposit_sum_7d": 0.0, "avg_odds_bet_7d": null, "deposit_sum_24h": 0.0, "deposit_sum_30d": 0.0, "deposit_sum_90d": 0.0, "feature_version": 2, "new_device_flag": false, "bet_stake_sum_7d": 0.0, "cashout_ratio_7d": 0.0, "deposit_count_1h": 0, "deposit_count_7d": 0, "deposit_velocity": 0.0, "gold_object_path": "gold/tenant_id=335bc3ac-6769-407d-ab8e-8a5d8955b1fd/feature_date=2026-05-22/entity_type=PLAYER/player_id=erase_test_gap7_1bf4e916.json", "snapshot_version": 2, "bet_stake_sum_24h": 0.0, "deposit_count_24h": 0, "deposit_count_90d": 0, "withdrawal_sum_7d": 0.0, "win_loss_ratio_30d": null, "withdrawal_sum_24h": 0.0, "withdrawal_sum_90d": 0.0, "chargeback_rate_30d": 0.0, "shared_device_count": 0, "shared_device_score": 0.0, "chargeback_count_30d": 0, "night_activity_ratio": 0.0, "withdrawal_count_24h": 0, "unique_instruments_7d": 0, "slot_session_count_24h": 0, "weekend_activity_ratio": 0.0, "baseline_stddev_deposit": 0.0, "bonus_to_real_ratio_30d": 0.0, "shared_instrument_score": 0.0, "bet_product_diversity_7d": 0, "casino_session_count_24h": 0, "failed_deposit_count_24h": 0, "shared_bank_account_count": 0, "baseline_avg_daily_deposit": 0.0, "inconsistent_currency_flag": false, "unique_instruments_used_7d": 0, "new_payment_instrument_flag": true, "bonus_to_real_money_ratio_30d": 0.0, "ratio_withdrawal_to_deposit_7d": 0.0, "avg_deposit_to_withdrawal_hours": null, "zscore_current_deposit_vs_baseline": 0.0, "avg_time_between_deposit_and_withdrawal_7d": null}	\N	2026-05-22 15:46:33.2593+00	2026-05-22	2
8d7bcb26-595a-478d-843f-15a547a7dee2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	3dca48e5-9da8-452f-b1f6-2533bf111baf	2026-05-22	{"player_id": "erase_test_gap7_458fbe56", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "cluster_id": "solo:erase_test_gap7_458fbe56", "computed_at": "2026-05-22T16:02:00.619063", "entity_type": "PLAYER", "bet_count_7d": 0, "cluster_size": 1, "bet_count_30d": 0, "bet_count_90d": 0, "snapshot_date": "2026-05-22", "deposit_sum_7d": 0.0, "avg_odds_bet_7d": null, "deposit_sum_24h": 0.0, "deposit_sum_30d": 0.0, "deposit_sum_90d": 0.0, "feature_version": 2, "new_device_flag": false, "bet_stake_sum_7d": 0.0, "cashout_ratio_7d": 0.0, "deposit_count_1h": 0, "deposit_count_7d": 0, "deposit_velocity": 0.0, "gold_object_path": "gold/tenant_id=335bc3ac-6769-407d-ab8e-8a5d8955b1fd/feature_date=2026-05-22/entity_type=PLAYER/player_id=erase_test_gap7_458fbe56.json", "snapshot_version": 2, "bet_stake_sum_24h": 0.0, "deposit_count_24h": 0, "deposit_count_90d": 0, "withdrawal_sum_7d": 0.0, "win_loss_ratio_30d": null, "withdrawal_sum_24h": 0.0, "withdrawal_sum_90d": 0.0, "chargeback_rate_30d": 0.0, "shared_device_count": 0, "shared_device_score": 0.0, "chargeback_count_30d": 0, "night_activity_ratio": 0.0, "withdrawal_count_24h": 0, "unique_instruments_7d": 0, "slot_session_count_24h": 0, "weekend_activity_ratio": 0.0, "baseline_stddev_deposit": 0.0, "bonus_to_real_ratio_30d": 0.0, "shared_instrument_score": 0.0, "bet_product_diversity_7d": 0, "casino_session_count_24h": 0, "failed_deposit_count_24h": 0, "shared_bank_account_count": 0, "baseline_avg_daily_deposit": 0.0, "inconsistent_currency_flag": false, "unique_instruments_used_7d": 0, "new_payment_instrument_flag": true, "bonus_to_real_money_ratio_30d": 0.0, "ratio_withdrawal_to_deposit_7d": 0.0, "avg_deposit_to_withdrawal_hours": null, "zscore_current_deposit_vs_baseline": 0.0, "avg_time_between_deposit_and_withdrawal_7d": null}	\N	2026-05-22 16:02:00.784083+00	2026-05-22	2
\.


--
-- Data for Name: financial_transactions; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.financial_transactions (id, tenant_id, player_id, external_tx_id, source_system, type, amount, currency, status, payment_method, payment_instrument, bank_account_hash, source_event_id, ingest_job_id, raw_payload, occurred_at, settled_at, created_at, payment_method_flagged) FROM stdin;
a2674e67-519a-4cb7-8734-a8afe5396b25	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	100.00	BRL	SETTLED	PIX	{}	\N	6b1f6ebe-94ef-44a3-9f79-fb06fb0cf61e	\N	{"amount": 100, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "erase_test_gap7_2664b238", "occurred_at": "2026-05-22T15:46:31.679089Z", "transaction_type": "DEPOSIT"}	2026-05-22 15:46:31.679089+00	\N	2026-05-22 15:46:33.146801+00	f
c8d5fc5e-0af1-42aa-958d-3578a47b6364	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	23b9d36d-0c52-4e54-91f1-edb5d8f822d3	\N	BackofficeAlpha	DEPOSIT	100.00	BRL	SETTLED	PIX	{}	\N	d9b89e04-f790-4e70-832c-4d74b1d433d8	\N	{"amount": 100, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "erase_test_gap7_1bf4e916", "occurred_at": "2026-05-22T15:46:32.608711Z", "transaction_type": "DEPOSIT"}	2026-05-22 15:46:32.608711+00	\N	2026-05-22 15:46:33.322256+00	f
fa71e945-ad71-4df7-9db3-ff78dd3ac0d1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	8d4103fe-aa4b-493d-b734-03bd6eb82e91	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-de52eca9", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:49.391229+00	f
6e1f4052-0f30-45ff-811e-ccd36676b091	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	119596b3-bc72-4818-880a-1c7a094719f9	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-9631e91f", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:49.700715+00	f
09c87f34-64ed-4d4e-9d10-522c6adb7150	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	dab05bb2-64eb-4e6e-a734-571a3eb30b50	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-048bec6e", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:50.152564+00	f
dd192567-4201-4612-ba03-e65d04e84d4a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	503c86fd-70e4-46d7-8069-9fd2b7ed2875	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-2c8c35f1", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:50.372365+00	f
a49660de-8035-43bc-b815-a22da48e7497	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	fd8235d5-c2cf-4a90-92d2-6b08bd9eca9c	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-0ae20593", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:50.574384+00	f
217a6eb7-68b4-4070-a6c7-70eb3b6cddc3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	7cb00677-baf1-43a3-963d-b74938e01211	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-e4d66115", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:50.759066+00	f
0b74a0b7-b960-41f8-bb0f-92f0b19c03ed	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	89648d94-4f76-4692-8499-552196e28789	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-1da72f35", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:51.095623+00	f
56a8ea9d-8609-4d91-987c-108c55d8061c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	dd191847-d6ee-46b5-b40a-5727e3592b07	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-a9bbd403", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:51.482887+00	f
77db2248-f452-4943-9567-087cab3f9cfd	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	586ac666-a22a-4774-843e-18ced729c28b	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-28718511", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:51.95488+00	f
f6809c10-70ff-487f-8007-82769892be3e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	a0aa2ff8-648d-4d46-8326-04149a27d86a	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-4aa4fe24", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:52.256234+00	f
39f8c4c7-7766-4b3f-9290-191e1f981041	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	20d39843-3cfb-466f-bfef-d845aa44d92a	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-d5764db4", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:52.473088+00	f
a6c97ca7-a4da-48da-a5c0-b334d204dc2e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	82c74db6-2df9-423b-a56f-0f358ee48ab4	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-4a1afbc4", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:52.649897+00	f
9b73ba90-b8b6-4cab-a06a-4fc8c2cc9e2d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	6d5d72a1-5a02-4aa6-992c-5ed671c765cc	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-3cd369b8", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:52.853056+00	f
7b492f1b-2ce7-4d8e-8ad9-04b9eafdff21	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	3ada6e9f-5e13-4cb4-b6dd-71d78cd57d3c	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-e923774e", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:53.040014+00	f
7945b91d-9a9b-40ab-99e3-51c44285af30	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	f8c844a8-12c5-476d-b964-c948a53aa4c7	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-3fb44483", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:56.247832+00	f
b5722027-850e-4629-8332-92a7128075b3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	9700.00	BRL	SETTLED	PIX	{}	\N	3dfdeb13-157e-4ca9-8814-2b76c7de71ad	\N	{"amount": 9700.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-E2E-23a588", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:46:56.47656+00	f
772f2053-a62e-4e0e-b0ec-fcf287b4b928	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	100.00	BRL	SETTLED	PIX	{}	\N	2f9a8e1d-356d-419d-8753-2fd1c06acffb	\N	{"amount": 100, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "erase_test_gap7_9401aff0", "occurred_at": "2026-05-22T15:54:43.333973Z", "transaction_type": "DEPOSIT"}	2026-05-22 15:54:43.333973+00	\N	2026-05-22 15:54:43.623856+00	f
31b435df-64e7-48fe-9b72-e2f253f8a7d8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	c7f730d3-4c94-4659-b411-9ec765f4e63a	\N	BackofficeAlpha	DEPOSIT	100.00	BRL	SETTLED	PIX	{}	\N	82ced2cb-0f93-423f-88c6-4d4ec556b451	\N	{"amount": 100, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "erase_test_gap7_e6c634c9", "occurred_at": "2026-05-22T15:54:43.925810Z", "transaction_type": "DEPOSIT"}	2026-05-22 15:54:43.92581+00	\N	2026-05-22 15:54:44.162611+00	f
c507a9fe-3b9f-4981-9c0b-e788e18ec2cc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	29d27f36-aacf-48b2-b420-e3416a053dd3	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-4d24a573", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:00.387304+00	f
43f14152-ebb5-4727-b260-92cb3535baeb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	6d335ca2-c8f8-4adc-aca1-b112cd6da28e	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-bea97316", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:00.588143+00	f
81bafa67-86f6-46e4-8ce7-96c5c9cdae04	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	0f0f1318-c92f-45af-9d70-40fa017ed6d2	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-1842f33b", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:00.810955+00	f
dccbf186-c7ce-466f-bb55-0225e62a8ee0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	500e06dc-3a5e-4cab-950e-ea029c1948af	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-63929508", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:01.019982+00	f
8007796d-af63-4835-b67e-6a83e87d94d6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	7df0c888-e761-4059-8c22-3b1976612dcf	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-56032d30", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:01.538399+00	f
53688d6c-d843-4526-87ca-8aeb4e8c38a0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	f0eb23b9-e0b2-463d-9456-ffbaaa1ac6ca	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-0e5d1841", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:01.771387+00	f
d34f0530-d580-4b8a-bc8c-74e7377dc258	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	b9b50970-449b-44e4-8364-ea5943c32fa5	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-6254bd2d", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:02.175978+00	f
7cd490e4-08c8-40ce-a7be-3da9c4fc5541	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	91a7e675-b183-4173-9814-3391967d6ed3	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-74143f7d", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:02.688522+00	f
044579f7-bbf9-41f1-bef4-3248b7d87f25	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	fb610306-bdfb-4065-80df-91097c844293	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-eaba4627", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:03.05357+00	f
203d2f2b-14db-49a6-b628-d857e233085d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	ab396834-ad42-415e-8cff-a0675d257ace	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-b6bdaad3", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:03.316823+00	f
47e1e03f-665e-4ba2-ae8f-c4720208be1d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	2de39c3e-8da9-4727-9249-e5619f17d7cf	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-e04e8876", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:03.515489+00	f
4951987d-98e3-4081-b0f5-39c2e6e8bc45	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	f97fbf14-b9c1-4724-8175-e3d2c6aba719	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-27ac68b0", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:03.760633+00	f
95e1b772-07a5-4fa8-9518-f223126b4289	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	9b181b02-b4c7-4fa1-bc4a-4aff8bceba88	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-c1bba6be", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:03.992331+00	f
b2d209f9-45c9-43b4-a1e5-55e9eeebbb94	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	d30c8869-e00c-4639-903f-6d7a0344ed5b	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-7fd14fa8", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:04.268594+00	f
c3584eaf-d667-4650-85df-6a2e412acb30	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	bfe562e2-e1c0-4589-ad9c-102e5c30101f	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-d8c15b5e", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:08.259521+00	f
279a3857-aa31-4f98-8475-71c44808829e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	9700.00	BRL	SETTLED	PIX	{}	\N	b84e7a5f-4c80-4fe7-8140-2e2cf55a1510	\N	{"amount": 9700.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-E2E-e3a1f4", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 15:55:08.438713+00	f
1dc983ac-3faa-4a62-a249-2a1658ebc2be	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	34f63a9b-3a0d-4678-8594-82483e32af4f	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-91b95ebd", "occurred_at": "2026-03-20T10:00:00Z", "transaction_type": "DEPOSIT"}	2026-03-20 10:00:00+00	\N	2026-05-22 16:01:12.769374+00	f
973928ec-ee29-452d-b508-182fac3b12b5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	2d2284a0-bc44-46e5-80f2-c26de8fb6045	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-bc7ac07b", "occurred_at": "2026-03-20T10:00:00Z", "transaction_type": "DEPOSIT"}	2026-03-20 10:00:00+00	\N	2026-05-22 16:01:13.584717+00	f
fe7fb5f6-0766-43eb-8352-5f374792228f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	d63c01ea-2d11-4ad9-b085-932ca57f7234	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-a8807a5a", "occurred_at": "2026-03-20T10:00:00Z", "transaction_type": "DEPOSIT"}	2026-03-20 10:00:00+00	\N	2026-05-22 16:01:31.987791+00	f
77a3d2e1-1bee-48b8-98fd-251842999675	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	100.00	BRL	SETTLED	PIX	{}	\N	badb56fb-968a-4166-bbff-de3aaacc5e74	\N	{"amount": 100, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "erase_test_gap7_bf1480e2", "occurred_at": "2026-05-22T16:01:58.889982Z", "transaction_type": "DEPOSIT"}	2026-05-22 16:01:58.889982+00	\N	2026-05-22 16:01:59.423715+00	f
a0c4c5be-3dbc-4c0f-9399-1823e8d97bcb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	3dca48e5-9da8-452f-b1f6-2533bf111baf	\N	BackofficeAlpha	DEPOSIT	100.00	BRL	SETTLED	PIX	{}	\N	8bc94a7b-da4a-4337-88a3-93abe0883825	\N	{"amount": 100, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "erase_test_gap7_458fbe56", "occurred_at": "2026-05-22T16:02:00.580107Z", "transaction_type": "DEPOSIT"}	2026-05-22 16:02:00.580107+00	\N	2026-05-22 16:02:00.912666+00	f
f5abed52-f717-4649-a179-f10f7cf46dc2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	621eb188-4831-49ec-82cf-56f5b1a4742e	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-3376c487", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:16.468989+00	f
df7a106d-0af0-4284-a064-01ca01f7eef3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	1a03db62-ad96-4aaa-8e92-0a6c12cae4f3	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-e2e67d58", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:16.666103+00	f
ea7bb0fb-65fa-423d-9aa6-89e31fdbdbea	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	98fef229-b0e8-4d7a-b488-817506e9bd15	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-7286f419", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:16.864048+00	f
a7c541ec-8276-4943-bcb4-8f3227395d42	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	10f134f4-dc22-42ac-9004-a03c6e30160f	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-124c9f89", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:17.092187+00	f
d3fa576d-979a-4ee0-8cff-aa0595403bb2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	08015e3c-1ede-4d79-8cbc-e1ad90efd084	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-21bcb2a2", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:17.321754+00	f
20e7e28e-54b1-4aff-bddf-2a53b89f1195	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	239181f9-6906-4211-b2d6-e32c09262dc6	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-9d71f9d6", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:17.847543+00	f
36e975c8-fcb8-4064-b49d-7a179bc24486	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	08120590-5b56-4540-a47b-c03ddf729992	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-73512a5f", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:17.744756+00	f
1c6d78bc-f30a-4424-84fa-cb77eaffb847	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	7a4c117f-0ffd-4c2d-8dc1-cae0ac36fa5d	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-42471807", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:18.66601+00	f
8978a536-e36f-485c-aad6-31bcf8877a26	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	6b517799-aa14-4bc0-9726-aaa68029dd94	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-c48d97da", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:19.411792+00	f
21a06a38-9074-4473-91ae-edd6d380cf0b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	ae17e02b-1c27-4b01-9dee-177c9f91d401	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-073efac1", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:19.712052+00	f
a0cf2ca3-4268-4c1b-acd0-88547f30cdf4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	d38b6924-64d7-425f-a0d8-cc5aa688f559	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-477b2e01", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:19.986116+00	f
f753491c-76bf-4a7d-b5f5-6f9ac2fa68b3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	28f07fd5-1ece-442f-b737-8ead581f0ef7	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-eb4af8fc", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:20.121779+00	f
b2e08938-7bfb-40ee-b811-497a472f9d69	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	8fe6bf38-6b78-48c3-a04d-e846e2cc8362	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-d36afb0a", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:20.285204+00	f
221d8b80-3174-498d-960e-888826257e4f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	9a726058-f99b-4995-84aa-f8749a8171b2	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-e2cbe9d4", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:20.477513+00	f
f7a0a75f-9ff0-4515-bf12-f294a5911a94	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	4458232b-23f1-460d-9afa-9c5cc65f478b	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-6c57405d", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:22.823586+00	f
aa985308-57c4-4729-b56e-ade07b7b4fa6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	9700.00	BRL	SETTLED	PIX	{}	\N	6f462123-b2d1-46f9-9939-b7dca8714154	\N	{"amount": 9700.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-E2E-7c0b4a", "occurred_at": "2024-06-15T10:00:00Z", "transaction_type": "DEPOSIT"}	2024-06-15 10:00:00+00	\N	2026-05-22 16:02:22.997926+00	f
10055cff-2700-4309-8da9-6fd4098391f8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	0.00	BRL	SETTLED	\N	{}	\N	1f7992db-3887-4ae5-9f5a-1982c2259dc7	\N	{"txnId": "TXN-369a74fd", "txnType": "DEPOSIT", "playerId": "PLY-0d6b2c39", "txnAmount": "2000.0", "txnStatus": "SETTLED", "txnTimestamp": "2024-06-15T10:00:00Z"}	2026-05-22 16:02:39.697867+00	\N	2026-05-22 16:02:39.700298+00	f
826344e6-fcce-4640-b9a8-f4f00a3b821b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	0.00	BRL	SETTLED	\N	{}	\N	e7fd9fe8-f514-4133-bbb4-83f92e2587d2	\N	{"txnId": "TXN-80ac9e95", "txnType": "DEPOSIT", "playerId": "PLY-7de2ec52", "txnAmount": "1000.0", "txnStatus": "SETTLED", "txnTimestamp": "2024-06-15T10:00:00Z"}	2026-05-22 16:02:39.975133+00	\N	2026-05-22 16:02:39.976828+00	f
02c38efd-a219-4f83-863f-c02fcc0cfd78	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	0.00	BRL	SETTLED	\N	{}	\N	b61918e5-3ef1-4072-9b43-fd42f2f05065	\N	{"txnId": "TXN-d56d5f0d", "txnType": "DEPOSIT", "playerId": "PLY-88eae3e1", "txnAmount": "3000.0", "txnStatus": "SETTLED", "txnTimestamp": "2024-06-15T10:00:00Z"}	2026-05-22 16:02:40.112909+00	\N	2026-05-22 16:02:40.11492+00	f
0f8141ca-4cef-4c07-9277-983303a8b700	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	0.00	BRL	SETTLED	\N	{}	\N	454cd21b-3c3f-4775-88f9-b2ca2ffb5d53	\N	{"txnId": "TXN-78da49be", "txnType": "DEPOSIT", "playerId": "PLY-90388593", "txnAmount": "3000.0", "txnStatus": "SETTLED", "txnTimestamp": "2024-06-15T10:00:00Z"}	2026-05-22 16:02:40.283388+00	\N	2026-05-22 16:02:40.284841+00	f
2b6a571d-c4b3-4681-89ff-6c44907a1063	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	0.00	BRL	SETTLED	\N	{}	\N	44124abc-de25-44d6-a272-2af82bfd3d11	\N	{"txnId": "TXN-b8929056", "txnType": "DEPOSIT", "playerId": "PLY-27cad379", "txnAmount": "5000.0", "txnStatus": "SETTLED", "txnTimestamp": "2024-06-15T10:00:00Z"}	2026-05-22 16:02:40.424021+00	\N	2026-05-22 16:02:40.425541+00	f
96f24849-7fa0-4edd-b806-bb595e67c3f7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	0.00	BRL	SETTLED	\N	{}	\N	962afdb1-f201-4bcf-b548-007a8d7a0bd2	\N	{"txnId": "TXN-a79e89ca", "txnType": "DEPOSIT", "playerId": "PLY-a159e89d", "txnAmount": "2000.0", "txnStatus": "SETTLED", "txnTimestamp": "2024-06-15T10:00:00Z"}	2026-05-22 16:02:40.577321+00	\N	2026-05-22 16:02:40.579176+00	f
4bea7054-618e-4287-a6d9-7b9b59ae43fe	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	0.00	BRL	SETTLED	\N	{}	\N	2b950e8e-8dcb-4226-b018-c23f04b939d1	\N	{"txnId": "TXN-74bacdfb", "txnType": "DEPOSIT", "playerId": "PLY-a737421a", "txnAmount": "4000.0", "txnStatus": "SETTLED", "txnTimestamp": "2024-06-15T10:00:00Z"}	2026-05-22 16:02:40.721942+00	\N	2026-05-22 16:02:40.723515+00	f
58d09473-847e-40ed-b6f8-c947cd64f416	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	0.00	BRL	SETTLED	\N	{}	\N	70c48795-4249-4fa0-897d-2abc32bae758	\N	{"txnId": "TXN-fc8f2dd8", "txnType": "DEPOSIT", "playerId": "PLY-4f5e880e", "txnAmount": "1000.0", "txnStatus": "SETTLED", "txnTimestamp": "2024-06-15T10:00:00Z"}	2026-05-22 16:02:40.868448+00	\N	2026-05-22 16:02:40.870236+00	f
8693e4a9-5813-485c-801e-e8fb21af6b1c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	0.00	BRL	SETTLED	\N	{}	\N	3537db72-9e06-45b5-a55d-edf6c4e606ec	\N	{"txnId": "TXN-397a4403", "txnType": "DEPOSIT", "playerId": "PLY-b69ec305", "txnAmount": "1000.0", "txnStatus": "SETTLED", "txnTimestamp": "2024-06-15T10:00:00Z"}	2026-05-22 16:02:41.202464+00	\N	2026-05-22 16:02:41.203948+00	f
744f2295-bfcf-41f2-8b90-e84cfe1d1dba	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	0.00	BRL	SETTLED	\N	{}	\N	959b530b-0797-404d-91ff-4d9c1e06de10	\N	{"txnId": "TXN-89537411", "txnType": "DEPOSIT", "playerId": "PLY-5461708c", "txnAmount": "2000.0", "txnStatus": "SETTLED", "txnTimestamp": "2024-06-15T10:00:00Z"}	2026-05-22 16:02:41.336544+00	\N	2026-05-22 16:02:41.337914+00	f
bca865d2-fab0-4c21-a905-86478c610d88	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	\N	\N	BackofficeAlpha	DEPOSIT	1500.00	BRL	SETTLED	PIX	{}	\N	9397852e-55fb-4a07-92fc-a2a55236534b	\N	{"amount": 1500.0, "method": "PIX", "status": "SETTLED", "currency": "BRL", "player_id": "PLY-5742cf93", "occurred_at": "2026-03-20T10:00:00Z", "transaction_type": "DEPOSIT"}	2026-03-20 10:00:00+00	\N	2026-05-22 16:02:52.291238+00	f
\.


--
-- Data for Name: ingest_errors; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.ingest_errors (id, tenant_id, ingest_job_id, source_system, entity_type, raw_payload, error_reason, error_detail, line_number, resolved, resolved_by, resolved_at, created_at) FROM stdin;
e1e958a6-3456-4e0e-8662-5fd214bd3814	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	7f4ec6ad-c77f-472a-901c-38eafdeeff43	ConnectorGamma	transaction	{"id": "TXG-1", "player_id": "PLY-G-1", "type": "DEPOSIT", "amount": "1200.50", "currency": "BRL", "timestamp": "2026-03-09T10:00:00Z", "source_system": "ConnectorGamma"}	validation_failed: empty_required_fields=['external_transaction_id', 'occurred_at', 'player_cpf', 'type']	{"stage": "validation", "connector": "gamma", "mapping_config_id": null}	\N	f	\N	\N	2026-05-22 15:46:50.387064+00
9c949ea5-084c-4d9a-bf28-48b93c99dc5e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	9ca70809-3f7a-45e0-82ce-855cd78a303b	ConnectorGamma	transaction	{"id": "TXG-EX-1", "player_id": "PLY-G-EX-1", "type": "DEPOSIT", "amount": "777.0", "currency": "BRL", "timestamp": "2026-03-09T10:00:00Z", "source_system": "ConnectorGamma"}	validation_failed: empty_required_fields=['external_transaction_id', 'occurred_at', 'player_cpf', 'type']	{"stage": "validation", "connector": "gamma", "mapping_config_id": "c4b6334e-d490-4708-b59b-b1c8af9313c7"}	\N	f	\N	\N	2026-05-22 15:46:50.710176+00
ee791fba-b68e-4f69-a568-ede8d678b5bf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	0a0cd981-12ce-4cea-a31b-9c17cbb15efd	ConnectorDelta	transaction	{"source_system": "ConnectorDelta", "id": "TXD-1", "player_id": "PLY-D-1", "evt_type": "DEPOSIT", "amount": 500.0, "ts": "2026-03-09T10:01:00Z", "currency": "BRL"}	validation_failed: empty_required_fields=['amount', 'player_cpf']; amount inválido: None	{"stage": "validation", "connector": "delta", "mapping_config_id": null}	\N	f	\N	\N	2026-05-22 15:46:50.98112+00
9035b3cd-4bba-4b2f-9d95-b936dd837806	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	0a0cd981-12ce-4cea-a31b-9c17cbb15efd	ConnectorDelta	transaction	{"source_system": "ConnectorDelta", "id": "TXD-2", "player_id": "PLY-D-2", "evt_type": "WITHDRAWAL", "amount": 100.0, "ts": "2026-03-09T10:02:00Z", "currency": "BRL"}	validation_failed: empty_required_fields=['amount', 'player_cpf']; amount inválido: None	{"stage": "validation", "connector": "delta", "mapping_config_id": null}	\N	f	\N	\N	2026-05-22 15:46:50.98112+00
e5fc2ca5-a978-4fc2-8709-8b06efce2385	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	4b98108a-3351-422c-a82b-0123d962f8d6	ConnectorEpsilon	TRANSACTION	{"events": [{"event_id": "evt-eps-f7e575d3", "player_id": "PLY-EPS-43ed24", "event_type": "DEPOSIT", "gross_amount": 999.9, "event_time": "2026-03-09T10:03:00Z", "currency_code": "BRL"}]}	Invalid signature	{"line": null, "channel": "webhook", "connector": "epsilon"}	\N	f	\N	\N	2026-05-22 15:46:51.381492+00
01a7444c-0e43-4b0b-85f3-4a2ff0eae53d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	bc8ac885-086d-4090-90e3-b18db8a0ad94	ConnectorGamma	TRANSACTION	{"event_id": null, "external_player_id": "CPF-REPLAY-01", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "100.00", "occurred_at": "2026-03-10T10:00:00Z", "source_system": "ConnectorGamma"}	validation_failed: empty_required_fields=['external_transaction_id']	{"stage": "validation", "replay": {"note": "correção manual de payload", "status": "QUEUED", "event_id": "6fee4db2-92cd-43ab-b9c8-0d54bb1c0edc", "entity_type": "TRANSACTION", "replayed_at": "2026-05-22T15:46:52.562924+00:00", "replayed_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "apply_mapping": true, "source_event_id": "evt-replay-421f1b4b", "mapping_config_id": "c4b6334e-d490-4708-b59b-b1c8af9313c7", "mapping_version_id": "c4b6334e-d490-4708-b59b-b1c8af9313c7"}, "connector": "gamma", "mapping_config_id": "c4b6334e-d490-4708-b59b-b1c8af9313c7"}	\N	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:52.56304+00	2026-05-22 15:46:52.464149+00
ce3ef407-5745-4e5f-aad4-1a5c5008bd29	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	daaccf0d-7205-44d6-b819-adce00cb9ceb	ConnectorEpsilon	TRANSACTION	{"events": [{"event_id": "evt-eps-c2e266ce", "player_id": "PLY-EPS-247186", "event_type": "DEPOSIT", "gross_amount": 999.9, "event_time": "2026-03-09T10:03:00Z", "currency_code": "BRL"}]}	Invalid signature	{"line": null, "channel": "webhook", "connector": "epsilon"}	\N	f	\N	\N	2026-05-22 15:52:53.383722+00
cdec9d33-0d93-4179-8808-c35a522fafda	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ee2893b6-8ed3-4989-8f6e-163292310ecf	ConnectorEpsilon	TRANSACTION	{"events": [{"event_id": "evt-eps-4a82b4a4", "player_id": "PLY-EPS-ba6ed0", "event_type": "DEPOSIT", "gross_amount": 999.9, "event_time": "2026-03-09T10:03:00Z", "currency_code": "BRL"}]}	Invalid signature	{"line": null, "channel": "webhook", "connector": "epsilon"}	\N	f	\N	\N	2026-05-22 15:55:02.857195+00
d9c1d011-5b2d-476c-960f-f1ad45486775	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	3eb52f04-4eb5-4e28-9f06-6d952c807746	ConnectorGamma	TRANSACTION	{"event_id": null, "external_player_id": "CPF-REPLAY-01", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "100.00", "occurred_at": "2026-03-10T10:00:00Z", "source_system": "ConnectorGamma"}	validation_failed: empty_required_fields=['external_transaction_id']	{"stage": "validation", "replay": {"note": "correção manual de payload", "status": "QUEUED", "event_id": "2116a091-86cd-42d3-acc5-25a2f8847bf4", "entity_type": "TRANSACTION", "replayed_at": "2026-05-22T15:55:03.979213+00:00", "replayed_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "apply_mapping": true, "source_event_id": "evt-replay-464f63eb", "mapping_config_id": "3ae3ca80-84ea-4b5d-a31f-f715f543ee53", "mapping_version_id": "3ae3ca80-84ea-4b5d-a31f-f715f543ee53"}, "connector": "gamma", "mapping_config_id": "3ae3ca80-84ea-4b5d-a31f-f715f543ee53"}	\N	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:03.979444+00	2026-05-22 15:55:03.83031+00
8ba07777-625f-424e-8a25-f2277f3de806	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a3a592f4-0f1e-47aa-8ec7-4a32bc1bcbf2	ConnectorEpsilon	TRANSACTION	{"events": [{"event_id": "evt-eps-e0a35b53", "player_id": "PLY-EPS-11e241", "event_type": "DEPOSIT", "gross_amount": 999.9, "event_time": "2026-03-09T10:03:00Z", "currency_code": "BRL"}]}	Invalid signature	{"line": null, "channel": "webhook", "connector": "epsilon"}	\N	f	\N	\N	2026-05-22 16:02:18.67623+00
4ac7cab0-f963-47d6-9cc9-a6de8a6eb7f2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	12e23da3-a8b2-440b-b3f1-ac2643bfc8e0	ConnectorGamma	TRANSACTION	{"event_id": null, "external_player_id": "CPF-REPLAY-01", "transaction_type": "DEPOSIT", "currency": "BRL", "amount": "100.00", "occurred_at": "2026-03-10T10:00:00Z", "source_system": "ConnectorGamma"}	validation_failed: empty_required_fields=['external_transaction_id']	{"stage": "validation", "replay": {"note": "correção manual de payload", "status": "QUEUED", "event_id": "2b712449-f86a-4568-8606-5b37d22ef749", "entity_type": "TRANSACTION", "replayed_at": "2026-05-22T16:02:20.227205+00:00", "replayed_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "apply_mapping": true, "source_event_id": "evt-replay-f661a84c", "mapping_config_id": "df93c57c-5ce2-4ff3-a291-ba9bcfc45673", "mapping_version_id": "df93c57c-5ce2-4ff3-a291-ba9bcfc45673"}, "connector": "gamma", "mapping_config_id": "df93c57c-5ce2-4ff3-a291-ba9bcfc45673"}	\N	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:20.227276+00	2026-05-22 16:02:20.122798+00
\.


--
-- Data for Name: ingest_jobs; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.ingest_jobs (id, tenant_id, source_system, mapping_config_id, file_name, file_size_bytes, file_path, status, total_records, processed_records, failed_records, error_message, created_by, created_at, updated_at, bytes_processed, duration_ms, error_sample, connector_type, reprocessed_from, mapping_version_id, ingest_mode, is_backfill) FROM stdin;
7f4ec6ad-c77f-472a-901c-38eafdeeff43	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorGamma	\N	gamma.xml	288	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/7f4ec6ad-c77f-472a-901c-38eafdeeff43/gamma.xml	FAILED	1	0	1	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:50.214927+00	2026-05-22 15:46:50.387064+00	288	\N	[{"raw": {"id": "TXG-1", "type": "DEPOSIT", "amount": "1200.50", "currency": "BRL", "player_id": "PLY-G-1", "timestamp": "2026-03-09T10:00:00Z", "source_system": "ConnectorGamma"}, "line": null, "reason": "validation_failed: empty_required_fields=['external_transaction_id', 'occurred_at', 'player_cpf', 'type']"}]	FILE	\N	\N	incremental	f
92d7dae2-b3c3-46e9-9ee6-a587e218c6ad	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	transactions.csv	266	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/92d7dae2-b3c3-46e9-9ee6-a587e218c6ad/transactions.csv	DONE	3	3	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:56.462767+00	2026-05-22 15:46:57.536085+00	486	82	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
9ca70809-3f7a-45e0-82ce-855cd78a303b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorGamma	c4b6334e-d490-4708-b59b-b1c8af9313c7	gamma-explicit.xml	292	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/9ca70809-3f7a-45e0-82ce-855cd78a303b/gamma-explicit.xml	FAILED	1	0	1	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:50.640936+00	2026-05-22 15:46:50.710176+00	292	\N	[{"raw": {"id": "TXG-EX-1", "type": "DEPOSIT", "amount": "777.0", "currency": "BRL", "player_id": "PLY-G-EX-1", "timestamp": "2026-03-09T10:00:00Z", "source_system": "ConnectorGamma"}, "line": null, "reason": "validation_failed: empty_required_fields=['external_transaction_id', 'occurred_at', 'player_cpf', 'type']"}]	FILE	\N	c4b6334e-d490-4708-b59b-b1c8af9313c7	incremental	f
0a0cd981-12ce-4cea-a31b-9c17cbb15efd	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorDelta	\N	delta.ndjson	205	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/0a0cd981-12ce-4cea-a31b-9c17cbb15efd/delta.ndjson	FAILED	2	0	2	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:50.841016+00	2026-05-22 15:46:50.98112+00	205	\N	[{"raw": {"id": "TXD-1", "ts": "2026-03-09T10:01:00Z", "amount": 500.0, "currency": "BRL", "evt_type": "DEPOSIT", "player_id": "PLY-D-1", "source_system": "ConnectorDelta"}, "line": null, "reason": "validation_failed: empty_required_fields=['amount', 'player_cpf']; amount inválido: None"}, {"raw": {"id": "TXD-2", "ts": "2026-03-09T10:02:00Z", "amount": 100.0, "currency": "BRL", "evt_type": "WITHDRAWAL", "player_id": "PLY-D-2", "source_system": "ConnectorDelta"}, "line": null, "reason": "validation_failed: empty_required_fields=['amount', 'player_cpf']; amount inválido: None"}]	FILE	\N	\N	incremental	f
8dd102b0-2c22-4a53-a519-a6ec65e64cf0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	test_batch.csv	406	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/8dd102b0-2c22-4a53-a519-a6ec65e64cf0/test_batch.csv	DONE	5	5	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:56.595183+00	2026-05-22 15:46:57.469711+00	810	147	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
4b98108a-3351-422c-a82b-0123d962f8d6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorEpsilon	\N	epsilon-webhook-20260522T154651294305Z.json	187	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/4b98108a-3351-422c-a82b-0123d962f8d6/epsilon-webhook-20260522T154651294305Z.json	FAILED	0	0	1	webhook_validation_failed	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:51.259649+00	2026-05-22 15:46:51.381492+00	187	86	[{"raw": "{\\"events\\": [{\\"event_id\\": \\"evt-eps-f7e575d3\\", \\"player_id\\": \\"PLY-EPS-43ed24\\", \\"event_type\\": \\"DEPOSIT\\", \\"gross_amount\\": 999.9, \\"event_time\\": \\"2026-03-09T10:03:00Z\\", \\"currency_code\\": \\"BRL\\"}]}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
bc8ac885-086d-4090-90e3-b18db8a0ad94	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorGamma	c4b6334e-d490-4708-b59b-b1c8af9313c7	gamma-invalid.xml	230	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/bc8ac885-086d-4090-90e3-b18db8a0ad94/gamma-invalid.xml	FAILED	1	0	1	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:52.381044+00	2026-05-22 15:46:52.464149+00	230	\N	[{"raw": {"amount": "100.00", "currency": "BRL", "event_id": null, "occurred_at": "2026-03-10T10:00:00Z", "source_system": "ConnectorGamma", "transaction_type": "DEPOSIT", "external_player_id": "CPF-REPLAY-01"}, "line": null, "reason": "validation_failed: empty_required_fields=['external_transaction_id']"}]	FILE	\N	c4b6334e-d490-4708-b59b-b1c8af9313c7	incremental	f
346fb240-1885-4e05-a7ed-8fa8de3920a5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	isolation_test.csv	196	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/346fb240-1885-4e05-a7ed-8fa8de3920a5/isolation_test.csv	DONE	2	2	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:59.007434+00	2026-05-22 15:46:59.344861+00	324	93	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
1a60c9ca-ae17-450b-b611-0e850ffc5a91	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/1a60c9ca-ae17-450b-b611-0e850ffc5a91/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 15:47:29.731936+00	2026-05-22 15:47:30.871783+00	172	217	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
2bd78656-7b42-4456-bb9b-0ef9df09d0a0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/2bd78656-7b42-4456-bb9b-0ef9df09d0a0/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 15:47:29.149394+00	2026-05-22 15:47:30.320577+00	172	400	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
f35bbcb9-f094-4d08-b774-ab6d8eae9a31	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/f35bbcb9-f094-4d08-b774-ab6d8eae9a31/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 15:47:30.767802+00	2026-05-22 15:47:32.376391+00	172	176	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
ca239290-f7a6-456d-a656-fbc79f32432a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/ca239290-f7a6-456d-a656-fbc79f32432a/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 15:47:30.283399+00	2026-05-22 15:47:31.931132+00	172	198	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
c1874eb9-1017-46d1-b679-58259117c655	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	transacoes_reais_exemplo.csv	837	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/c1874eb9-1017-46d1-b679-58259117c655/transacoes_reais_exemplo.csv	DONE	10	10	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:47:35.331647+00	2026-05-22 15:47:35.597648+00	2028	106	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
55bba683-3c19-4493-a06d-1e1bc26fdf99	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorGamma	c4b6334e-d490-4708-b59b-b1c8af9313c7	gamma.xml	288	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/55bba683-3c19-4493-a06d-1e1bc26fdf99/gamma.xml	DONE	1	1	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:52:52.591673+00	2026-05-22 15:52:52.793453+00	288	\N	[]	FILE	\N	c4b6334e-d490-4708-b59b-b1c8af9313c7	incremental	f
2f0d97b9-c513-4fdf-9636-b60521679587	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorDelta	58e56f03-653a-4f40-acdd-4c5003eaa35f	delta.ndjson	205	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/2f0d97b9-c513-4fdf-9636-b60521679587/delta.ndjson	DONE	2	2	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:52:52.852668+00	2026-05-22 15:52:52.94285+00	205	\N	[]	FILE	\N	58e56f03-653a-4f40-acdd-4c5003eaa35f	incremental	f
42c51d31-fd8b-4433-99a3-c8951fbfb270	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorEpsilon	\N	epsilon-webhook-20260522T155253084302Z.json	187	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/42c51d31-fd8b-4433-99a3-c8951fbfb270/epsilon-webhook-20260522T155253084302Z.json	DONE	1	1	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:52:53.030612+00	2026-05-22 15:52:53.175073+00	187	89	[]	WEBHOOK	\N	\N	incremental	f
daaccf0d-7205-44d6-b819-adce00cb9ceb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorEpsilon	\N	epsilon-webhook-20260522T155253323955Z.json	187	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/daaccf0d-7205-44d6-b819-adce00cb9ceb/epsilon-webhook-20260522T155253323955Z.json	FAILED	0	0	1	webhook_validation_failed	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:52:53.261032+00	2026-05-22 15:52:53.383722+00	187	58	[{"raw": "{\\"events\\": [{\\"event_id\\": \\"evt-eps-c2e266ce\\", \\"player_id\\": \\"PLY-EPS-247186\\", \\"event_type\\": \\"DEPOSIT\\", \\"gross_amount\\": 999.9, \\"event_time\\": \\"2026-03-09T10:03:00Z\\", \\"currency_code\\": \\"BRL\\"}]}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
c6b8b220-cb83-4247-b436-619a8118252f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorGamma	c4b6334e-d490-4708-b59b-b1c8af9313c7	gamma.xml	288	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/c6b8b220-cb83-4247-b436-619a8118252f/gamma.xml	DONE	1	1	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:01.278133+00	2026-05-22 15:55:01.551146+00	288	\N	[]	FILE	\N	c4b6334e-d490-4708-b59b-b1c8af9313c7	incremental	f
744dc438-3052-4f8e-a3e5-8011038d283c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorGamma	3ae3ca80-84ea-4b5d-a31f-f715f543ee53	gamma-explicit.xml	292	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/744dc438-3052-4f8e-a3e5-8011038d283c/gamma-explicit.xml	DONE	1	1	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:01.694199+00	2026-05-22 15:55:01.773773+00	292	\N	[]	FILE	\N	3ae3ca80-84ea-4b5d-a31f-f715f543ee53	incremental	f
2a514130-eecb-46cf-9852-664253ae63da	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	transactions.csv	266	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/2a514130-eecb-46cf-9852-664253ae63da/transactions.csv	DONE	3	3	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:24.095108+00	2026-05-22 15:55:25.766943+00	486	621	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
7554f758-2e66-4eac-977a-219e13846fe5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorDelta	58e56f03-653a-4f40-acdd-4c5003eaa35f	delta.ndjson	205	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/7554f758-2e66-4eac-977a-219e13846fe5/delta.ndjson	DONE	2	2	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:01.995517+00	2026-05-22 15:55:02.168633+00	205	\N	[]	FILE	\N	58e56f03-653a-4f40-acdd-4c5003eaa35f	incremental	f
a580e8b4-35a1-4bd0-8df4-e2136f220eaa	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorEpsilon	\N	epsilon-webhook-20260522T155502457903Z.json	187	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/a580e8b4-35a1-4bd0-8df4-e2136f220eaa/epsilon-webhook-20260522T155502457903Z.json	DONE	1	1	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:02.3687+00	2026-05-22 15:55:02.609958+00	187	148	[]	WEBHOOK	\N	\N	incremental	f
281f329a-c0ab-41ab-b795-2ef5b7859be8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	test_batch.csv	406	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/281f329a-c0ab-41ab-b795-2ef5b7859be8/test_batch.csv	DONE	5	5	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:24.562144+00	2026-05-22 15:55:26.556344+00	810	117	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
ee2893b6-8ed3-4989-8f6e-163292310ecf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorEpsilon	\N	epsilon-webhook-20260522T155502779039Z.json	187	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/ee2893b6-8ed3-4989-8f6e-163292310ecf/epsilon-webhook-20260522T155502779039Z.json	FAILED	0	0	1	webhook_validation_failed	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:02.676627+00	2026-05-22 15:55:02.857195+00	187	77	[{"raw": "{\\"events\\": [{\\"event_id\\": \\"evt-eps-4a82b4a4\\", \\"player_id\\": \\"PLY-EPS-ba6ed0\\", \\"event_type\\": \\"DEPOSIT\\", \\"gross_amount\\": 999.9, \\"event_time\\": \\"2026-03-09T10:03:00Z\\", \\"currency_code\\": \\"BRL\\"}]}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
3eb52f04-4eb5-4e28-9f06-6d952c807746	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorGamma	3ae3ca80-84ea-4b5d-a31f-f715f543ee53	gamma-invalid.xml	230	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/3eb52f04-4eb5-4e28-9f06-6d952c807746/gamma-invalid.xml	FAILED	1	0	1	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:03.754654+00	2026-05-22 15:55:03.83031+00	230	\N	[{"raw": {"amount": "100.00", "currency": "BRL", "event_id": null, "occurred_at": "2026-03-10T10:00:00Z", "source_system": "ConnectorGamma", "transaction_type": "DEPOSIT", "external_player_id": "CPF-REPLAY-01"}, "line": null, "reason": "validation_failed: empty_required_fields=['external_transaction_id']"}]	FILE	\N	3ae3ca80-84ea-4b5d-a31f-f715f543ee53	incremental	f
4fd2c9fc-6f8e-4e78-847d-2673e4cf1f47	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/4fd2c9fc-6f8e-4e78-847d-2673e4cf1f47/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 15:56:00.920346+00	2026-05-22 15:56:01.552338+00	172	139	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
1ca58ef7-076d-432a-8d2d-225780b7d494	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	isolation_test.csv	196	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/1ca58ef7-076d-432a-8d2d-225780b7d494/isolation_test.csv	DONE	2	2	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:27.760116+00	2026-05-22 15:55:28.321968+00	324	646	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
5d422868-6cb2-4971-a8ed-d2d8d222a10b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/5d422868-6cb2-4971-a8ed-d2d8d222a10b/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 15:56:00.693481+00	2026-05-22 15:56:01.142301+00	172	124	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
82cb3e8d-40b8-4942-914d-29171081e689	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/82cb3e8d-40b8-4942-914d-29171081e689/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 15:56:01.220558+00	2026-05-22 15:56:01.773327+00	172	66	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
c19983e2-408b-4d8b-9ae0-3c706bbc47be	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/c19983e2-408b-4d8b-9ae0-3c706bbc47be/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 15:56:01.430583+00	2026-05-22 15:56:02.050383+00	172	82	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
df699b1c-f309-4e5f-bd4b-68ede7886e34	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	transacoes_reais_exemplo.csv	837	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/df699b1c-f309-4e5f-bd4b-68ede7886e34/transacoes_reais_exemplo.csv	DONE	10	10	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:56:04.551008+00	2026-05-22 15:56:06.096592+00	2028	549	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
2e568b1c-b7c7-46f7-9db4-57b146436742	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	transacoes_reais_exemplo.csv	837	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/2e568b1c-b7c7-46f7-9db4-57b146436742/transacoes_reais_exemplo.csv	DONE	10	10	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:01:32.581956+00	2026-05-22 16:01:33.147205+00	2028	80	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
cafc7363-1b25-459e-b991-c1abd7a22099	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorGamma	3ae3ca80-84ea-4b5d-a31f-f715f543ee53	gamma.xml	288	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/cafc7363-1b25-459e-b991-c1abd7a22099/gamma.xml	DONE	1	1	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:17.027978+00	2026-05-22 16:02:17.156406+00	288	\N	[]	FILE	\N	3ae3ca80-84ea-4b5d-a31f-f715f543ee53	incremental	f
c14a409f-c045-496a-ab36-e5d3d25123b5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorGamma	df93c57c-5ce2-4ff3-a291-ba9bcfc45673	gamma-explicit.xml	292	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/c14a409f-c045-496a-ab36-e5d3d25123b5/gamma-explicit.xml	DONE	1	1	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:17.347166+00	2026-05-22 16:02:17.424834+00	292	\N	[]	FILE	\N	df93c57c-5ce2-4ff3-a291-ba9bcfc45673	incremental	f
72f1eb74-0e0f-4a5c-b0fb-d3f557497226	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorDelta	cec3e3c3-5ed7-479b-b432-47e86745d031	delta.ndjson	205	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/72f1eb74-0e0f-4a5c-b0fb-d3f557497226/delta.ndjson	DONE	2	2	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:17.841033+00	2026-05-22 16:02:17.591451+00	205	\N	[]	FILE	\N	cec3e3c3-5ed7-479b-b432-47e86745d031	incremental	f
50968edd-bd6f-4350-9f09-018ff3931884	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorEpsilon	\N	epsilon-webhook-20260522T160217800912Z.json	187	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/50968edd-bd6f-4350-9f09-018ff3931884/epsilon-webhook-20260522T160217800912Z.json	DONE	1	1	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:17.742957+00	2026-05-22 16:02:18.406428+00	187	601	[]	WEBHOOK	\N	\N	incremental	f
691c788d-2388-469a-82bc-db25961b94fd	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/691c788d-2388-469a-82bc-db25961b94fd/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 16:02:53.646283+00	2026-05-22 16:02:53.899946+00	172	66	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
a3a592f4-0f1e-47aa-8ec7-4a32bc1bcbf2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorEpsilon	\N	epsilon-webhook-20260522T160218586701Z.json	187	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/a3a592f4-0f1e-47aa-8ec7-4a32bc1bcbf2/epsilon-webhook-20260522T160218586701Z.json	FAILED	0	0	1	webhook_validation_failed	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:18.544099+00	2026-05-22 16:02:18.67623+00	187	88	[{"raw": "{\\"events\\": [{\\"event_id\\": \\"evt-eps-e0a35b53\\", \\"player_id\\": \\"PLY-EPS-11e241\\", \\"event_type\\": \\"DEPOSIT\\", \\"gross_amount\\": 999.9, \\"event_time\\": \\"2026-03-09T10:03:00Z\\", \\"currency_code\\": \\"BRL\\"}]}", "line": null, "reason": "Invalid signature"}]	WEBHOOK	\N	\N	incremental	f
12e23da3-a8b2-440b-b3f1-ac2643bfc8e0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	ConnectorGamma	df93c57c-5ce2-4ff3-a291-ba9bcfc45673	gamma-invalid.xml	230	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/12e23da3-a8b2-440b-b3f1-ac2643bfc8e0/gamma-invalid.xml	FAILED	1	0	1	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:20.069452+00	2026-05-22 16:02:20.122798+00	230	\N	[{"raw": {"amount": "100.00", "currency": "BRL", "event_id": null, "occurred_at": "2026-03-10T10:00:00Z", "source_system": "ConnectorGamma", "transaction_type": "DEPOSIT", "external_player_id": "CPF-REPLAY-01"}, "line": null, "reason": "validation_failed: empty_required_fields=['external_transaction_id']"}]	FILE	\N	df93c57c-5ce2-4ff3-a291-ba9bcfc45673	incremental	f
d97ffbae-55bc-4284-a603-4f3df6390c74	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/d97ffbae-55bc-4284-a603-4f3df6390c74/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 16:02:53.78934+00	2026-05-22 16:02:54.248673+00	172	140	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
7eacf5eb-032a-4b0c-9dda-8ec2ad3b927c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/7eacf5eb-032a-4b0c-9dda-8ec2ad3b927c/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 16:02:53.933524+00	2026-05-22 16:02:54.538939+00	172	86	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
1ac2af22-9560-4910-8d02-ababcd607610	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	transactions.csv	266	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/1ac2af22-9560-4910-8d02-ababcd607610/transactions.csv	DONE	3	3	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:38.758787+00	2026-05-22 16:02:39.198794+00	486	90	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
cbfe2db5-1142-42d4-b3df-8acbc9f36f62	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/cbfe2db5-1142-42d4-b3df-8acbc9f36f62/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 16:02:54.219434+00	2026-05-22 16:02:54.800912+00	172	89	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
0b425716-cfbb-46c9-8d62-6877ccc3181f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	test_batch.csv	406	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/0b425716-cfbb-46c9-8d62-6877ccc3181f/test_batch.csv	DONE	5	5	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:39.045137+00	2026-05-22 16:02:39.488516+00	810	96	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
1b0ce6bb-7bea-4602-aa05-876f5ed262ed	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	isolation_test.csv	196	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/1b0ce6bb-7bea-4602-aa05-876f5ed262ed/isolation_test.csv	DONE	2	2	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:40.30709+00	2026-05-22 16:02:41.048033+00	324	81	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
9f1ab621-5afe-447c-9a55-ae4b1215ba58	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	transacoes_reais_exemplo.csv	837	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/9f1ab621-5afe-447c-9a55-ae4b1215ba58/transacoes_reais_exemplo.csv	DONE	10	10	0	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:56.735024+00	2026-05-22 16:02:56.965836+00	2028	68	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
8ea013ca-ce89-4847-8345-2b9fa210dc96	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/8ea013ca-ce89-4847-8345-2b9fa210dc96/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 19:35:36.864001+00	2026-05-22 19:35:38.24204+00	172	387	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
1ef539f6-f238-4387-a361-dc0bd7b68584	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/1ef539f6-f238-4387-a361-dc0bd7b68584/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 17:21:34.9472+00	2026-05-22 17:21:41.668542+00	172	393	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
a66c0015-c8a1-4c0a-9028-a87cc74fd9e1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/a66c0015-c8a1-4c0a-9028-a87cc74fd9e1/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 17:21:35.55715+00	2026-05-22 17:21:42.736036+00	172	188	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
4d891efe-e9e8-418b-923a-609310c23bfa	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/4d891efe-e9e8-418b-923a-609310c23bfa/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 17:21:35.857111+00	2026-05-22 17:21:43.424439+00	172	155	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
35500060-2cd1-4370-a195-bda81856f125	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/35500060-2cd1-4370-a195-bda81856f125/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 17:21:36.362911+00	2026-05-22 17:21:44.245119+00	172	238	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
d54c4473-4da6-47ce-8941-15c34ea5f456	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/d54c4473-4da6-47ce-8941-15c34ea5f456/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 19:35:36.160288+00	2026-05-22 19:35:37.533768+00	172	326	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
6cc2cb57-d9a8-40ab-b3c7-cdd13c4f704c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/6cc2cb57-d9a8-40ab-b3c7-cdd13c4f704c/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 19:35:37.726637+00	2026-05-22 19:35:39.280443+00	172	147	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
1bbc5494-e57a-4f64-9df7-7655364f3268	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/1bbc5494-e57a-4f64-9df7-7655364f3268/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 19:35:37.280223+00	2026-05-22 19:35:38.813077+00	172	349	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
11e4462c-37e1-460e-8a22-cb206adb600f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/11e4462c-37e1-460e-8a22-cb206adb600f/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 19:38:07.120139+00	2026-05-22 19:38:08.256244+00	172	228	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
eafc7c21-acbd-4853-a232-d7cade7bac01	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/eafc7c21-acbd-4853-a232-d7cade7bac01/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 19:38:07.819225+00	2026-05-22 19:38:09.223403+00	172	210	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
1ca2c8ee-1dd9-4e86-b76d-c2cba52efa76	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/1ca2c8ee-1dd9-4e86-b76d-c2cba52efa76/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 19:38:08.216738+00	2026-05-22 19:38:09.845273+00	172	263	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
05b6cf98-c0e6-4815-9d53-b8a0ef8d3b49	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	tenant-test.csv	136	bronze/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/ingest_jobs/05b6cf98-c0e6-4815-9d53-b8a0ef8d3b49/tenant-test.csv	DONE	1	1	0	\N	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-22 19:38:08.758384+00	2026-05-22 19:38:10.265176+00	172	147	[]	FILE	\N	b25fbfbe-b11e-4310-8d00-7a65e5335f9a	incremental	f
\.


--
-- Data for Name: mapping_configs; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.mapping_configs (id, tenant_id, name, source_system, entity_type, version, config_json, active, created_by, created_at, updated_at, parent_id, is_current, version_number, change_notes) FROM stdin;
b25fbfbe-b11e-4310-8d00-7a65e5335f9a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeAlpha Transaction Mapping	BackofficeAlpha	TRANSACTION	1.0	{"fields": [{"source": "transactionId", "target": "transaction_id", "transform": "copy"}, {"source": "playerId", "target": "player_id", "transform": "copy"}, {"source": "type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "transform": "copy"}, {"source": "paymentMethod", "target": "method", "transform": "copy"}, {"source": "status", "target": "status", "transform": "copy"}, {"source": "transactionDate", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "BackofficeAlpha"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	t	1	\N
7e9924ec-ed58-44a3-96bd-3ace1784bdfc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	BackofficeBeta Transaction Mapping	BackofficeBeta	TRANSACTION	1.0	{"fields": [{"source": "txn_id", "target": "transaction_id", "transform": "copy"}, {"source": "user_id", "target": "player_id", "transform": "copy"}, {"source": "txn_type", "target": "type", "transform": "copy"}, {"source": "value", "target": "amount", "transform": "coerceDecimal"}, {"source": "ccy", "target": "currency", "transform": "copy"}, {"source": "method", "target": "method", "transform": "copy"}, {"source": "txn_status", "target": "status", "transform": "copy"}, {"source": "occurred_utc", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "BackofficeBeta"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	t	1	\N
4c244531-7a9b-42c5-9690-c7fbb91b079e	98c56b0f-fa44-47cd-a8d9-9479174e3140	BackofficeAlpha Transaction Mapping	BackofficeAlpha	TRANSACTION	1.0	{"fields": [{"source": "transactionId", "target": "transaction_id", "transform": "copy"}, {"source": "playerId", "target": "player_id", "transform": "copy"}, {"source": "type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "currency", "target": "currency", "transform": "copy"}, {"source": "paymentMethod", "target": "method", "transform": "copy"}, {"source": "status", "target": "status", "transform": "copy"}, {"source": "transactionDate", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "BackofficeAlpha"}	t	89a78d77-d61e-44d1-916c-c9fda278d0e9	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	t	1	\N
41ee492b-c924-4310-8806-181da3330135	98c56b0f-fa44-47cd-a8d9-9479174e3140	BackofficeBeta Transaction Mapping	BackofficeBeta	TRANSACTION	1.0	{"fields": [{"source": "txn_id", "target": "transaction_id", "transform": "copy"}, {"source": "user_id", "target": "player_id", "transform": "copy"}, {"source": "txn_type", "target": "type", "transform": "copy"}, {"source": "value", "target": "amount", "transform": "coerceDecimal"}, {"source": "ccy", "target": "currency", "transform": "copy"}, {"source": "method", "target": "method", "transform": "copy"}, {"source": "txn_status", "target": "status", "transform": "copy"}, {"source": "occurred_utc", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "BackofficeBeta"}	t	89a78d77-d61e-44d1-916c-c9fda278d0e9	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	t	1	\N
1d443879-6aee-423d-abf3-5b2b0610a51b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Map Test 8c19bb	ConnectorDelta	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "event_id", "transform": "copy"}, {"source": "external_player_id", "target": "external_player_id", "transform": "copy"}, {"source": "transaction_type", "target": "transaction_type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:52.012207+00	2026-05-22 16:02:19.967681+00	\N	f	1	v1
c4b6334e-d490-4708-b59b-b1c8af9313c7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Gamma explicit map 412fb1	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "transform": "copy"}, {"source": "transaction_type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:50.511235+00	2026-05-22 16:02:17.202512+00	\N	f	1	gamma explicit mapping
93bbac78-6f83-4aeb-8c4c-f20014c653e9	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Map Test 8c19bb	ConnectorDelta	TRANSACTION	2.0	{"fields": [{"source": "event_id", "target": "event_id", "transform": "copy"}, {"source": "external_player_id", "target": "external_player_id", "transform": "copy"}, {"source": "transaction_type", "target": "transaction_type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}, {"source": "currency", "target": "currency", "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:52.126709+00	2026-05-22 16:02:19.967681+00	1d443879-6aee-423d-abf3-5b2b0610a51b	f	2	v2
3ae3ca80-84ea-4b5d-a31f-f715f543ee53	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Gamma explicit map 281f95	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "transform": "copy"}, {"source": "transaction_type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:01.609542+00	2026-05-22 16:02:17.202512+00	\N	f	2	gamma explicit mapping
58e56f03-653a-4f40-acdd-4c5003eaa35f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Map Test 8c19bb	ConnectorDelta	TRANSACTION	3.0	{"fields": [{"source": "event_id", "target": "event_id", "transform": "copy"}, {"source": "external_player_id", "target": "external_player_id", "transform": "copy"}, {"source": "transaction_type", "target": "transaction_type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:46:52.271721+00	2026-05-22 16:02:19.967681+00	1d443879-6aee-423d-abf3-5b2b0610a51b	f	3	Rollback para v1
81972174-f1c9-4b96-ac18-ff110cd928e2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Map Test 0ac28c	ConnectorDelta	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "event_id", "transform": "copy"}, {"source": "external_player_id", "target": "external_player_id", "transform": "copy"}, {"source": "transaction_type", "target": "transaction_type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:03.38927+00	2026-05-22 16:02:19.967681+00	\N	f	4	v1
be41dcfa-4c16-44a9-b851-78c26525ac70	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Map Test 0ac28c	ConnectorDelta	TRANSACTION	5.0	{"fields": [{"source": "event_id", "target": "event_id", "transform": "copy"}, {"source": "external_player_id", "target": "external_player_id", "transform": "copy"}, {"source": "transaction_type", "target": "transaction_type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}, {"source": "currency", "target": "currency", "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:03.461576+00	2026-05-22 16:02:19.967681+00	81972174-f1c9-4b96-ac18-ff110cd928e2	f	5	v2
df93c57c-5ce2-4ff3-a291-ba9bcfc45673	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Gamma explicit map a8ca0c	ConnectorGamma	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "external_transaction_id", "transform": "copy"}, {"source": "external_player_id", "target": "player_cpf", "transform": "copy"}, {"source": "transaction_type", "target": "type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorGamma"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:17.202512+00	2026-05-22 16:02:17.202512+00	\N	t	3	gamma explicit mapping
cec3e3c3-5ed7-479b-b432-47e86745d031	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Map Test 8c19bb	ConnectorDelta	TRANSACTION	6.0	{"fields": [{"source": "event_id", "target": "event_id", "transform": "copy"}, {"source": "external_player_id", "target": "external_player_id", "transform": "copy"}, {"source": "transaction_type", "target": "transaction_type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:03.562043+00	2026-05-22 16:02:19.967681+00	1d443879-6aee-423d-abf3-5b2b0610a51b	f	6	Rollback para v1
71c597b8-b557-4328-80d7-9b97b79526e6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Map Test 6258fa	ConnectorDelta	TRANSACTION	1.0	{"fields": [{"source": "event_id", "target": "event_id", "transform": "copy"}, {"source": "external_player_id", "target": "external_player_id", "transform": "copy"}, {"source": "transaction_type", "target": "transaction_type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:19.668301+00	2026-05-22 16:02:19.967681+00	\N	f	7	v1
9eb8e2b6-f40e-4b66-80a7-26234eaacd44	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Map Test 6258fa	ConnectorDelta	TRANSACTION	8.0	{"fields": [{"source": "event_id", "target": "event_id", "transform": "copy"}, {"source": "external_player_id", "target": "external_player_id", "transform": "copy"}, {"source": "transaction_type", "target": "transaction_type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}, {"source": "currency", "target": "currency", "transform": "copy"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:19.817307+00	2026-05-22 16:02:19.967681+00	71c597b8-b557-4328-80d7-9b97b79526e6	f	8	v2
6aa4779e-bc8b-4105-bf1e-3bbc77e5a4f4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Map Test 8c19bb	ConnectorDelta	TRANSACTION	9.0	{"fields": [{"source": "event_id", "target": "event_id", "transform": "copy"}, {"source": "external_player_id", "target": "external_player_id", "transform": "copy"}, {"source": "transaction_type", "target": "transaction_type", "transform": "copy"}, {"source": "amount", "target": "amount", "transform": "coerceDecimal"}, {"source": "occurred_at", "target": "occurred_at", "transform": "parseDate"}], "version": "1.0", "entity_type": "TRANSACTION", "source_system": "ConnectorDelta"}	t	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:19.967681+00	2026-05-22 16:02:19.967681+00	1d443879-6aee-423d-abf3-5b2b0610a51b	t	9	Rollback para v1
\.


--
-- Data for Name: model_inference_logs; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.model_inference_logs (id, tenant_id, player_id, model_id, model_variant, anomaly_score, is_anomaly, request_id, scored_at) FROM stdin;
\.


--
-- Data for Name: model_registry; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.model_registry (id, tenant_id, model_name, model_version, algorithm, dataset_window_days, metrics, trained_at, created_at, model_type, status, dataset_window_start, dataset_window_end, promoted_by, promoted_at, is_challenger, champion_id, artifact_uri, is_active, training_rows, trained_by, feature_columns) FROM stdin;
\.


--
-- Data for Name: notifications; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.notifications (id, tenant_id, user_id, type, title, body, entity_type, entity_id, read, read_at, created_at, is_read, reference_type, reference_id) FROM stdin;
\.


--
-- Data for Name: player_kyc_events; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.player_kyc_events (id, tenant_id, player_id, entity_type, subtype, provider, document_type, pep_flag, income_declared, exclusion_source, exclusion_scope, exclusion_duration_days, old_deposit_limit, new_deposit_limit, previous_status, new_status, reason, ingest_mode, backfill_job_id, occurred_at, created_at, event_type, status, payload, response, error_message, processed_at) FROM stdin;
541e96b5-6156-4f29-a4bb-0ccc0028e132	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	f71ed380-a936-4b4d-a075-1b3fd6e022c2	KYC_EVENT	DOCUMENT_CHECK	manual	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:11:59.925429+00	2026-05-20 00:11:59.925429+00	DOCUMENT_CHECK	PENDING	{}	{}	\N	\N
1cb952e9-27d6-4fa7-bd09-b82910163948	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	KYC_EVENT	DOCUMENT_CHECK	Serasa	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:16:02.742956+00	2026-05-20 00:16:02.742956+00	DOCUMENT_CHECK	PENDING	{}	{}	\N	\N
1ea6714d-058e-4eba-9f80-bc94161dbf91	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	KYC_EVENT	FACIAL_BIOMETRY	manual	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:16:03.535295+00	2026-05-20 00:16:03.535295+00	FACIAL_BIOMETRY	REJECTED	{}	{}	\N	2026-05-20 00:16:03.549197+00
3a590472-5c70-471e-b2d0-bc028d27e538	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	KYC_EVENT	MANUAL_APPROVAL	compliance-team	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:16:03.630724+00	2026-05-20 00:16:03.630724+00	MANUAL_APPROVAL	APPROVED	{}	{}	\N	2026-05-20 00:16:03.6368+00
815abfac-e89d-4d5d-8df9-13c5c700f292	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	KYC_EVENT	PEP_CHECK	Lista PEP Gov	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:16:04.400869+00	2026-05-20 00:16:04.400869+00	PEP_CHECK	APPROVED	{}	{}	\N	2026-05-20 00:16:04.415295+00
e503e5df-17de-4b9a-9225-70ef3ad88f1e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	KYC_EVENT	DOCUMENT_CHECK	Serasa	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:19:17.442974+00	2026-05-20 00:19:17.442974+00	DOCUMENT_CHECK	PENDING	{}	{}	\N	\N
6aa49636-07ed-4623-b8fb-3c0779104325	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	KYC_EVENT	SANCTIONS_CHECK	OFAC	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:19:48.831639+00	2026-05-20 00:19:48.831639+00	SANCTIONS_CHECK	APPROVED	{}	{}	\N	2026-05-20 00:19:48.852099+00
0ab7e53c-dd1d-4455-8814-6d2e99bd66a5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	KYC_EVENT	PEP_CHECK	Lista PEP	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:19:48.918854+00	2026-05-20 00:19:48.918854+00	PEP_CHECK	PENDING	{}	{}	\N	\N
bb5f0f19-51cb-41d6-8d9f-ebcd37e3f415	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	KYC_EVENT	DOCUMENT_CHECK	Serasa	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:22:10.129609+00	2026-05-20 00:22:10.129609+00	DOCUMENT_CHECK	PENDING	{}	{}	\N	\N
0810ad20-6f83-41d3-8029-dcc0c45c9a81	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	KYC_EVENT	FACIAL_BIOMETRY	manual	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:22:11.031838+00	2026-05-20 00:22:11.031838+00	FACIAL_BIOMETRY	REJECTED	{}	{}	\N	2026-05-20 00:22:11.046181+00
a1609bfb-251b-4a56-9523-14131d09f029	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	6aca664d-2b4d-470a-b8b2-6abd64d14d5d	KYC_EVENT	MANUAL_APPROVAL	compliance-team	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:22:11.119514+00	2026-05-20 00:22:11.119514+00	MANUAL_APPROVAL	APPROVED	{}	{}	\N	2026-05-20 00:22:11.14727+00
249c2ed3-7bbb-4a9c-a360-a9ffd3ba6bdf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	KYC_EVENT	PEP_CHECK	Lista PEP Gov	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:22:12.312315+00	2026-05-20 00:22:12.312315+00	PEP_CHECK	APPROVED	{}	{}	\N	2026-05-20 00:22:12.328385+00
38a8caea-f4b1-4fee-978b-eb5f06be6ecc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	KYC_EVENT	DOCUMENT_CHECK	Serasa	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:30:59.587279+00	2026-05-20 00:30:59.587279+00	DOCUMENT_CHECK	PENDING	{}	{}	\N	\N
3c27464f-ec7a-46ae-91fa-b94acb9474b2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	KYC_EVENT	FACIAL_BIOMETRY	manual	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:31:00.391223+00	2026-05-20 00:31:00.391223+00	FACIAL_BIOMETRY	REJECTED	{}	{}	\N	2026-05-20 00:31:00.397139+00
6809a7e3-777e-42b3-b1fd-cd6c76909a8c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	KYC_EVENT	MANUAL_APPROVAL	compliance-team	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:31:00.458451+00	2026-05-20 00:31:00.458451+00	MANUAL_APPROVAL	APPROVED	{}	{}	\N	2026-05-20 00:31:00.464153+00
160e6142-9591-4b2a-83f2-d755944515a6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	KYC_EVENT	PEP_CHECK	Lista PEP Gov	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:31:01.30747+00	2026-05-20 00:31:01.30747+00	PEP_CHECK	APPROVED	{}	{}	\N	2026-05-20 00:31:01.315565+00
9b56a11a-610c-44fa-a5b2-0755af46f18c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	KYC_EVENT	SANCTIONS_CHECK	OFAC	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:34:18.581325+00	2026-05-20 00:34:18.581325+00	SANCTIONS_CHECK	APPROVED	{}	{}	\N	2026-05-20 00:34:18.598436+00
42a9381b-f813-46a2-a372-ba00af98e536	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	KYC_EVENT	PEP_CHECK	Lista PEP	\N	f	\N	\N	\N	\N	\N	\N	\N	\N	\N	incremental	\N	2026-05-20 00:34:18.683725+00	2026-05-20 00:34:18.683725+00	PEP_CHECK	PENDING	{}	{}	\N	\N
\.


--
-- Data for Name: player_list_entries; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.player_list_entries (id, list_id, tenant_id, player_id, external_player_id, cpf_hash, notes, added_by, added_at, value, value_type, player_list_id) FROM stdin;
f558a999-20ce-46b0-bbd9-3e47a125ce1b	ccee7e20-4f16-4668-9231-15f654a1f8a3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	f71ed380-a936-4b4d-a075-1b3fd6e022c2	EXT-OPERADOR_A-001	\N	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-19 23:57:44.872891+00	EXT-OPERADOR_A-001	EXTERNAL_ID	ccee7e20-4f16-4668-9231-15f654a1f8a3
258b7863-7caf-47f2-a1a4-f2e0b357ffe3	ccee7e20-4f16-4668-9231-15f654a1f8a3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	5f4b66dd-66b9-49d7-ac79-10c15f7b9e71	EXT-OPERADOR_A-002	\N	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-19 23:57:44.872891+00	EXT-OPERADOR_A-002	EXTERNAL_ID	ccee7e20-4f16-4668-9231-15f654a1f8a3
96de3bc7-4c31-446f-9064-6fa012b48649	ccee7e20-4f16-4668-9231-15f654a1f8a3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dc662a23-33a0-4898-81c1-22fe4404f5c4	EXT-OPERADOR_A-003	\N	\N	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-19 23:57:44.872891+00	EXT-OPERADOR_A-003	EXTERNAL_ID	ccee7e20-4f16-4668-9231-15f654a1f8a3
288a9a47-3c89-4495-8e73-1e0b7163f0e0	6a2c4b9e-042d-4f01-8b1d-b5f599f09328	98c56b0f-fa44-47cd-a8d9-9479174e3140	defd8826-200c-43b0-8ac6-1f57a384bb36	EXT-OPERADOR_B-001	\N	\N	89a78d77-d61e-44d1-916c-c9fda278d0e9	2026-05-19 23:57:44.872891+00	EXT-OPERADOR_B-001	EXTERNAL_ID	6a2c4b9e-042d-4f01-8b1d-b5f599f09328
22d166d9-2975-4942-9441-7091910de6f4	6a2c4b9e-042d-4f01-8b1d-b5f599f09328	98c56b0f-fa44-47cd-a8d9-9479174e3140	0e146917-2e26-47c4-ba5e-3506cac9644c	EXT-OPERADOR_B-002	\N	\N	89a78d77-d61e-44d1-916c-c9fda278d0e9	2026-05-19 23:57:44.872891+00	EXT-OPERADOR_B-002	EXTERNAL_ID	6a2c4b9e-042d-4f01-8b1d-b5f599f09328
d4a663e3-33e3-4ea9-a52c-a0b22a736298	6a2c4b9e-042d-4f01-8b1d-b5f599f09328	98c56b0f-fa44-47cd-a8d9-9479174e3140	c3d5fa96-9a4e-4f70-aa98-0e36d66ffb42	EXT-OPERADOR_B-003	\N	\N	89a78d77-d61e-44d1-916c-c9fda278d0e9	2026-05-19 23:57:44.872891+00	EXT-OPERADOR_B-003	EXTERNAL_ID	6a2c4b9e-042d-4f01-8b1d-b5f599f09328
\.


--
-- Data for Name: player_lists; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.player_lists (id, tenant_id, name, list_type, description, active, source, created_by, updated_by, created_at, updated_at) FROM stdin;
ccee7e20-4f16-4668-9231-15f654a1f8a3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	pep_watchlist	WATCH_LIST	Jogadores identificados como PEP ou conexão com PEP	t	MANUAL	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00
0fd82621-84ef-4a08-8475-ac5ab01229f3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	internal_suspects	CUSTOM	Lista interna de suspeitos identificados em investigações anteriores	t	MANUAL	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00
6a2c4b9e-042d-4f01-8b1d-b5f599f09328	98c56b0f-fa44-47cd-a8d9-9479174e3140	pep_watchlist	WATCH_LIST	Jogadores identificados como PEP ou conexão com PEP	t	MANUAL	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00
28329b81-4593-4da0-9ff2-550cea2a6773	98c56b0f-fa44-47cd-a8d9-9479174e3140	internal_suspects	CUSTOM	Lista interna de suspeitos identificados em investigações anteriores	t	MANUAL	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00
\.


--
-- Data for Name: players; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.players (id, tenant_id, external_player_id, cpf_encrypted, name_encrypted, birth_date, pep_flag, declared_income_monthly, profession, risk_score, last_scored_at, created_at, updated_at, registered_since, status, external_id, risk_band, cpf_hmac, self_exclusion_flag, deposit_limit_daily, features, cluster_id, cluster_size) FROM stdin;
087318c7-8467-41d9-a23a-ffed149c7dfb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-005	\\x674141414141427144506a366b7259624548706251514a6870637146326b6369614c6933547865366f534b335346536d416d4746454a5969635749525351655a4e55506248614a784f367644744b31474a59694f6b634935685767554a44763372673d3d	\\x674141414141427144506a365a7155516e487954576b7074356165517674696c566d38654530755277764a635a7077376d7a4f7574574a504873367859784b495a70586647796c6b4264727449697a6135746137396d68643549387039417937564c466c30505850666c38706247456244785f373070383d	\N	f	2000.00	Teacher	0.0455	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	79f6faad44e0452104c822c45982eeeb5dc146ae58c05c89d58f80a0ed0d63a7	f	\N	{}	\N	0
d318d2bf-6a0a-47e7-b229-14f1651ed66c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-006	\\x674141414141427144506a3649667271496668756e4e582d74434d5f634b655a66354d306e5458536861366b524f37454c39436a4f3131476e737737766a70684a497957547765307964745a656c6239546238694c32676f4c6a747133546b4950513d3d	\\x674141414141427144506a366d686565427663427933576d564745495339774b57484e706b5a5f51594761502d77785a5869655174784f57385a5731633261477737656b5075375831655a49393876345a3373746a6f596f4a74314f50557864494c74445f39786c4a52764d36483236355a6a366c7a413d	\N	f	10000.00	Teacher	0.2616	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	5cb83caf4e68968e56344105e94517f6c6d6c2e1b1f03f8c98d63357d125104e	f	\N	{}	\N	0
07d1e776-b028-4c6c-aa3a-25576c7f05a1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-007	\\x674141414141427144506a366a38324b4c7a323331704d414e3644724e467a4953424e4654556161366d5754574f654d665273525158554d784f686b774355334b4c3046413842677358794476675f3735414749305267556b6733533254657659773d3d	\\x674141414141427144506a3630786e66586c395635374a306469626337546170466b455435433179414e70543151586b63585043375a35445f7052785f7668396150394d646d6665535f544677466670724235587a30706c68646f6c6c6862474b7a57744c576c5447536b464c6d35653334644972394d3d	\N	f	2000.00	Trader	0.2289	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	ada110c923cbbdfed05da8c5899ae1c064a02f18e85bef6c446837c22a5a85ae	f	\N	{}	\N	0
288fa6ba-246d-4935-bfc9-c9e5d78170b8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-008	\\x674141414141427144506a36384b6b4a793536794a6b774c526b4a77475548426934426551563667734e754d6e6d715f484a46544d647a72355145754d50512d734c53323875544346624f556f784d6874654c77726576375355346265775f6378773d3d	\\x674141414141427144506a36785452494b424e494b4c5a6f31646e4b684757347071584250326245704c364667335772696149554e37693564354151424177655356797637633956505451325158534a7347446a6d7579427162756469744d446e637869474474675856424e35717a36455876634770413d	\N	f	\N	Teacher	0.2315	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	ea0709b7f64a28f819d1427d6e401aae0471d1a5bb0d95fcb4cf3bc6e6f78f69	f	\N	{}	\N	0
8c12abe8-44e5-4c5b-bc61-cec2e4afad13	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-009	\\x674141414141427144506a366b6f417472564e4a586b3674446846464f49526d31523237696d79734e7458544d4451585279546e593170307a324741636d416f4142703244465441745531735377785067714e68417265324169686b6576624a64673d3d	\\x674141414141427144506a364c354c63306e4a717a7254646f2d637531317131483870457634427a5174327639766775395679787333553166492d4a5945524b66422d63444e6e6464423961786142797848337865727655366973626f4f5574455f3863566b48594e347744595f395f4b4148454661383d	\N	f	\N	Engineer	0.1732	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	7bb53420f3e0c23a3456d4ecf1db404eec960e4ae942ea537c1711acb2ac74ae	f	\N	{}	\N	0
e03db635-2cee-4728-8db4-537bdb0d4454	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-010	\\x674141414141427144506a367669625f56566f365f504374704752364141673659494b32396e4c65747268566632637938677353345f6f6f6b4867397453364264435749584b65477449416f74616f6d44624c73426e5a44695f72614c644b595f673d3d	\\x674141414141427144506a364341444a4a5367616c6649637865425f6c5a5f4f424b365951395377447667624a305a6a77457639394849534f33364949555773526e387636655a6d6a32494c5a72774b766c53394659766a52536b4133776d50645f50305f61464e65475348477459376e3569525034733d	\N	f	20000.00	\N	0.0480	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	e0646c017d0c511010d1c79d8b4f30c8a4243612288b22635a8d0776d10a89b2	f	\N	{}	\N	0
edf97664-48a0-4415-a6f2-b8a2548b8ab2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-011	\\x674141414141427144506a3639677976577a304c374f3456475977543646724a55486468674b315f787032783851314a506949554c596c644f4568746341784158424f4c594c36676b4a7a55674f6f31534b39794a736d6b5676727a5631614572773d3d	\\x674141414141427144506a365531775278416877437872687344766d4f335130465a355a6868576b7a7064764d534366624e42795a327157626e6c476f5f564355587a492d4b52626f526167436236754f66576f514a5032506374544b4f3955753641494b6e747072574f447a43424c494c67517974673d	\N	f	2000.00	Engineer	0.1521	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	f4e55cc06130c718b6a82efb119a0c0e7e465209e3b35396a64828f6c8287910	f	\N	{}	\N	0
65eaff56-ec0c-463f-a097-e244f177993c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-012	\\x674141414141427144506a364a427a36594e2d6d56346d3544427a4a66325242636d327243494a3330725f3232676a647377654178546239774d5262727956543178356d397232505a587457376c6a70662d694f69446442784b487579795f6766773d3d	\\x674141414141427144506a3673564a6f6e6a7243634756575a566247437169756b4e35514e316a58465f5735687a61314b6f7442654575505853747971396c30776f5f7633496b4d4c664976616c446562564467364d6c72624863513873364f65742d4742426a7139665a72764f5455626b6a4945504d3d	\N	f	5000.00	\N	0.1220	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	111006e3d8e37e53a1a680c7053455cb36367468270cca50c58384852e542748	f	\N	{}	\N	0
d9c2fdf7-c210-49a9-9234-15f6ba424c60	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-013	\\x674141414141427144506a3647716535634538414635384d3541546f2d484e676a76416447667978357553726250574d7354716d46656a4e473956727548724b344b786952436c76784a43414a386a625f4b654d6d6a343159735f5774322d5045773d3d	\\x674141414141427144506a364834596d5938556c485a7339555771555672736e4f3441323632686e6942736c4643466e756f6e6e713838686177716a64427858654830437934666866485632534e4479686b333079374b684b4b34677a393168444d57525a7a7877784a706b545f6e57446365534847513d	\N	f	20000.00	Teacher	0.2069	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	87bae632781386c06b4c0b49f59f6b0d5b9ffe7ff8fa4817e1a2be18daaca38f	f	\N	{}	\N	0
ad30aa93-be63-4531-bfcb-db2ff53015b0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-014	\\x674141414141427144506a36544346645942395a6b416e644b544c6564464e504f534230784a416447416b376e505f42665f674b56357644434d6c3858534146316454634a4f6c496230434e4953534e627232616374533763556e78397074682d673d3d	\\x674141414141427144506a364d783442362d5f7973784435415a7a7259793555675f4d5f55455742414b787a6c5031614a6341776a454a5f6b715533306c393044584f78344636676761684b2d35414e30586d412d5066366a2d704b74634b332d4c39594e56346942554d4475584e344537524c7a784d3d	\N	f	2000.00	\N	0.1908	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	971f1715655823491d446fc90086d047589527f8c56fc5070c5b84c93ce43b9b	f	\N	{}	\N	0
ec796a23-8d6b-495d-9186-00a93252b69b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-015	\\x674141414141427144506a36354b7546366e326d61774664567448336b494361575746716f3768474c2d7a4444486a5461326953706a4a5f59744c7a673032334a453055484a2d566a374e6d5271716531722d7074524e7953754b3072354e384f673d3d	\\x674141414141427144506a36617757664c444b63615368685f644552423574526350706d5861784c774e4a34697a69446a3045373641774e6e776b64746b48735177686837414779624a474935457a62625045674c446154506465535237692d4b58504750414a4942456f3236565f374f5a61494a354d3d	\N	f	20000.00	\N	0.1719	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	4407350e43d4eb5ed1aef3b398e3878c433144be24c668e81a01c00536ba6af4	f	\N	{}	\N	0
1ffece25-fcf1-4ef1-a333-cb589a72834d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-016	\\x674141414141427144506a36785f345f2d5563426d426f7172734356625f5376316876704e6d4e4244414f45504653565649456d725a693531314a75687a4658624245733637335775515850304b56696978714b6331694b4c5848776f54394262413d3d	\\x674141414141427144506a3679474247677a637557465542485952734e5970663075565f7756702d6b4a5661586b52767a674c46563261594844787159536f6754724d313173716f786b32306b5f6465504479675a526c555348614e313779474e6e555f7365495438694a725f4f572d746e62467975733d	\N	f	2000.00	\N	0.0244	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	5b1844634aa7f28fc573b6072632ccf4dca49a6bf5fee0f0ff46734b6e8970c0	f	\N	{}	\N	0
0d3eb2cf-cdf5-4c16-872c-b3f6b0c56b67	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-017	\\x674141414141427144506a36666a524967684d4c6647764b69715a59706964513169496e4844357456425750705271774b75307870314d6466764938625f372d36526b71644d796167704970456c68774874737964417566576c33653330593145673d3d	\\x674141414141427144506a363868684479552d6f50764434583633716c593978327075795f377a787844626b4b44463770505071642d446e4a4e414b6a5445304e375645744c30345f5f673233384c4e562d5731713434316f6369734d49363051502d5057394e30554b697746346756754b647a5037673d	\N	f	10000.00	Engineer	0.2003	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	23105a0f44bce630fd6be4157fa656d70bfc9539b08d338ceb3ca58febcea4ca	f	\N	{}	\N	0
c0f0911b-93a4-47ee-8cf5-bd9fe8c94b8e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-018	\\x674141414141427144506a365a4842353244546e3761505f687066467479743263416a2d75384c4634773151332d32756c315f5954384e70477a384d46336a574237654678364163504c57612d4370636c644c4256736f7557625f6270476e7944773d3d	\\x674141414141427144506a36303452316e486a414b6b526f5750784c744a596430766e524d337a513254377779715351644a58316f7236353166586f7a57526e4772764365784365456a5a4f6a614f6d6d52773653305958614d386737553651476e5872786536756d764b5f426d4557777a534c6153673d	\N	f	\N	Teacher	0.2745	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	9fffe690086f40cf7b84102852d2f2aad5c40b0abeeb512eb70bab64899d5d94	f	\N	{}	\N	0
4bf5512f-9bcd-4af2-8732-61e17d7bc97f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-019	\\x674141414141427144506a36677149443641546a794441646e59684950496a4a34613363674d4c443574455f344c2d785839364746434c6a3749386c7046573537434544666569793071366b755673356b724868655a75555a4b56337a4f6b6878773d3d	\\x674141414141427144506a36454d6d7231337274726c673559676239737234793173365f49486c6f394159326b4a325068495347387541732d7842315f46594c48584a69416632526f4a614f6c64386e7a43345771434d5265446848774565376769486231654d45415953463247586274677930676c733d	\N	f	\N	Trader	0.1071	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	a11552299a74336ea99d95e62fe22be56332d43bbb2f56057dfe30cf2085c90c	f	\N	{}	\N	0
2c0b1ed4-7fac-472e-92f0-a79417590cc6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-020	\\x674141414141427144506a3641523245546d56756f52637332414f5a4c762d6d4762424772444737726174556b64374f62706b756b53722d717a745358337a7a433846487a5569714b7a4955464c6b7775367a4650306b5a4c6a4e776650644d66773d3d	\\x674141414141427144506a3666494e4c6c5a596a546c50515a46754573565573787068776d41624a5f6d315672386c59423771746256505f374f7658566b5778614135706443464f7a385659476a4d325a56424f435f42724d354748734b425658616e504c5147774a6865384d4774577775424a5656633d	\N	f	\N	Engineer	0.2506	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	b779f1dad8c14972ad9b819ba56c3e43dbec274632d136419b246b31d32225cb	f	\N	{}	\N	0
5635dfca-5841-4bdc-a8d3-c97d31c5d9fb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-021	\\x674141414141427144506a36372d4c4f6d4e746b6f6f6855315f6456586835517372357a74723144304d794d4f36726233436d68797556356b6a53755666452d536434646b6a5f48415868536c504c494671647832706c654e6247437667664c47773d3d	\\x674141414141427144506a365f4d6b68436337506f4771656a30474253334156634f6d37775645596e656257596f305f654f345047374562545657535033397150755537516d4e6971304653704b64426773357646433974766147755157664577595a52724e417937523672505464455148766d5a546f3d	\N	f	\N	Engineer	0.0469	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	d9ae598eaee94dc0d30fbb31e7fd40d465ce954b9a757bf7056c6399b14f6054	f	\N	{}	\N	0
04560e6f-5044-44b3-b164-e019a233bf8f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-022	\\x674141414141427144506a36346e6c75555a6d5558455a6e6f724b2d754c373454554c425f574e6872614a726f38436c5755616c526d714370395973456c543162444268763561566d4858626f7061433570345152697546386767507143415056673d3d	\\x674141414141427144506a366d4248724758785579567a4d484c4f56313970316c666e476a65526364547574765a65417a775874727779366a616670525a513067502d753130727a637a54494f56684e7854566137446f4435737859714b4a374331346b7066585655532d4d38592d63555a73697a73343d	\N	f	2000.00	Teacher	0.2796	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	685364d83461df3c9477727c282df46fa556f936d24c18a7b486c800db0c504e	f	\N	{}	\N	0
7e9ba28c-2fbc-4a8d-9c32-43315b4ff3df	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-023	\\x674141414141427144506a363943536f33786a51636b4638425f7774466c6e4c4c575f536958646b724d753957726f313654306a556159746772686c746b4e674f6d39453033366e585279494a6f5f704e734d6d574d7573655865777037747248413d3d	\\x674141414141427144506a3632724930524f346c6d494a6d416c6b71677134375069595a667250676c5364466165336d514b5444624d74796c515a75554532526d41766474783867303445373049567164304848307851684e473948317a4252726572696a58446f577165503655705f70326351766f493d	\N	f	\N	Engineer	0.1051	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	cf3a2d65b13381633a83a352c73c9ed2cad1dbd5730309fab58b4f6bfa371eee	f	\N	{}	\N	0
4d1405e5-3c47-4ed6-927f-5d4397edda11	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-024	\\x674141414141427144506a366c5368456b346b4742774c65744f376c4f3831714371644e325a42767637556f4c79336671687a7767304e535566415659743477546c466b4247384f5a4772457a7a33726f71363849504979505330617974733875413d3d	\\x674141414141427144506a3674394c69577053466e61376b396b415f746e6b5568613279305844436f694943516571525a6f34737237644158617973497a347836525950517852363744436338566a4e777434506e31385064674d646d43714f6753496b7739356357536a327530504466704f4376546b3d	\N	f	5000.00	Engineer	0.1205	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	058ecce035a015e109a951534ba09edbe69508f4cdb387f03d621fa5d49e5511	f	\N	{}	\N	0
298e4d79-1887-4174-9161-96e3d6d1b98a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-025	\\x674141414141427144506a36526c754548336d54462d705f31614245546d44694776553167637261786f6f55787678476e50746b477a4f30784a674e494268737a554433527a69383347473832655a374e79733541486661396f4f4575614d5541413d3d	\\x674141414141427144506a36416244592d4936516b434a327032627361447a2d61635a53414b723843456e56506a746d573553337264734f6451794c6e7539312d4b715142656d4b6c5444334773766b36613073497135754c462d62676568644f6e32653946482d566c575643575558555261547554553d	\N	f	10000.00	Teacher	0.2357	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	f54105e4fbe8830bc3eab5d94c26ed2069472667f7a3130ef28666624274c555	f	\N	{}	\N	0
1a731889-5f8c-4806-b4db-f3ebd9a6a66b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-026	\\x674141414141427144506a36494c6a64424b744d765153672d735644477a4d73763868466f7931447672376256594d635a4d764f36745f467a6f666c4b46576d3447544b4c6445494e44446b776c61483146664a3435575f4a50593532785f7668673d3d	\\x674141414141427144506a3670754a7171777852573343706e6147303031694f5330536e58746975566a575f544d63425836694d4a54745a61425a766467497276613256695874737a485332717a3361496a655553656e6e665137315a686f4f77666f5a5f484453464e6d637951674a42344f506171413d	\N	f	2000.00	\N	0.0238	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	b84a5b7615dce4952aadb9bcdbd675e15c0e51307efd0ffbf38195016914ea5a	f	\N	{}	\N	0
a146eda5-e306-4c46-9fd8-eae9b497cd1d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-027	\\x674141414141427144506a367951487734586a4e384875386a696d306d556c4c2d5045536c6743556d51633946706b6a6956504637313643455276676c704b74714f536545527679454967487a306a69566a565870573537726d54723463494639673d3d	\\x674141414141427144506a364f6c694d334f556352753754436b456f30435f51745a34596f66474654563962375379426d7472324a4a614e6e62364265783573356866473972476c36632d345f415f306d6537486164455747794e6a35494c456f6d696d762d35632d42327a706a6f4d775763786a33633d	\N	f	2000.00	\N	0.1985	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	30f4297507d0c74e341a324ce30144a61c6dd2bfe9f4816311b6346a555d7f83	f	\N	{}	\N	0
c993c3c9-4893-4f03-ab79-666f38fa6c5c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-028	\\x674141414141427144506a36637873306f6d2d307463317474504f4e6d4e4d4849714b6647455871454b3977454f45723759366b4d58515766444770705570736632557356796153344248657042536e34327571674838503234544e62726c6b41513d3d	\\x674141414141427144506a367573643357496f646a3844505f73736d332d307956524e4f5471744b5a6d343248623951373459377144334d356c79784c6a6973687a675830496f63326367437a5539645252436934646c58426e4d786179303849324e4b7131336d76496e6a44556e37765544427566553d	\N	f	20000.00	Engineer	0.0386	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	feb23ba911d2688ff1eabd532b61e119b0f3bd44222f0b1118e1887f1d3a8996	f	\N	{}	\N	0
00dafd62-d4ac-4b10-ab7b-535380ebbe1f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-029	\\x674141414141427144506a3650417a3247764a384d75563768364a49305069386778326d63736d30617275744939704c36695a415835456544644a386d4b6f5f3353423061336a4a334c4333636d79774f544f4b714d666231506b496376572d30673d3d	\\x674141414141427144506a365641757432477747416356304c664a6a45336e47577a6971456f32415f33776536775f6e6773764853344e714733475056735073614842573530666d506e716c6462375a4f515746352d67466b446e425659384b4a57774832384c643646513358574856365a7432594c4d3d	\N	f	10000.00	Engineer	0.1652	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	0e1942e369d2991f685cc55052f68eff9bc9654b596a09dee30d266ad4a44899	f	\N	{}	\N	0
e7cbfc26-a370-4f7d-98a5-a41d065cbebb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-030	\\x674141414141427144506a364b4e74644c3071372d65437967456d446359377a78706872655f4a375250796c594f396e624b377363627655756e65584a4e30696d69546270503635534f494b5a3255317431303076376d6173346c45792d594c38673d3d	\\x674141414141427144506a36465a4f48343949737450364f414e30423036555a4d6d44504a7645566b6f333746716b71684539506835527a66445a376a646b68335f446d7562346c4c37647865613367357951576f6d63624b6733537347714547364772386941326557566c436c717a4d6248717262673d	\N	f	5000.00	Teacher	0.0470	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	dbb12e51ddd6980d69e7eaff048c71f710566fc7741d8fe39d910919b65236e7	f	\N	{}	\N	0
18b7914e-7c2f-4747-9d2c-f0d2910e914a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-031	\\x674141414141427144506a36434f54442d6930715a3257793865496774524f534a4b4e6a3778304969776c70587470514e46627435685a787839566651466470634e36704a384f4d48496a7a644f3855723348614664424e6d546447476e634162513d3d	\\x674141414141427144506a364561537242386e5537675270553170586b70714f336c31467837663949573366566c3039316945593032455862625763675a394f355637315f6e544771507847507667577768714955676b376348384157494e63377a33555649714976506b64315953526957427a6d61773d	\N	f	\N	\N	0.2007	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	97dca73d97c18c105773ef9b05b854a3478c9aaf6063ea392a9dcabd273b5f77	f	\N	{}	\N	0
83dad57b-d447-4307-aad0-6d3f19225fb5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-032	\\x674141414141427144506a36786d7a486d30614a3135634d4e654f38414633556958425a66395867705042556d7675315749515f506b767931456f4f683938354d7044716d74784e49335a4f6a31686f2d716f546c4c515172577a624767583364673d3d	\\x674141414141427144506a3661306a7a32442d3336372d5330745f307047333849337a706252515750475348426444383159386879376a4c757147516b6136676274464b50363561414b73595553615a636c5639463337667033534b65566142707a7061416d4537494c337a6c3347336557454d3538343d	\N	f	10000.00	Teacher	0.1024	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	9105c4fc471870bf4e9003116c572dfa0f4aaadd94fbd61e96e5c73beea3f775	f	\N	{}	\N	0
785741a5-875d-4fef-a94d-6b8698e248b0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-033	\\x674141414141427144506a3675544e7934702d766d454c764f6a79307259717142427079347572694952725a414168524a58546b7262364a303950426b7263544a47655242687832454a704e446d794353754e64665432546e7351507573356e48773d3d	\\x674141414141427144506a3666326351636979463056747039317276526b3661475f78646c646c7a4461663568597245485f4770734b7476655537464d7774524751754b4c4d6852597769585464674a32594b6b6a6b366e42665662635f4e464f776b426c317947646b35495f3062336d314a703530493d	\N	f	10000.00	Trader	0.0697	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	be087a0bf36e0db11ca8912facbfaf4e2bab76adb371a093ed69ad87e97a696e	f	\N	{}	\N	0
179550d1-8296-4997-97e7-f45675b034c0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-034	\\x674141414141427144506a3669306f364449735a534b5a6a64344576576e475950772d6d53427953584c593835596d35686a3645566f6b374f30434a6c4e556c4e6c447a5f654161717435327566426536544e35594c47337652642d4139314f38673d3d	\\x674141414141427144506a365739445f4275785961514c66504850425972637972464833706c51754c55323145636951317033635a574975515948566f334b6b444d787665305f74663159696c6e716f6a6d5246594b454b5f77445f77464e3256766d5a6f3170624d4957707463676e625a4c6639754d3d	\N	f	20000.00	Teacher	0.0680	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	88c478832eb4be04e4f969a3391e37c2eb15eb8d67d9b3d1ed6109d24a0c7548	f	\N	{}	\N	0
4ce9311d-657a-4219-be48-ffd7bd6ec282	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-035	\\x674141414141427144506a366f7868384777524c7766374a6f7752733544696168663879584e67367a424d62764437654270396c637143677556695f572d6f745f356e7a68494e616651766f336f6c4461537166574f43465f5959714564504a4f673d3d	\\x674141414141427144506a3658664361576473396b7a46776a4f583645784645707161376e4a393247765f5867326f612d6174424751384148384f673673394c306d67594e754953764865567a624a2d306a3648476549503245314b473433536c6a3550695f69724578345f547a656a717256744235303d	\N	f	10000.00	Trader	0.2237	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	335f436f69bd527b3e47da430de6b342499e32b3f759c52d939c57256a43f44e	f	\N	{}	\N	0
4a1c5b1b-2965-4c79-a7a1-e3488861e9b4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-036	\\x674141414141427144506a3637705f43794235593868576f3330614e76636f47736f74705655635348356d4435676a766e5130556b724a4153784e684d7a695477576967336e5671527965333072414f415243445a30516d327855495f4e324f49513d3d	\\x674141414141427144506a36566535435651673443517478626c6736744872614d42533275494c36634f757071726c6c3837736d314d75314c575855315843744264546b6449456e627769353737442d386c347a343275504c57423862776e4553563256482d6c5a596571336f74694733722d617554383d	\N	f	\N	Engineer	0.2470	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	33f0737100b2a6a8568910aead794573e865a94cb0beb9eac2b4dbdfbaceb323	f	\N	{}	\N	0
91901c18-1df5-4a60-812d-dde87dd44974	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-037	\\x674141414141427144506a3678713344577865566a7571536d4d3077623746705846547a572d34754372677771414c4d6b7349384a336662707070514757576f53397954463943674a667234486950324c726476697a3533466a5356655a6b5a4c673d3d	\\x674141414141427144506a36563642496d38595f6d65554f4964493170364363746b4e5647496631716b382d423333617775486971587258756e77525641775a61624f44596143625f37474c69776c6752723979374c306c6b4d793549554a6c6e644139745a4b4f574b6b5444376d636553523166356b3d	\N	f	5000.00	Teacher	0.1162	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	f47ed8fa8541fd60ca4e2546be77547bfcd3da13e0c5778d122f7c0950e27211	f	\N	{}	\N	0
ea52b761-267c-4de0-bf7e-250ea92e0757	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-038	\\x674141414141427144506a3671623631454b71654e636b48484931325f6a784c6d5f4156577177336965316965424848653875496b6b7376545a6f424b6967334d735669634535545275324d4b5539483357456235384c315853775866322d526b773d3d	\\x674141414141427144506a36584d66596841463062485771466f56413138696831712d57696e4e5132696b39617959585a4c38573431566836304b534e38425557574f543876315071366156686e3652505f5479796932424d7a5446367246556a47587252424343313133554f6a3750445446464a48383d	\N	f	20000.00	Engineer	0.0937	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	7f8c17405f1939be308bce81350872e95ae1a70e7cd3da51d454a86b3759d0c0	f	\N	{}	\N	0
0ece8fe7-fe88-40aa-bad2-cf7182459e2f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-039	\\x674141414141427144506a364376584e4d536b485439464d523872342d626f5030396b796469314635754434346f476d6e426d4b76414d445641576e6e3063753055576e44504470494c6d46464630376e6a325030745559315862417a766b4d37773d3d	\\x674141414141427144506a365f4d595f6b58793574556b543659566b687a5f594b586b2d506d5575366251673169413375514f634b36444e35733245656441584d70514f73635f72684c6f4f4347634a5a33353643707668763775587a4d4b736e6d765762456a53584136325957303671325f4a6d56553d	\N	f	2000.00	\N	0.0177	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	68c02fbe42e03b29fccd76547cdd5f3bced6b887412be97e5b8cbac39f419698	f	\N	{}	\N	0
1879d465-a9d8-459a-97ee-bb39cea7abe4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-040	\\x674141414141427144506a36384379386a5076326e6676626d385a375259786d58425861613857745438696c5f6b343438796e4347504b5a306c4832544d426b585f424667365a6e4a7365326673676c533251534669396d7441476f594f343267413d3d	\\x674141414141427144506a3650554577734641576c7378634e567465746c6e2d59536544315156494f54494e6e53453867756d6371416a6c55533562306c503261594147734530395746766f534d485a5f6c315832665f69454a712d79714e4658434f564c6c6a737378516d5f346c72616a49457049513d	\N	f	20000.00	\N	0.2395	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	22dee7499b0627cbed232655aedf29093f2da338480e7e0c867e5b0aa2110b9d	f	\N	{}	\N	0
6aca664d-2b4d-470a-b8b2-6abd64d14d5d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-004	\\x674141414141427144506a363279523568335a38314939376a31577042447132494656663844744156556f544357524869786669514f5a48574f7a55664269356e39482d584b724d447a334558376a34573163746f5950636b4d4c6f4e6b785175513d3d	\\x674141414141427144506a36307a66343864392d52392d427a6a696d454e4735344d592d306f73686a564450325a4f463134704857595149425562547a4644456e39564a56706733383249763778307942564951514d4a753074375a30576769332d55485534797a4c696e796264664a513750784f34453d	\N	f	5000.00	Teacher	0.7640	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	20d8d5d534a638997cda6e3c4c843c6885a9da2b69baa915da60431724b41116	f	\N	{}	\N	0
dc662a23-33a0-4898-81c1-22fe4404f5c4	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-003	\\x674141414141427144506a36564e3277383437656e4e6b765267487a52656b7a7147477654664e6230566b585f504c6c646d58436e3269634b3075394e59376a54787a6a75595f67667762744c73374c72386e6e494e5479734769326f50725067413d3d	\\x674141414141427144506a3666587179475254357a68555f4278695a5f52464d64653449613261325a596e315f54384b4236726e31667754694f53474b3074635a6e386d414162682d533666514f4b46623070767749496751763142785043715f4d785334414c3449774c6d7544386e7a51774b755a593d	\N	t	20000.00	Engineer	0.3000	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	SELF_EXCLUDED	\N	LOW	8fd1d4b6fc8cf5c0815b2908f8ac4b52d09221414d252abf8826f586370ca3a8	t	500.00	{}	\N	0
5f4b66dd-66b9-49d7-ac79-10c15f7b9e71	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-002	\\x674141414141427144506a3635435175584c66614c714971506a3279665851544b355f39495a676470722d32394568315a7a3750474a6e7657384c63336f4443444f6f76796b787a6b5446644e715642705937796d78594e775a76665f6255336f513d3d	\\x674141414141427144506a365761684261667658536c476e344d4a4247507138514430443476326b4e42413932556c787858303670724c4a6578546d67645a5251715a76645862785a4d4f5978776856633030686b33306339464b34444d634858556c686c635a4732584d666976695a6f7643584264513d	\N	t	10000.00	Teacher	0.4000	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	ad68d9d24a56dd6122a4fa6562a0cab55459a6b487eb73c2bc108cdb9fbe99a1	f	\N	{}	\N	0
9371d0ba-9daf-48ff-9238-25608be02cfc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-041	\\x674141414141427144506a3665795536624a33797a4456394b664c304b3267566369466d514a754a4a32704a36435f416e526a36487665712d6f5f6f34384b4a513347766175586d4d477473395a51586b39384b5a70424a56507732543252496c673d3d	\\x674141414141427144506a36427878553759664e3046715772666a324d445947446b316231343867716f54375f374454794e4254657637756354765f2d7864624a744a61414256536339423046534435626f505032716c634b496f374559547341664749516c3668716671304270716878445039745f593d	\N	f	\N	Trader	0.2178	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	1a9551bfb4f6371ce806009e5e633c3e1196740a1684aea9d8df6853de757f7c	f	\N	{}	\N	0
cdf44926-ab02-4862-a8f5-941025665164	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-042	\\x674141414141427144506a3631397a5f393559495a437338524c506f624879777a32446b567630522d4837386c65754d6c66684e436d67425954784231736b4a6b4266774a3430475a326e7557574c53633955594a6757314766336a767a4d7949413d3d	\\x674141414141427144506a366d6b624545436d344b69554c376430795a505744395a5958376f2d306930435f6a6f396f54586349504c64776758715f554d31635238517048675a4f495f5262665864526b52736e4b646d6a6331417a49526d5a4f31534878516e3945557337577a334f72704d777a50733d	\N	f	5000.00	Trader	0.1841	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	bf1df413d3963f252e1c92330ba3c85c85a7eac3f771495d5b33c1b3ba01ee25	f	\N	{}	\N	0
3de4c1a5-8baf-4300-a4bf-cf15438b4bb7	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-043	\\x674141414141427144506a36457449556152536443385a5831614a65656953387436774f454b2d6450646e56777844303658547164746744324f6e463361754c73663170793872535272447245644f48446d2d5a315879445531316a5655443345773d3d	\\x674141414141427144506a364838344359764b46313172593076595967716f484d344f634b475274314d654964775257716f446d59346c5f6f79305449753277506a3355707a63634d5f3732325230694e50655149544d51777756772d502d5f7a52792d634c2d543472696d464452474c7345715847303d	\N	f	20000.00	Trader	0.2582	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	41d82c04dec7a85975ceeeadf0b88e71034fea78758ec98e9f4d9c10ad19077b	f	\N	{}	\N	0
61da37f2-6d08-4e73-a16b-140078b22d65	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-044	\\x674141414141427144506a3653725855654257304455686c3445635a695a43354a4e513957554d76552d776d426f4845446358636b484766477a444e4634434b4e444c336770384358586930586e7335354971325f745345764746502d5536456e673d3d	\\x674141414141427144506a3636585a4b614572676b6d6c4c316b6e6e4b6f2d6b62356c345866424a2d46596e3352776d4968535530486c743865457249755155306c61647048716f634845465f4a586261576e5955674d37486e53324a69386539786b5f75696463684c6a72635259306956714e516d733d	\N	f	\N	\N	0.1330	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	fa8f6236a5917b19758761b5c16c1ff1dee8052ffc639b417e182005a8e974fb	f	\N	{}	\N	0
4df21221-0040-4a64-813b-199d851cf8dc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-045	\\x674141414141427144506a366b436766325331454c38462d776245794f386d59395644456a426b656165377834643554384e706f68487743652d7a6d5a2d596f7a51334c4c7532614b664e4b76743654757a584b436a6e4a45324d66774d4d6933413d3d	\\x674141414141427144506a36697444587a68784e53567747616479376b4469567432544c5870396a32634157716f5f716762452d52415171386e4c75337138376d2d6d686e3137593930696d3732796f7a646d4d30697a64666e763265724e79775f7a72385667695045757048564866575269723157493d	\N	f	20000.00	\N	0.2166	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	2db5b89047550e8289fc37571c15403445507f11454953d33d756d3dba3f309a	f	\N	{}	\N	0
ac617af1-053e-4af7-b057-993131613e37	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-046	\\x674141414141427144506a366c454377624774347457424b566e7354555861726b68565433437a44505a6a55507a2d79753049626b654644534b5933715a4d64336c57585348544d707234656a564d7471695a3665733764556c4c6a6f69684154513d3d	\\x674141414141427144506a36774c6459344668746f6454434531554e636335375132473546387a3374415f6173316d517838316649656839412d4a356136487633414142646a466f61304c4c57385a734c46704252767363715246345a4c756548737741516247304a676662324170435368624b4d4d773d	\N	f	5000.00	Trader	0.0617	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	e514864d63c3a0f56ec097f6ac9e10ecc211e154d91c78d02f132ed2aed4aa05	f	\N	{}	\N	0
0a495ede-f284-4488-9a5d-3e8cb1dc68c1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-047	\\x674141414141427144506a36306c6c6e4e4e507a306d787a52573461777249396b5179617a654668675f6a47304a6736785a7541476f734e4e6b445931444276706e46336e34352d69345a55334e376b6a55695032555656753079315773626c77773d3d	\\x674141414141427144506a36545261504f4b4b466a47504b774149787565454f58713530626944507a5755766547454f726347574d62464b386d6c5a69536949436769625451674c35726d61564e4c38325450776c4842365f654b4e633541754931714e35514a5a5645534330724c36635f6b34524b773d	\N	f	20000.00	Trader	0.2475	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	f010334ddba33c6b73869b547a6497ebbbcd1f260a7ae17472615ab754188ced	f	\N	{}	\N	0
dc03d498-356c-4fa2-aa6a-d8ee31087c61	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-048	\\x674141414141427144506a3668414a793451433476386a6a7766416a6651753073686d626b4a4748384b526b667133786744573765626a69613144426c4e6573314f344367574c346f6f762d65545845472d4d6745586961693441307867754744513d3d	\\x674141414141427144506a365145325f2d724d4f434e7379376f6a706470543071517538696349716d6b6c773958526d5453753368305f36304a704b4a4d6e32574d564f3545304e495546754d4a7473645f746e4b5676305f4749656b4d51466255307441712d74575677352d4778754f357866356a303d	\N	f	5000.00	Engineer	0.0460	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	6bc884bafc773b9cc0087557245366e1c385f52479d78a2aa8e067ee568a8508	f	\N	{}	\N	0
0435bd1a-793d-4e7a-b0bb-458edd771feb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-049	\\x674141414141427144506a3670372d665465327a6a624279432d642d366847653047597834767079436977757a6f54432d6c6d574742626c655f56566a784b616b6a396f67397641784c4f3935744d5450526b44752d6379666e636c694d585530673d3d	\\x674141414141427144506a3641415742456573394b4d7a64397565656c706167414d6d525f424546395a6f4f75486474347169734d51634b484c5665443539514d32502d35383055566c386963467941396c6a5f416c43465933723141786c6a683071654e7a70782d66355678373054364b746a3345413d	\N	f	10000.00	\N	0.2341	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	b8765223609c6a2c44410878206da39d8590156b8fabe707f96ede559a8cb4c8	f	\N	{}	\N	0
ce926e60-a671-41ec-9a4d-1ba7afc2781c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-050	\\x674141414141427144506a366a695556335a7848795851615a4375685a376a3654695452674e756a3851474d4d4a617032354f7237534734494c6b696d5653547377784b4a3676306d307634795157665474395268746a30317871443864692d55673d3d	\\x674141414141427144506a3674725663326a4c467646306d6855452d414b72774e70767065764161345f314b4f556a572d6c424455435f7730536c5a4f48702d6e6d663463646e535f43307058357259544b6442535934753045616a2d634b6e4a556238663042632d616b62466b364f33566d41744c6f3d	\N	f	5000.00	Engineer	0.2061	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	c9da2f0054c5941b623633bf1b748bcf3e54c5905d24a46f3f99e33322204d17	f	\N	{}	\N	0
ac5f7f44-115b-4d3d-b92b-487a8a7c259d	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-019	\\x674141414141427144506a38555f484d5f6838483033527a5561624276637437614b47476376675836364a395757524b33596c683561636a5a7036434b596c5351306f4f67667a5842717732706e787462524369653436485872526d5a69577645513d3d	\\x674141414141427144506a386d744d6c434d5268544a495958636877317744714c74445846715453662d595f7461576e416f396d514b59433751626b4a356e75725f6270447132314a5736645748624e755f5a47474650646d7130574865386f4c6266386c5564597753735f3553423872595a5157576b3d	\N	f	5000.00	Teacher	0.1448	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	ccd5fe6950c7282dad9b5e26c4fb8b6c654f8838199819f5eb7dd06eacad415e	f	\N	{}	\N	0
4dfc9863-92bf-4ba1-bd76-49f93f497b4e	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-020	\\x674141414141427144506a384a6d6f5472444a5f653461766a314a6f626e536832336c6e46436f4236786c6d6a474969436e7679797537495534614765506b504e497452494d6b354472436f4f6a6237777071386f51696d704146346b6d697531673d3d	\\x674141414141427144506a3851344a342d4670614b47564672375470723865554e3849646d2d586857626c495f415259594e7237327870765f5f35744d41595a386c4a6658437643437050554a5559454b6c6f59764358745f4f305639596248504858413542466a7945547879566758567138325a71633d	\N	f	10000.00	Trader	0.2458	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	b6f4ef983d7a07702622adb004a15c51b9c9235ab2e20602709f6a23467c4a06	f	\N	{}	\N	0
a8cf153d-bfce-45b0-bcb6-465a8a0e6f68	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-021	\\x674141414141427144506a38394a726c5f794d755869485a30666d563658766a5468543437346e32477a724a474f624f3576543441624676386d627330756e724d384a37576f4263483243744741362d4375424e476a4176735139445474463263513d3d	\\x674141414141427144506a38333349657a6635373254584c5352422d776d306177373659645659583378784c6f785167436b75355132355466612d36536b757a514f795f6f69425f38386f706d6f646c54527271445a793462546a717868562d355948794b3379453649434936575277464a443244734d3d	\N	f	2000.00	Trader	0.1862	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	03af2d35cf1cd15dbcf337a845d11484ee27a77d34ca6700e90528535a619817	f	\N	{}	\N	0
ee4e4786-42db-470b-9dbc-3fab86d36ee8	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-022	\\x674141414141427144506a387a68336b615832495a595951563747564f776f437261766249534e617138706639514c307a61306b754143586b626172567a74536e64383337686a55516d554d416a6a6e58735870644353624a6e69464d6d366e5a413d3d	\\x674141414141427144506a38734a4f6f50586a334748594c486e4d756a5f6b4c4f344f464a4e2d73463774424c663972376a4f54684f6a56497a4b5f4b506c45696874445a415f632d55724d7175347a7479524437724b37304834583047363646634348776c79412d344b4e64764f54325847366433303d	\N	f	10000.00	Trader	0.0369	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	8c91448cd412fc61ce018607bd7b323a259ff3a79f5680d0751d525e6d11d446	f	\N	{}	\N	0
8db10f15-722b-4bb0-8fae-46675d0da88a	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-023	\\x674141414141427144506a3879624877344855797a46735539324e445871526d6e4b47386c34726b43342d654a4961696d48475850536f776a356b4b6c3769756955333638686c4a6d4a4f4a6764455f507633516c7465354865787a587447426a673d3d	\\x674141414141427144506a38463650426d544965484e57507a657368745f79646937624c6e6d4a32617648474a652d6a35525f2d37455a416c38325f6c726b7a75746c39767173746c477031682d4a4a3331597774676264426a736b4f65426731304e4b5a4e325647546c615677736a785755793172343d	\N	f	10000.00	Engineer	0.0491	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	e198dd078cc487ac60e654f9cf0d2b5d9af745ac4560352be246aa06b50f41bf	f	\N	{}	\N	0
23b9d36d-0c52-4e54-91f1-edb5d8f822d3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	erase_test_gap7_1bf4e916	\\x67414141414142714548705969484b316a342d4b416e6753415a4677785551727a50574f6175624a504a7838704a66784970644272377754547947434641505042787161725a3941474634694f3563755652704e70616f4137374156364e706f495447636d2d34505876474b35554e6e5a574b324238773d	\\x67414141414142714548705963646c353767545165615075566776423135785663753451574c475f7a4556654a795a4d505646657668744d68773949615f64356f685764467430663862523341384a535739525f6f6e306c456f66575772563255773d3d	\N	f	\N	\N	0.0000	\N	2026-05-22 15:46:32.671791+00	2026-05-22 15:46:32.776236+00	\N	ERASED	\N	LOW	6d727ab65f67bdad5655800a450cf560dfedca0dcfb47114ad5bd0dfca701043	f	\N	{}	\N	0
c7f730d3-4c94-4659-b411-9ec765f4e63a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	erase_test_gap7_e6c634c9	\\x674141414141427145487845715a6e53473455667035715849776f755f3852344d756d6b5659377870305f744c414856666f33676339456c374258746d454d4f71356737693870374b5963347842726578532d733030704567494571614b4a6c62665f61733747634f6b4f464d6764564e595a6b567a513d	\\x6741414141414271454878454a344c5661326e5a74365036674936712d72362d692d31706e6a364a47516c7054695073503063765063686651533468346173505a657748784349715f635f6377504d466c6f4b73653432726c594855643453424e413d3d	\N	f	\N	\N	0.0000	\N	2026-05-22 15:54:44.015545+00	2026-05-22 15:54:44.054843+00	\N	ERASED	\N	LOW	ddb59da99baa199bc99a335d25aa68a42ec8ee5d235d48dca655f614c8e3de98	f	\N	{}	\N	0
3dca48e5-9da8-452f-b1f6-2533bf111baf	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	erase_test_gap7_458fbe56	\\x6741414141414271454833346172384d47552d437a6178536154325772547856395a44697255444a327238314b7573676b4971735838784f4f4f4c697368484966746859796b686a71655a33637342454c4b644f6a505f37585877765536746d3833414f6f3233614d5f42566c7872797a77364d6c53493d	\\x674141414141427145483334487472656d7570677a61394a374e6e446f526c6e4165544a756b66334b5877764c574246317074324654445566614769575334504d384e564f3951694a6f4259414a3930694c425253526368734f6d653150597a34413d3d	\N	f	\N	\N	0.0000	\N	2026-05-22 16:02:00.661377+00	2026-05-22 16:02:00.685526+00	\N	ERASED	\N	LOW	6b8c0795dc6cbad049c9e6775377dd41b56f329771b24f49bcae61ab3d22db11	f	\N	{}	\N	0
defd8826-200c-43b0-8ac6-1f57a384bb36	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-001	\\x674141414141427144506a383666717478785142704c385f7a4b637a64366a644d5a533070667658794655354b6833464c38567942446e4d786c5679343057596a6b2d4d56487834385869536b55572d5a77306c66666d5655725f626a61643270773d3d	\\x674141414141427144506a38777259706e34303063526c5a6f4970774d5a644d585a514a5366434245634e6c47346256446c4e4c7031556c756d47346c504f6f6f434c6c6b7476444c6a426a5f5f514c6c72663038756e4f566375554e566932722d614f6d4b546734584c38506445446c6269497143633d	\N	t	20000.00	Teacher	0.3000	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	4de49412d59c83c1d1e6fd529bdd6bf761e7ab6a23a6743874e503f6997abef9	f	\N	{}	\N	0
0e146917-2e26-47c4-ba5e-3506cac9644c	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-002	\\x674141414141427144506a384b6c3158435633325a73374e41737639616a567a4b646e655531304339454564766e5565364749484336596b4655745f586d6261595870786675326b63456278305a3946504777656b7349574838336d584e2d3955773d3d	\\x674141414141427144506a384742596143345f7536635551485036437a787a523167705a53714f75523151305547416e587153385856465a4c4550594e533631574339305f4d4d355061414450373570333738394a392d32754c7a32466b4b576944626c674667446c3567747533445a4c6e7542726f673d	\N	t	20000.00	Trader	0.4000	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	f2c7275021efa387a1a91a4c5a71aa320e2124ab4e1ed2b8db73bbeab422df50	f	\N	{}	\N	0
c3d5fa96-9a4e-4f70-aa98-0e36d66ffb42	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-003	\\x674141414141427144506a38715f70436a4b7a733151724262394f2d6941334c4c326b574a50326f6958755f685650367750506439706d69534c553748764b6967685f3476797159436a3442735031514a46445f2d4f43526b76726b79776c5549773d3d	\\x674141414141427144506a3846356c6474536738586a636b513662796d42357041487a5f573075336c737435425a67467368503045504b767a767a715857413476474574706c757043763759376c794e7a2d53367749626d6374697472624f644e31335676415144305a5f5a5259476d4a7555307235413d	\N	t	20000.00	Engineer	0.3000	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	2a342dc4b392d417b8c300bb3a635f85aa6ac9c4826bd4daa1ca862f0cd95a2f	f	\N	{}	\N	0
295626b4-138e-4166-8bcb-f9fc7e4febd4	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-004	\\x674141414141427144506a385959425a747332356a6b42416f4268764876366f487174796c594a39616a4d35355a435a3457596475565935496a6e7766435f525f566f4b54624e76666f4d6a395265757774644d716478396c2d4a704663614f5a673d3d	\\x674141414141427144506a38464749504b766e46683771434a746556344d5966675950513567777a536e7973486c34644770354353553745676b497651457048617338674270473749616f705a6b47516e495162514b687a5335684e656751337a63487a2d377547434844335f34334d36524d643355633d	\N	f	\N	Teacher	0.7640	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	70eb09e0d6917b6faa3e103f0d2aa0386bd1dc451344ba39aa736da4ea6db540	f	\N	{}	\N	0
a67bc53e-5d98-43bb-8eb7-169eb71d5672	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-005	\\x674141414141427144506a38566a7a6b742d4f5171446e7158582d423147387777655a6e685f437532333741586d6f5561464151706d30715f322d6d736c4c6d6a43746c362d4d6276654e32594b2d4b5473624c764a49696b6b784c664b635a71673d3d	\\x674141414141427144506a384179527266545652376d6830657552532d7738516f3047444246305059536d4169394d434b5252366273303842613466556b54777657485334535f7855326a614c4533735a644d7646624654646c41536956384637734e636a61426f435761436d69393578587557735a773d	\N	f	10000.00	Trader	0.2067	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	23604e5ba303b1e79e7c0796c1edf449d6c0f56b02b69904b274a7a8605a078b	f	\N	{}	\N	0
b811d880-5ff0-4dd1-8dc6-049f7ba9c370	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-006	\\x674141414141427144506a38736a616d55744462785a365a6d41775970304549693247334d3954387a4d417a4e594e5a4469384954564b49723958786c466861415a6d6136622d4e68723263366c4e4d457432346d63476b53655048725066364f673d3d	\\x674141414141427144506a385f64716747336b34626a38344f61334c6233576d4635395562727142436c525f5a4f445034725251506f37666a77366f7169545432656b4867375935306e477270753954674e4e472d4a306535766c6952515476585552592d6f392d6d45516c4662417a526f726c3952303d	\N	f	5000.00	Trader	0.1084	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	d82f87954e39d44bb22dce7713fbf5dca1d6b6b2982351ac109e0682f3a09575	f	\N	{}	\N	0
4e15a90a-2a6b-430e-b1c2-faf7586f6dbf	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-007	\\x674141414141427144506a38667758325836505479656f4f6e36324a4a6b4e4e6d4a64525654436767706b617a41387137756c6873394b77707569514b48416638366d376e6a524b306a77333275796a69516d686d377471694d48757a444a6f59513d3d	\\x674141414141427144506a385867506e534c343330653679785561436756727178446664424b41715149533459623835366153683069734a5352626967325831326b614f6d4458434369706b5f474b6b616241734366306841674853546d4154345a4b364c38544c57546879414d6337635771466559513d	\N	f	10000.00	\N	0.1275	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	6577ca75cff1e02e8561b3d42ecb19a5fa631984eafe251d85a2f168b826dd3f	f	\N	{}	\N	0
371c8244-d9e1-4ddd-a9f0-12970ff36d96	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-008	\\x674141414141427144506a384b515a375648756e437334397451345a735a502d50614d36396748663270576643484162774c6a6971715a2d49754e72704a4474777a634e476b62304b4e61634f6f676458556e7745384353614143334530786a62773d3d	\\x674141414141427144506a386233334d3332534f517136375f43553858685f3676513657524553636d6a51736876455a46466e53506a5953595a794846457a346c39636c3578304f6e313866585742746f785a6a3554735331347436625738644b2d4d316e4a756b6d497234686d614e734574414276383d	\N	f	\N	\N	0.2799	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	4e8bb83551746c0c1fc9b77f5d5a76fff0e6635a8c580727911babbcc2fc8694	f	\N	{}	\N	0
f71ed380-a936-4b4d-a075-1b3fd6e022c2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	EXT-OPERADOR_A-001	\\x674141414141427144506a367076374e443561676e68536732304a764e776747534d66466872496e5546447474747433384d506e705164774573376c5f70353036436b545a496a6436354c6a6f6d6a4e5136714e3452616e487a4a793461755237413d3d	\\x674141414141427144506a36487958484f6a443959395645696c46784a63504e452d785f77736e496a446274775450315870697a4443416b335063747244666332686836325a554a41353756425369334c303279694c4a725a634d766e694f7830534d34443236515771747375557a5477466b50444f773d	\N	t	5000.00	Teacher	0.3000	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.007202+00	\N	ACTIVE	\N	LOW	c7ae12d75b93a93c3c45e229b26a305e0188c17bd84e89ed0971ceff376c8be2	f	\N	{}	\N	0
d4e87fce-a3be-4ae6-b6ba-a1c93e37460a	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-009	\\x674141414141427144506a386d4e31786c3162786d7a6c476a756a42776c565939416c7730373655314130524a50393848466d563557396b6a627961613365457267386b436939694b45413154674f63304a70457565433948372d416770465963513d3d	\\x674141414141427144506a38756831495a583635756b6c6f32743771635a465778643746375655546b534c5f727a3374383665625a557a747a37784859714436615467354e6235726f4d4b344f4c6e4d6f6f7377664a30415f5f53677051313671786c72387267784a5875446a75545f74512d535365493d	\N	f	2000.00	Teacher	0.0524	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	5eec4f6c62bc662cc18b23c0054a2c389fbdb445cf953f07e9f4f4531908bcf2	f	\N	{}	\N	0
2f36cc85-3906-439e-9a03-0af888a1341e	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-010	\\x674141414141427144506a3871793859396c5f6c624777375a666c6864762d55653679776643715a4f48734e50314b4c70572d487944724146505a3343314e585f4b4648685958592d6256474737467a534667737972497a6c6d7030322d5a5a64413d3d	\\x674141414141427144506a386f7a6633714c72697659726b6c313054636c39683559796f78564d653276644f752d712d52594375356c477370696f70586c694c4c4b546a517870767a4a77395934535336546d4c6e48756b356a747a583636507a644b56784278375863377347326c43436a5f725a43733d	\N	f	20000.00	\N	0.1723	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	d91afed9c74eec61ab76352be4f753a238876566c75f0891c7e0e04b790aa020	f	\N	{}	\N	0
c71b4841-809a-4eee-ba71-b93375320407	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-011	\\x674141414141427144506a3876714e567779395072702d63307451446950416d674c76424e4249696e716459566b654a4b63326543454e47737430563253616e494645695838714e587a62613249727144367377487737376e4b5f464730645a70673d3d	\\x674141414141427144506a3846507a4e516c6e32345639454765323070424162584d58766c573430787a3134566b6f73536a4d544d4f4451527a626d566c6435394d41665762574a586a386d747738394a424f56526270684f2d304c35534f49616c437368584b79676e55617770432d44514d745935553d	\N	f	2000.00	Engineer	0.2303	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	b198ec646115e02a7cf9dbd8893513e0b9a66cc740366f68b62574d1bcc7b5a8	f	\N	{}	\N	0
6837efc5-9866-48b6-b1c4-7ddc3c89a369	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-012	\\x674141414141427144506a384d4f4c795639796a6b723739792d57505736483472696a65484c41446b2d446c5256735f7a493537517553544737766c5742465f324b6b614d644a6e6e64617244375f306d67726e56657962434f58535571416754513d3d	\\x674141414141427144506a384571313131584b51683532704f465335654f6b4c43613735774e2d52686c767a5671767239536963305753645338376f56384b525148706254496e51466b56624f544c777258454433583349707a415a7971714f4b786b33314a5a4a3049386430515070356e7a443545773d	\N	f	5000.00	Engineer	0.0969	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	eef3504ae13e9b15ceb85e81ce3b7d59b741856211eb5595b1a184a4da1f0af5	f	\N	{}	\N	0
d569290a-1524-4d80-83f3-17c09854ec52	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-013	\\x674141414141427144506a384732686c6a527570574367656159706143694964364853624b4b6767456f4f4e6a756e32486b79794b62585136657a436e31575a64344e46374a55394d575569456477586136546d66703156304a774b467265614f773d3d	\\x674141414141427144506a384a763655786f6637502d585f694e3455594e57646d53312d48304854745845775f666542775156756149345a41304d6d7977695f43435a496a4d4e395730435755694f4f416c4d333567566f6f79524b72376e6a6e636c714752746b44567272796f576b444f4167692d553d	\N	f	2000.00	Trader	0.0310	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	5e754a3693b878ab2003647dffb1ce9540b0e27a5b569c4bb9dff19edd55e22c	f	\N	{}	\N	0
bad8ab61-c22d-4c00-a093-f0631d6c931e	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-014	\\x674141414141427144506a384d36436e6c4a45356a59416d49786f477646507a68434a4b5542463748443935367470744159306f746764686f5a3159636746687830364238625f43766a6b796b5072414a643858345468764350396647466b3958673d3d	\\x674141414141427144506a384f5f5a704445516f7561355954656c4f556866437a79334e7473594b744b6c5845414c35485639675469532d3466524f5752686c474d4e4966344d4b4d567155492d54464c69785437714c6c69634266426577616a416531767a667a544d75774e79697a66486f486677773d	\N	f	2000.00	\N	0.0143	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	9bcd9854048734fb89ab65090f20d5fd8e27f3ae8038276ce6b48f0923baeda7	f	\N	{}	\N	0
b36f8e0c-f97d-4a01-a7f4-ccefee71ef68	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-015	\\x674141414141427144506a384d4b4c2d755a484c65586b4350356355734b4945596a47485455546b76536f656f74336f4f45485151734f5348615352495536514f6656686f6937483463346968586a62634f50586269525374544377353246364f513d3d	\\x674141414141427144506a385751327a7078624e517a756946466b643056464f49504756707838484b526a69714d382d6c616964504f4862524b4832785547794171445633796470673731577679484966626162615f7977724348794c7266575675686f50757935617552746a614c394d64455a4f51453d	\N	f	10000.00	Trader	0.1945	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	a4ac49ad3616abef9c20bb7419d34528f95a978004f337bc3d2b1e4b842c8bf2	f	\N	{}	\N	0
092b8455-8bcd-450c-b760-56c76e04a7aa	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-016	\\x674141414141427144506a38473857456c7367597036474f66634f53326856554e6f744b6b723856743033566d546a5337473167654665452d7a794d355835517945526e42317a386b377448306e2d30452d5456464746637265523178694a7555513d3d	\\x674141414141427144506a38316e5f6c7475345248365a476c51396a3064686234357848737236565246376f7174584b444c644b32704661687a7a426a735a466854543758794c4662306b4a6f74344f6b484566396a45486c3649366c7751473934476e536b2d52734e684a5049744b336767747749453d	\N	f	20000.00	Trader	0.1661	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	727841e2f387de9f606f275663975efd2ab6ad1a4cfb8880ceeb18167167822c	f	\N	{}	\N	0
c6cb8ee7-3128-476c-9ed2-b68dd8bae19b	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-017	\\x674141414141427144506a384955395f6147687661644e596d5933336c69534b37774665656e4174767a43714e6661667a615435624638766d4f76502d316473457443316645726443527a317349784f68794a746858325665596c4a4c58776649413d3d	\\x674141414141427144506a386a33595350333452386d64786b3151303361687235674e70396e534e4854534a486672504b52535043675555724a5246437867775a316a596c4b6f3738454a39614b6e5f6e5f754d314b777a37314f5a636a71364d6961434f674e655a4f512d5a396f6748724a7a6250673d	\N	f	\N	\N	0.0694	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	3d7722a513360e181e123d1aac08f90c85dcc2d6a799660786813a4e11a69ed4	f	\N	{}	\N	0
f3b2ca01-ea10-489c-a519-db7ec215958f	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-018	\\x674141414141427144506a386542494a69723335584f783262474e566f7a686366326e636744765a30316e70315f794c58685368457164303372706a506d41744362613671595363626f634e4d554f373650574737544168666f4b7a664446304d773d3d	\\x674141414141427144506a387249774573514b384b4e673162315465557270363732624876534e744f727373764337366c707a364c63354c706f6e71426d7a737259376c4a597a6c54756f484c764b50796e58686f6d535f76746e38524232765f38544c644b694a504b50764f4b7579626c6e45756a593d	\N	f	2000.00	Trader	0.2736	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	ca3e944c7d947ad92e50fdf6f2656c929d21cd8e6f1842cf0117352c7b4dcd83	f	\N	{}	\N	0
1f459bec-83f8-415e-b301-4c1515874c2c	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-045	\\x674141414141427144506a383961485f343365796f6f744955434d6c465066774a7850704b4633514473475a525f36503341514132644b37703869765835646f535a4a417a4932476c6d4b55626f31584343757844675f44755a767a4164516954773d3d	\\x674141414141427144506a38447a4c745745396554586c4d6d3062543477524556323447754d32453245766271316a765541724e52654e6e6932633749674b665864364d764e63704871717656703157547748724c33644e6a55554d4c597476554631736e7645707755683057507644614c5a2d3238343d	\N	f	20000.00	Engineer	0.1677	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	761162789bd4514a5e9c3ec58f65f1c258a45968c005f9a57d1a64479be14b24	f	\N	{}	\N	0
8083531b-e1f1-49e6-bf27-68243ec5d09b	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-024	\\x674141414141427144506a384a4330387a656b664d41513566304f6169345962306650652d6d63324d783643523148337461314b55565a426b355648564234644d493635696152343077702d743649345932664645617a4a6d4f6e4c5a56487458773d3d	\\x674141414141427144506a385a6e4e38633448756671775f4e55753668737a4c69446841353452367868435843666c5835423163426562457a37474c6e70757832545733733069476e754f6a6239546c6c6167666d786346797a32506962794a5843395278344e6b6b726a7144524f7a6e7144496347733d	\N	f	5000.00	Engineer	0.0971	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	b7283a6dc2afe2458e3eefdc7969be7566771d64e18f52d8ec034fb0d362cfa3	f	\N	{}	\N	0
3e704bed-b0e7-4c91-8199-3d26d9a7bbac	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-025	\\x674141414141427144506a38367678427976546c6f545f416c532d6e4669334165764a374a773732644b4937634a58635734724a5a6c7934646d3967574630714269416f68356f4b624645726b73796e49335a6657527a6268755159506330546f513d3d	\\x674141414141427144506a384231654c4871726646725a734c414451776a746a64642d695a464e3656746b74454b327771305932452d616b307268795f6338786972676c4473527a4a77736f4e34462d547072447965626f426634416f4150705f6f5f41333673305550356b4c47575248704a527664593d	\N	f	\N	\N	0.1245	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	b9d2884c31a7c62769efd4c4b7a0fd3bbd552bdcf4def97f9176e0c8903a25d5	f	\N	{}	\N	0
6b3f3caa-2e6d-470a-9039-14cd84f78713	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-026	\\x674141414141427144506a38304e4c32356445785f43754e326935543570514c432d786e4b576c647a35394f35627a53342d7a6d7a737143304c685f6274436e56546b2d417863422d757238612d424b5267615f47346c346e4a576c4c756b3778773d3d	\\x674141414141427144506a383253706e6674626f6556562d4c4435654d3641592d31572d6e7068686e38484b54597930685035365962695f4166464373357572636548357379636a7a7539427557542d396a6c53327663526a74635246715934425175637a3753562d7850376937677477346e514751303d	\N	f	5000.00	Trader	0.2538	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	cca076fcc7167b4b9aae4a8bbef5adf5529fdecc675cf3ee67d8b28b421eb76b	f	\N	{}	\N	0
da07b061-66c1-427a-a19f-6bcd9f3b389b	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-027	\\x674141414141427144506a383250413468736b797a384a68324a6179596f7a4b67587a4a31676a5a70435563446875335379307363484a6331717263534f5a7331747064437a336a52346e6a5737626177435549436b586c6c6430305137735f74673d3d	\\x674141414141427144506a38415a35772d6943656944756a57724e6c646b656d786d467746654c54446265415f4f32686b4a45496d6c30364a6d6d6e41796a4c6249464176694238586f396e4d653247384334577372334d4e526d776c5233772d654d5275524d584c6c554561305251504a4343512d453d	\N	f	\N	Engineer	0.0580	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	1d81cbdf4ad9c09442bdb253f1d7e879ed3a3a848d527aac66ddd1dc9de96f30	f	\N	{}	\N	0
46add1e3-44ab-4e06-a154-02cee46b8bae	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-028	\\x674141414141427144506a384b6c2d45535a6e37315f31686933453847734e7770734d6378703239324c4d4c79414d525a616f42317857697a71643176797555364e6b394c6a303453655a304a42492d35365a697644744a65336c79506139317a513d3d	\\x674141414141427144506a38397148765a49526971635254726a567a4f5f77786a4445705230725362724d6446307867444c4236375f767856695632787336526351345361516e5064377a3146726177564e577745704b4b693731455f567a6a4e55335f7a69665669486d636774583366306f334876303d	\N	f	2000.00	Trader	0.0131	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	99d6cb4d39d4e48f6c871bc809c6dd302dceaa611d5bed55b0bf32d7d0d1f231	f	\N	{}	\N	0
56536a94-92c4-49be-bc93-3c59f902704e	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-029	\\x674141414141427144506a382d574c3343556954787a6a7474767259455635796d3635666e7946555556696377784446345a5744662d6258655157574b3033596b7137413062557769747342655952495868464e61716d48736449536931337a41673d3d	\\x674141414141427144506a387139665f5a4b62494c686d697a476c646d6934623872744e644c534b36654f7371776b6f4367515267767469695a434b7835706a38655a344365766a6169434554424750343867366d564a4b524d757833704849736d756f4e4633652d6d39572d544a4a4d4238507049383d	\N	f	\N	Trader	0.1917	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	b870a71450f809be538b76e307b8aa12f95f22d6b89656d923c27c1dfa6be91c	f	\N	{}	\N	0
946518a0-a764-4421-abf8-db158dcccaed	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-030	\\x674141414141427144506a386e533934796d724d32713233476f4d5a677a4155755164696a5665584b3031493676637077674d743952644539536f786f477072386b77396a68734c46656d596f734a636e70436c4e754430737851416e47797972413d3d	\\x674141414141427144506a38673942714e577147502d712d49777a465137784351644f5f536767556b705a306931445951766e64774f5255476d3734554e326f322d3950716f655748695042785a32757848584672424c364c4d67746d482d386f3078665978545a67637053674f51445757646d4c6a303d	\N	f	20000.00	Trader	0.2130	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	944aaef15c875e008b3844ede48bba637f9ab34de6044988106ab075a0d31e6d	f	\N	{}	\N	0
440921d9-b0c4-4f32-b140-954fa9216e7e	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-031	\\x674141414141427144506a384678763854314c514a595075694335375f5169344d7171525f6f4a796b49452d4e58536270304467756444423569362d433550573630707041773455676b325253635349514258414a33416e7a4636744e464f6d45773d3d	\\x674141414141427144506a38467a7037674c6d584c73543535526e35535a68536542444962784c44672d756472535a32766b576d73693333356e39777475613344632d552d5769747a78652d55596e75464d77384756786435545163714b46325967684c6356584f30324a4430665257486d48426c44453d	\N	f	\N	\N	0.1341	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	b7d1a7906bef96ddca088769b6bf3ab36acf02902515fa25fa30af06e8a1328d	f	\N	{}	\N	0
6c559022-e32e-442b-a948-83e4df412f51	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-032	\\x674141414141427144506a38674568346a6e5a6c717550304556555671366551706244333331754f704b74724f707767766f5f5475744576506955394f386e54576a4a6b44666353746b3531546f36436c55514f4949766c343071646e55754539513d3d	\\x674141414141427144506a386f6c54616c4a6b57666976634b70795762735773774a475f66394e63772d64536578384865717754667078516d4b6b38474372794b4430484e6f34343373445773397942536c4959676853476a463666614e64504a4f567536566a5764385937414743764f324275626a773d	\N	f	2000.00	Engineer	0.2520	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	42d89d6c3d3ea9138dca484e7db4c4e5d390f148bdbe5e07c3e37c6134348131	f	\N	{}	\N	0
b6a32835-bc79-4c1e-8384-9a3af54b52db	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-033	\\x674141414141427144506a3842473341744e5a6e63574774413749354f664a6b4b324f31455f3138434856634c47345f55336a314b6842466a76795a336133424c5f7a594e6c6f3857516857393078714142664e354c3774646b306b4f39486f4a673d3d	\\x674141414141427144506a38425057457073484472526c48626f7a304d35724d4f2d3543774c43305f6d4e445035304f4c4958766731375a654d336578312d672d616170355363646f7070494b6e543535383443395571357773435372696b3457304b7154796e6f376a6e367179736e5851396c7034303d	\N	f	10000.00	Teacher	0.2843	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	f8f065fd7f1630d9e29a2e3568a889df3c083d7af9daf7e6c3f8520273b41547	f	\N	{}	\N	0
8c8bfd82-fa1c-4626-baf6-dbfbf16804b4	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-034	\\x674141414141427144506a38517844726d2d78612d427a735f6c7a5832474e6572693152324e7a56344d4d5f54516a5373525532372d544b3633505a5941615475395266626c5077384c623273396e32506e4d7834643632514272677748395870413d3d	\\x674141414141427144506a383258784869394d39304a5839746d754544365968436b495a6652474e59726b6473695362745f377a584e76704853666162787664686a6e76654f464464547578664f5061674954305238643443644849484c5932773654353238795263395f6b7156505869564f6a666f593d	\N	f	5000.00	Trader	0.2142	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	c59ee6608865ff23f779c8f35ad2d619fbde298f4c8a83ef9e7e948413035390	f	\N	{}	\N	0
c30cec85-dc3a-41d5-be47-9ce592b74f79	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-035	\\x674141414141427144506a383532327a58416a77687638366657472d5850414e6f6e2d4765624c2d4e622d433431644a6c504a3356776c57526f68524d7432414d7a44334659647762337976394a677632766a6536744a526730514a63596b7973673d3d	\\x674141414141427144506a384b4761626d66304c6c44306c66717143563635495369514d6673484e6f6752694730436d36716937633573695f5578706f7847596b446134773461314b30746e447153695f69334f7965744968346934536b65396232546a6d5276696158676f6c74464b5f6f41536654343d	\N	f	5000.00	Trader	0.2323	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	8d5e68c8d0e665c505b2cfc1ae9e709eeb86470900b4a2109f4f5812afb32c9f	f	\N	{}	\N	0
cdd1cdaf-8c8f-402f-b9e3-3d99ea38426b	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-036	\\x674141414141427144506a385a75455f74555a4e54623734306f66585f7748467a695677454f5a6763465577474b3838425a6e68496635755970733751676c42796a6f7a35304d51596576544756485450747351735f696336662d30345f7a4468413d3d	\\x674141414141427144506a38386742384b615452665264626667647356474f5a47744f366a386e563442616f344f493849536473574349356e42784d5674334c5a456e634d7264766b426966693358466a4473645f766e6b6856344d584d6554653268574462744759394a4a4e62774636777841614a673d	\N	f	20000.00	Teacher	0.2267	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	2c823009bf0b805878a2bdb034e270d0e7ab0a39db758604549bbd3e8a4b874c	f	\N	{}	\N	0
5b91f275-e5c6-477a-8e27-601d6fc7fbc7	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-037	\\x674141414141427144506a386665636f4963735f51544d6976564d6f334a5939624c42314835656b4d6f6c41556e446b6c3857434f534857394e6167716769414d677463515a6c666e326e6e6665545742773978442d39466253453470554b5a42673d3d	\\x674141414141427144506a385f3241644f5546684e624b756848647232486a6970774e424f666b6f384e79413253585769654771376e4e727055734c795a3055617549356937344a556c7168784642762d7a35795974645f534a3872414c454f6b3563423441615463533868626c6d4846716e303559343d	\N	f	2000.00	Trader	0.2660	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	28f883ae685062fd04d93a8950225dfcd921ab6d6b2fbdf6efbd4c472a925725	f	\N	{}	\N	0
27a05739-9606-4c16-8154-4d0ea122a2af	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-038	\\x674141414141427144506a3861797870574e3761387959522d516a3373336d58715649585f50437469744d4c62424b69304e706642553570423379422d3932794b703431466a796b68666974716f364f516a30353752654e77364e735779645468773d3d	\\x674141414141427144506a387555514f77724a2d2d4f6f6d6232707530436e7265785672674336413136704c5f6e526d6644496458715f30314b665167466577524d563976714d754847666d44575473685465485f56765f68386c585636766439694f6d34336c783243416936346a622d6c34347a66733d	\N	f	2000.00	\N	0.2774	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	848c254158376c8cd555493cd181943ba9f57c3009083c251f1d5c326ff1896c	f	\N	{}	\N	0
8e81e2a2-1698-4cfa-8b28-ebac52dba068	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-039	\\x674141414141427144506a38534d6d6b5734734b4f7177554258675168387745626a5678534e7144454f4f7857773273386a797a785443717130656c58314953455376455871726d574f556f385431656558444d327268306b6a2d634678354947413d3d	\\x674141414141427144506a383774705774365f544a475f5278714f4861354c64466e49696a6870744c76474f564378374b58456630534c39434972717431574673562d5250374854697431754f7056354b6a797757474e3245444c665234734243564c334b442d55435f7467576c555f4b4a51595956773d	\N	f	10000.00	Trader	0.0484	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	39ab64f071c289a13ddbd06a933b562156827021d3867bed9d6298cdb028d5bd	f	\N	{}	\N	0
51e5024b-cee8-4da1-9a0b-dd9dd6a0bff1	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-040	\\x674141414141427144506a382d38745761333837594a68344930574744446b766d64396a745533376b675048716f756c397044794c415444773668485633432d784f734f49454431554262794d354a514c35414b47646775314f787a3867483033673d3d	\\x674141414141427144506a386c684f36594462574d39464a73304e6a68785258584231775035576a67433163446f757a327172426f465573455a444d4931546163674d784457504b2d4b424f706a3458353639505435336c6574634e42586f7676754853335334715132566833662d774357676730336f3d	\N	f	5000.00	Engineer	0.1410	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	5ea32dac793a2e37702931f3cdd6446a62eaa3d0d30fddf5aff2c044294ccb6d	f	\N	{}	\N	0
3cebac04-8e31-4cac-b7a2-d992ec915a89	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-041	\\x674141414141427144506a387757353132674678624d7579714877695364645779325449477a72464f6c4d566d7054516370412d70746271354f334f436c66496d4d6c6a386b673968484b62485a387933586435396a6d514b54316f344e4d4230413d3d	\\x674141414141427144506a384e417a42666369454472495562334e785f664b6f762d745336365a506f6674754a6d45556a466732636b61616e665365647232326b43353841694852386b49527735467a794b4c47394e793041567964327a4b50347a6c31552d5f6f48644c4332543763423038454276413d	\N	f	\N	Trader	0.1530	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	9912eb4e119b8779f3e645ed50d074a942487b40c60e2b57e769cc8ad49a0c6c	f	\N	{}	\N	0
adfd0e8a-c36b-4d14-95fc-bd9584ff88d4	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-042	\\x674141414141427144506a385a714d346e344c32526d30484a5f58574f6c4459613975752d6f5a585a6f6c68426538324553394169546e556b7567395a53314c6767547472665f596b64746b74443935644c656b6e61535671324b4f746a5a714d413d3d	\\x674141414141427144506a38714e7074536356385f476b51686b486d367430434e4d7a5f50685359556433435857716d39494136584f55793173447841666c34476f4e485445686e794a504c70623779554b3055456f62506d457546784344713550656334745f7565587a4f4a5f6752494c58304530343d	\N	f	2000.00	\N	0.1985	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	f235a3dccec60ec2ac406315aead3d35da34643b754c3f1eccbff53033e0275e	f	\N	{}	\N	0
2ce33d3a-409e-4f60-bebf-ad7a6cf5467d	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-043	\\x674141414141427144506a38386a726c5f4d61696973304449424c756946644b777a5f4f4b48353839394976537453624179444557575257495f745a7744654e6743414a5576696161544f5778576b666444755f4a6874453242546a7469456647773d3d	\\x674141414141427144506a38305a386f763059787354516e323242535f6c695664346575347172366c41344d59735135526b6171313357645365727a39494e50436b3955455965394e4b697338376a6b334b6e79506d327061346c592d304655466a46424d75414a5f716f5964633546354a7675694f673d	\N	f	10000.00	Teacher	0.1287	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	ecb9ba81f2cdbb643162cf4e51f888c966773a291f511127ae7ddd387438cd24	f	\N	{}	\N	0
84c74914-2d3a-4bac-9488-e6b95903dc28	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-044	\\x674141414141427144506a38364b4774584a4c322d6d46766c52505236354b626243485075544a6e5048677a71763245515f61434c2d5448475663595377534e444d6962625f7a4c664f6f5132494e556a376a747a59666f5861502d5a737a5175513d3d	\\x674141414141427144506a38304b703753792d4358684561416334446e33413844563478794839735332304e376e31793861703734355a6771343945315f323265543442484241506578666433547257576364565770646f456e77547563757563786d55734831716963315139625833534c62495361413d	\N	f	\N	Trader	0.0986	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	35bfbc4eb095320a2897584225003a6ecb26d61209591f780cb8182874856df4	f	\N	{}	\N	0
ecbd37bb-3da8-4503-bdd7-1119dc35cf7a	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-046	\\x674141414141427144506a3878506b2d74376a3555526c6e6c457a51754f79446e614253463134326659573271476c62364e337147326a47534a49415363366a6536655f763143306658484843714363375864584838435a483537416938775a76413d3d	\\x674141414141427144506a38577176714f473034332d373372375a58523737784b4763394c783963356e3144584274717371387846664a774438704e59357a53704e44324c4732747862485f4a52473173554848574952553457484d54736b547165665644726d707a3754746979774338764b6a384d733d	\N	f	5000.00	Teacher	0.2405	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	364bddfd899e0364e6821290895978a142ada0df7bd57c9b2be9e6e53b140f23	f	\N	{}	\N	0
b1ab9195-4dda-4fc3-b69e-5b305ebb0ffb	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-047	\\x674141414141427144506a383072543769484834586a5642494c4949506762704d346a523933554733626a6d6f3975733677615a65575730322d464548515267446b3256723559544b3339766d714f75692d4473715931756d7646594f4f433177773d3d	\\x674141414141427144506a386e53617478582d6d41454b764f6c4868587475614f464a485933575974554f55482d4b696f36764f633871316b4567706842654d48317246316b4f6a55456d383973396b4e5f547433663251664a6f31304a44584b7a7a33695769444479663272553978626644694b72383d	\N	f	20000.00	Engineer	0.2317	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	4367957db7468c9e291fe0cab6a5006db205749237281877ebffe134f8685b39	f	\N	{}	\N	0
3712dd46-5293-44bc-a3bc-abf656424dab	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-048	\\x674141414141427144506a382d387455385f79314948374478566d357a784874723833625539694f50544d713165595a68747a4656416d337272556138786d6662694e5a6f474255452d486447784f42353156494f5a4566717a5071774b376563773d3d	\\x674141414141427144506a383141444a4b66344b4e4f686c3636684432714a5333484b4c3579416758626f614d564d3045375270636552434178496c3966384a7a70486759644d5a4167516c5a39694562635059666e7a7a703174565f4c4f6d586a5f52386157637742376174464c36777274793451513d	\N	f	20000.00	Engineer	0.0313	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	2c9d858196c085240fb8901d591dc9899e8b281135d5c3ea83a5abf0d7746ba1	f	\N	{}	\N	0
32381f6b-8a46-4c16-b67e-585f22d4f0e6	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-049	\\x674141414141427144506a382d39597670563558414449443734474d6f4d74784c66667a6d36426266377a6f675354454e44536d446e6748753758486476475938523864363169396d69363367594e7a5572534a37364565684d6d694542775769773d3d	\\x674141414141427144506a38684d6764557450516b462d4e3955546241573750684e42756b537134346145534b7933382d5f5354576b5436696b7564526379616465675462687a6e67617332676463414666384f465674365553616750774a7466644e44524a774b6b68654833434838453031656b61303d	\N	f	2000.00	\N	0.0532	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	580060f201065e01a74b7542c4e2abc9a8e361ce8c8fa9e2714726f408da93cc	f	\N	{}	\N	0
3c386a03-970c-439f-b4ca-4d40ef08e0bd	98c56b0f-fa44-47cd-a8d9-9479174e3140	EXT-OPERADOR_B-050	\\x674141414141427144506a38485236765477336555414d33565057654d436c32345a5638356d707034747a38544a567a4856457537326f7a337152314b4362527242627231674e4930635068747238636370626d7369505a6542365f3364574e5a513d3d	\\x674141414141427144506a385f4d67537545614b754268556637746236656e467273464342475a59354c6d39626a64344a654136593930505747736d394a55597355336b73643856785f744d556a6e7261356731376e5f3536616f6559752d57434c42304f5a745473755568734e6f4c6c6f38775450493d	\N	f	2000.00	\N	0.0755	\N	2026-05-19 23:57:44.872891+00	2026-05-20 04:00:00.436007+00	\N	ACTIVE	\N	LOW	ef97a513d578b413a98dea3b2d31de64c5f11dc58d3bef7e063a389b60c6ae48	f	\N	{}	\N	0
\.


--
-- Data for Name: report_packages; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.report_packages (id, tenant_id, case_id, player_id, payload, format, created_by, created_at, pdf_path, status, analyst_narrative, decision, xml_path, xml_sha256, coaf_protocol_number, filed_at) FROM stdin;
22f53a1e-875c-4ef2-9462-496deee3ea09	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	e21505cc-cb01-4958-a794-e6f59fbe8ee6	5f4b66dd-66b9-49d7-ac79-10c15f7b9e71	{"case": {"id": "e21505cc-cb01-4958-a794-e6f59fbe8ee6", "title": "E2E COAF Protocol 1779235166159", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-19T23:59:26.248043+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.25", "name": "Player 2 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Teacher", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 10000.0}, "decision": "CLOSE", "reportId": "1fb9e889-23d6-4f03-979d-85784d55899c", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "1fb9e889-23d6-4f03-979d-85784d55899c", "caseNumber": "CASE-20260519-E21505CC", "attachments": [], "generatedAt": "2026-05-20T00:12:00.112442+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:12:00.112442+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "NO_ACTION", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "test e2e suite", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/1fb9e889-23d6-4f03-979d-85784d55899c.pdf", "pdf_sha256": "0c5cc0524595644bd87b893c95258836510dcb14d0b9976646086fc3a35ca586", "generated_at": "2026-05-20T00:12:00.112442+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "527172fbae72b5c53ac6a8b524e307f91e77a86eb5a6c1fb553754fed2d0a9d2"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "test e2e suite", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-19T23:59:26.347495+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-19T23:59:26.424256+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-19T23:59:26.493701+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:12:00.048497+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/1fb9e889-23d6-4f03-979d-85784d55899c.pdf	FINAL	test e2e suite	CLOSE	\N	\N	\N	\N
ca82e2ae-02e1-4c0d-898f-c6540fac9951	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	f0fe6296-60e6-439d-a7a5-bcacc4239d18	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "f0fe6296-60e6-439d-a7a5-bcacc4239d18", "title": "E2E COAF Protocol 1779236006620", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:13:26.746134+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "29da91f3-aa9e-4782-af6e-85e79db28325", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "29da91f3-aa9e-4782-af6e-85e79db28325", "caseNumber": "CASE-20260520-F0FE6296", "attachments": [], "generatedAt": "2026-05-20T00:13:27.204487+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:13:27.204487+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/29da91f3-aa9e-4782-af6e-85e79db28325.pdf", "pdf_sha256": "3c859a9d5fbe4b4c2abd5f4f04a0a370a55e9d74736987f865c7c1b672b7e97f", "generated_at": "2026-05-20T00:13:27.204487+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "46185c7dfad933d90252575fdef012b1ec202cbc09a33355ca73ea69ac3ea484"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:26.859759+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:26.941374+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:27.082596+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:27.175562+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/29da91f3-aa9e-4782-af6e-85e79db28325.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/f0fe6296-60e6-439d-a7a5-bcacc4239d18/coaf-ca82e2ae-02e1-4c0d-898f-c6540fac9951.xml	c7a7746e7057110aebf6b642b48032beed432bfa4f1d6b86e1d81203ad7bdad5	COAF-E2E-1779236007474	2026-05-20 00:13:27.477916+00
1e764da9-9396-4d9a-a397-ca28426ee889	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	20307f11-535c-46e4-a4d9-8d7090bd954c	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "20307f11-535c-46e4-a4d9-8d7090bd954c", "title": "E2E COAF Protocol 1779236009272", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:13:29.297254+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "84950925-d4a7-4ce8-960d-fcb7961ca7d2", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "84950925-d4a7-4ce8-960d-fcb7961ca7d2", "caseNumber": "CASE-20260520-20307F11", "attachments": [], "generatedAt": "2026-05-20T00:13:29.616867+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:13:29.616867+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/84950925-d4a7-4ce8-960d-fcb7961ca7d2.pdf", "pdf_sha256": "a593766d22af4a0ff769c2675fed0dc89268030f7fb16137466bf9e431734838", "generated_at": "2026-05-20T00:13:29.616867+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "419e701cc1225ce8537d68d3539276056760e935b1c248915e75fb0dcdc82bf4"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:29.380753+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:29.448610+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:29.518091+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:29.587441+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/84950925-d4a7-4ce8-960d-fcb7961ca7d2.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/20307f11-535c-46e4-a4d9-8d7090bd954c/coaf-1e764da9-9396-4d9a-a397-ca28426ee889.xml	dc9ece06964d32a5696e00e2f43b064d602e31264e24cfda6648933292148c37	\N	2026-05-20 00:13:29.758934+00
7162e1bb-e010-456b-9b73-dbebad25f33c	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	607d3d6d-e568-4a39-ba6e-d1aa19db91b3	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "607d3d6d-e568-4a39-ba6e-d1aa19db91b3", "title": "E2E COAF Protocol 1779236011493", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:13:31.627150+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "deb2093c-6e95-435e-a377-dc48385d1f11", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "deb2093c-6e95-435e-a377-dc48385d1f11", "caseNumber": "CASE-20260520-607D3D6D", "attachments": [], "generatedAt": "2026-05-20T00:13:32.054416+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:13:32.054416+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/deb2093c-6e95-435e-a377-dc48385d1f11.pdf", "pdf_sha256": "747bd7b854d7182cb2c2439741ae5f394a561505d30d7d13ab46468a5326d633", "generated_at": "2026-05-20T00:13:32.054416+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "653c9eef2362d024307e5af2388182469482493ac5febca14f4b1d6622bdb930"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:31.757431+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:31.833163+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:31.898232+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:32.018197+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/deb2093c-6e95-435e-a377-dc48385d1f11.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/607d3d6d-e568-4a39-ba6e-d1aa19db91b3/coaf-7162e1bb-e010-456b-9b73-dbebad25f33c.xml	cf6af3f82ea3ff656a6aa9590e379a5098584cad9a5c740ec9f7778799f67ec8	\N	2026-05-20 00:13:32.203875+00
3ada4fea-7d67-4971-bb71-2e0ea89d4416	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	e94f825a-af60-4a71-9eac-f4673f07b720	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "e94f825a-af60-4a71-9eac-f4673f07b720", "title": "E2E COAF Protocol 1779236013019", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:13:33.212315+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "bd25c805-ed5a-4d7b-9998-1896c6eb17cf", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "bd25c805-ed5a-4d7b-9998-1896c6eb17cf", "caseNumber": "CASE-20260520-E94F825A", "attachments": [], "generatedAt": "2026-05-20T00:13:33.644316+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:13:33.644316+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/bd25c805-ed5a-4d7b-9998-1896c6eb17cf.pdf", "pdf_sha256": "c16768d9a6541c81ca25f8ffce1d670ff0b4fca63c8df6158fa9a6cac677139b", "generated_at": "2026-05-20T00:13:33.644316+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "a63941f692089a7dd4f18dcb78583b714119c46d2e1d747eeae9fb6dde049f7a"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:33.357237+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:33.437399+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:33.517274+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:33.607385+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/bd25c805-ed5a-4d7b-9998-1896c6eb17cf.pdf	FINAL	Relatório E2E para teste de protocolo COAF.	REPORT	\N	\N	\N	\N
528299eb-e916-4875-935e-fb42ef1338fb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	edefa731-72fc-4b4c-bb96-8cb786eb3433	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "edefa731-72fc-4b4c-bb96-8cb786eb3433", "title": "E2E COAF Protocol 1779236015689", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:13:35.837854+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "e42b7db9-6b36-49d0-8834-5d7d0d79e793", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "e42b7db9-6b36-49d0-8834-5d7d0d79e793", "caseNumber": "CASE-20260520-EDEFA731", "attachments": [], "generatedAt": "2026-05-20T00:13:36.216434+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:13:36.216434+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/e42b7db9-6b36-49d0-8834-5d7d0d79e793.pdf", "pdf_sha256": "cd04d5875237f78054a9637874ff56196c475c905fbf47aee9835eed0d9bed2d", "generated_at": "2026-05-20T00:13:36.216434+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "bd424b0f8fb7fe52047204e335ad85615d90a6645917ed1355595adbc4de7ce0"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:35.935207+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:36.028566+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:36.102075+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:36.186931+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/e42b7db9-6b36-49d0-8834-5d7d0d79e793.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/edefa731-72fc-4b4c-bb96-8cb786eb3433/coaf-528299eb-e916-4875-935e-fb42ef1338fb.xml	0c00c6a92b5fb44c28fc9e516b05ca13d18ee1265913ae048538a5f919db31e1	COAF-AUDIT-1779236016355	2026-05-20 00:13:36.384103+00
2395e07b-e648-4cd5-82ab-7779d8cec89f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	e21867bf-2495-4371-8cdd-0f46d083bb6e	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "e21867bf-2495-4371-8cdd-0f46d083bb6e", "title": "E2E COAF Protocol 1779236026036", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:13:46.093429+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "3cbd33a4-ce30-4d68-bf3e-4654404d985f", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "3cbd33a4-ce30-4d68-bf3e-4654404d985f", "caseNumber": "CASE-20260520-E21867BF", "attachments": [], "generatedAt": "2026-05-20T00:13:46.410605+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:13:46.410605+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/3cbd33a4-ce30-4d68-bf3e-4654404d985f.pdf", "pdf_sha256": "ef266b2a19d47fe437303a915e80195a0dc7b8ea1297d931ab7627fc472f7788", "generated_at": "2026-05-20T00:13:46.410605+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "ad4c757c4f9e9e990176d869d62b4c46ea26d4c4f9b4f449bd91d26d92aeee6c"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:46.300577+00:00"}, {"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:46.162418+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:13:46.228326+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:13:46.380863+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/3cbd33a4-ce30-4d68-bf3e-4654404d985f.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/e21867bf-2495-4371-8cdd-0f46d083bb6e/coaf-2395e07b-e648-4cd5-82ab-7779d8cec89f.xml	c7f24d9ab8622a75d0234f4a0b2bf606e46c48aac4621f2e6f1b3969f64df648	\N	2026-05-20 00:13:46.56533+00
af990639-bcd1-47ac-8c8b-2719a24e6ac1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5", "title": "E2E COAF Protocol 1779236072705", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:14:32.791017+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "aaf163a5-8417-4c14-8474-2a1c3919aaf5", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "aaf163a5-8417-4c14-8474-2a1c3919aaf5", "caseNumber": "CASE-20260520-A7F2AD2D", "attachments": [], "generatedAt": "2026-05-20T00:14:33.520407+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:14:33.520407+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/aaf163a5-8417-4c14-8474-2a1c3919aaf5.pdf", "pdf_sha256": "1d0e542535c36584428cb65540011ee2907f91218d5673bf4fd4578c06208a13", "generated_at": "2026-05-20T00:14:33.520407+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "5c3d56c7c880ef14bc1b7ff21ac1816f289307fd5c0052704fba58cbe1a6f74d"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:14:32.991246+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:14:33.153851+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:14:33.270035+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:14:33.452895+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/aaf163a5-8417-4c14-8474-2a1c3919aaf5.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/a7f2ad2d-f47a-4a1b-9c0f-538f6b18a8a5/coaf-af990639-bcd1-47ac-8c8b-2719a24e6ac1.xml	516bb1942d72ade3d3b26aeb96860da8dc2a5a84a1c891979e876f02e8809147	\N	2026-05-20 00:14:33.752839+00
4b84fda5-b796-4aa6-ac4c-fcb2622e615e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	97cb2b12-475b-4596-995c-73eb62f51ba4	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "97cb2b12-475b-4596-995c-73eb62f51ba4", "title": "E2E COAF Protocol 1779236114577", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:15:14.795210+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "d3772679-a33c-4250-a0ed-f0a195120a15", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "d3772679-a33c-4250-a0ed-f0a195120a15", "caseNumber": "CASE-20260520-97CB2B12", "attachments": [], "generatedAt": "2026-05-20T00:15:15.289928+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:15:15.289928+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d3772679-a33c-4250-a0ed-f0a195120a15.pdf", "pdf_sha256": "979e9e46bb53c3c4f2c3611bc4b88a5c1adea80d26d4ef4768b8139a3e435452", "generated_at": "2026-05-20T00:15:15.289928+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "7cd2505248296d0e88eb61cb35453051693de748e594cc4ce1e95d8a6d39a7d6"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:15:14.884618+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:15:15.009459+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:15:15.181741+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:15:15.262066+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d3772679-a33c-4250-a0ed-f0a195120a15.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/97cb2b12-475b-4596-995c-73eb62f51ba4/coaf-4b84fda5-b796-4aa6-ac4c-fcb2622e615e.xml	d03c8ae58b74957495763bbf4ccc6d223ab65474ed4482741177fb182a1832e8	\N	2026-05-20 00:15:15.593838+00
b30cf1c1-b049-4e85-bf83-d21067594b51	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	cdef2fe6-dea8-4b0f-b76f-948d085e810f	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "cdef2fe6-dea8-4b0f-b76f-948d085e810f", "title": "E2E COAF Protocol 1779236390712", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:19:50.765927+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "1874f73d-c44c-4434-a86c-49ed8d0f927d", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "1874f73d-c44c-4434-a86c-49ed8d0f927d", "caseNumber": "CASE-20260520-CDEF2FE6", "attachments": [], "generatedAt": "2026-05-20T00:19:51.210418+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:19:51.210418+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/1874f73d-c44c-4434-a86c-49ed8d0f927d.pdf", "pdf_sha256": "a949f23285f55d5b50099356bcac9d981a54527a7b88ea7257cb7e5833f5eb3a", "generated_at": "2026-05-20T00:19:51.210418+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "f8f7373a019d5519c368dca8b7c4c46a040e67c2d8b9cd30ed64d42fb5ea3e13"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:50.886103+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:50.996605+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:51.072989+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:51.148951+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/1874f73d-c44c-4434-a86c-49ed8d0f927d.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/cdef2fe6-dea8-4b0f-b76f-948d085e810f/coaf-b30cf1c1-b049-4e85-bf83-d21067594b51.xml	91113dca14f93ce58d0a13817b323b5c87727fc94f21e1a6dc4f39f9797d46cc	COAF-E2E-1779236391733	2026-05-20 00:19:51.68426+00
a72577c1-e3aa-4f1f-96ed-6cd4c56119eb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	898955fd-f537-4a4a-9cc3-e490d5f343b5	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "898955fd-f537-4a4a-9cc3-e490d5f343b5", "title": "E2E COAF Protocol 1779236393362", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:19:53.450425+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "186db93f-4e0b-4200-ac83-40e6b7528116", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "186db93f-4e0b-4200-ac83-40e6b7528116", "caseNumber": "CASE-20260520-898955FD", "attachments": [], "generatedAt": "2026-05-20T00:19:53.833628+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:19:53.833628+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/186db93f-4e0b-4200-ac83-40e6b7528116.pdf", "pdf_sha256": "f44e5a22691b920732809159ed2c44c87c198ec78acea836c1663d38186450a2", "generated_at": "2026-05-20T00:19:53.833628+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "5f7cd05a2fc57e448dace0a49f21330da29d7458e4126f00d61ef9ee229f1e37"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:53.546892+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:53.629980+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:53.704904+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:53.7989+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/186db93f-4e0b-4200-ac83-40e6b7528116.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/898955fd-f537-4a4a-9cc3-e490d5f343b5/coaf-a72577c1-e3aa-4f1f-96ed-6cd4c56119eb.xml	8ff56664c0f2b810946dd52215263adffbf7cc53271f36a9742b8cbf3ec89ef6	\N	2026-05-20 00:19:54.08832+00
a809ca82-9296-4055-be34-06469524a9f8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	93321cb0-c1d2-4c42-bd47-84f0d1da6bdf	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "93321cb0-c1d2-4c42-bd47-84f0d1da6bdf", "title": "E2E COAF Protocol 1779236395867", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:19:55.993806+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "12cc65c6-decb-4aea-ace8-a6c5a6fe9533", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "12cc65c6-decb-4aea-ace8-a6c5a6fe9533", "caseNumber": "CASE-20260520-93321CB0", "attachments": [], "generatedAt": "2026-05-20T00:19:56.312208+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:19:56.312208+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/12cc65c6-decb-4aea-ace8-a6c5a6fe9533.pdf", "pdf_sha256": "9d571811b6fa9234cedf989272424f96d96d4ec13fcc769982afe2cb9c82892a", "generated_at": "2026-05-20T00:19:56.312208+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "498412647a7549b3a2a6f325c7874d33827bcbbc07c466c3a4c291c2fde465f4"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:56.091513+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:56.174683+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:56.231601+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:56.291796+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/12cc65c6-decb-4aea-ace8-a6c5a6fe9533.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/93321cb0-c1d2-4c42-bd47-84f0d1da6bdf/coaf-a809ca82-9296-4055-be34-06469524a9f8.xml	f6cd087287e6a6dead2dfb8473ee327e0d1852414fdef9d40aa96760b348b8c2	\N	2026-05-20 00:19:56.430319+00
70759bb8-3c82-45aa-bd44-893697e1e234	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	5014b829-e438-4d15-8647-28ee47547247	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "5014b829-e438-4d15-8647-28ee47547247", "title": "E2E COAF Protocol 1779236397180", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:19:57.311373+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "d8b40707-cc26-4d60-b3b2-087920615564", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "d8b40707-cc26-4d60-b3b2-087920615564", "caseNumber": "CASE-20260520-5014B829", "attachments": [], "generatedAt": "2026-05-20T00:19:57.611624+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:19:57.611624+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d8b40707-cc26-4d60-b3b2-087920615564.pdf", "pdf_sha256": "4e9350a675b8496549c0b679cfd8699df0a2c4be444d97f38a59ad4d5ea218ae", "generated_at": "2026-05-20T00:19:57.611624+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "d17223a818708de83185c3c6bda81aac245d9e76c8b9a6fa8d10199da248bcb0"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:57.393337+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:57.471599+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:57.528351+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:57.592075+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d8b40707-cc26-4d60-b3b2-087920615564.pdf	FINAL	Relatório E2E para teste de protocolo COAF.	REPORT	\N	\N	\N	\N
9694ef42-b209-4c01-a091-a265c18a3c37	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	803539be-379f-4992-a510-c1f50278372e	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "803539be-379f-4992-a510-c1f50278372e", "title": "E2E COAF Protocol 1779236399614", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:19:59.638006+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "cfc4cb2b-1b18-467a-984a-25abe611024e", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "cfc4cb2b-1b18-467a-984a-25abe611024e", "caseNumber": "CASE-20260520-803539BE", "attachments": [], "generatedAt": "2026-05-20T00:20:00.045461+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:20:00.045461+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/cfc4cb2b-1b18-467a-984a-25abe611024e.pdf", "pdf_sha256": "e7a9c1eb4e42fb01968e3d89a9235c05da6c50e7998a27f6b7763ffd36c56fc7", "generated_at": "2026-05-20T00:20:00.045461+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "99f8c460ed8eea33842f8c5fdb815ec6117a6be56d7dc8a67f94377fe2f894ce"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:59.744167+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:59.819504+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:19:59.884840+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:19:59.965276+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/cfc4cb2b-1b18-467a-984a-25abe611024e.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/803539be-379f-4992-a510-c1f50278372e/coaf-9694ef42-b209-4c01-a091-a265c18a3c37.xml	dd1e3b11b3f34a9a7b588547b2a7d0ec4f81982490db541a2278204397523b5a	COAF-AUDIT-1779236400362	2026-05-20 00:20:00.252513+00
a89b0764-3613-432f-b99f-9926168ff629	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	95c36d67-1b75-4e86-bd3a-b317c80e50af	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "95c36d67-1b75-4e86-bd3a-b317c80e50af", "title": "E2E COAF Protocol 1779236407084", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:20:07.177460+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "01487da8-2dd9-46e2-9990-0254381d86d8", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "01487da8-2dd9-46e2-9990-0254381d86d8", "caseNumber": "CASE-20260520-95C36D67", "attachments": [], "generatedAt": "2026-05-20T00:20:07.637324+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:20:07.637324+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/01487da8-2dd9-46e2-9990-0254381d86d8.pdf", "pdf_sha256": "4d8b7a931c0c52a77c155cd3317a9f732f545796366f8745fdfd8217eafd0b82", "generated_at": "2026-05-20T00:20:07.637324+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "1353c15efe511933f45ff5d5c1f980ad81af23afcc7af8b14642b3f1ecf2406e"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:20:07.266630+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:20:07.380074+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:20:07.501992+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:20:07.599454+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/01487da8-2dd9-46e2-9990-0254381d86d8.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/95c36d67-1b75-4e86-bd3a-b317c80e50af/coaf-a89b0764-3613-432f-b99f-9926168ff629.xml	f8330a71e33b9404c86a65efc79034e571b675ae3204f25c4c53b7da8507c745	\N	2026-05-20 00:20:07.885992+00
bcd483fd-b8a4-4ac7-bd76-3d743ffdc4b1	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	d02b4133-26c3-4b85-a9da-8ac6948e3e0c	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "d02b4133-26c3-4b85-a9da-8ac6948e3e0c", "title": "E2E COAF Protocol 1779236450921", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:20:50.948316+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "993a85f7-c695-42eb-9abe-a1428b8e16ce", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "993a85f7-c695-42eb-9abe-a1428b8e16ce", "caseNumber": "CASE-20260520-D02B4133", "attachments": [], "generatedAt": "2026-05-20T00:20:51.310211+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:20:51.310211+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/993a85f7-c695-42eb-9abe-a1428b8e16ce.pdf", "pdf_sha256": "450cff48a76cee57327b8eaef7f310a008fce1cdd678d2ee1934df297896111b", "generated_at": "2026-05-20T00:20:51.310211+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "8972907bc34ce497d60e2af73e431cd0c7f38b5eb7fa06ac304803387582c8e6"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:20:51.026616+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:20:51.091297+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:20:51.149441+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:20:51.275081+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/993a85f7-c695-42eb-9abe-a1428b8e16ce.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d02b4133-26c3-4b85-a9da-8ac6948e3e0c/coaf-bcd483fd-b8a4-4ac7-bd76-3d743ffdc4b1.xml	a1a5dc84a4eb09ad6ac425e9d3e3c08952493551b172e05e831e7fdf9928392c	\N	2026-05-20 00:20:51.461917+00
e2b9c351-9302-44c9-84b1-aa508e858668	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	e69af611-da75-4fe3-8a48-a76b10f9546f	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "e69af611-da75-4fe3-8a48-a76b10f9546f", "title": "E2E COAF Protocol 1779236489976", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:21:29.995799+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "653fb266-093c-4e7a-b221-8b4b23a1efa1", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "653fb266-093c-4e7a-b221-8b4b23a1efa1", "caseNumber": "CASE-20260520-E69AF611", "attachments": [], "generatedAt": "2026-05-20T00:21:30.387249+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:21:30.387249+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/653fb266-093c-4e7a-b221-8b4b23a1efa1.pdf", "pdf_sha256": "941edae0dcd38ca9c6d343637bef621da3bc3a03b6c2b50054ee1786c801d78b", "generated_at": "2026-05-20T00:21:30.387249+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "e4ad8f7e8c81ca7d2939a241b3d1def129fb09e6bb5cc9469290db4bc59fcdfc"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:21:30.096133+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:21:30.185224+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:21:30.251650+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:21:30.368645+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/653fb266-093c-4e7a-b221-8b4b23a1efa1.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/e69af611-da75-4fe3-8a48-a76b10f9546f/coaf-e2b9c351-9302-44c9-84b1-aa508e858668.xml	916a4f66cd732f62892dfc4b63ec7ce05df75d85d94d03ebdf967849ebd01790	\N	2026-05-20 00:21:30.519355+00
0c6f08ab-62a2-4856-bb8e-3fb9a4a68aee	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	3a3f6cae-cf66-47a1-b02d-142bf667665e	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "3a3f6cae-cf66-47a1-b02d-142bf667665e", "title": "E2E COAF Protocol 1779236922205", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:28:42.293764+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "668b8ed4-daa9-4130-a67e-871f77c4ef33", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "668b8ed4-daa9-4130-a67e-871f77c4ef33", "caseNumber": "CASE-20260520-3A3F6CAE", "attachments": [], "generatedAt": "2026-05-20T00:28:42.700634+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:28:42.700634+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/668b8ed4-daa9-4130-a67e-871f77c4ef33.pdf", "pdf_sha256": "a2374b31d332d96a3ff49cd2b478d38e4c6f768a7582a4b8ff5296e1bb4fdf0a", "generated_at": "2026-05-20T00:28:42.700634+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "24035a0cf47934a6dd15613dd9a8569adbe5f6d969b23d3d6e980acb5de0bdea"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:42.428388+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:42.511501+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:42.582350+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:42.650146+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/668b8ed4-daa9-4130-a67e-871f77c4ef33.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/3a3f6cae-cf66-47a1-b02d-142bf667665e/coaf-0c6f08ab-62a2-4856-bb8e-3fb9a4a68aee.xml	5800bb392930606bc9c22141a5e54a84f661b83d11f18cc2365a7b9329b4ae48	COAF-E2E-1779236923618	2026-05-20 00:28:43.528658+00
67a9a2d1-f687-449e-8d75-cdeadf38b345	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	0a2b0872-efcd-4bca-b668-3bfad54a5b93	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "0a2b0872-efcd-4bca-b668-3bfad54a5b93", "title": "E2E COAF Protocol 1779236925667", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:28:45.826910+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "bda1d5b6-086b-423b-807e-5ae5d4bafe2f", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "bda1d5b6-086b-423b-807e-5ae5d4bafe2f", "caseNumber": "CASE-20260520-0A2B0872", "attachments": [], "generatedAt": "2026-05-20T00:28:46.248688+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:28:46.248688+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/bda1d5b6-086b-423b-807e-5ae5d4bafe2f.pdf", "pdf_sha256": "ee8e9b5fc1f8a94a2debd189f2a57cdd8a8fed7c84a8d563a2c1b5427199a024", "generated_at": "2026-05-20T00:28:46.248688+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "5bc06ea45b3d28ddc9b3db128ec94df37629bea7de259ce3f445cc34a720754a"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:45.900342+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:45.970784+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:46.139212+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:46.219001+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/bda1d5b6-086b-423b-807e-5ae5d4bafe2f.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/0a2b0872-efcd-4bca-b668-3bfad54a5b93/coaf-67a9a2d1-f687-449e-8d75-cdeadf38b345.xml	7793d100c508533c1a60405f706df1c583e98c117e940c3b46bff721e8626320	\N	2026-05-20 00:28:46.397848+00
92b2998b-e991-4c67-8883-748249c35390	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	a6c823d3-7622-4ffb-a61b-7ebcea535e95	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "a6c823d3-7622-4ffb-a61b-7ebcea535e95", "title": "E2E COAF Protocol 1779236928289", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:28:48.460170+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "89e768db-4339-4f67-8e57-255f284574df", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "89e768db-4339-4f67-8e57-255f284574df", "caseNumber": "CASE-20260520-A6C823D3", "attachments": [], "generatedAt": "2026-05-20T00:28:48.633731+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:28:48.633731+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/89e768db-4339-4f67-8e57-255f284574df.pdf", "pdf_sha256": "9e5751d421f271b3ca2352e1904c91d4e8141cb89ab4d96d8da8ef8419e63187", "generated_at": "2026-05-20T00:28:48.633731+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "dbb66939578dcc401c467697701c96d80f19e343c54032add1ee2b423e632c01"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:48.686801+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:48.616336+00:00"}, {"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:48.516731+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:48.614952+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/89e768db-4339-4f67-8e57-255f284574df.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/a6c823d3-7622-4ffb-a61b-7ebcea535e95/coaf-92b2998b-e991-4c67-8883-748249c35390.xml	62541e18eedf2a6b4aa096507e9d4f9b9f377ae4719c3a55f57603313dced81d	\N	2026-05-20 00:28:48.780468+00
19911c86-9a25-43bd-b826-ecdf2c67f94b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1", "title": "E2E COAF Protocol 1779236929685", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:28:49.726126+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "93c67528-0f08-4b22-ab86-b932c31c65b3", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "93c67528-0f08-4b22-ab86-b932c31c65b3", "caseNumber": "CASE-20260520-2D88FFD1", "attachments": [], "generatedAt": "2026-05-20T00:28:50.141529+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:28:50.141529+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/93c67528-0f08-4b22-ab86-b932c31c65b3.pdf", "pdf_sha256": "02b572d882a637aea86594e88efc06b98f12dffd3ee1f7dd368cd5793a967903", "generated_at": "2026-05-20T00:28:50.141529+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "77ac23543d7b395c86ddace087a15da4ec0914e02e3f06391a9c13b3a1d75291"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:49.986609+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:49.896581+00:00"}, {"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:49.812486+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:50.109829+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/93c67528-0f08-4b22-ab86-b932c31c65b3.pdf	FINAL	Relatório E2E para teste de protocolo COAF.	REPORT	\N	\N	\N	\N
d6df8218-84a8-44e7-b66e-af1ca0f7caa8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	7d7cdb0d-b5dd-4090-84b2-9486019ce2e0	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "7d7cdb0d-b5dd-4090-84b2-9486019ce2e0", "title": "E2E COAF Protocol 1779236932457", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:28:52.539262+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "07d7c24c-0ee6-4cae-b9a7-43fc7a7228d3", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "07d7c24c-0ee6-4cae-b9a7-43fc7a7228d3", "caseNumber": "CASE-20260520-7D7CDB0D", "attachments": [], "generatedAt": "2026-05-20T00:28:52.877022+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:28:52.877022+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/07d7c24c-0ee6-4cae-b9a7-43fc7a7228d3.pdf", "pdf_sha256": "0ff08119c8bccfd96b340c2420968c9ad86c2ad985c62a249986298dc8f5dbd0", "generated_at": "2026-05-20T00:28:52.877022+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "e22967e715459059520d3650bb2f4a11a6c8ef3ea994d18cd429f79142aeea7e"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:52.761852+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:52.701203+00:00"}, {"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:52.624485+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:28:52.840986+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/07d7c24c-0ee6-4cae-b9a7-43fc7a7228d3.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/7d7cdb0d-b5dd-4090-84b2-9486019ce2e0/coaf-d6df8218-84a8-44e7-b66e-af1ca0f7caa8.xml	4778bf0a77c50301d33d045fa47cad277e6c87c0fd2589c290c2d40031c3fd82	COAF-AUDIT-1779236933065	2026-05-20 00:28:53.05752+00
a6517a64-a57a-41a8-a9af-f8bc1b10c93a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	817097da-1c7f-45a0-bad6-61c27412c1e9	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "817097da-1c7f-45a0-bad6-61c27412c1e9", "title": "E2E COAF Protocol 1779236940983", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:29:01.027176+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "6ef058bb-7190-4ede-ade1-265127616651", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "6ef058bb-7190-4ede-ade1-265127616651", "caseNumber": "CASE-20260520-817097DA", "attachments": [], "generatedAt": "2026-05-20T00:29:01.302161+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:29:01.302161+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/6ef058bb-7190-4ede-ade1-265127616651.pdf", "pdf_sha256": "985aabae2afaaced908e09554811613e9f300c19a3153f40931a99f366cbb7e8", "generated_at": "2026-05-20T00:29:01.302161+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "35edf3eceb02a06bd633f00de39f709bad09e8c2a2f73a6c77b0122f8ebee1a3"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:29:01.217743+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:29:01.162857+00:00"}, {"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:29:01.105636+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:29:01.280398+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/6ef058bb-7190-4ede-ade1-265127616651.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/817097da-1c7f-45a0-bad6-61c27412c1e9/coaf-a6517a64-a57a-41a8-a9af-f8bc1b10c93a.xml	136b315fde2b109b794db50c08889b978d3be8159d06431327ed89b86cc096b7	\N	2026-05-20 00:29:01.440611+00
4e0d46b5-575a-4b1f-832b-cdc17d9ac91e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	3e8279c9-50d4-48e0-8849-c862d24d8c5d	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "3e8279c9-50d4-48e0-8849-c862d24d8c5d", "title": "E2E COAF Protocol 1779236981167", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:29:41.334029+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "d04d21ef-502f-44d2-9f80-b687db87ad58", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "d04d21ef-502f-44d2-9f80-b687db87ad58", "caseNumber": "CASE-20260520-3E8279C9", "attachments": [], "generatedAt": "2026-05-20T00:29:41.699485+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:29:41.699485+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d04d21ef-502f-44d2-9f80-b687db87ad58.pdf", "pdf_sha256": "42f8893b8d7db55025026edaff78aa668e9e3fe9c73ebd9c58ea743925436e7a", "generated_at": "2026-05-20T00:29:41.699485+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "0b63ce2b64ecf9078062348cb7d6b852dae7a43b16bd5c90fab0b8bc6ae1c9b3"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:29:41.608614+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:29:41.534517+00:00"}, {"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:29:41.463106+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:29:41.676453+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d04d21ef-502f-44d2-9f80-b687db87ad58.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/3e8279c9-50d4-48e0-8849-c862d24d8c5d/coaf-4e0d46b5-575a-4b1f-832b-cdc17d9ac91e.xml	b0d27dd6ad115ec7dec442eb1dad66bdb9c9d82a7f93a982701e86b92c87b105	\N	2026-05-20 00:29:41.867875+00
7541779c-5795-4ad0-ad23-592cc6bcff1f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	dd83cc19-5fee-42e0-9aa1-d5149c82e097	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "dd83cc19-5fee-42e0-9aa1-d5149c82e097", "title": "E2E COAF Protocol 1779237018746", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:30:18.767819+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 8000.0, "valor_apostas": 6500.0, "occurrence_codes": [1407], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Teste automatizado de registro de protocolo Siscoaf.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "78062c9b-b61d-4fc2-ac79-6c4676ba34d3", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "78062c9b-b61d-4fc2-ac79-6c4676ba34d3", "caseNumber": "CASE-20260520-DD83CC19", "attachments": [], "generatedAt": "2026-05-20T00:30:19.105880+00:00", "generatedBy": "analyst_a (AML_ANALYST)", "generated_at": "2026-05-20T00:30:19.105880+00:00", "generated_by": "47b184c7-360c-41ac-8676-f52b54c5e4a8", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Relatório E2E para teste de protocolo COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/78062c9b-b61d-4fc2-ac79-6c4676ba34d3.pdf", "pdf_sha256": "6f09e346702da805bb40c5566697bb42b4889e3a44d93d2e074dacf0de6ca34f", "generated_at": "2026-05-20T00:30:19.105880+00:00", "generated_by": "analyst_a (AML_ANALYST)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "fddbbe4df923f884ab86e1e13356957315206b00472c843656558b52c0b59580"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Relatório E2E para teste de protocolo COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:30:18.988155+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:30:18.905489+00:00"}, {"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:30:18.838932+00:00"}]}	JSON	47b184c7-360c-41ac-8676-f52b54c5e4a8	2026-05-20 00:30:19.076275+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/78062c9b-b61d-4fc2-ac79-6c4676ba34d3.pdf	FILED	Relatório E2E para teste de protocolo COAF.	REPORT	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/dd83cc19-5fee-42e0-9aa1-d5149c82e097/coaf-7541779c-5795-4ad0-ad23-592cc6bcff1f.xml	64444308b4e2de0489a41994386aee08c00b658e16112545d17c9f7cc1678e1a	\N	2026-05-20 00:30:19.24019+00
60ecd3fe-b2e6-4ef6-9e69-8050fdcd0637	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	7067f39b-8afe-4b83-b7e9-4391b079ebda	\N	{"case": {"id": "7067f39b-8afe-4b83-b7e9-4391b079ebda", "title": "Caso COAF Test 82cf2c", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-05-22T15:54:25.456379+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": null, "name": null, "pepFlag": false, "birthDate": null, "profession": null, "riskCategory": null, "registeredSince": null, "declaredIncomeMonthly": 0}, "decision": "MONITOR", "reportId": "9fb0595f-61ea-4851-9391-6defd221554e", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "9fb0595f-61ea-4851-9391-6defd221554e", "caseNumber": "CASE-20260522-7067F39B", "attachments": [], "generatedAt": "2026-05-22T15:54:25.573999+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T15:54:25.573999+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "PENDING", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/9fb0595f-61ea-4851-9391-6defd221554e.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "3cf68ca17d207d58c553e4cf23dba454f79ab3ef03e6ae26ea337715556eda9e", "generated_at": "2026-05-22T15:54:25.573999+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "26d7bc2df6fe5357413e58bfe30df1bcb8f2182ca0acd351331a86c0577899f9"}, "financialSummary": {"unusualPatterns": [], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:54:25.536212+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/9fb0595f-61ea-4851-9391-6defd221554e.pdf	DRAFT	\N	MONITOR	\N	\N	\N	\N
b687d3f4-d12e-4964-be74-677bfb29ac58	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	233a5b9e-1d89-493c-9b94-9d96c59991d7	\N	{"case": {"id": "233a5b9e-1d89-493c-9b94-9d96c59991d7", "title": "Caso COAF Test ee05dd", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-05-22T15:55:38.350196+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": null, "name": null, "pepFlag": false, "birthDate": null, "profession": null, "riskCategory": null, "registeredSince": null, "declaredIncomeMonthly": 0}, "decision": "MONITOR", "reportId": "301e1bb9-4281-4f8e-8fae-de463552b9ab", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "301e1bb9-4281-4f8e-8fae-de463552b9ab", "caseNumber": "CASE-20260522-233A5B9E", "attachments": [], "generatedAt": "2026-05-22T15:55:38.489937+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T15:55:38.489937+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "PENDING", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/301e1bb9-4281-4f8e-8fae-de463552b9ab.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "3a3b74920210375dcfd93cf2f23541c1fc220e1dbff12329555e5c0c4d04827f", "generated_at": "2026-05-22T15:55:38.489937+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "99bac121a89366220376ee2a6c8d97fd36f3ae258aefa0deaef1528775bbcc31"}, "financialSummary": {"unusualPatterns": [], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:38.453515+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/301e1bb9-4281-4f8e-8fae-de463552b9ab.pdf	DRAFT	\N	MONITOR	\N	\N	\N	\N
e5d842ce-7fab-4ebe-bba1-8ee2cf6a5746	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	6c6d0df9-0f51-4bc5-84f4-53c16bf788e9	\N	{"case": {"id": "6c6d0df9-0f51-4bc5-84f4-53c16bf788e9", "title": "Caso SAR 8d4939", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-05-22T15:55:38.637594+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [1420], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Deposits fracionados identificados pelo sistema BetAML em janela de 7 dias.", "occurrence_descriptions": {"1420": "Art. 25-XI — Fracionamento / dissimulação de operações"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": null, "name": null, "pepFlag": false, "birthDate": null, "profession": null, "riskCategory": null, "registeredSince": null, "declaredIncomeMonthly": 0}, "decision": "REPORT", "reportId": "d911f74c-2d62-4aba-8d48-1eb7e71cf020", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "d911f74c-2d62-4aba-8d48-1eb7e71cf020", "caseNumber": "CASE-20260522-6C6D0DF9", "attachments": [], "generatedAt": "2026-05-22T15:55:38.750351+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T15:55:38.750351+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Operações de depósito fracionado abaixo do limite obrigatório de comunicação, padrão típico de Structuring (COAF/FATF Tipologia ML-01). Recomenda-se comunicação ao COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d911f74c-2d62-4aba-8d48-1eb7e71cf020.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "1f13d9911a282ab467aa38bb42829f1d4faa248775627474ac7862c2255d5f7e", "generated_at": "2026-05-22T15:55:38.750351+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "d980c87b75a014de75ad6565eb77119f5f58f462ba40cf0e58b361b17ad300e2"}, "financialSummary": {"unusualPatterns": [], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Operações de depósito fracionado abaixo do limite obrigatório de comunicação, padrão típico de Structuring (COAF/FATF Tipologia ML-01). Recomenda-se comunicação ao COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:38.731712+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d911f74c-2d62-4aba-8d48-1eb7e71cf020.pdf	FINAL	Operações de depósito fracionado abaixo do limite obrigatório de comunicação, padrão típico de Structuring (COAF/FATF Tipologia ML-01). Recomenda-se comunicação ao COAF.	REPORT	\N	\N	\N	\N
d427d654-2cdb-4f3c-bb80-50031a9dd4d5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	3b1515c5-de8b-420d-9e89-7a01bfb8a3de	\N	{"case": {"id": "3b1515c5-de8b-420d-9e89-7a01bfb8a3de", "title": "Caso CPF Mask Test", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-05-22T15:55:39.052398+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": null, "name": null, "pepFlag": false, "birthDate": null, "profession": null, "riskCategory": null, "registeredSince": null, "declaredIncomeMonthly": 0}, "decision": "MONITOR", "reportId": "1f8f4810-012e-4539-8ec1-bcf9b84e994c", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "1f8f4810-012e-4539-8ec1-bcf9b84e994c", "caseNumber": "CASE-20260522-3B1515C5", "attachments": [], "generatedAt": "2026-05-22T15:55:39.148755+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T15:55:39.148755+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "PENDING", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/1f8f4810-012e-4539-8ec1-bcf9b84e994c.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "46c8f7880d331e627965bdf190112e41ec2efadf8161ae3adc9eeea7e8c8e67d", "generated_at": "2026-05-22T15:55:39.148755+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "339d0e59afbf0140c8ea77b200f370276ae581b9d8d5a77201231aace915ba59"}, "financialSummary": {"unusualPatterns": [], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:39.1348+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/1f8f4810-012e-4539-8ec1-bcf9b84e994c.pdf	DRAFT	\N	MONITOR	\N	\N	\N	\N
eeb15565-6b34-4965-8e7e-020fbcc49a7e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	f22ee9d6-f2bd-42bf-9a16-01fa36424384	\N	{"case": {"id": "f22ee9d6-f2bd-42bf-9a16-01fa36424384", "title": "Caso Audit Test", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-05-22T15:55:41.091622+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": null, "name": null, "pepFlag": false, "birthDate": null, "profession": null, "riskCategory": null, "registeredSince": null, "declaredIncomeMonthly": 0}, "decision": "MONITOR", "reportId": "d557a2ff-c9e5-4279-ad12-49a471009e3c", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "d557a2ff-c9e5-4279-ad12-49a471009e3c", "caseNumber": "CASE-20260522-F22EE9D6", "attachments": [], "generatedAt": "2026-05-22T15:55:41.221668+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T15:55:41.221668+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "PENDING", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d557a2ff-c9e5-4279-ad12-49a471009e3c.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "170807b5d3f9ff2788ae3a198d8c068bd3e18f21938d17fa34aa10119e46ab8f", "generated_at": "2026-05-22T15:55:41.221668+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "82b060af3c37d6dcbef678db025d0e38210844221753699dac1c6092fca3a2ec"}, "financialSummary": {"unusualPatterns": [], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:55:41.190768+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d557a2ff-c9e5-4279-ad12-49a471009e3c.pdf	DRAFT	\N	MONITOR	\N	\N	\N	\N
e129945d-7237-446f-a9fa-ca6b4a803fd0	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	f22ee9d6-f2bd-42bf-9a16-01fa36424384	\N	{"case": {"id": "f22ee9d6-f2bd-42bf-9a16-01fa36424384", "title": "Caso Audit Test", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-05-22T15:55:41.091622+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [1407], "involvement_types": [1], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Padrão identificado pelo motor de regras BetAML. Comunicado Siscoaf 97. Portaria SPA/MF 1.143/2024.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"1": "Titular"}}, "subject": {"cpf": null, "name": null, "pepFlag": false, "birthDate": null, "profession": null, "riskCategory": null, "registeredSince": null, "declaredIncomeMonthly": 0}, "decision": "REPORT", "reportId": "a7e978b1-89c7-4537-a098-414f462e8e83", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "a7e978b1-89c7-4537-a098-414f462e8e83", "caseNumber": "CASE-20260522-F22EE9D6", "attachments": [], "generatedAt": "2026-05-22T15:56:25.668983+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T15:56:25.668983+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/a7e978b1-89c7-4537-a098-414f462e8e83.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "93c675195a37bddfbadc73230fb8168191af08d26e777c77482b9812f378c828", "generated_at": "2026-05-22T15:56:25.668983+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "dabcacc83f3b204533822f52bf3e52e32dfbe523798d2e594eaeab53aa8fc723"}, "financialSummary": {"unusualPatterns": [], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"decision": "PENDING", "report_id": "d557a2ff-c9e5-4279-ad12-49a471009e3c", "pdf_sha256": "170807b5d3f9ff2788ae3a198d8c068bd3e18f21938d17fa34aa10119e46ab8f", "payload_sha256": "82b060af3c37d6dcbef678db025d0e38210844221753699dac1c6092fca3a2ec", "attachments_count": 0}, "event_type": "REPORT_GENERATED", "recorded_at": "2026-05-22T15:55:41.190768+00:00"}]}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:56:25.655732+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/a7e978b1-89c7-4537-a098-414f462e8e83.pdf	FINAL	Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.	REPORT	\N	\N	\N	\N
9739f207-213c-4606-8151-f8a159f247b2	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1", "title": "E2E COAF Protocol 1779236929685", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:28:49.726126+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [1407], "involvement_types": [1], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Padrão identificado pelo motor de regras BetAML. Comunicado Siscoaf 97. Portaria SPA/MF 1.143/2024.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"1": "Titular"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "762b1829-0386-49af-a7a9-f5c655965b0c", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "762b1829-0386-49af-a7a9-f5c655965b0c", "caseNumber": "CASE-20260520-2D88FFD1", "attachments": [], "generatedAt": "2026-05-22T15:56:26.367154+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T15:56:26.367154+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/762b1829-0386-49af-a7a9-f5c655965b0c.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "2e75ad3788bcbed8130a5d3fa343efa4f1866c6c84537bbea214deb7d6993c11", "generated_at": "2026-05-22T15:56:26.367154+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "76802436ea5e2ef0cac9f9635fd4547e2a7e8182ece371841facf490ed768f95"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:49.812486+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:49.896581+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:49.986609+00:00"}, {"content": {"decision": "FILE_SAR", "report_id": "93c67528-0f08-4b22-ab86-b932c31c65b3", "pdf_sha256": "02b572d882a637aea86594e88efc06b98f12dffd3ee1f7dd368cd5793a967903", "payload_sha256": "77ac23543d7b395c86ddace087a15da4ec0914e02e3f06391a9c13b3a1d75291", "attachments_count": 0}, "event_type": "REPORT_GENERATED", "recorded_at": "2026-05-20T00:28:50.109829+00:00"}]}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 15:56:26.349896+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/762b1829-0386-49af-a7a9-f5c655965b0c.pdf	FINAL	Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.	REPORT	\N	\N	\N	\N
8457ecdd-7a3c-4730-9c19-02c5af460c7b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	f22ee9d6-f2bd-42bf-9a16-01fa36424384	\N	{"case": {"id": "f22ee9d6-f2bd-42bf-9a16-01fa36424384", "title": "Caso Audit Test", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-05-22T15:55:41.091622+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [1407], "involvement_types": [1], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Padrão identificado pelo motor de regras BetAML. Comunicado Siscoaf 97. Portaria SPA/MF 1.143/2024.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"1": "Titular"}}, "subject": {"cpf": null, "name": null, "pepFlag": false, "birthDate": null, "profession": null, "riskCategory": null, "registeredSince": null, "declaredIncomeMonthly": 0}, "decision": "REPORT", "reportId": "55163958-bbfa-4913-af4a-92c6b8a95d09", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "55163958-bbfa-4913-af4a-92c6b8a95d09", "caseNumber": "CASE-20260522-F22EE9D6", "attachments": [], "generatedAt": "2026-05-22T16:01:40.606828+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T16:01:40.606828+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/55163958-bbfa-4913-af4a-92c6b8a95d09.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "6e7e2dc62d325e31ae6aec213875ab5810e95c7ce81401f821f3718cd9902cd1", "generated_at": "2026-05-22T16:01:40.606828+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "e5af6423f9a71c62706efd235c7067733a552308fcfe541d7d2bb7b6155a1158"}, "financialSummary": {"unusualPatterns": [], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"decision": "FILE_SAR", "report_id": "a7e978b1-89c7-4537-a098-414f462e8e83", "pdf_sha256": "93c675195a37bddfbadc73230fb8168191af08d26e777c77482b9812f378c828", "payload_sha256": "dabcacc83f3b204533822f52bf3e52e32dfbe523798d2e594eaeab53aa8fc723", "attachments_count": 0}, "event_type": "REPORT_GENERATED", "recorded_at": "2026-05-22T15:56:25.655732+00:00"}, {"content": {"decision": "PENDING", "report_id": "d557a2ff-c9e5-4279-ad12-49a471009e3c", "pdf_sha256": "170807b5d3f9ff2788ae3a198d8c068bd3e18f21938d17fa34aa10119e46ab8f", "payload_sha256": "82b060af3c37d6dcbef678db025d0e38210844221753699dac1c6092fca3a2ec", "attachments_count": 0}, "event_type": "REPORT_GENERATED", "recorded_at": "2026-05-22T15:55:41.190768+00:00"}]}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:01:40.570335+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/55163958-bbfa-4913-af4a-92c6b8a95d09.pdf	FINAL	Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.	REPORT	\N	\N	\N	\N
14002954-c54f-4844-954c-7941c0cfe27a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1", "title": "E2E COAF Protocol 1779236929685", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:28:49.726126+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [1407], "involvement_types": [1], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Padrão identificado pelo motor de regras BetAML. Comunicado Siscoaf 97. Portaria SPA/MF 1.143/2024.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"1": "Titular"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "bfa2f26f-3d16-4c74-bd4a-8b18fcbe2dcb", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "bfa2f26f-3d16-4c74-bd4a-8b18fcbe2dcb", "caseNumber": "CASE-20260520-2D88FFD1", "attachments": [], "generatedAt": "2026-05-22T16:01:42.202965+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T16:01:42.202965+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/bfa2f26f-3d16-4c74-bd4a-8b18fcbe2dcb.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "8d87cd4d7a0bf24b5234f70d859cbb20e9ec4cc0c0333c5d68fc46d4ab23930f", "generated_at": "2026-05-22T16:01:42.202965+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "1cd9c70ed4c2e152587265f7bc275bf4eecb87792b3935ae6ef0462ff087cb32"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"decision": "FILE_SAR", "report_id": "762b1829-0386-49af-a7a9-f5c655965b0c", "pdf_sha256": "2e75ad3788bcbed8130a5d3fa343efa4f1866c6c84537bbea214deb7d6993c11", "payload_sha256": "76802436ea5e2ef0cac9f9635fd4547e2a7e8182ece371841facf490ed768f95", "attachments_count": 0}, "event_type": "REPORT_GENERATED", "recorded_at": "2026-05-22T15:56:26.349896+00:00"}, {"content": {"decision": "FILE_SAR", "report_id": "93c67528-0f08-4b22-ab86-b932c31c65b3", "pdf_sha256": "02b572d882a637aea86594e88efc06b98f12dffd3ee1f7dd368cd5793a967903", "payload_sha256": "77ac23543d7b395c86ddace087a15da4ec0914e02e3f06391a9c13b3a1d75291", "attachments_count": 0}, "event_type": "REPORT_GENERATED", "recorded_at": "2026-05-20T00:28:50.109829+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:49.986609+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:49.896581+00:00"}, {"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:49.812486+00:00"}]}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:01:42.179914+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/bfa2f26f-3d16-4c74-bd4a-8b18fcbe2dcb.pdf	FINAL	Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.	REPORT	\N	\N	\N	\N
01dcaf10-8c07-4727-bf9f-936823c36055	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	11dc8f67-7311-4647-85f0-8117406bc5d6	\N	{"case": {"id": "11dc8f67-7311-4647-85f0-8117406bc5d6", "title": "Caso COAF Test dffd7c", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-05-22T16:02:49.148235+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": null, "name": null, "pepFlag": false, "birthDate": null, "profession": null, "riskCategory": null, "registeredSince": null, "declaredIncomeMonthly": 0}, "decision": "MONITOR", "reportId": "d0cc410b-bc42-4e11-bc9e-ac757670e85e", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "d0cc410b-bc42-4e11-bc9e-ac757670e85e", "caseNumber": "CASE-20260522-11DC8F67", "attachments": [], "generatedAt": "2026-05-22T16:02:49.246685+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T16:02:49.246685+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "PENDING", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d0cc410b-bc42-4e11-bc9e-ac757670e85e.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "0276d62d12d56c2041f7648d2a0fda5eed55df6821cb49a80b8d867feb253bc8", "generated_at": "2026-05-22T16:02:49.246685+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "ee4ce66e56bc8e50c1b1b482008cc98d41676360c5a3af93130859ace2c52cf8"}, "financialSummary": {"unusualPatterns": [], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:49.221437+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/d0cc410b-bc42-4e11-bc9e-ac757670e85e.pdf	DRAFT	\N	MONITOR	\N	\N	\N	\N
2c09bf23-e969-4272-a03d-e094e47a3cce	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	3e32661a-e88d-41c7-b177-36c262195da1	\N	{"case": {"id": "3e32661a-e88d-41c7-b177-36c262195da1", "title": "Caso SAR fac7ea", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-05-22T16:02:49.383088+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [1420], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Deposits fracionados identificados pelo sistema BetAML em janela de 7 dias.", "occurrence_descriptions": {"1420": "Art. 25-XI — Fracionamento / dissimulação de operações"}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": null, "name": null, "pepFlag": false, "birthDate": null, "profession": null, "riskCategory": null, "registeredSince": null, "declaredIncomeMonthly": 0}, "decision": "REPORT", "reportId": "4916ab29-472a-4a7a-a712-826e850574ed", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "4916ab29-472a-4a7a-a712-826e850574ed", "caseNumber": "CASE-20260522-3E32661A", "attachments": [], "generatedAt": "2026-05-22T16:02:49.483047+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T16:02:49.483047+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Operações de depósito fracionado abaixo do limite obrigatório de comunicação, padrão típico de Structuring (COAF/FATF Tipologia ML-01). Recomenda-se comunicação ao COAF.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/4916ab29-472a-4a7a-a712-826e850574ed.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "fd4adf35e3fc4ad203f4a52ffa20f450639912de73a3df8993cef450e18ff16a", "generated_at": "2026-05-22T16:02:49.483047+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "9b282fa222c2d9b078d4cafcc30129ea273365b8d818f4a747ffe6933f7c4cef"}, "financialSummary": {"unusualPatterns": [], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Operações de depósito fracionado abaixo do limite obrigatório de comunicação, padrão típico de Structuring (COAF/FATF Tipologia ML-01). Recomenda-se comunicação ao COAF.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:49.453469+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/4916ab29-472a-4a7a-a712-826e850574ed.pdf	FINAL	Operações de depósito fracionado abaixo do limite obrigatório de comunicação, padrão típico de Structuring (COAF/FATF Tipologia ML-01). Recomenda-se comunicação ao COAF.	REPORT	\N	\N	\N	\N
39298c78-c827-4192-b20b-0374fdc0feeb	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	cf67acb2-a3f3-4384-aaa5-fac4c2067efe	\N	{"case": {"id": "cf67acb2-a3f3-4384-aaa5-fac4c2067efe", "title": "Caso CPF Mask Test", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-05-22T16:02:49.702581+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": null, "name": null, "pepFlag": false, "birthDate": null, "profession": null, "riskCategory": null, "registeredSince": null, "declaredIncomeMonthly": 0}, "decision": "MONITOR", "reportId": "758e0ec1-858d-4301-8a17-30a30f92c2d7", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "758e0ec1-858d-4301-8a17-30a30f92c2d7", "caseNumber": "CASE-20260522-CF67ACB2", "attachments": [], "generatedAt": "2026-05-22T16:02:49.794887+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T16:02:49.794887+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "PENDING", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/758e0ec1-858d-4301-8a17-30a30f92c2d7.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "ff5b796ceefce9a090779ba45eebd18ded2a3be85f076824570a5c34d5c6ee5a", "generated_at": "2026-05-22T16:02:49.794887+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "737302fc85df4ee7520e9a925f01ef4f6fd4b9b3de242c62ff7372d24c62f1a8"}, "financialSummary": {"unusualPatterns": [], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:49.778991+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/758e0ec1-858d-4301-8a17-30a30f92c2d7.pdf	DRAFT	\N	MONITOR	\N	\N	\N	\N
f66ea8ff-c929-4293-b83d-654ca41889cd	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	510078bd-3aab-411d-97f9-e22b883da667	\N	{"case": {"id": "510078bd-3aab-411d-97f9-e22b883da667", "title": "Caso Audit Test", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-05-22T16:02:51.285011+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [], "involvement_types": [49], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "", "occurrence_descriptions": {}, "involvement_descriptions": {"49": "Apostador"}}, "subject": {"cpf": null, "name": null, "pepFlag": false, "birthDate": null, "profession": null, "riskCategory": null, "registeredSince": null, "declaredIncomeMonthly": 0}, "decision": "MONITOR", "reportId": "90bee7c5-4947-4e8e-b653-61ea63b6a231", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "90bee7c5-4947-4e8e-b653-61ea63b6a231", "caseNumber": "CASE-20260522-510078BD", "attachments": [], "generatedAt": "2026-05-22T16:02:51.340491+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T16:02:51.340491+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "PENDING", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/90bee7c5-4947-4e8e-b653-61ea63b6a231.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "590426ca3c5123fff3bcccdfe878d714ccb35d64ad09e2cb087a7fe38df4017a", "generated_at": "2026-05-22T16:02:51.340491+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "1e2467448b661887631f764333e403602d03a523142203c354a52353c9bf5b36"}, "financialSummary": {"unusualPatterns": [], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": []}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:02:51.326609+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/90bee7c5-4947-4e8e-b653-61ea63b6a231.pdf	DRAFT	\N	MONITOR	\N	\N	\N	\N
afdff049-8919-40b1-99d2-95cdd31d98b6	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	510078bd-3aab-411d-97f9-e22b883da667	\N	{"case": {"id": "510078bd-3aab-411d-97f9-e22b883da667", "title": "Caso Audit Test", "status": "OPEN", "severity": "HIGH", "opened_at": "2026-05-22T16:02:51.285011+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [1407], "involvement_types": [1], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Padrão identificado pelo motor de regras BetAML. Comunicado Siscoaf 97. Portaria SPA/MF 1.143/2024.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"1": "Titular"}}, "subject": {"cpf": null, "name": null, "pepFlag": false, "birthDate": null, "profession": null, "riskCategory": null, "registeredSince": null, "declaredIncomeMonthly": 0}, "decision": "REPORT", "reportId": "49913c05-90e6-4550-b6cd-33cd2ff094a4", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "49913c05-90e6-4550-b6cd-33cd2ff094a4", "caseNumber": "CASE-20260522-510078BD", "attachments": [], "generatedAt": "2026-05-22T16:03:07.824996+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T16:03:07.824996+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/49913c05-90e6-4550-b6cd-33cd2ff094a4.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "061d2c33bcf75df8f6c3c0bab536e598f350cb18e96467825ed91115169af470", "generated_at": "2026-05-22T16:03:07.824996+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "f686a10f6943e5f2c265a231dbe79e7383a7b7b7ed9a1727613b18f9eda591a9"}, "financialSummary": {"unusualPatterns": [], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"decision": "PENDING", "report_id": "90bee7c5-4947-4e8e-b653-61ea63b6a231", "pdf_sha256": "590426ca3c5123fff3bcccdfe878d714ccb35d64ad09e2cb087a7fe38df4017a", "payload_sha256": "1e2467448b661887631f764333e403602d03a523142203c354a52353c9bf5b36", "attachments_count": 0}, "event_type": "REPORT_GENERATED", "recorded_at": "2026-05-22T16:02:51.326609+00:00"}]}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:03:07.809572+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/49913c05-90e6-4550-b6cd-33cd2ff094a4.pdf	FINAL	Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.	REPORT	\N	\N	\N	\N
f52f753f-1ebd-4da9-820d-0db97542dfbc	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1	dc662a23-33a0-4898-81c1-22fe4404f5c4	{"case": {"id": "2d88ffd1-98eb-4e2e-aaa1-ee8961793ee1", "title": "E2E COAF Protocol 1779236929685", "status": "CLOSED", "severity": "HIGH", "opened_at": "2026-05-20T00:28:49.726126+00:00"}, "keyBets": [], "siscoaf": {"valor_premio": 0.0, "valor_apostas": 0.0, "occurrence_codes": [1407], "involvement_types": [1], "comunicado_siscoaf": "97", "portaria_referencia": "SPA/MF 1.143/2024", "informacoes_adicionais": "Padrão identificado pelo motor de regras BetAML. Comunicado Siscoaf 97. Portaria SPA/MF 1.143/2024.", "occurrence_descriptions": {"1407": "Art. 24-I — Falta de fundamento econômico ou legal"}, "involvement_descriptions": {"1": "Titular"}}, "subject": {"cpf": "***.***.***.96", "name": "Player 3 OperadorA", "pepFlag": true, "birthDate": null, "profession": "Engineer", "riskCategory": "LOW", "registeredSince": null, "declaredIncomeMonthly": 20000.0}, "decision": "REPORT", "reportId": "0fb773aa-f428-466e-aac5-697e35372170", "tenantId": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "report_id": "0fb773aa-f428-466e-aac5-697e35372170", "caseNumber": "CASE-20260520-2D88FFD1", "attachments": [], "generatedAt": "2026-05-22T16:03:08.465592+00:00", "generatedBy": "admin_a (ADMIN)", "generated_at": "2026-05-22T16:03:08.465592+00:00", "generated_by": "a59dcbec-90f2-4427-bd34-c2359850fb9d", "alertsSummary": [], "decisionLegacy": "FILE_SAR", "decision_basis": "Análise conforme COAF Res. 36/2021 e regulamentação Bacen/MF", "schema_version": "2.0", "keyTransactions": [], "analystNarrative": "Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.", "chain_of_custody": {"pdf_path": "minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/0fb773aa-f428-466e-aac5-697e35372170.pdf", "hash_scope": "payload_excluding_chain_of_custody", "pdf_sha256": "5f626dd38ae79dd7bd49daeaa54ddd069846a744ec9e7ede3a541c755feedc1f", "generated_at": "2026-05-22T16:03:08.465592+00:00", "generated_by": "admin_a (ADMIN)", "attachments_count": 0, "attachments_sha256": [], "pdf_storage_backend": "minio", "report_payload_sha256": "e34eadc120ef1c5830bcc42d61e5384edc5c0b9560eb454c812bc9c2a73c2d12"}, "financialSummary": {"unusualPatterns": ["pep_player"], "totalBetStake90d": 0, "totalDeposits90d": 0, "primaryInstruments": [], "totalWithdrawals90d": 0}, "reporting_entity": {"platform": "BetAML", "tenant_id": "335bc3ac-6769-407d-ab8e-8a5d8955b1fd", "tenant_name": "OperadorA"}, "analyst_narrative": "Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.", "financial_summary": {"alert_types": [], "total_alerts": 0, "total_amount_brl": 0, "max_single_amount_brl": 0.0}, "suspicious_operations": [], "investigation_timeline": [{"content": {"decision": "FILE_SAR", "report_id": "bfa2f26f-3d16-4c74-bd4a-8b18fcbe2dcb", "pdf_sha256": "8d87cd4d7a0bf24b5234f70d859cbb20e9ec4cc0c0333c5d68fc46d4ab23930f", "payload_sha256": "1cd9c70ed4c2e152587265f7bc275bf4eecb87792b3935ae6ef0462ff087cb32", "attachments_count": 0}, "event_type": "REPORT_GENERATED", "recorded_at": "2026-05-22T16:01:42.179914+00:00"}, {"content": {"decision": "FILE_SAR", "report_id": "762b1829-0386-49af-a7a9-f5c655965b0c", "pdf_sha256": "2e75ad3788bcbed8130a5d3fa343efa4f1866c6c84537bbea214deb7d6993c11", "payload_sha256": "76802436ea5e2ef0cac9f9635fd4547e2a7e8182ece371841facf490ed768f95", "attachments_count": 0}, "event_type": "REPORT_GENERATED", "recorded_at": "2026-05-22T15:56:26.349896+00:00"}, {"content": {"decision": "FILE_SAR", "report_id": "93c67528-0f08-4b22-ab86-b932c31c65b3", "pdf_sha256": "02b572d882a637aea86594e88efc06b98f12dffd3ee1f7dd368cd5793a967903", "payload_sha256": "77ac23543d7b395c86ddace087a15da4ec0914e02e3f06391a9c13b3a1d75291", "attachments_count": 0}, "event_type": "REPORT_GENERATED", "recorded_at": "2026-05-20T00:28:50.109829+00:00"}, {"content": {"new_status": "CLOSED"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:49.986609+00:00"}, {"content": {"new_status": "PENDING_REVIEW"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:49.896581+00:00"}, {"content": {"new_status": "INVESTIGATING"}, "event_type": "STATUS_CHANGE", "recorded_at": "2026-05-20T00:28:49.812486+00:00"}]}	JSON	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-22 16:03:08.450139+00	minio://betaml-reports/reports/335bc3ac-6769-407d-ab8e-8a5d8955b1fd/0fb773aa-f428-466e-aac5-697e35372170.pdf	FINAL	Auditoria e2e pós-deploy — padrão suspeito detectado pelo ML.	REPORT	\N	\N	\N	\N
\.


--
-- Data for Name: rule_definitions; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.rule_definitions (id, tenant_id, name, description, status, severity, scope, condition_dsl, params, version, created_by, updated_by, created_at, updated_at, weight) FROM stdin;
ff4faf5e-9166-44e5-8626-f15a586a2b0a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Spike vs Baseline (Z-Score)	Depósito atual com z-score alto versus baseline do jogador	ACTIVE	HIGH	TRANSACTION	zscore(features.deposit_sum_24h, features.baseline_avg_daily_deposit, features.baseline_stddev_deposit) >= params.zscore_threshold and transaction.type == "DEPOSIT"	{"zscore_threshold": 3}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
265cc264-8c01-4aad-aa32-440a68239ac3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Structuring (Muitos depósitos pequenos 24h)	Múltiplos depósitos pequenos em 24h (fracionamento)	ACTIVE	HIGH	TRANSACTION	features.deposit_count_24h >= params.count_threshold and features.deposit_sum_24h >= params.sum_threshold and transaction.type == "DEPOSIT"	{"sum_threshold": 5000, "count_threshold": 5}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
5af6259c-22de-4c1b-bc0b-c94551dd244f	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Instrumento novo + valor alto	Uso de instrumento de pagamento nunca visto + valor elevado	ACTIVE	MEDIUM	TRANSACTION	features.new_payment_instrument_flag == true and transaction.amount >= params.amount_threshold	{"amount_threshold": 2000}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
c42cec14-854f-4fb7-b4b4-dac43cd0803b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	PEP com desvio alto	Jogador PEP com depósito acima do income declarado	ACTIVE	CRITICAL	TRANSACTION	player.pep_flag == true and transaction.amount >= params.pep_threshold	{"pep_threshold": 5000}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
6eab0d80-d4b1-4b05-a5b8-8871b8729aae	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Conta bancária compartilhada	Mesma conta bancária usada por múltiplos players	ACTIVE	HIGH	TRANSACTION	features.shared_bank_account_count >= params.shared_threshold	{"shared_threshold": 2}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
3d085a72-3ce0-4397-9d69-870cf5f0dda3	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Mesmo device em múltiplos CPFs	Mesmo dispositivo usado por múltiplos joueurs distintos	ACTIVE	HIGH	DEVICE_EVENT	features.shared_device_count >= params.device_threshold	{"device_threshold": 3}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
b6c3621b-f3e6-441b-8140-243acb14ed2a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Alta razão saque/depósito 7d	Razão entre saques e depósitos em 7d acima do threshold	ACTIVE	MEDIUM	TRANSACTION	ratio(features.withdrawal_sum_7d, features.deposit_sum_7d) >= params.ratio_threshold and features.deposit_sum_7d >= params.min_volume	{"min_volume": 1000, "ratio_threshold": "0.9"}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
e7235874-de70-4518-9dfe-23731d4b1843	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Spike de stake em apostas 7d	Stake de aposta muito acima da média histórica	ACTIVE	MEDIUM	BET	bet.stakeAmount >= params.stake_min and features.bet_stake_sum_7d >= params.volume_threshold	{"stake_min": 1000, "volume_threshold": 10000}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
edbdfd35-019c-4770-92af-740c6dcda2bd	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Chargebacks acima do normal	Múltiplos chargebacks em 30 dias	ACTIVE	HIGH	TRANSACTION	features.chargeback_count_30d >= params.cb_threshold and transaction.type == "CHARGEBACK"	{"cb_threshold": 2}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
4797378e-d256-41d4-b211-90d80905cb2e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Depósitos falhos + sucesso grande	Várias tentativas falhas seguidas de depósito bem-sucedido alto	ACTIVE	MEDIUM	TRANSACTION	features.failed_deposit_count_24h >= params.failed_threshold and transaction.amount >= params.amount_threshold and transaction.status == "SETTLED"	{"amount_threshold": 3000, "failed_threshold": 3}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
5bea9aca-74be-4283-8b83-5f63af3cb617	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Round-tripping (depósito → aposta mínima → saque)	Padrão de lavagem: depósito, aposta simbólica, saque rápido	ACTIVE	CRITICAL	TRANSACTION	transaction.type == "WITHDRAWAL" and ratio(features.withdrawal_sum_24h, features.deposit_sum_24h) >= params.round_trip_ratio and features.bet_stake_sum_24h <= params.max_stake	{"max_stake": 50, "round_trip_ratio": "0.8"}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
a6f51e74-18a7-4ded-b924-ce091bc91149	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Saque rápido após depósito	Saque alto realizado logo após depósito relevante no mesmo dia	ACTIVE	HIGH	TRANSACTION	transaction.type == "WITHDRAWAL" and features.deposit_sum_24h >= params.min_deposit and ratio(features.withdrawal_sum_24h, features.deposit_sum_24h) >= params.ratio_threshold	{"min_deposit": 1000, "ratio_threshold": "0.7"}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
d77d5be7-7849-4dfc-8625-e92d71ab4146	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Incompatibilidade renda/volume 30d	Volume de depósitos nos últimos 30d incompatível com a renda mensal declarada (Res. COAF 40/2021 Art. 2 — indício de lavagem por volume atípico)	ACTIVE	HIGH	TRANSACTION	transaction.type == "DEPOSIT" and player.declared_income_monthly != null and features.income_ratio_30d >= params.ratio_threshold	{"ratio_threshold": 3.0}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
aaa01cb5-5731-43cc-9acd-e9ca5423bfea	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Alta frequência em slots (24h)	Volume anômalo de rodadas de slots em 24h — possível automação ou lavagem via jogos de baixo RTP	ACTIVE	MEDIUM	BET	bet.productType == "SLOT" and features.slot_session_count_24h >= params.threshold	{"threshold": 200}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
f324b491-18c2-42a1-bbf7-203f3f2ad14b	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Diversificação de produto suspeita (7d)	Jogador usando muitas modalidades distintas em 7d — possível dispersão para dificultar rastreamento	ACTIVE	MEDIUM	BET	features.bet_product_diversity_7d >= params.max_types	{"max_types": 4}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
ed481e83-35ad-435d-8283-5cad93a69658	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Casino chip washing	Padrão de lavagem em casino ao vivo: apostas mínimas + saque alto (chips → cash)	ACTIVE	HIGH	BET	bet.productType == "CASINO_LIVE" and features.casino_session_count_24h >= params.min_sessions and bet.stakeAmount <= params.max_stake	{"max_stake": 25, "min_sessions": 50}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
a2fb3750-c845-4ccf-9b6d-68724062c159	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Alta frequência em casino ao vivo (24h)	Volume anômalo de sessões de casino ao vivo em 24h	ACTIVE	MEDIUM	BET	bet.productType == "CASINO_LIVE" and features.casino_session_count_24h >= params.threshold	{"threshold": 150}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
941505b4-3e42-47a4-9ad1-39789ed52069	98c56b0f-fa44-47cd-a8d9-9479174e3140	Spike vs Baseline (Z-Score)	Depósito atual com z-score alto versus baseline do jogador	ACTIVE	HIGH	TRANSACTION	zscore(features.deposit_sum_24h, features.baseline_avg_daily_deposit, features.baseline_stddev_deposit) >= params.zscore_threshold and transaction.type == "DEPOSIT"	{"zscore_threshold": 3}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
f1f67fd5-6533-4ad3-97a3-ccaa5b36da1b	98c56b0f-fa44-47cd-a8d9-9479174e3140	Structuring (Muitos depósitos pequenos 24h)	Múltiplos depósitos pequenos em 24h (fracionamento)	ACTIVE	HIGH	TRANSACTION	features.deposit_count_24h >= params.count_threshold and features.deposit_sum_24h >= params.sum_threshold and transaction.type == "DEPOSIT"	{"sum_threshold": 5000, "count_threshold": 5}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
86ec55eb-54a6-4f16-b47b-cdd31cff0f27	98c56b0f-fa44-47cd-a8d9-9479174e3140	Instrumento novo + valor alto	Uso de instrumento de pagamento nunca visto + valor elevado	ACTIVE	MEDIUM	TRANSACTION	features.new_payment_instrument_flag == true and transaction.amount >= params.amount_threshold	{"amount_threshold": 2000}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
5af73c87-3b70-4b1b-be64-20bb34c95367	98c56b0f-fa44-47cd-a8d9-9479174e3140	PEP com desvio alto	Jogador PEP com depósito acima do income declarado	ACTIVE	CRITICAL	TRANSACTION	player.pep_flag == true and transaction.amount >= params.pep_threshold	{"pep_threshold": 5000}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
9503bec0-9192-40a0-85da-bbb951ab66d9	98c56b0f-fa44-47cd-a8d9-9479174e3140	Conta bancária compartilhada	Mesma conta bancária usada por múltiplos players	ACTIVE	HIGH	TRANSACTION	features.shared_bank_account_count >= params.shared_threshold	{"shared_threshold": 2}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
92aab73e-348e-4ac3-9e20-ca516b728a3b	98c56b0f-fa44-47cd-a8d9-9479174e3140	Mesmo device em múltiplos CPFs	Mesmo dispositivo usado por múltiplos joueurs distintos	ACTIVE	HIGH	DEVICE_EVENT	features.shared_device_count >= params.device_threshold	{"device_threshold": 3}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
6ee49720-4a41-415e-974a-f2cc2940894f	98c56b0f-fa44-47cd-a8d9-9479174e3140	Alta razão saque/depósito 7d	Razão entre saques e depósitos em 7d acima do threshold	ACTIVE	MEDIUM	TRANSACTION	ratio(features.withdrawal_sum_7d, features.deposit_sum_7d) >= params.ratio_threshold and features.deposit_sum_7d >= params.min_volume	{"min_volume": 1000, "ratio_threshold": "0.9"}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
b93b6112-32e8-4b72-ab5b-c72edf4a311f	98c56b0f-fa44-47cd-a8d9-9479174e3140	Spike de stake em apostas 7d	Stake de aposta muito acima da média histórica	ACTIVE	MEDIUM	BET	bet.stakeAmount >= params.stake_min and features.bet_stake_sum_7d >= params.volume_threshold	{"stake_min": 1000, "volume_threshold": 10000}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
e466f72e-94e0-4ff6-be59-5f193f08e6bc	98c56b0f-fa44-47cd-a8d9-9479174e3140	Chargebacks acima do normal	Múltiplos chargebacks em 30 dias	ACTIVE	HIGH	TRANSACTION	features.chargeback_count_30d >= params.cb_threshold and transaction.type == "CHARGEBACK"	{"cb_threshold": 2}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
33734419-6096-4c01-9ee0-247ff9591724	98c56b0f-fa44-47cd-a8d9-9479174e3140	Depósitos falhos + sucesso grande	Várias tentativas falhas seguidas de depósito bem-sucedido alto	ACTIVE	MEDIUM	TRANSACTION	features.failed_deposit_count_24h >= params.failed_threshold and transaction.amount >= params.amount_threshold and transaction.status == "SETTLED"	{"amount_threshold": 3000, "failed_threshold": 3}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
3781de8f-4c2c-4708-8723-1ae7b652ffdc	98c56b0f-fa44-47cd-a8d9-9479174e3140	Round-tripping (depósito → aposta mínima → saque)	Padrão de lavagem: depósito, aposta simbólica, saque rápido	ACTIVE	CRITICAL	TRANSACTION	transaction.type == "WITHDRAWAL" and ratio(features.withdrawal_sum_24h, features.deposit_sum_24h) >= params.round_trip_ratio and features.bet_stake_sum_24h <= params.max_stake	{"max_stake": 50, "round_trip_ratio": "0.8"}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
b4c76f07-0f9d-4702-9621-bc7cdace0345	98c56b0f-fa44-47cd-a8d9-9479174e3140	Saque rápido após depósito	Saque alto realizado logo após depósito relevante no mesmo dia	ACTIVE	HIGH	TRANSACTION	transaction.type == "WITHDRAWAL" and features.deposit_sum_24h >= params.min_deposit and ratio(features.withdrawal_sum_24h, features.deposit_sum_24h) >= params.ratio_threshold	{"min_deposit": 1000, "ratio_threshold": "0.7"}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
145b3392-9ae2-425d-bc79-da13e4b2eeb3	98c56b0f-fa44-47cd-a8d9-9479174e3140	Incompatibilidade renda/volume 30d	Volume de depósitos nos últimos 30d incompatível com a renda mensal declarada (Res. COAF 40/2021 Art. 2 — indício de lavagem por volume atípico)	ACTIVE	HIGH	TRANSACTION	transaction.type == "DEPOSIT" and player.declared_income_monthly != null and features.income_ratio_30d >= params.ratio_threshold	{"ratio_threshold": 3.0}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
c8261218-21b8-47f4-890f-0e344c3942f9	98c56b0f-fa44-47cd-a8d9-9479174e3140	Alta frequência em slots (24h)	Volume anômalo de rodadas de slots em 24h — possível automação ou lavagem via jogos de baixo RTP	ACTIVE	MEDIUM	BET	bet.productType == "SLOT" and features.slot_session_count_24h >= params.threshold	{"threshold": 200}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
64e02a85-448d-487b-8cfa-34ab84ccc0b5	98c56b0f-fa44-47cd-a8d9-9479174e3140	Diversificação de produto suspeita (7d)	Jogador usando muitas modalidades distintas em 7d — possível dispersão para dificultar rastreamento	ACTIVE	MEDIUM	BET	features.bet_product_diversity_7d >= params.max_types	{"max_types": 4}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
09bdac0a-63d0-456f-abfb-3b31599f6b9e	98c56b0f-fa44-47cd-a8d9-9479174e3140	Casino chip washing	Padrão de lavagem em casino ao vivo: apostas mínimas + saque alto (chips → cash)	ACTIVE	HIGH	BET	bet.productType == "CASINO_LIVE" and features.casino_session_count_24h >= params.min_sessions and bet.stakeAmount <= params.max_stake	{"max_stake": 25, "min_sessions": 50}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
f274eb4f-3483-40b7-825c-8cef197d656b	98c56b0f-fa44-47cd-a8d9-9479174e3140	Alta frequência em casino ao vivo (24h)	Volume anômalo de sessões de casino ao vivo em 24h	ACTIVE	MEDIUM	BET	bet.productType == "CASINO_LIVE" and features.casino_session_count_24h >= params.threshold	{"threshold": 150}	1	89a78d77-d61e-44d1-916c-c9fda278d0e9	\N	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.500
1c46bbbe-c80d-41c7-ae4c-152d913b7cb5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Regra Teste 8aff80	\N	ACTIVE	HIGH	TRANSACTION	transaction.amount > 9000 and transaction.type == 'DEPOSIT'	{}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-22 15:46:54.499961+00	2026-05-22 15:46:54.499961+00	0.500
9673cf76-936c-4998-a009-d30c29a4ee3e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Regra Teste 7d91c2	\N	ACTIVE	HIGH	TRANSACTION	transaction.amount > 9000 and transaction.type == 'DEPOSIT'	{}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-22 15:55:06.188971+00	2026-05-22 15:55:06.188971+00	0.500
42028baf-41a6-4090-abba-78fb297c42ac	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	Regra Teste 69e088	\N	ACTIVE	HIGH	TRANSACTION	transaction.amount > 9000 and transaction.type == 'DEPOSIT'	{}	1	a59dcbec-90f2-4427-bd34-c2359850fb9d	\N	2026-05-22 16:02:21.318774+00	2026-05-22 16:02:21.318774+00	0.500
\.


--
-- Data for Name: rule_execution_logs; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.rule_execution_logs (id, tenant_id, rule_id, rule_version, source_event_id, player_id, matched, evaluation_ms, context_snapshot, created_at) FROM stdin;
\.


--
-- Data for Name: rule_macros; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.rule_macros (id, tenant_id, name, body_dsl, description, created_by, created_at, updated_at) FROM stdin;
\.


--
-- Data for Name: scoring_configs; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.scoring_configs (id, tenant_id, rule_weight, ml_weight, network_weight, auto_case_threshold, sla_critical_hours, sla_high_hours, sla_medium_hours, sla_low_hours, ingest_rate_limit_tpm, data_retention_raw_years, data_retention_silver_years, data_retention_gold_years, updated_by, created_at, updated_at, risk_band_low_threshold, risk_band_high_threshold, income_volume_ratio_threshold, low_threshold, medium_threshold, high_threshold, critical_threshold, is_active, data_retention_days, ml_challenger_pct) FROM stdin;
c5541697-ef1b-4c4c-8024-866af180f1ff	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	0.400	0.400	0.200	0.7500	4	24	72	168	1000	5	5	3	a59dcbec-90f2-4427-bd34-c2359850fb9d	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	1825	0
89c10853-8080-4417-99db-5575328f2245	98c56b0f-fa44-47cd-a8d9-9479174e3140	0.400	0.400	0.200	0.7500	4	24	72	168	1000	5	5	3	89a78d77-d61e-44d1-916c-c9fda278d0e9	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	1825	0
b2029155-e883-4cf3-b7c5-2bf8e325aeeb	812a654a-3f32-4532-9bf6-5748ef933472	0.400	0.400	0.200	0.7500	4	24	72	168	1000	5	5	3	320a4ada-fb75-4ef7-9f51-9f0956c76ac2	2026-05-22 15:47:32.777289+00	2026-05-22 15:47:32.777289+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	730	0
29fddb6e-0df0-4fb7-996c-31e6b9f0c904	960eb25d-b7ff-49bb-983b-c980d18aea6e	0.400	0.400	0.200	0.7500	4	24	72	168	1000	5	5	3	c7b588f4-5f26-4df5-b8a7-d43544fd540f	2026-05-22 15:56:03.019484+00	2026-05-22 15:56:03.019484+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	730	0
ebaf6df7-8cc6-4d96-9df9-ef91eaaeaf3b	08589c68-4b20-4484-a1d7-86ff73a084e4	0.400	0.400	0.200	0.7500	4	24	72	168	1000	5	5	3	c769a70c-d627-4ee3-8546-b1201c72d597	2026-05-22 16:02:55.625658+00	2026-05-22 16:02:55.625658+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	730	0
511052b0-5a69-4a9b-929b-8e6464348746	b10f6774-339e-46ed-8385-8af37cac6b2e	0.400	0.400	0.200	0.7500	4	24	72	168	1000	5	5	3	bec3c909-8c9e-4da4-a904-cde314fe8602	2026-05-22 17:21:38.492062+00	2026-05-22 17:21:38.492062+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	730	0
02c9644e-4376-4a90-97e9-30b800f12ef8	9423e928-b354-4b58-a26d-6ea1cad11f37	0.400	0.400	0.200	0.7500	4	24	72	168	1000	5	5	3	4406b966-b71c-48ac-b3fc-8c4b4fccc274	2026-05-22 19:35:40.133825+00	2026-05-22 19:35:40.133825+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	730	0
c17971a3-0b62-429b-8883-c3b5221a835a	f19e18c1-272d-48bb-9c61-5dd767ffc99d	0.400	0.400	0.200	0.7500	4	24	72	168	1000	5	5	3	2d9eec84-c0e7-4e35-b6f7-74b08ffb5841	2026-05-22 19:38:12.90199+00	2026-05-22 19:38:12.90199+00	0.3500	0.7000	1.50	30.00	60.00	80.00	95.00	t	730	0
\.


--
-- Data for Name: system_flags; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.system_flags (key, value, updated_by, updated_at) FROM stdin;
maintenance_mode	false	\N	2026-05-19 23:48:08.591244+00
\.


--
-- Data for Name: tenants; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.tenants (id, name, slug, active, settings, risk_score_threshold, created_at, updated_at, cnpj, plan_tier) FROM stdin;
335bc3ac-6769-407d-ab8e-8a5d8955b1fd	OperadorA	operador_a	t	{}	0.75	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	standard
98c56b0f-fa44-47cd-a8d9-9479174e3140	OperadorB	operador_b	t	{}	0.75	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	standard
812a654a-3f32-4532-9bf6-5748ef933472	Test test-slug-dd0b2b12	test-slug-dd0b2b12	t	{}	0.75	2026-05-22 15:47:32.777289+00	2026-05-22 15:47:32.777289+00	\N	standard
960eb25d-b7ff-49bb-983b-c980d18aea6e	Test test-slug-c55a7f87	test-slug-c55a7f87	t	{}	0.75	2026-05-22 15:56:03.019484+00	2026-05-22 15:56:03.019484+00	\N	standard
08589c68-4b20-4484-a1d7-86ff73a084e4	Test test-slug-07c07e77	test-slug-07c07e77	t	{}	0.75	2026-05-22 16:02:55.625658+00	2026-05-22 16:02:55.625658+00	\N	standard
b10f6774-339e-46ed-8385-8af37cac6b2e	Test test-slug-826bbc1e	test-slug-826bbc1e	t	{}	0.75	2026-05-22 17:21:38.492062+00	2026-05-22 17:21:38.492062+00	\N	standard
9423e928-b354-4b58-a26d-6ea1cad11f37	Test test-slug-4a2d7f63	test-slug-4a2d7f63	t	{}	0.75	2026-05-22 19:35:40.133825+00	2026-05-22 19:35:40.133825+00	\N	standard
f19e18c1-272d-48bb-9c61-5dd767ffc99d	Test test-slug-ab4204aa	test-slug-ab4204aa	t	{}	0.75	2026-05-22 19:38:12.90199+00	2026-05-22 19:38:12.90199+00	\N	standard
\.


--
-- Data for Name: users; Type: TABLE DATA; Schema: public; Owner: betaml
--

COPY public.users (id, tenant_id, username, email, password_hash, role, active, created_at, updated_at, refresh_token_jti, roles) FROM stdin;
81d93242-e4fa-425d-a6af-bbcb9b5ac7b5	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	auditor_a	auditor_a@betaml.dev	$2b$12$KvtED18GclQ0br83z69tUOP5OPO540sms0tkvexdwsS8uGsVKEy0O	AUDITOR	t	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	[]
9a9f19fd-6f55-4f0e-bb46-b548a9288c9e	98c56b0f-fa44-47cd-a8d9-9479174e3140	auditor_b	auditor_b@betaml.dev	$2b$12$.HQPKvZvMSkGFG95XUtR/eUTzLt4I9v./IvQFYvlf4msvYKoBJc2m	AUDITOR	t	2026-05-19 23:57:44.872891+00	2026-05-19 23:57:44.872891+00	\N	[]
c769a70c-d627-4ee3-8546-b1201c72d597	08589c68-4b20-4484-a1d7-86ff73a084e4	u_test-s	test-slug-07c07e77@test.com	$2b$12$7H7TohaKuFzehj82z7YxQegCyL2saHFKjLxMYkYX4aMdpTIOY0LDG	ADMIN	t	2026-05-22 16:02:55.625658+00	2026-05-22 16:02:55.625658+00	\N	[]
0a609ad1-9832-4f8f-88a8-f878b6bb1d8a	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	gap7_0218a4e0	gap7_0218a4e0@test.com	$2b$12$Xa0Nsp1rcHqd7kvvWVFT6OzZi3hK0gCTip6UEGgNdAO49pgjv43mi	AML_ANALYST	f	2026-05-22 15:54:46.227646+00	2026-05-22 15:54:46.620662+00	\N	["Operador_Analista"]
89a78d77-d61e-44d1-916c-c9fda278d0e9	98c56b0f-fa44-47cd-a8d9-9479174e3140	admin_b	admin_b@betaml.dev	$2b$12$YGgYvxgAq6mTl5JVNxe0iefloeEIf4GG6M.qko94cEEUHFlRxGxzO	ADMIN	t	2026-05-19 23:57:44.872891+00	2026-05-22 16:03:09.031027+00	dae34c5a-811d-4164-8991-f7c6256f8dbd	[]
bec3c909-8c9e-4da4-a904-cde314fe8602	b10f6774-339e-46ed-8385-8af37cac6b2e	u_test-s	test-slug-826bbc1e@test.com	$2b$12$gAOvQuTAKe.5rTTzadmtDu3qBDaHvF4VQSLaYbX4844Dfv1iB2cJC	ADMIN	t	2026-05-22 17:21:38.492062+00	2026-05-22 17:21:38.492062+00	\N	[]
a59dcbec-90f2-4427-bd34-c2359850fb9d	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	admin_a	admin_a@betaml.dev	$2b$12$.JgKH7u3IiPBLIwJ2EduEOEi/ZOKNqtXYmwG6FiNLHdR4SFQv6x/e	ADMIN	t	2026-05-19 23:57:44.872891+00	2026-05-22 19:35:01.196463+00	04d14be2-9fd7-41e9-84f6-95e9621f64c2	[]
4406b966-b71c-48ac-b3fc-8c4b4fccc274	9423e928-b354-4b58-a26d-6ea1cad11f37	u_test-s	test-slug-4a2d7f63@test.com	$2b$12$wYcF8k/ybsCK9GXBL3CIxuGI5C/AsyxPm9uJQOKtf4HlMNAhPmqFO	ADMIN	t	2026-05-22 19:35:40.133825+00	2026-05-22 19:35:40.133825+00	\N	[]
47b184c7-360c-41ac-8676-f52b54c5e4a8	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	analyst_a	analyst_a@betaml.dev	$2b$12$F1yiPuzWfHym4yJAubjOBesFmt.XFD2QHYydBLQZ3dYRrfbSCjOcm	AML_ANALYST	t	2026-05-19 23:57:44.872891+00	2026-05-22 19:38:02.061118+00	3f8a3e7a-b5bf-490e-b0d5-712c457940c7	[]
82401e84-c8b3-4f97-9e02-7b8c27cc8c2a	98c56b0f-fa44-47cd-a8d9-9479174e3140	analyst_b	analyst_b@betaml.dev	$2b$12$4uodgpNf2HKC6mTqwg1oneuBiXXCGQQFqnJbHFwMm6n7EBuvROET.	AML_ANALYST	t	2026-05-19 23:57:44.872891+00	2026-05-22 19:38:03.637868+00	05b07bb6-a855-469e-b686-4da301d573e5	[]
9ae8cfe6-5d09-459d-8ec7-bd3807c8f653	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	superadmin	superadmin@betaml.dev	$2b$12$ghcM.2qUm4bT.WwkXjj3T.dMVkWlZ6uA1wAUavZy9CAyA/NDfrEt.	ADMIN	t	2026-05-19 23:57:44.872891+00	2026-05-22 19:38:11.248551+00	f9b27ea8-3902-4018-9f9b-6736d7d4de6c	["BetAML_SuperAdmin"]
2d9eec84-c0e7-4e35-b6f7-74b08ffb5841	f19e18c1-272d-48bb-9c61-5dd767ffc99d	u_test-s	test-slug-ab4204aa@test.com	$2b$12$j2ExnD1zE7Vd02La3FEbCunfxrBIDqy5LmrqiJ2PK5VXYw8fti8su	ADMIN	t	2026-05-22 19:38:12.90199+00	2026-05-22 19:38:12.90199+00	\N	[]
c7b588f4-5f26-4df5-b8a7-d43544fd540f	960eb25d-b7ff-49bb-983b-c980d18aea6e	u_test-s	test-slug-c55a7f87@test.com	$2b$12$yuts2f5NgHdDXIaFCeZlB.0SKZ.5DyOg2k.NVhjLQfyE5iNFenSCe	ADMIN	t	2026-05-22 15:56:03.019484+00	2026-05-22 15:56:03.019484+00	\N	[]
3fb10cdb-5eaa-4207-bd31-9b34f8f99c7e	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	gap7_fce8fecb	gap7_fce8fecb@test.com	$2b$12$oopgALgS5aYIIoqFpSJGOuxJ33EYer5Yi3sM13XdKN3x4b0BPa8d6	AML_ANALYST	f	2026-05-22 15:46:35.217129+00	2026-05-22 15:46:35.758389+00	\N	["Operador_Analista"]
bcfd0d18-07aa-4911-9159-eadf44d44757	335bc3ac-6769-407d-ab8e-8a5d8955b1fd	gap7_2ee1ea0d	gap7_2ee1ea0d@test.com	$2b$12$4kBdo1V9z8nk6YkGvErxC.b0NE89mXxBqK796yhgODOCly9SoBCBu	AML_ANALYST	f	2026-05-22 16:02:03.603925+00	2026-05-22 16:02:04.142044+00	\N	["Operador_Analista"]
320a4ada-fb75-4ef7-9f51-9f0956c76ac2	812a654a-3f32-4532-9bf6-5748ef933472	u_test-s	test-slug-dd0b2b12@test.com	$2b$12$SXk7..FHsSTnifB2vRK4te6SLsrA2kYCVdV9UbsU1rLzw4NwIuERG	ADMIN	t	2026-05-22 15:47:32.777289+00	2026-05-22 15:47:32.777289+00	\N	[]
\.


--
-- Name: alembic_version alembic_version_pkc; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.alembic_version
    ADD CONSTRAINT alembic_version_pkc PRIMARY KEY (version_num);


--
-- Name: alerts alerts_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_pkey PRIMARY KEY (id);


--
-- Name: api_keys api_keys_key_hash_key; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_key_hash_key UNIQUE (key_hash);


--
-- Name: api_keys api_keys_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_pkey PRIMARY KEY (id);


--
-- Name: audit_logs audit_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_pkey PRIMARY KEY (id);


--
-- Name: bets bets_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.bets
    ADD CONSTRAINT bets_pkey PRIMARY KEY (id);


--
-- Name: case_events case_events_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.case_events
    ADD CONSTRAINT case_events_pkey PRIMARY KEY (id);


--
-- Name: cases cases_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_pkey PRIMARY KEY (id);


--
-- Name: compound_rules compound_rules_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.compound_rules
    ADD CONSTRAINT compound_rules_pkey PRIMARY KEY (id);


--
-- Name: device_events device_events_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.device_events
    ADD CONSTRAINT device_events_pkey PRIMARY KEY (id);


--
-- Name: external_validation_requests external_validation_requests_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.external_validation_requests
    ADD CONSTRAINT external_validation_requests_pkey PRIMARY KEY (id);


--
-- Name: feature_snapshots feature_snapshots_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.feature_snapshots
    ADD CONSTRAINT feature_snapshots_pkey PRIMARY KEY (id);


--
-- Name: feature_snapshots feature_snapshots_tenant_id_player_id_feature_date_key; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.feature_snapshots
    ADD CONSTRAINT feature_snapshots_tenant_id_player_id_feature_date_key UNIQUE (tenant_id, player_id, feature_date);


--
-- Name: financial_transactions financial_transactions_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_pkey PRIMARY KEY (id);


--
-- Name: ingest_errors ingest_errors_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.ingest_errors
    ADD CONSTRAINT ingest_errors_pkey PRIMARY KEY (id);


--
-- Name: ingest_jobs ingest_jobs_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.ingest_jobs
    ADD CONSTRAINT ingest_jobs_pkey PRIMARY KEY (id);


--
-- Name: mapping_configs mapping_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.mapping_configs
    ADD CONSTRAINT mapping_configs_pkey PRIMARY KEY (id);


--
-- Name: model_inference_logs model_inference_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.model_inference_logs
    ADD CONSTRAINT model_inference_logs_pkey PRIMARY KEY (id);


--
-- Name: model_registry model_registry_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_pkey PRIMARY KEY (id);


--
-- Name: notifications notifications_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_pkey PRIMARY KEY (id);


--
-- Name: player_kyc_events player_kyc_events_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.player_kyc_events
    ADD CONSTRAINT player_kyc_events_pkey PRIMARY KEY (id);


--
-- Name: player_list_entries player_list_entries_list_id_cpf_hash_key; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_list_id_cpf_hash_key UNIQUE (list_id, cpf_hash);


--
-- Name: player_list_entries player_list_entries_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_pkey PRIMARY KEY (id);


--
-- Name: player_lists player_lists_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.player_lists
    ADD CONSTRAINT player_lists_pkey PRIMARY KEY (id);


--
-- Name: player_lists player_lists_tenant_id_name_key; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.player_lists
    ADD CONSTRAINT player_lists_tenant_id_name_key UNIQUE (tenant_id, name);


--
-- Name: players players_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_pkey PRIMARY KEY (id);


--
-- Name: players players_tenant_id_external_player_id_key; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_tenant_id_external_player_id_key UNIQUE (tenant_id, external_player_id);


--
-- Name: report_packages report_packages_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.report_packages
    ADD CONSTRAINT report_packages_pkey PRIMARY KEY (id);


--
-- Name: rule_definitions rule_definitions_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.rule_definitions
    ADD CONSTRAINT rule_definitions_pkey PRIMARY KEY (id);


--
-- Name: rule_execution_logs rule_execution_logs_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.rule_execution_logs
    ADD CONSTRAINT rule_execution_logs_pkey PRIMARY KEY (id);


--
-- Name: rule_macros rule_macros_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.rule_macros
    ADD CONSTRAINT rule_macros_pkey PRIMARY KEY (id);


--
-- Name: rule_macros rule_macros_tenant_id_name_key; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.rule_macros
    ADD CONSTRAINT rule_macros_tenant_id_name_key UNIQUE (tenant_id, name);


--
-- Name: scoring_configs scoring_configs_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.scoring_configs
    ADD CONSTRAINT scoring_configs_pkey PRIMARY KEY (id);


--
-- Name: scoring_configs scoring_configs_tenant_id_key; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.scoring_configs
    ADD CONSTRAINT scoring_configs_tenant_id_key UNIQUE (tenant_id);


--
-- Name: system_flags system_flags_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.system_flags
    ADD CONSTRAINT system_flags_pkey PRIMARY KEY (key);


--
-- Name: tenants tenants_name_key; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_name_key UNIQUE (name);


--
-- Name: tenants tenants_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_pkey PRIMARY KEY (id);


--
-- Name: tenants tenants_slug_key; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.tenants
    ADD CONSTRAINT tenants_slug_key UNIQUE (slug);


--
-- Name: users users_pkey; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_pkey PRIMARY KEY (id);


--
-- Name: users users_tenant_id_email_key; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_email_key UNIQUE (tenant_id, email);


--
-- Name: users users_tenant_id_username_key; Type: CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_username_key UNIQUE (tenant_id, username);


--
-- Name: idx_alerts_backfill_job; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_alerts_backfill_job ON public.alerts USING btree (tenant_id, backfill_job_id) WHERE (backfill_job_id IS NOT NULL);


--
-- Name: idx_alerts_case_id; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_alerts_case_id ON public.alerts USING btree (case_id) WHERE (case_id IS NOT NULL);


--
-- Name: idx_alerts_created; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_alerts_created ON public.alerts USING btree (created_at DESC);


--
-- Name: idx_alerts_ingest_mode; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_alerts_ingest_mode ON public.alerts USING btree (tenant_id, ingest_mode, created_at DESC);


--
-- Name: idx_alerts_player; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_alerts_player ON public.alerts USING btree (player_id);


--
-- Name: idx_alerts_tenant_label_created; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_alerts_tenant_label_created ON public.alerts USING btree (tenant_id, label, created_at) WHERE (label IS NOT NULL);


--
-- Name: idx_alerts_tenant_player; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_alerts_tenant_player ON public.alerts USING btree (tenant_id, player_id);


--
-- Name: idx_alerts_tenant_priority_sla; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_alerts_tenant_priority_sla ON public.alerts USING btree (tenant_id, priority, sla_due_at) WHERE (sla_due_at IS NOT NULL);


--
-- Name: idx_alerts_tenant_severity; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_alerts_tenant_severity ON public.alerts USING btree (tenant_id, severity);


--
-- Name: idx_alerts_tenant_status; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_alerts_tenant_status ON public.alerts USING btree (tenant_id, status);


--
-- Name: idx_alerts_tenant_status_created; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_alerts_tenant_status_created ON public.alerts USING btree (tenant_id, status, created_at DESC);


--
-- Name: idx_alerts_triage_note_not_null; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_alerts_triage_note_not_null ON public.alerts USING btree (triaged_at DESC) WHERE (triage_note IS NOT NULL);


--
-- Name: idx_alerts_triaged_by_status; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_alerts_triaged_by_status ON public.alerts USING btree (tenant_id, triaged_by, status) WHERE (triaged_by IS NOT NULL);


--
-- Name: idx_api_keys_hash; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_api_keys_hash ON public.api_keys USING btree (key_hash);


--
-- Name: idx_api_keys_tenant; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_api_keys_tenant ON public.api_keys USING btree (tenant_id);


--
-- Name: idx_audit_logs_pii_accessed; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_audit_logs_pii_accessed ON public.audit_logs USING btree (tenant_id, pii_accessed) WHERE (pii_accessed IS NOT NULL);


--
-- Name: idx_audit_logs_tenant; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_audit_logs_tenant ON public.audit_logs USING btree (tenant_id, created_at DESC);


--
-- Name: idx_audit_logs_tenant_created; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_audit_logs_tenant_created ON public.audit_logs USING btree (tenant_id, created_at DESC);


--
-- Name: idx_audit_logs_tenant_entity; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_audit_logs_tenant_entity ON public.audit_logs USING btree (tenant_id, entity_type);


--
-- Name: idx_audit_logs_tenant_user; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_audit_logs_tenant_user ON public.audit_logs USING btree (tenant_id, user_id);


--
-- Name: idx_bets_product_type; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_bets_product_type ON public.bets USING btree (product_type);


--
-- Name: idx_bets_tenant_occurred; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_bets_tenant_occurred ON public.bets USING btree (tenant_id, occurred_at DESC);


--
-- Name: idx_bets_tenant_player; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_bets_tenant_player ON public.bets USING btree (tenant_id, player_id);


--
-- Name: idx_bets_tenant_player_ts; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_bets_tenant_player_ts ON public.bets USING btree (tenant_id, player_id, occurred_at DESC);


--
-- Name: idx_bets_tenant_product; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_bets_tenant_product ON public.bets USING btree (tenant_id, product_type);


--
-- Name: idx_bets_tenant_settled; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_bets_tenant_settled ON public.bets USING btree (tenant_id, settled_at) WHERE (settled_at IS NOT NULL);


--
-- Name: idx_bets_tenant_status; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_bets_tenant_status ON public.bets USING btree (tenant_id, status);


--
-- Name: idx_case_events_case_type; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_case_events_case_type ON public.case_events USING btree (case_id, event_type, created_at DESC);


--
-- Name: INDEX idx_case_events_case_type; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON INDEX public.idx_case_events_case_type IS 'Module 5 — case timeline: events by case + type + time';


--
-- Name: idx_cases_auto_created; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_cases_auto_created ON public.cases USING btree (tenant_id, auto_created);


--
-- Name: idx_cases_backfill_job; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_cases_backfill_job ON public.cases USING btree (tenant_id, backfill_job_id) WHERE (backfill_job_id IS NOT NULL);


--
-- Name: idx_cases_open_player; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_cases_open_player ON public.cases USING btree (tenant_id, player_id, status, created_at DESC) WHERE (status = ANY (ARRAY['OPEN'::text, 'IN_REVIEW'::text, 'INVESTIGATING'::text, 'PENDING_REVIEW'::text]));


--
-- Name: idx_cases_player; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_cases_player ON public.cases USING btree (player_id);


--
-- Name: idx_cases_sla; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_cases_sla ON public.cases USING btree (tenant_id, sla_due_at) WHERE (status <> ALL (ARRAY['CLOSED'::text, 'CLOSED_SAR'::text, 'CLOSED_SAT'::text]));


--
-- Name: idx_cases_sla_active; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_cases_sla_active ON public.cases USING btree (tenant_id, sla_due_at, status) WHERE ((status <> ALL (ARRAY['CLOSED'::text, 'REPORTED'::text])) AND (sla_due_at IS NOT NULL));


--
-- Name: INDEX idx_cases_sla_active; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON INDEX public.idx_cases_sla_active IS 'Module 5 — SLA dashboard: active cases sorted by deadline';


--
-- Name: idx_cases_sla_due; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_cases_sla_due ON public.cases USING btree (tenant_id, sla_due_at) WHERE (status <> ALL (ARRAY['CLOSED'::text, 'REPORTED'::text, 'ARCHIVED'::text]));


--
-- Name: idx_cases_tenant_assigned; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_cases_tenant_assigned ON public.cases USING btree (tenant_id, assigned_to) WHERE (assigned_to IS NOT NULL);


--
-- Name: idx_cases_tenant_priority; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_cases_tenant_priority ON public.cases USING btree (tenant_id, priority);


--
-- Name: idx_cases_tenant_status; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_cases_tenant_status ON public.cases USING btree (tenant_id, status);


--
-- Name: idx_cases_tenant_status_sla; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_cases_tenant_status_sla ON public.cases USING btree (tenant_id, status, sla_due_at DESC NULLS LAST);


--
-- Name: idx_compound_rules_active; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_compound_rules_active ON public.compound_rules USING btree (tenant_id, is_active);


--
-- Name: idx_compound_rules_tenant; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_compound_rules_tenant ON public.compound_rules USING btree (tenant_id, is_active);


--
-- Name: idx_dev_tenant_device; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_dev_tenant_device ON public.device_events USING btree (tenant_id, device_hash) WHERE (device_hash IS NOT NULL);


--
-- Name: idx_dev_tenant_ip; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_dev_tenant_ip ON public.device_events USING btree (tenant_id, ip_hash) WHERE (ip_hash IS NOT NULL);


--
-- Name: idx_dev_tenant_occurred; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_dev_tenant_occurred ON public.device_events USING btree (tenant_id, occurred_at DESC);


--
-- Name: idx_dev_tenant_player; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_dev_tenant_player ON public.device_events USING btree (tenant_id, player_id);


--
-- Name: idx_device_events_device_hash; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_device_events_device_hash ON public.device_events USING btree (tenant_id, device_hash, player_id) WHERE (device_hash IS NOT NULL);


--
-- Name: idx_device_events_ip_hash; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_device_events_ip_hash ON public.device_events USING btree (tenant_id, ip_hash, player_id) WHERE (ip_hash IS NOT NULL);


--
-- Name: idx_ext_validation_idempotency_lookup; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ext_validation_idempotency_lookup ON public.external_validation_requests USING btree (tenant_id, player_id, provider, validation_type, requested_at);


--
-- Name: idx_ext_validation_status_requested_at; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ext_validation_status_requested_at ON public.external_validation_requests USING btree (status, requested_at);


--
-- Name: idx_feature_snapshots_player; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_feature_snapshots_player ON public.feature_snapshots USING btree (player_id, feature_date DESC);


--
-- Name: idx_feature_snapshots_tenant_created; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_feature_snapshots_tenant_created ON public.feature_snapshots USING btree (tenant_id, created_at);


--
-- Name: idx_feature_snapshots_tenant_player_date; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_feature_snapshots_tenant_player_date ON public.feature_snapshots USING btree (tenant_id, player_id, snapshot_date DESC NULLS LAST);


--
-- Name: idx_feature_snapshots_tenant_player_snapshot_date; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_feature_snapshots_tenant_player_snapshot_date ON public.feature_snapshots USING btree (tenant_id, player_id, snapshot_date DESC);


--
-- Name: idx_feature_snapshots_version; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_feature_snapshots_version ON public.feature_snapshots USING btree (tenant_id, player_id, feature_version);


--
-- Name: idx_financial_transactions_bank_account_hash; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_financial_transactions_bank_account_hash ON public.financial_transactions USING btree (tenant_id, bank_account_hash, player_id) WHERE (bank_account_hash IS NOT NULL);


--
-- Name: idx_financial_transactions_payment_instrument; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_financial_transactions_payment_instrument ON public.financial_transactions USING btree (tenant_id, payment_instrument, player_id) WHERE (payment_instrument IS NOT NULL);


--
-- Name: idx_financial_transactions_tenant_player_ts; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_financial_transactions_tenant_player_ts ON public.financial_transactions USING btree (tenant_id, player_id, occurred_at DESC);


--
-- Name: idx_financial_transactions_tenant_status; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_financial_transactions_tenant_status ON public.financial_transactions USING btree (tenant_id, status);


--
-- Name: idx_financial_transactions_tenant_type; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_financial_transactions_tenant_type ON public.financial_transactions USING btree (tenant_id, type);


--
-- Name: idx_ft_bank_hash; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ft_bank_hash ON public.financial_transactions USING btree (bank_account_hash) WHERE (bank_account_hash IS NOT NULL);


--
-- Name: idx_ft_instrument; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ft_instrument ON public.financial_transactions USING btree (payment_instrument) WHERE (payment_instrument IS NOT NULL);


--
-- Name: idx_ft_tenant_occurred; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ft_tenant_occurred ON public.financial_transactions USING btree (tenant_id, occurred_at DESC);


--
-- Name: idx_ft_tenant_player; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ft_tenant_player ON public.financial_transactions USING btree (tenant_id, player_id);


--
-- Name: idx_ft_tenant_type_status; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ft_tenant_type_status ON public.financial_transactions USING btree (tenant_id, type, status);


--
-- Name: idx_ingest_errors_job; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ingest_errors_job ON public.ingest_errors USING btree (ingest_job_id);


--
-- Name: idx_ingest_errors_tenant; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ingest_errors_tenant ON public.ingest_errors USING btree (tenant_id, resolved);


--
-- Name: idx_ingest_errors_tenant_created; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ingest_errors_tenant_created ON public.ingest_errors USING btree (tenant_id, created_at);


--
-- Name: idx_ingest_errors_tenant_job; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ingest_errors_tenant_job ON public.ingest_errors USING btree (tenant_id, ingest_job_id);


--
-- Name: idx_ingest_errors_tenant_resolved; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ingest_errors_tenant_resolved ON public.ingest_errors USING btree (tenant_id, resolved) WHERE (resolved = false);


--
-- Name: idx_ingest_jobs_ingest_mode; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ingest_jobs_ingest_mode ON public.ingest_jobs USING btree (tenant_id, ingest_mode, created_at DESC);


--
-- Name: idx_ingest_jobs_tenant; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ingest_jobs_tenant ON public.ingest_jobs USING btree (tenant_id, status);


--
-- Name: idx_ingest_jobs_tenant_source; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ingest_jobs_tenant_source ON public.ingest_jobs USING btree (tenant_id, source_system);


--
-- Name: idx_ingest_jobs_tenant_status_created; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_ingest_jobs_tenant_status_created ON public.ingest_jobs USING btree (tenant_id, status, created_at DESC);


--
-- Name: idx_model_inference_model; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_model_inference_model ON public.model_inference_logs USING btree (tenant_id, model_id, scored_at DESC);


--
-- Name: idx_model_inference_tenant_time; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_model_inference_tenant_time ON public.model_inference_logs USING btree (tenant_id, scored_at DESC);


--
-- Name: idx_model_inference_variant; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_model_inference_variant ON public.model_inference_logs USING btree (tenant_id, model_variant, scored_at DESC);


--
-- Name: idx_model_registry_active; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_model_registry_active ON public.model_registry USING btree (tenant_id, is_active, algorithm);


--
-- Name: idx_model_registry_tenant; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_model_registry_tenant ON public.model_registry USING btree (tenant_id, status);


--
-- Name: idx_notifications_reference; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_notifications_reference ON public.notifications USING btree (reference_type, reference_id) WHERE (reference_type IS NOT NULL);


--
-- Name: idx_notifications_tenant_read_created; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_notifications_tenant_read_created ON public.notifications USING btree (tenant_id, is_read, created_at DESC);


--
-- Name: idx_notifications_unread; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_notifications_unread ON public.notifications USING btree (user_id) WHERE (read = false);


--
-- Name: idx_notifications_user; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_notifications_user ON public.notifications USING btree (user_id, is_read, created_at DESC);


--
-- Name: idx_notifications_user_unread; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_notifications_user_unread ON public.notifications USING btree (user_id, is_read, created_at DESC) WHERE (is_read = false);


--
-- Name: INDEX idx_notifications_user_unread; Type: COMMENT; Schema: public; Owner: betaml
--

COMMENT ON INDEX public.idx_notifications_user_unread IS 'Module 5 — notification bell: unread count per user';


--
-- Name: idx_pkyc_backfill; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_pkyc_backfill ON public.player_kyc_events USING btree (tenant_id, backfill_job_id) WHERE (backfill_job_id IS NOT NULL);


--
-- Name: idx_pkyc_player; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_pkyc_player ON public.player_kyc_events USING btree (tenant_id, player_id, occurred_at DESC);


--
-- Name: idx_pkyc_subtype; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_pkyc_subtype ON public.player_kyc_events USING btree (tenant_id, entity_type, subtype, occurred_at DESC);


--
-- Name: idx_player_kyc_events_tenant_player_created; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_player_kyc_events_tenant_player_created ON public.player_kyc_events USING btree (tenant_id, player_id, created_at DESC);


--
-- Name: idx_player_list_entries_cpf; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_player_list_entries_cpf ON public.player_list_entries USING btree (cpf_hash);


--
-- Name: idx_player_list_entries_list; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_player_list_entries_list ON public.player_list_entries USING btree (list_id);


--
-- Name: idx_player_list_entries_unique_val; Type: INDEX; Schema: public; Owner: betaml
--

CREATE UNIQUE INDEX idx_player_list_entries_unique_val ON public.player_list_entries USING btree (list_id, value) WHERE (value IS NOT NULL);


--
-- Name: idx_player_list_entries_val; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_player_list_entries_val ON public.player_list_entries USING btree (tenant_id, value);


--
-- Name: idx_player_lists_tenant; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_player_lists_tenant ON public.player_lists USING btree (tenant_id, list_type);


--
-- Name: idx_players_cluster_id; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_players_cluster_id ON public.players USING btree (tenant_id, cluster_id) WHERE (cluster_id IS NOT NULL);


--
-- Name: idx_players_risk_band; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_players_risk_band ON public.players USING btree (tenant_id, risk_band);


--
-- Name: idx_players_risk_score; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_players_risk_score ON public.players USING btree (tenant_id, risk_score DESC);


--
-- Name: idx_players_status_not_erased; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_players_status_not_erased ON public.players USING btree (tenant_id, status) WHERE (status <> 'ERASED'::text);


--
-- Name: idx_players_tenant; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_players_tenant ON public.players USING btree (tenant_id, external_player_id);


--
-- Name: idx_players_tenant_cpf; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_players_tenant_cpf ON public.players USING btree (tenant_id, cpf_encrypted);


--
-- Name: idx_players_tenant_cpf_hmac; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_players_tenant_cpf_hmac ON public.players USING btree (tenant_id, cpf_hmac) WHERE (cpf_hmac IS NOT NULL);


--
-- Name: idx_players_tenant_customer_id; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_players_tenant_customer_id ON public.players USING btree (tenant_id, external_player_id);


--
-- Name: idx_players_tenant_risk_score; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_players_tenant_risk_score ON public.players USING btree (tenant_id, risk_score DESC NULLS LAST);


--
-- Name: idx_players_tenant_status; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_players_tenant_status ON public.players USING btree (tenant_id, status);


--
-- Name: idx_report_packages_case; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_report_packages_case ON public.report_packages USING btree (case_id);


--
-- Name: idx_report_packages_tenant; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_report_packages_tenant ON public.report_packages USING btree (tenant_id, created_at DESC);


--
-- Name: idx_report_packages_tenant_status_created; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_report_packages_tenant_status_created ON public.report_packages USING btree (tenant_id, status, created_at);


--
-- Name: idx_rule_definitions_tenant_active; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_rule_definitions_tenant_active ON public.rule_definitions USING btree (tenant_id, status) WHERE (status = 'ACTIVE'::text);


--
-- Name: idx_rule_exec_tenant_event; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_rule_exec_tenant_event ON public.rule_execution_logs USING btree (tenant_id, source_event_id);


--
-- Name: idx_scoring_config_tenant; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_scoring_config_tenant ON public.scoring_configs USING btree (tenant_id);


--
-- Name: idx_users_refresh_token_jti; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_users_refresh_token_jti ON public.users USING btree (refresh_token_jti);


--
-- Name: idx_users_roles; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX idx_users_roles ON public.users USING gin (roles);


--
-- Name: ix_external_validation_requests_player_id; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX ix_external_validation_requests_player_id ON public.external_validation_requests USING btree (player_id);


--
-- Name: ix_external_validation_requests_tenant_id; Type: INDEX; Schema: public; Owner: betaml
--

CREATE INDEX ix_external_validation_requests_tenant_id ON public.external_validation_requests USING btree (tenant_id);


--
-- Name: uq_feature_snapshots_tenant_player_date; Type: INDEX; Schema: public; Owner: betaml
--

CREATE UNIQUE INDEX uq_feature_snapshots_tenant_player_date ON public.feature_snapshots USING btree (tenant_id, player_id, feature_date);


--
-- Name: audit_logs trg_prevent_audit_log_update_delete; Type: TRIGGER; Schema: public; Owner: betaml
--

CREATE TRIGGER trg_prevent_audit_log_update_delete BEFORE DELETE OR UPDATE ON public.audit_logs FOR EACH ROW EXECUTE FUNCTION public.prevent_audit_log_mutation();


--
-- Name: alerts alerts_compound_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_compound_rule_id_fkey FOREIGN KEY (compound_rule_id) REFERENCES public.compound_rules(id);


--
-- Name: alerts alerts_labeled_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_labeled_by_fkey FOREIGN KEY (labeled_by) REFERENCES public.users(id);


--
-- Name: alerts alerts_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: alerts alerts_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.rule_definitions(id);


--
-- Name: alerts alerts_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: alerts alerts_triaged_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT alerts_triaged_by_fkey FOREIGN KEY (triaged_by) REFERENCES public.users(id);


--
-- Name: api_keys api_keys_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: api_keys api_keys_revoked_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_revoked_by_fkey FOREIGN KEY (revoked_by) REFERENCES public.users(id);


--
-- Name: api_keys api_keys_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.api_keys
    ADD CONSTRAINT api_keys_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: audit_logs audit_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: audit_logs audit_logs_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.audit_logs
    ADD CONSTRAINT audit_logs_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id);


--
-- Name: bets bets_ingest_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.bets
    ADD CONSTRAINT bets_ingest_job_id_fkey FOREIGN KEY (ingest_job_id) REFERENCES public.ingest_jobs(id) ON DELETE SET NULL;


--
-- Name: bets bets_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.bets
    ADD CONSTRAINT bets_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE SET NULL;


--
-- Name: bets bets_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.bets
    ADD CONSTRAINT bets_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: case_events case_events_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.case_events
    ADD CONSTRAINT case_events_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE CASCADE;


--
-- Name: case_events case_events_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.case_events
    ADD CONSTRAINT case_events_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: case_events case_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.case_events
    ADD CONSTRAINT case_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: cases cases_assigned_to_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_assigned_to_fkey FOREIGN KEY (assigned_to) REFERENCES public.users(id);


--
-- Name: cases cases_closed_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_closed_by_fkey FOREIGN KEY (closed_by) REFERENCES public.users(id);


--
-- Name: cases cases_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: cases cases_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: cases cases_source_alert_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_source_alert_id_fkey FOREIGN KEY (source_alert_id) REFERENCES public.alerts(id);


--
-- Name: cases cases_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.cases
    ADD CONSTRAINT cases_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: compound_rules compound_rules_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.compound_rules
    ADD CONSTRAINT compound_rules_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: compound_rules compound_rules_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.compound_rules
    ADD CONSTRAINT compound_rules_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: compound_rules compound_rules_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.compound_rules
    ADD CONSTRAINT compound_rules_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: device_events device_events_ingest_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.device_events
    ADD CONSTRAINT device_events_ingest_job_id_fkey FOREIGN KEY (ingest_job_id) REFERENCES public.ingest_jobs(id) ON DELETE SET NULL;


--
-- Name: device_events device_events_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.device_events
    ADD CONSTRAINT device_events_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE SET NULL;


--
-- Name: device_events device_events_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.device_events
    ADD CONSTRAINT device_events_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: feature_snapshots feature_snapshots_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.feature_snapshots
    ADD CONSTRAINT feature_snapshots_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE CASCADE;


--
-- Name: feature_snapshots feature_snapshots_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.feature_snapshots
    ADD CONSTRAINT feature_snapshots_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: financial_transactions financial_transactions_ingest_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_ingest_job_id_fkey FOREIGN KEY (ingest_job_id) REFERENCES public.ingest_jobs(id) ON DELETE SET NULL;


--
-- Name: financial_transactions financial_transactions_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE SET NULL;


--
-- Name: financial_transactions financial_transactions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.financial_transactions
    ADD CONSTRAINT financial_transactions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: alerts fk_alerts_case; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.alerts
    ADD CONSTRAINT fk_alerts_case FOREIGN KEY (case_id) REFERENCES public.cases(id) ON DELETE SET NULL;


--
-- Name: ingest_errors ingest_errors_ingest_job_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.ingest_errors
    ADD CONSTRAINT ingest_errors_ingest_job_id_fkey FOREIGN KEY (ingest_job_id) REFERENCES public.ingest_jobs(id) ON DELETE SET NULL;


--
-- Name: ingest_errors ingest_errors_resolved_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.ingest_errors
    ADD CONSTRAINT ingest_errors_resolved_by_fkey FOREIGN KEY (resolved_by) REFERENCES public.users(id);


--
-- Name: ingest_errors ingest_errors_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.ingest_errors
    ADD CONSTRAINT ingest_errors_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: ingest_jobs ingest_jobs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.ingest_jobs
    ADD CONSTRAINT ingest_jobs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: ingest_jobs ingest_jobs_mapping_config_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.ingest_jobs
    ADD CONSTRAINT ingest_jobs_mapping_config_id_fkey FOREIGN KEY (mapping_config_id) REFERENCES public.mapping_configs(id);


--
-- Name: ingest_jobs ingest_jobs_mapping_version_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.ingest_jobs
    ADD CONSTRAINT ingest_jobs_mapping_version_id_fkey FOREIGN KEY (mapping_version_id) REFERENCES public.mapping_configs(id);


--
-- Name: ingest_jobs ingest_jobs_reprocessed_from_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.ingest_jobs
    ADD CONSTRAINT ingest_jobs_reprocessed_from_fkey FOREIGN KEY (reprocessed_from) REFERENCES public.ingest_jobs(id);


--
-- Name: ingest_jobs ingest_jobs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.ingest_jobs
    ADD CONSTRAINT ingest_jobs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: mapping_configs mapping_configs_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.mapping_configs
    ADD CONSTRAINT mapping_configs_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: mapping_configs mapping_configs_parent_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.mapping_configs
    ADD CONSTRAINT mapping_configs_parent_id_fkey FOREIGN KEY (parent_id) REFERENCES public.mapping_configs(id);


--
-- Name: mapping_configs mapping_configs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.mapping_configs
    ADD CONSTRAINT mapping_configs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: model_inference_logs model_inference_logs_model_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.model_inference_logs
    ADD CONSTRAINT model_inference_logs_model_id_fkey FOREIGN KEY (model_id) REFERENCES public.model_registry(id) ON DELETE SET NULL;


--
-- Name: model_inference_logs model_inference_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.model_inference_logs
    ADD CONSTRAINT model_inference_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: model_registry model_registry_champion_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_champion_id_fkey FOREIGN KEY (champion_id) REFERENCES public.model_registry(id);


--
-- Name: model_registry model_registry_promoted_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_promoted_by_fkey FOREIGN KEY (promoted_by) REFERENCES public.users(id);


--
-- Name: model_registry model_registry_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.model_registry
    ADD CONSTRAINT model_registry_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: notifications notifications_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: notifications notifications_user_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.notifications
    ADD CONSTRAINT notifications_user_id_fkey FOREIGN KEY (user_id) REFERENCES public.users(id) ON DELETE CASCADE;


--
-- Name: player_list_entries player_list_entries_added_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_added_by_fkey FOREIGN KEY (added_by) REFERENCES public.users(id);


--
-- Name: player_list_entries player_list_entries_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_list_id_fkey FOREIGN KEY (list_id) REFERENCES public.player_lists(id) ON DELETE CASCADE;


--
-- Name: player_list_entries player_list_entries_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id) ON DELETE SET NULL;


--
-- Name: player_list_entries player_list_entries_player_list_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_player_list_id_fkey FOREIGN KEY (player_list_id) REFERENCES public.player_lists(id) ON DELETE CASCADE;


--
-- Name: player_list_entries player_list_entries_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.player_list_entries
    ADD CONSTRAINT player_list_entries_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: player_lists player_lists_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.player_lists
    ADD CONSTRAINT player_lists_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: player_lists player_lists_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.player_lists
    ADD CONSTRAINT player_lists_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: player_lists player_lists_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.player_lists
    ADD CONSTRAINT player_lists_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: players players_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.players
    ADD CONSTRAINT players_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: report_packages report_packages_case_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.report_packages
    ADD CONSTRAINT report_packages_case_id_fkey FOREIGN KEY (case_id) REFERENCES public.cases(id);


--
-- Name: report_packages report_packages_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.report_packages
    ADD CONSTRAINT report_packages_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: report_packages report_packages_player_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.report_packages
    ADD CONSTRAINT report_packages_player_id_fkey FOREIGN KEY (player_id) REFERENCES public.players(id);


--
-- Name: report_packages report_packages_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.report_packages
    ADD CONSTRAINT report_packages_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: rule_definitions rule_definitions_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.rule_definitions
    ADD CONSTRAINT rule_definitions_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: rule_definitions rule_definitions_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.rule_definitions
    ADD CONSTRAINT rule_definitions_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: rule_definitions rule_definitions_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.rule_definitions
    ADD CONSTRAINT rule_definitions_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: rule_execution_logs rule_execution_logs_rule_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.rule_execution_logs
    ADD CONSTRAINT rule_execution_logs_rule_id_fkey FOREIGN KEY (rule_id) REFERENCES public.rule_definitions(id);


--
-- Name: rule_execution_logs rule_execution_logs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.rule_execution_logs
    ADD CONSTRAINT rule_execution_logs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id);


--
-- Name: rule_macros rule_macros_created_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.rule_macros
    ADD CONSTRAINT rule_macros_created_by_fkey FOREIGN KEY (created_by) REFERENCES public.users(id);


--
-- Name: rule_macros rule_macros_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.rule_macros
    ADD CONSTRAINT rule_macros_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: scoring_configs scoring_configs_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.scoring_configs
    ADD CONSTRAINT scoring_configs_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: scoring_configs scoring_configs_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.scoring_configs
    ADD CONSTRAINT scoring_configs_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: system_flags system_flags_updated_by_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.system_flags
    ADD CONSTRAINT system_flags_updated_by_fkey FOREIGN KEY (updated_by) REFERENCES public.users(id);


--
-- Name: users users_tenant_id_fkey; Type: FK CONSTRAINT; Schema: public; Owner: betaml
--

ALTER TABLE ONLY public.users
    ADD CONSTRAINT users_tenant_id_fkey FOREIGN KEY (tenant_id) REFERENCES public.tenants(id) ON DELETE CASCADE;


--
-- Name: alerts; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.alerts ENABLE ROW LEVEL SECURITY;

--
-- Name: alerts alerts_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY alerts_tenant_isolation ON public.alerts USING ((tenant_id = public.current_tenant_id()));


--
-- Name: api_keys; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.api_keys ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.audit_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: audit_logs audit_logs_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY audit_logs_tenant_isolation ON public.audit_logs USING ((tenant_id = public.current_tenant_id()));


--
-- Name: bets; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.bets ENABLE ROW LEVEL SECURITY;

--
-- Name: case_events; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.case_events ENABLE ROW LEVEL SECURITY;

--
-- Name: case_events case_events_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY case_events_tenant_isolation ON public.case_events USING ((tenant_id = public.current_tenant_id()));


--
-- Name: cases; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.cases ENABLE ROW LEVEL SECURITY;

--
-- Name: cases cases_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY cases_tenant_isolation ON public.cases USING ((tenant_id = public.current_tenant_id()));


--
-- Name: compound_rules; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.compound_rules ENABLE ROW LEVEL SECURITY;

--
-- Name: compound_rules compound_rules_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY compound_rules_tenant_isolation ON public.compound_rules USING ((tenant_id = public.current_tenant_id()));


--
-- Name: device_events; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.device_events ENABLE ROW LEVEL SECURITY;

--
-- Name: external_validation_requests; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.external_validation_requests ENABLE ROW LEVEL SECURITY;

--
-- Name: feature_snapshots; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.feature_snapshots ENABLE ROW LEVEL SECURITY;

--
-- Name: feature_snapshots feature_snapshots_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY feature_snapshots_tenant_isolation ON public.feature_snapshots USING ((tenant_id = public.current_tenant_id()));


--
-- Name: financial_transactions; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.financial_transactions ENABLE ROW LEVEL SECURITY;

--
-- Name: ingest_errors; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.ingest_errors ENABLE ROW LEVEL SECURITY;

--
-- Name: ingest_jobs; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.ingest_jobs ENABLE ROW LEVEL SECURITY;

--
-- Name: ingest_jobs ingest_jobs_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY ingest_jobs_tenant_isolation ON public.ingest_jobs USING ((tenant_id = public.current_tenant_id()));


--
-- Name: mapping_configs; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.mapping_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: mapping_configs mapping_configs_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY mapping_configs_tenant_isolation ON public.mapping_configs USING ((tenant_id = public.current_tenant_id()));


--
-- Name: model_inference_logs; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.model_inference_logs ENABLE ROW LEVEL SECURITY;

--
-- Name: model_registry; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.model_registry ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.notifications ENABLE ROW LEVEL SECURITY;

--
-- Name: notifications notifications_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY notifications_tenant_isolation ON public.notifications USING ((tenant_id = public.current_tenant_id()));


--
-- Name: player_list_entries; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.player_list_entries ENABLE ROW LEVEL SECURITY;

--
-- Name: player_list_entries player_list_entries_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY player_list_entries_tenant_isolation ON public.player_list_entries USING ((tenant_id = public.current_tenant_id()));


--
-- Name: player_lists; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.player_lists ENABLE ROW LEVEL SECURITY;

--
-- Name: player_lists player_lists_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY player_lists_tenant_isolation ON public.player_lists USING ((tenant_id = public.current_tenant_id()));


--
-- Name: players; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.players ENABLE ROW LEVEL SECURITY;

--
-- Name: players players_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY players_tenant_isolation ON public.players USING ((tenant_id = public.current_tenant_id()));


--
-- Name: report_packages; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.report_packages ENABLE ROW LEVEL SECURITY;

--
-- Name: report_packages report_packages_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY report_packages_tenant_isolation ON public.report_packages USING ((tenant_id = public.current_tenant_id()));


--
-- Name: rule_definitions; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.rule_definitions ENABLE ROW LEVEL SECURITY;

--
-- Name: rule_definitions rules_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY rules_tenant_isolation ON public.rule_definitions USING ((tenant_id = public.current_tenant_id()));


--
-- Name: scoring_configs; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.scoring_configs ENABLE ROW LEVEL SECURITY;

--
-- Name: scoring_configs scoring_configs_tenant_isolation; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY scoring_configs_tenant_isolation ON public.scoring_configs USING ((tenant_id = public.current_tenant_id()));


--
-- Name: alerts tenant_isolation_alerts; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_alerts ON public.alerts USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: api_keys tenant_isolation_api_keys; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_api_keys ON public.api_keys USING ((tenant_id = public.current_tenant_id()));


--
-- Name: audit_logs tenant_isolation_audit_logs; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_audit_logs ON public.audit_logs USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: bets tenant_isolation_bets; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_bets ON public.bets USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: case_events tenant_isolation_case_events; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_case_events ON public.case_events USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: cases tenant_isolation_cases; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_cases ON public.cases USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: device_events tenant_isolation_device_events; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_device_events ON public.device_events USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: external_validation_requests tenant_isolation_external_validation_requests; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_external_validation_requests ON public.external_validation_requests USING ((tenant_id = public.current_tenant_id()));


--
-- Name: financial_transactions tenant_isolation_financial_transactions; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_financial_transactions ON public.financial_transactions USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: ingest_errors tenant_isolation_ingest_errors; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_ingest_errors ON public.ingest_errors USING ((tenant_id = public.current_tenant_id()));


--
-- Name: ingest_jobs tenant_isolation_ingest_jobs; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_ingest_jobs ON public.ingest_jobs USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: model_inference_logs tenant_isolation_model_inference_logs; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_model_inference_logs ON public.model_inference_logs USING ((tenant_id = public.current_tenant_id()));


--
-- Name: model_registry tenant_isolation_model_registry; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_model_registry ON public.model_registry USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: notifications tenant_isolation_notifications; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_notifications ON public.notifications USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: players tenant_isolation_players; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_players ON public.players USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: report_packages tenant_isolation_report_packages; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_report_packages ON public.report_packages USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: rule_definitions tenant_isolation_rule_definitions; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_rule_definitions ON public.rule_definitions USING (((tenant_id)::text = current_setting('app.current_tenant'::text, true)));


--
-- Name: tenants tenant_isolation_tenants_delete; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_tenants_delete ON public.tenants FOR DELETE USING ((id = public.current_tenant_id()));


--
-- Name: tenants tenant_isolation_tenants_insert; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_tenants_insert ON public.tenants FOR INSERT WITH CHECK (((id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenants tenant_isolation_tenants_select; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_tenants_select ON public.tenants FOR SELECT USING (((id = public.current_tenant_id()) OR (public.current_tenant_id() IS NULL)));


--
-- Name: tenants tenant_isolation_tenants_update; Type: POLICY; Schema: public; Owner: betaml
--

CREATE POLICY tenant_isolation_tenants_update ON public.tenants FOR UPDATE USING ((id = public.current_tenant_id()));


--
-- Name: tenants; Type: ROW SECURITY; Schema: public; Owner: betaml
--

ALTER TABLE public.tenants ENABLE ROW LEVEL SECURITY;

--
-- Name: SCHEMA public; Type: ACL; Schema: -; Owner: pg_database_owner
--

GRANT USAGE ON SCHEMA public TO betaml_app;


--
-- Name: TABLE alembic_version; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.alembic_version TO betaml_app;


--
-- Name: TABLE alerts; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.alerts TO betaml_app;


--
-- Name: TABLE api_keys; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.api_keys TO betaml_app;


--
-- Name: TABLE audit_logs; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.audit_logs TO betaml_app;


--
-- Name: TABLE bets; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.bets TO betaml_app;


--
-- Name: TABLE case_events; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.case_events TO betaml_app;


--
-- Name: TABLE cases; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.cases TO betaml_app;


--
-- Name: TABLE compound_rules; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.compound_rules TO betaml_app;


--
-- Name: TABLE device_events; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.device_events TO betaml_app;


--
-- Name: TABLE external_validation_requests; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.external_validation_requests TO betaml_app;


--
-- Name: TABLE feature_snapshots; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.feature_snapshots TO betaml_app;


--
-- Name: TABLE financial_transactions; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.financial_transactions TO betaml_app;


--
-- Name: TABLE ingest_errors; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ingest_errors TO betaml_app;


--
-- Name: TABLE ingest_jobs; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.ingest_jobs TO betaml_app;


--
-- Name: TABLE mapping_configs; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.mapping_configs TO betaml_app;


--
-- Name: TABLE model_inference_logs; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.model_inference_logs TO betaml_app;


--
-- Name: TABLE model_registry; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.model_registry TO betaml_app;


--
-- Name: TABLE notifications; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.notifications TO betaml_app;


--
-- Name: TABLE player_kyc_events; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.player_kyc_events TO betaml_app;


--
-- Name: TABLE player_list_entries; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.player_list_entries TO betaml_app;


--
-- Name: TABLE player_lists; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.player_lists TO betaml_app;


--
-- Name: TABLE players; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.players TO betaml_app;


--
-- Name: TABLE report_packages; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.report_packages TO betaml_app;


--
-- Name: TABLE rule_definitions; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.rule_definitions TO betaml_app;


--
-- Name: TABLE rule_execution_logs; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.rule_execution_logs TO betaml_app;


--
-- Name: TABLE rule_macros; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.rule_macros TO betaml_app;


--
-- Name: TABLE scoring_configs; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.scoring_configs TO betaml_app;


--
-- Name: TABLE system_flags; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.system_flags TO betaml_app;


--
-- Name: TABLE tenants; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.tenants TO betaml_app;


--
-- Name: TABLE users; Type: ACL; Schema: public; Owner: betaml
--

GRANT SELECT,INSERT,DELETE,UPDATE ON TABLE public.users TO betaml_app;


--
-- Name: DEFAULT PRIVILEGES FOR SEQUENCES; Type: DEFAULT ACL; Schema: public; Owner: betaml
--

ALTER DEFAULT PRIVILEGES FOR ROLE betaml IN SCHEMA public GRANT SELECT,USAGE ON SEQUENCES TO betaml_app;


--
-- Name: DEFAULT PRIVILEGES FOR TABLES; Type: DEFAULT ACL; Schema: public; Owner: betaml
--

ALTER DEFAULT PRIVILEGES FOR ROLE betaml IN SCHEMA public GRANT SELECT,INSERT,DELETE,UPDATE ON TABLES TO betaml_app;


--
-- PostgreSQL database dump complete
--

\unrestrict N5v3rYPncnYLJxIWdPnbA1xM8nKtHNLAjIaezEYy8ozLxqQDTTBIY65Oecq952C

